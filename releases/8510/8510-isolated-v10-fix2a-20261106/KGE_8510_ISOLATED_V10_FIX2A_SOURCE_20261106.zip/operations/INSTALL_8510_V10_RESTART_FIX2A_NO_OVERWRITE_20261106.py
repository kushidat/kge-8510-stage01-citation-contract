#!/usr/bin/env python3
"""No-overwrite installation of independent 8510 V10 restart FIX2A readiness runner.
Does not modify FIX2, FIX1, V10, active containers or production apps.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys

HERE=Path(__file__).resolve().parent
DEST=Path.home()/"projects/mondo_eval/release_records/8504_8510/isolated/8510_V10_RESTART_OWNER_FIX2A_HTTP_WAIT_20261106"
MANIFEST="MANIFEST_FIX2A_SHA256_SIZE.json"
FILES=["RESTART_8510_V10_SAFE_OWNER_FIX2A_20261106.py", "README_8510_V10_FIX2A_JA.md", "INSTALL_8510_V10_RESTART_FIX2A_NO_OVERWRITE_20261106.py", MANIFEST]
BASE=Path.home()/"projects/mondo_eval/release_records/8504_8510/isolated/8510_V10_RESTART_OWNER_FIX2_20261106/RESTART_8510_V10_SAFE_OWNER_FIX2_20261106.py"
BASE_SHA="9498bfd0a5326d976b189270a130efe35ba3def9bb7da4afcc9161e5304353ad"

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def check():
    if sha(BASE)!=BASE_SHA:
        raise RuntimeError("STOP_FIX2_PARENT_NOT_PINNED")
    info=json.loads((HERE/MANIFEST).read_text())
    if set(info)!=set(FILES)-{MANIFEST}:
        raise RuntimeError("STOP_FIX2A_MANIFEST_NAMES")
    for n in info:
        p=HERE/n
        if p.is_symlink() or not p.is_file() or p.stat().st_size!=info[n]['size'] or sha(p)!=info[n]['sha256']:
            raise RuntimeError("STOP_FIX2A_FILE_SHA_SIZE:"+n)
    print("FIX2A_SHA_SIZE_AND_PARENT_PINNED=PASS")
    return info

def verify():
    for n in FILES:
        p=DEST/n
        if p.is_symlink() or not p.is_file() or p.read_bytes()!=(HERE/n).read_bytes():
            raise RuntimeError("STOP_FIX2A_READBACK:"+n)
    print("FIX2A_INSTALLED_READBACK=PASS")


def main():
    a=argparse.ArgumentParser()
    g=a.add_mutually_exclusive_group(required=True)
    for opt in ("check","install","verify"):
        g.add_argument("--"+opt,action="store_true")
    args=a.parse_args()
    check()
    print("DEST="+str(DEST))
    if args.verify:
        verify()
        print("VERIFY_ONLY_WRITES=0")
        return
    if DEST.is_symlink() or DEST.exists():
        raise RuntimeError("STOP_DEST_ALREADY_EXISTS_USE_VERIFY")
    if args.check:
        print("CHECK_ONLY_WRITES=0")
        return
    # Only the newly named isolated directory is eligible for creation.
    DEST.parent.mkdir(parents=True, exist_ok=True)
    DEST.mkdir(mode=0o755)
    try:
        for n in FILES:
            fd=os.open(DEST/n,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o644)
            with os.fdopen(fd,"wb") as f:
                f.write((HERE/n).read_bytes())
        verify()
        print("NO_OVERWRITE=YES; OLD_V10_FIX1_FIX2_UNCHANGED=YES")
    except BaseException:
        # Do not delete any pre-existing user files: check our own just-created directory.
        import shutil
        shutil.rmtree(DEST)
        raise

if __name__=='__main__':
    try:
        main()
    except Exception as e:
        print("FIX2A_INSTALL_STOP:"+str(e)[:300],file=sys.stderr)
        sys.exit(2)
