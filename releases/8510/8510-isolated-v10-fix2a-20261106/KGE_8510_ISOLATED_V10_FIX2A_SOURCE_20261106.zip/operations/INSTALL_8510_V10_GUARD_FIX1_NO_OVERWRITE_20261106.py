#!/usr/bin/env python3
"""Install a separate, pinned V10 launcher hotfix without altering V10 sources."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, sys
HERE=Path(__file__).resolve().parent
BASE=Path.home()/"projects/mondo_eval/release_records/8504_8510/isolated"
DEST=BASE/"8510_V10_STARTUP_GUARD_FIX1_20261106"
V10=BASE/"8510_SOURCE_PROVENANCE_SECONDARY_MGI_ISOLATED_V10_20261106"
ORIGINAL="START_8510_BRC_AUTHORITY_V10_NO_BIND_20261106.py"
ORIG_SHA="0ec32c283f049329a7e843f49904980a26a4197e4dabb5d03d864c4172c1791d"
MANIFEST="MANIFEST_FIX1_SHA256_SIZE.json"
INSTALLER="INSTALL_8510_V10_GUARD_FIX1_NO_OVERWRITE_20261106.py"

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate_source():
    p=V10/ORIGINAL
    if not p.is_file() or p.is_symlink() or digest(p)!=ORIG_SHA:
        raise RuntimeError("STOP_PINNED_V10_ORIGINAL_MISSING_OR_CHANGED")
    print("PINNED_V10_ORIGINAL_LAUNCHER_SHA=PASS")
def pkg():
    m=json.loads((HERE/MANIFEST).read_text())
    for name,r in m.items():
        if name.startswith('/') or '..' in Path(name).parts:raise RuntimeError("STOP_INVALID_NAME")
        p=HERE/name
        if p.is_symlink() or not p.is_file() or p.stat().st_size!=r['size'] or digest(p)!=r['sha256']:
            raise RuntimeError("STOP_PACKAGE_SHA_SIZE:"+name)
    print("FIX1_PACKAGE_SHA_SIZE=PASS")
    return m

def verify(m):
    if DEST.is_symlink() or not DEST.is_dir():raise RuntimeError("STOP_DEST_NOT_DIRECTORY")
    for name,r in m.items():
        p=DEST/name
        if p.is_symlink() or not p.is_file() or p.stat().st_size!=r['size'] or digest(p)!=r['sha256']:
            raise RuntimeError("STOP_INSTALLED_SHA_SIZE:"+name)
    for name in (INSTALLER,MANIFEST):
        if (DEST/name).is_symlink() or (DEST/name).read_bytes()!=(HERE/name).read_bytes():
            raise RuntimeError("STOP_INSTALLED_CONTROL_MISMATCH:"+name)
    print("FIX1_INSTALLED_READBACK=PASS")
    print("DEST="+str(DEST))

def install(m):
    if DEST.exists() or DEST.is_symlink():raise RuntimeError("STOP_DEST_EXISTS_NO_OVERWRITE")
    BASE.mkdir(parents=True,exist_ok=True)
    DEST.mkdir(mode=0o755)
    try:
        for name in list(m)+[INSTALLER,MANIFEST]:
            p=DEST/name
            fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o644)
            with os.fdopen(fd,'wb') as f:f.write((HERE/name).read_bytes())
        verify(m)
        print("NO_OVERWRITE=YES; V10_ORIGINALS_UNCHANGED=YES")
    except BaseException:
        shutil.rmtree(DEST)
        raise

def main():
    ap=argparse.ArgumentParser();g=ap.add_mutually_exclusive_group(required=True)
    for x in ('check','install','verify'):g.add_argument('--'+x,action='store_true')
    args=ap.parse_args();m=pkg();validate_source()
    if args.verify:verify(m);print("VERIFY_ONLY_WRITES=0");return
    if DEST.exists() or DEST.is_symlink():raise RuntimeError("STOP_ALREADY_INSTALLED_USE_VERIFY")
    print("DEST="+str(DEST))
    if args.check:print("CHECK_ONLY_WRITES=0");return
    install(m)
if __name__=='__main__':
    try:main()
    except Exception as e:print("INSTALL_STOP: "+str(e)[:350],file=sys.stderr);sys.exit(2)
