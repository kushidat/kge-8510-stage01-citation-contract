#!/usr/bin/env python3
"""Read-only preflight / isolated Docker run of 8510 generic LLM biology V10.

A separate container on 18520. Does NOT modify existing 8501/8504/formal8510,
or the previous 18511,18512,18513 isolated candidates. No host bind mounts.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.request

NAME='kgllm-8510-generic-llm-biology-v10'
FORMAL='kgllm-mouse-model-search-gpt6luna-staging'
PORT=18520
FORMAL_SHA='aa533ae78d2c2412461c0e35c0aca7bf035386607afa5adba4678cc459bf2cf1'
HERE=Path.home()/"projects/mondo_eval/release_records/8504_8510/isolated/8510_SOURCE_PROVENANCE_SECONDARY_MGI_ISOLATED_V10_20261106"
ORIGINAL_LAUNCHER_SHA256="0ec32c283f049329a7e843f49904980a26a4197e4dabb5d03d864c4172c1791d"
FILES={
 'streamlit_app_8510_generic_llm_v10.py':'/app/streamlit_app_8510_generic_llm_v10.py',
 'manual_8504_intake_v10.py':'/app/manual_8504_intake_v10.py',
 'citation_integrity_v10.py':'/app/citation_integrity_v10.py',
 'public_biology_lookup_v10_pipeline.py':'/app/public_biology_lookup_v10_pipeline.py',
 'public_mondo_label_v10.py':'/app/public_mondo_label_v10.py',
 'public_mgi_marker_phenotype_v10.py':'/app/public_mgi_marker_phenotype_v10.py',
 'public_stock_identity_v09.py':'/app/public_stock_identity_v09.py',
 'source_role_v09.py':'/app/source_role_v09.py',
 'public_biology_lookup_v09.py':'/app/public_biology_lookup_v09.py',
 'public_allele_evidence_v05.py':'/app/public_allele_evidence_v05.py',
 'public_mgi_report_chain_v09.py':'/app/public_mgi_report_chain_v09.py',
 'MGI_REPORT_FIX1_NO_LLM_20261106.py':'/app/MGI_REPORT_FIX1_NO_LLM_20261106.py',
 'MGI_GENOTYPE_REPORT_FIX2_NO_LLM_20261106.py':'/app/MGI_GENOTYPE_REPORT_FIX2_NO_LLM_20261106.py',
}

def run(*argv):
    return subprocess.run(argv,capture_output=True,text=True,check=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest():
    original=HERE/'START_8510_BRC_AUTHORITY_V10_NO_BIND_20261106.py'
    if not original.is_file() or original.is_symlink() or sha(original)!=ORIGINAL_LAUNCHER_SHA256:
        raise RuntimeError('STOP_V10_ORIGINAL_LAUNCHER_SHA_MISMATCH')
    m=json.loads((HERE/'MANIFEST_SHA256_SIZE.json').read_text())
    for name in FILES:
        src=HERE/name
        if not src.is_file() or src.is_symlink() or src.stat().st_size != m[name]['size'] or sha(src)!=m[name]['sha256']:
            raise RuntimeError('STOP_SOURCE_SHA_MISMATCH: '+name)
    return m

def inspect(name):
    p=run('docker','inspect',name)
    if p.returncode:return None
    try:return json.loads(p.stdout)[0]
    except (IndexError,ValueError,TypeError):raise RuntimeError('STOP_INSPECT_INVALID_JSON')

def check():
    if not shutil.which('docker'):raise RuntimeError('STOP_DOCKER_CLI_UNAVAILABLE')
    manifest()
    formal=inspect(FORMAL)
    if not formal or not formal.get('State',{}).get('Running'):
        raise RuntimeError('STOP_FORMAL_8510_NOT_RUNNING')
    image=formal.get('Config',{}).get('Image')
    if not image:raise RuntimeError('STOP_FORMAL_IMAGE_MISSING')
    q=run('docker','exec',FORMAL,'sha256sum','/app/streamlit_app.py')
    if q.returncode or FORMAL_SHA not in q.stdout:
        raise RuntimeError('STOP_FORMAL_8510_SHA_MISMATCH: '+q.stderr[:160])
    if inspect(NAME) is not None:
        raise RuntimeError('STOP_V10_CONTAINER_EXISTS: use --status, not repeated --start')
    with socket.socket() as sock:
        if sock.connect_ex(('127.0.0.1',PORT))==0:raise RuntimeError('STOP_PORT_18520_BUSY')
    print('PACKAGE_SOURCE_SHA=PASS')
    print('FORMAL_8510_SHA=PASS')
    print('NO_HOST_BIND=YES')
    print('EXISTING_CONTAINERS_UNCHANGED=YES')
    print('REAL_PROVIDER_CALLS=0')
    return image

def env_path():
    private=HERE/'private_runtime'
    if private.exists():
        if private.is_symlink() or not private.is_dir() or private.stat().st_mode & 0o077:
            raise RuntimeError('STOP_PRIVATE_RUNTIME_INSECURE')
    else:private.mkdir(mode=0o700)
    path=private/'byok.env'
    if path.exists():
        if path.is_symlink() or not path.is_file() or path.stat().st_mode & 0o077:
            raise RuntimeError('STOP_PRIVATE_ENV_INSECURE')
        return path
    secret=base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('ascii')
    fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,'w') as fh:
        fh.write('APP_USER_ID=8510_id_resolver_v10_operator\n')
        fh.write('KEY_ENCRYPTION_SECRET='+secret+'\n')
        fh.write('ALLOW_SERVER_OPENAI_KEY=false\n')
        fh.write('LLM_KEY_MODE=user_encrypted\n')
        fh.write('OPENAI_KEY_STORE_PATH=/secrets/openai_keys/openai_keys.sqlite3\n')
        fh.write('APP_BASE_DIR=/tmp\n')
    return path

def start(image):
    env=env_path()
    dest=FILES['streamlit_app_8510_generic_llm_v10.py']
    command=['docker','create','--name',NAME,'--network','bridge',
       '--publish',f'127.0.0.1:{PORT}:8501','--env-file',str(env),
       '--tmpfs','/secrets/openai_keys:rw,noexec,nosuid,size=32m,mode=0700',
       '--entrypoint','python',image,'-m','streamlit','run',dest,
       '--server.address','0.0.0.0','--server.port','8501',
       '--server.headless','true','--browser.gatherUsageStats','false']
    p=run(*command)
    if p.returncode:raise RuntimeError('STOP_DOCKER_CREATE: '+p.stderr[:250])
    print('V10_CANDIDATE_CREATED=YES')
    for src,dst in FILES.items():
        p=run('docker','cp',str(HERE/src),NAME+':'+dst)
        if p.returncode:raise RuntimeError('STOP_DOCKER_CP: '+src+':'+p.stderr[:180])
    print('SOURCE_TRANSFER=DOCKER_CP_NO_BIND')
    p=run('docker','start',NAME)
    if p.returncode:raise RuntimeError('STOP_DOCKER_START: '+p.stderr[:250])
    paths=list(FILES.values())
    p=run('docker','exec','-u','0',NAME,'chmod','0644',*paths)
    if p.returncode:raise RuntimeError('STOP_RUNTIME_CHMOD: '+p.stderr[:180])
    uid=run('docker','exec',NAME,'id','-u');gid=run('docker','exec',NAME,'id','-g')
    if uid.returncode or gid.returncode or not uid.stdout.strip().isdigit() or not gid.stdout.strip().isdigit():
        raise RuntimeError('STOP_RUNTIME_USER_ID')
    p=run('docker','exec','-u','0',NAME,'chown',uid.stdout.strip()+':'+gid.stdout.strip(),'/secrets/openai_keys')
    if p.returncode:raise RuntimeError('STOP_BYOK_CHOWN: '+p.stderr[:250])
    p=run('docker','exec',NAME,'sha256sum',*paths)
    m=manifest()
    if p.returncode or any(m[src]['sha256'] not in p.stdout for src in FILES):
        raise RuntimeError('STOP_SOURCE_READBACK: rc='+str(p.returncode)+' stderr='+p.stderr[:250])
    p=run('docker','exec',NAME,'python','-c',
          'import os; assert os.access("/secrets/openai_keys",os.R_OK|os.W_OK|os.X_OK); '
          'assert os.access("/app/streamlit_app_8510_generic_llm_v10.py",os.R_OK); '
          'assert os.access("/app/manual_8504_intake_v10.py",os.R_OK); '
          'assert os.access("/app/public_biology_lookup_v10_pipeline.py",os.R_OK); '
          'assert os.access("/app/public_biology_lookup_v09.py",os.R_OK); '
          'assert os.access("/app/public_mgi_marker_phenotype_v10.py",os.R_OK); '
          'assert os.access("/app/public_mondo_label_v10.py",os.R_OK); '
          'assert os.access("/app/citation_integrity_v10.py",os.R_OK); '
          'assert os.access("/app/public_allele_evidence_v05.py",os.R_OK); print("APP_AND_BYOK_READ_WRITE=PASS")')
    if p.returncode or 'APP_AND_BYOK_READ_WRITE=PASS' not in p.stdout:
        raise RuntimeError('STOP_RUNTIME_PERMISSIONS: '+p.stderr[:200])
    internal_health=False
    for _ in range(24):
        q=run('docker','exec',NAME,'python','-c',
              'import urllib.request; assert urllib.request.urlopen('
              '"http://127.0.0.1:8501/_stcore/health",timeout=2).status==200; '
              'print("INTERNAL_STREAMLIT_HEALTH=200")')
        if q.returncode==0 and 'INTERNAL_STREAMLIT_HEALTH=200' in q.stdout:
            internal_health=True;break
        time.sleep(.5)
    host_health=False
    try:
        with urllib.request.urlopen('http://127.0.0.1:'+str(PORT)+'/_stcore/health',timeout=2) as x:
            host_health=(x.status==200)
    except (OSError,TimeoutError):pass
    print('RUNTIME_SOURCE_AND_BYOK_PERMISSIONS=PASS')
    print('STREAMLIT_INTERNAL_HEALTH='+('PASS' if internal_health else 'NOT_VERIFIED'))
    print('MAC_HOST_HTTP_HEALTH='+('PASS' if host_health else 'NOT_VERIFIED_COLIMA_FORWARD'))
    print('URL=http://127.0.0.1:'+str(PORT))
    print('REAL_PROVIDER_CALLS=0')
    if not internal_health:raise RuntimeError('STOP_INTERNAL_HEALTH_UNVERIFIED: preserve container, inspect logs read-only')

def verify_running_readonly():
    # This diagnostic intentionally has no create/cp/start/stop/restart calls.
    m=manifest()
    state=inspect(NAME)
    if not state or not state.get('State',{}).get('Running'):
        raise RuntimeError('STOP_V10_CONTAINER_NOT_RUNNING')
    actual_ports=state.get('NetworkSettings',{}).get('Ports',{})
    print('V10_CANDIDATE_RUNNING=YES')
    paths=list(FILES.values())
    q=run('docker','exec',NAME,'sha256sum',*paths)
    if q.returncode:raise RuntimeError('STOP_RUNTIME_HASH_READ:'+q.stderr[:200])
    actual={}
    for line in q.stdout.splitlines():
        chunks=line.strip().split(maxsplit=1)
        if len(chunks)!=2:raise RuntimeError('STOP_RUNTIME_HASH_PARSE')
        digest,path=chunks
        if path.startswith('*'):path=path[1:]
        if path in actual:raise RuntimeError('STOP_RUNTIME_DUPLICATE_HASH_PATH')
        actual[path]=digest
    expected={dest:m[src]['sha256'] for src,dest in FILES.items()}
    if actual!=expected:
        raise RuntimeError('STOP_RUNTIME_SOURCE_HASH_MISMATCH')
    print('V10_RUNTIME_SOURCE_SHA256=PASS')
    checker=('import os; paths='+repr(paths)+'; '
             'missing=[p for p in paths if not os.access(p,os.R_OK)]; '
             'assert not missing, missing; '
             'assert os.access("/secrets/openai_keys",os.R_OK|os.W_OK|os.X_OK); '
             'print("MODULES_READABLE=",len(paths),"/",len(paths)); '
             'print("V10_RUNTIME_ACCESS=PASS")')
    p=run('docker','exec',NAME,'python','-c',checker)
    if p.returncode or 'V10_RUNTIME_ACCESS=PASS' not in p.stdout:
        raise RuntimeError('STOP_V10_RUNTIME_ACCESS:'+p.stderr[:200])
    print('V10_RUNTIME_ACCESS=PASS')
    q=run('docker','exec',NAME,'python','-c',
          'import urllib.request; assert urllib.request.urlopen('
          '"http://127.0.0.1:8501/_stcore/health",timeout=5).status==200; '
          'print("INTERNAL_HTTP=200")')
    if q.returncode or 'INTERNAL_HTTP=200' not in q.stdout:
        raise RuntimeError('STOP_V10_INTERNAL_HTTP:'+q.stderr[:200])
    print('STREAMLIT_INTERNAL_HEALTH=PASS')
    try:
        with urllib.request.urlopen('http://127.0.0.1:18520/_stcore/health',timeout=5) as response:
            if response.status!=200:raise RuntimeError('STOP_V10_MAC_HOST_HTTP_STATUS')
    except (OSError,TimeoutError) as exc:
        raise RuntimeError('STOP_V10_MAC_HOST_HTTP:'+str(exc)[:150]) from exc
    print('MAC_HOST_HTTP_HEALTH=PASS')
    print('APP_ORIGINALS_MUTATED=NO')
    print('NEW_LLM_API_CALLS=0')
    print('RESEARCH_OUTPUT_WRITES=0')
    print('TEST1_V10_RUNNING_VERIFICATION=PASS')


def main():
    ap=argparse.ArgumentParser()
    grp=ap.add_mutually_exclusive_group(required=True)
    for action in ('check','start','status','verify-running'):grp.add_argument('--'+action,action='store_true')
    args=ap.parse_args()
    if args.verify_running:
        verify_running_readonly();return
    if args.status:
        x=inspect(NAME)
        running=bool(x and x.get('State',{}).get('Running'))
        print('V10_CANDIDATE_RUNNING='+('YES' if running else 'NO'))
        return
    image=check()
    if args.check:print('CHECK_ONLY_WRITES=0');return
    start(image)

if __name__=='__main__':
    try:main()
    except Exception as ex:
        print(str(ex)[:550],file=sys.stderr)
        sys.exit(2)
