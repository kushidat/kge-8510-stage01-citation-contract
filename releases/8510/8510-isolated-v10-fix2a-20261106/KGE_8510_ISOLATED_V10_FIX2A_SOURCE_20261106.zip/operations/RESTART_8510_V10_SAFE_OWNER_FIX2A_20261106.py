#!/usr/bin/env python3
"""V10-only restart with BYOK tmpfs owner recovery; does not change app sources.

--check and --verify are read-only. --restart alone changes only named V10 state
and, if needed, the owner of its ephemeral BYOK tmpfs root. No calls to LLM.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import http.client

NAME = "kgllm-8510-generic-llm-biology-v10"
FORMAL_8501 = "kgllm-mouse-model-search"
FORMAL_8510 = "kgllm-mouse-model-search-gpt6luna-staging"
BYOK = "/secrets/openai_keys"
V10_DIR = Path.home() / "projects/mondo_eval/release_records/8504_8510/isolated/8510_SOURCE_PROVENANCE_SECONDARY_MGI_ISOLATED_V10_20261106"
FIX1_DIR = Path.home() / "projects/mondo_eval/release_records/8504_8510/isolated/8510_V10_STARTUP_GUARD_FIX1_20261106"
PIN_V10_LAUNCH = "0ec32c283f049329a7e843f49904980a26a4197e4dabb5d03d864c4172c1791d"
PIN_FIX1_LAUNCH = "f7f085e71cd3802e48c492c958d0f7211d5d569e99a4033eaaa9da6426ee40d0"
FIX1_FILE = "START_8510_V10_LAUNCH_GUARD_FIX1_20261106.py"
APP_UID, APP_GID = 10001, 10001  # both measured on user's Mac in Test7

def digest(p: Path) -> str:
    if p.is_symlink() or not p.is_file():
        raise RuntimeError("STOP_FILE_MISSING_OR_SYMLINK:" + str(p))
    return hashlib.sha256(p.read_bytes()).hexdigest()

def pins():
    checks = [
      (V10_DIR / "START_8510_BRC_AUTHORITY_V10_NO_BIND_20261106.py", PIN_V10_LAUNCH),
      (FIX1_DIR / FIX1_FILE, PIN_FIX1_LAUNCH),
    ]
    for p, expected in checks:
        if digest(p) != expected:
            raise RuntimeError("STOP_PINNED_SOURCE_CHANGED:" + p.name)
    print("V10_AND_FIX1_PINNED_SHA256=PASS")

def command(*argv):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=25, check=False)
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        raise RuntimeError("STOP_COMMAND_UNAVAILABLE_OR_TIMEOUT:" + argv[0]) from e
    if p.returncode:
        raise RuntimeError("STOP_COMMAND_FAILED:" + " ".join(argv[:5]) + " " + p.stderr[:160])
    return p.stdout.strip()

def inspect(name):
    data = json.loads(command("docker", "inspect", name))
    if len(data) != 1 or data[0].get("Name") != "/" + name:
        raise RuntimeError("STOP_DOCKER_INSPECT_IDENTITY:" + name)
    return data[0]

def preflight():
    pins()
    v10 = inspect(NAME)
    if not v10.get("State", {}).get("Running"):
        raise RuntimeError("STOP_V10_NOT_RUNNING")
    h = v10.get("HostConfig", {})
    if h.get("Privileged") or h.get("NetworkMode") != "bridge":
        raise RuntimeError("STOP_V10_UNEXPECTED_PRIVILEGE_OR_NETWORK")
    port = h.get("PortBindings", {}).get("8501/tcp", [])
    if len(port) != 1 or port[0].get("HostIp") != "127.0.0.1" or str(port[0].get("HostPort")) != "18520":
        raise RuntimeError("STOP_V10_UNEXPECTED_PORT")
    spec = h.get("Tmpfs", {}).get(BYOK, "")
    options = set(spec.split(","))
    if not {"rw", "noexec", "nosuid", "size=32m", "mode=0700"}.issubset(options):
        raise RuntimeError("STOP_V10_UNEXPECTED_BYOK_TMPFS_CONFIG")
    if v10.get("Mounts"):
        raise RuntimeError("STOP_V10_UNEXPECTED_HOST_MOUNTS")
    uid = command("docker", "exec", NAME, "id", "-u")
    gid = command("docker", "exec", NAME, "id", "-g")
    if (uid, gid) != (str(APP_UID), str(APP_GID)):
        raise RuntimeError("STOP_UNEXPECTED_V10_APP_USER:" + uid + ":" + gid)
    formal = [inspect(FORMAL_8501), inspect(FORMAL_8510)]
    if not all(x.get("State", {}).get("Running") for x in formal):
        raise RuntimeError("STOP_PROTECTED_APP_NOT_RUNNING")
    print("V10_ONLY_SCOPE_AND_PROTECTED_CONTAINERS=PASS")
    return {"v10": v10["Id"], "formal": [x["Id"] for x in formal]}

def byok_stat():
    script = (
      'import os,stat,json; s=os.lstat("/secrets/openai_keys"); '
      'print(json.dumps({"uid":s.st_uid,"gid":s.st_gid,'
      '"mode":stat.S_IMODE(s.st_mode),"is_dir":stat.S_ISDIR(s.st_mode),' 
      '"symlink":stat.S_ISLNK(s.st_mode)}))'
    )
    d = json.loads(command("docker", "exec", "-u", "0", NAME, "python", "-c", script))
    if not d.get("is_dir") or d.get("symlink") or d.get("mode") != 0o700:
        raise RuntimeError("STOP_BYOK_TMPFS_TYPE_OR_MODE")
    return (d.get("uid"), d.get("gid"))

def repair_owner_if_needed():
    actual = byok_stat()
    if actual == (APP_UID, APP_GID):
        print("BYOK_OWNER=ALREADY_CORRECT")
    elif actual == (0, 0):
        command("docker", "exec", "-u", "0", NAME, "chown", f"{APP_UID}:{APP_GID}", BYOK)
        if byok_stat() != (APP_UID, APP_GID):
            raise RuntimeError("STOP_BYOK_OWNER_REPAIR_NOT_EFFECTIVE")
        print("BYOK_TMPFS_OWNER_REAPPLIED=PASS")
    else:
        raise RuntimeError("STOP_UNEXPECTED_BYOK_OWNER:" + repr(actual))

def verify_fix1():
    output = command(sys.executable, str(FIX1_DIR / FIX1_FILE), "--verify-running")
    must = ["V10_CANDIDATE_RUNNING=YES", "V10_RUNTIME_SOURCE_SHA256=PASS", "V10_RUNTIME_ACCESS=PASS",
            "STREAMLIT_INTERNAL_HEALTH=PASS", "MAC_HOST_HTTP_HEALTH=PASS", "APP_ORIGINALS_MUTATED=NO",
            "NEW_LLM_API_CALLS=0", "RESEARCH_OUTPUT_WRITES=0", "TEST1_V10_RUNNING_VERIFICATION=PASS"]
    if not all(x in output for x in must):
        raise RuntimeError("STOP_FIX1_VERIFY_MISSING_PASS")
    print("V10_FIX1_RUNTIME_VERIFY=PASS")

def wait_streamlit_health(*, timeout_seconds=60):
    """Wait for the existing localhost Streamlit health endpoint, without restarting.

    This is a bounded, read-only GET readiness check; it is not a provider call.
    """
    deadline = time.monotonic() + timeout_seconds
    while True:
        try:
            connection = http.client.HTTPConnection("127.0.0.1", 18520, timeout=3)
            try:
                connection.request("GET", "/_stcore/health")
                response = connection.getresponse()
                if response.status == 200:
                    response.read()
                    print("V10_POST_START_HTTP_READY=PASS")
                    return
            finally:
                connection.close()
        except (OSError, TimeoutError, http.client.HTTPException):
            pass
        if time.monotonic() >= deadline:
            raise RuntimeError("STOP_V10_POST_START_HTTP_NOT_READY_60S")
        time.sleep(min(2, max(0, deadline - time.monotonic())))

def unchanged(snapshot):
    if inspect(NAME)["Id"] != snapshot["v10"]:
        raise RuntimeError("STOP_V10_CONTAINER_ID_CHANGED")
    now = [inspect(FORMAL_8501), inspect(FORMAL_8510)]
    if [x["Id"] for x in now] != snapshot["formal"] or not all(x["State"]["Running"] for x in now):
        raise RuntimeError("STOP_PROTECTED_CONTAINER_CHANGED")
    print("EXISTING_8501_AND_8510_CONTAINERS_PRESERVED=PASS")

def restart():
    state = preflight()
    print("V10_SINGLE_CONTAINER_STOP_START=BEGIN")
    command("docker", "stop", "--time", "15", NAME)
    if inspect(NAME)["State"]["Running"]:
        raise RuntimeError("STOP_V10_STILL_RUNNING_AFTER_STOP")
    command("docker", "start", NAME)
    if not inspect(NAME)["State"]["Running"]:
        raise RuntimeError("STOP_V10_NOT_RUNNING_AFTER_START")
    unchanged(state)
    repair_owner_if_needed()
    wait_streamlit_health()
    verify_fix1()
    unchanged(state)
    print("TEST7_FIX2_RESTART_WITH_AUTOMATIC_OWNER_RECOVERY=PASS")
    print("BYOK_EPHEMERAL_DB_PERSISTENCE=NOT_GUARANTEED")
    print("OTHER_APP_MUTATIONS=NONE")

def main():
    ap = argparse.ArgumentParser(description="V10-only restart safety fix. Do not use raw docker start for V10.")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true", help="read-only source, Docker identity and access preflight")
    g.add_argument("--verify", action="store_true", help="read-only existing V10 normality verification")
    g.add_argument("--restart", action="store_true", help="V10-only stop/start + automatic BYOK tmpfs owner repair")
    ap.add_argument("--accept-ephemeral-reset", action="store_true", help="explicit consent for transient V10 session/BYOK data loss")
    args = ap.parse_args()
    if args.check:
        preflight()
        print("CHECK_ONLY_WRITES=0")
    elif args.verify:
        state = preflight()
        verify_fix1()
        unchanged(state)
        print("VERIFY_ONLY_WRITES=0")
    else:
        if not args.accept_ephemeral_reset:
            raise RuntimeError("STOP_RESTART_REQUIRES_--accept-ephemeral-reset")
        restart()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(str(e)[:700], file=sys.stderr)
        sys.exit(2)
