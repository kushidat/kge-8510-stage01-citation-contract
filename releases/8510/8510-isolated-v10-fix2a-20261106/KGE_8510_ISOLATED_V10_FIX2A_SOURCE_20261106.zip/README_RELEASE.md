# 8510 isolated V10 + FIX1/FIX2A — source snapshot (2026-11-06)

This is a **public source snapshot of the isolated 8510 V10 candidate and related local operation scripts**, not the formal 8510 v1.0 replacement, institution-wide deployment, a multi-user security approval, or scientific validation. It does not supersede the formal 8501/8504/8510 applications.

## Included

- `src/`: isolated V10 Streamlit source and source-provenance modules used for manual 8504 Evidence JSON intake, BYOK GPT-6 Luna provisional interpretation and paired JSON/Markdown outputs.
- `operations/`: separate FIX1 startup guard and FIX2A bounded readiness/temporary-storage owner recovery scripts and their no-overwrite installers. FIX2A's combined restart path was not rerun on a real Mac after FIX2A was prepared.
- `tests/`: existing source-level provenance regression tests. No paid inference or protected evaluation has been rerun for this source publication.

## Verification and limitations

As previously recorded in the 2026-11-06 Drive verification ledger: tests 1–6 passed within their stated technical scopes; V10 restarted with automatic temporary storage ownership repair in the FIX2 Mac trial, followed by successful HTTP readiness and read-only verification. FIX2's immediate single-command verification failed due to a readiness race, which FIX2A addresses with an offline-tested wait. Real Mac end-to-end FIX2A restart is *not tested*. No evidence of multi-user BYOK authorization, scientific validity of generated interpretations, or inference of KGE ranking mechanism is claimed.

No real API keys, private user inputs or LLM answer files, frozen TRAIN triples, model weights, test/validation/withheld/PRIMARY_TEST datasets, or local runtime databases have been included. `PRIMARY_TEST_EMBARGO=ACTIVE` remains unchanged.

The original V10 launcher is intentionally excluded because its source-level path assertion was superseded by FIX1. Original byte-pinned ZIPs remain retained on the owner's private Google Drive and are **not** included in this source-only release. To run on Mac, follow the owner's private pinned installation records; this archive is not a turnkey deployment.

Source code and the repository's materials are subject to the repository's existing license terms where the publisher holds the necessary rights. Third-party web pages, data, models and dependencies are not relicensed by this archive.

## Origin (byte-pinned private archives)

- `8510_SOURCE_PROVENANCE_SECONDARY_MGI_ISOLATED_V10_20261106.zip` (328442 bytes; SHA256 `ac65a3205b69e9bdd703a96946fedc030192c51a8fb423c0086746dcf296496f`)
- `8510_V10_STARTUP_GUARD_FIX1_20261106.zip` (9083 bytes; SHA256 `a6daa4d6c9c6e5a7358b726e0d655fb514a9d7054b5e1138c5efe8c4d481f3c4`)
- `8510_V10_RESTART_OWNER_FIX2A_HTTP_WAIT_20261106.zip` (7455 bytes; SHA256 `f760e1907da872bc57bfe33106e4dc719bdea0411525e818b96edbbfcd70a6d8`)
