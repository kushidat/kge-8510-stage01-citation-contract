"""Optional click-triggered allele/genotype-level MGI source retrieval.

Generic and source-checked: stock card -> exact allele symbol + marker MGI ID ->
marker allele summary -> exact allele record -> marker genotype phenotypes ->
corresponding genotype record. No stock/allele-specific biological text.

IMPORTANT: A genotype record is NOT a measurement of a currently distributed stock.
All identities and evidence values come from successfully fetched public pages.
"""
from __future__ import annotations

import html
from html.parser import HTMLParser
import re
import urllib.parse
import urllib.request

MAX_RESPONSE_BYTES=1_500_000
_MAX_RECORDS_PER_RUN=4
_MGI_HOST='www.informatics.jax.org'


def _normal_symbol(text:str)->str:
    """For exact symbol comparisons with HTML sup/sub rendering differences."""
    return re.sub(r'[^A-Za-z0-9]','',html.unescape(text)).lower()


def _mgi_id(text:str):
    match=re.search(r'\bMGI:(\d{4,10})\b',text,re.I)
    return 'MGI:'+match.group(1) if match else None


class _Page(HTMLParser):
    """Read public HTML text and link text/URL without running scripts."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.bits=[]
        self.links=[]
        self._link=None
        self._suppress=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style','noscript'):
            self._suppress+=1
        if self._suppress:return
        if tag=='a':
            href=dict(attrs).get('href') or ''
            self._link={'href':href,'text':[]}
        if tag in ('td','tr','p','div','h1','h2','h3','br','li','sup','sub'):
            self.bits.append(' ')
    def handle_data(self,data):
        if self._suppress:return
        self.bits.append(html.unescape(data))
        if self._link is not None:self._link['text'].append(html.unescape(data))
    def handle_endtag(self,tag):
        if tag in ('script','style','noscript') and self._suppress:
            self._suppress-=1
            return
        if self._suppress:return
        if tag=='a' and self._link is not None:
            self._link['text']=''.join(self._link['text'])
            self.links.append(self._link)
            self._link=None
        if tag in ('td','tr','p','div','h1','h2','h3','br','li','sup','sub'):
            self.bits.append(' ')
    def plain(self):return ' '.join(''.join(self.bits).split())


def _parse_html(raw:bytes):
    page=_Page()
    page.feed(raw.decode('utf-8',errors='replace'))
    return page


def _fetch_mgi(url:str,timeout=5):
    p=urllib.parse.urlsplit(url)
    if p.scheme!='https' or p.hostname!=_MGI_HOST:
        raise ValueError('STOP_MGI_NON_ALLOWED_HOST')
    request=urllib.request.Request(url,headers={'User-Agent':'8510ResearchPrototype/0.5 (public MGI allele provenance; no personal data)','Accept':'text/html'})
    with urllib.request.urlopen(request,timeout=timeout) as response:
        actual=urllib.parse.urlsplit(response.geturl())
        if actual.scheme!='https' or actual.hostname not in (_MGI_HOST,'informatics.jax.org'):
            raise ValueError('STOP_MGI_REDIRECT_HOST')
        payload=response.read(MAX_RESPONSE_BYTES+1)
        if len(payload)>MAX_RESPONSE_BYTES:raise ValueError('STOP_MGI_PAGE_TOO_LARGE')
    return payload


def _stock_alleles(page_excerpt:str):
    """Extract only allele+gene marker pairs co-displayed in BRC Gene section.

    Stock card's marker MGI ID is for the GENE, never the mutant allele.
    Never use an unrelated marker MGI ID or an arbitrary uploaded string.
    """
    if not isinstance(page_excerpt,str):return []
    gene_segment=page_excerpt.partition(' Gene ')[2] or page_excerpt.partition('Gene ')[2]
    if not gene_segment:return []
    gene_segment=gene_segment.split(' Phenotype ')[0][:10000]
    result=[]
    pattern=r'\b([A-Za-z][A-Za-z0-9_.-]{0,30})\s*<\s*([A-Za-z0-9_.()/-]{1,70})\s*>'
    for m in re.finditer(pattern,gene_segment):
        gene=m.group(1);allele=m.group(2)
        previous=gene_segment[max(0,m.start()-260):m.start()]
        # A same-gene marker ID must precede this allele within the BRC gene row.
        markers=list(re.finditer(r'\b'+re.escape(gene)+r'\s+(MGI:\d{4,10})\b',previous,re.I))
        if not markers:continue
        marker_id=markers[-1].group(1)
        symbol=gene+'<'+allele+'>'
        item={'allele_symbol':symbol,'gene_symbol':gene,'gene_marker_id':marker_id}
        if item not in result:result.append(item)
    return result[:_MAX_RECORDS_PER_RUN]


def _href_mgi(link,route):
    url=urllib.parse.urljoin('https://'+_MGI_HOST,link.get('href') or '')
    p=urllib.parse.urlsplit(url)
    if p.scheme!='https' or p.hostname not in (_MGI_HOST,'informatics.jax.org'):
        return None
    m=re.fullmatch(r'/allele/'+route+r'/MGI:(\d{4,10})/?',urllib.parse.unquote(p.path),re.I) if route else re.fullmatch(r'/allele/MGI:(\d{4,10})/?',urllib.parse.unquote(p.path),re.I)
    return 'MGI:'+m.group(1) if m else None


def _find_exact_allele_id(page:_Page,allele_symbol:str):
    target=_normal_symbol(allele_symbol)
    matched=set()
    for link in page.links:
        mgi=_href_mgi(link,'')
        if mgi and _normal_symbol(link['text'])==target:
            matched.add(mgi)
    return next(iter(matched)) if len(matched)==1 else None


def _find_genotypes(page:_Page,allele_symbol:str):
    target=_normal_symbol(allele_symbol)
    results=[]
    for link in page.links:
        mgi=_href_mgi(link,'genoview')
        if not mgi:continue
        raw=link['text']
        # Genotype text is rendered as allele / + (or allele / allele).
        parts=re.split(r'[/|]',raw)
        if not any(_normal_symbol(piece)==target for piece in parts):continue
        if mgi not in results:results.append(mgi)
    return results[:2]


def _excerpt(page:_Page,needle='',length=3000):
    plain=page.plain()
    i=plain.lower().find(needle.lower()) if needle else 0
    if i<0:i=0
    return plain[max(0,i-250):i+length]


def _append_unique(target,record):
    if not any(z.get('id')==record.get('id') and z.get('type')==record.get('type') for z in target):
        target.append(record)


def append_allele_evidence(context:dict,fetch=None):
    """Enrich original V04 fetched STOCK records; fail closed on any uncertainty."""
    fetch=fetch or _fetch_mgi
    verified=context.setdefault('verified',[])
    unavailable=context.setdefault('unavailable',[])
    fetched=[]
    for source in list(verified):
        if source.get('type')!='public_stock_card':continue
        stock=source.get('id')
        for allele in _stock_alleles(source.get('page_excerpt','')):
            if len(fetched)>=_MAX_RECORDS_PER_RUN:break
            fetched.append((stock,allele))
    context['allele_lookup_policy']='EXACT_PUBLIC_STOCK_ALLELE_AND_GENE_MARKER_MATCH_OR_UNVERIFIED'
    context['allele_lookup_status']='NO_STOCK_ALLELE_RESOLVED' if not fetched else 'ATTEMPTED'
    context['source_boundary']='Genotype observations pertain to the cited genotype/background, not necessarily the distributed strain or an individual mouse.'
    for stock,item in fetched:
        marker=item['gene_marker_id'];symbol=item['allele_symbol']
        base={'stock_id':stock,'stock_allele_symbol':symbol,'gene_marker_id':marker,
              'match_chain':'RIKEN_STOCK_CARD_TO_MGI_MARKER_ALLELE_EXACT_SYMBOL'}
        summary='https://'+_MGI_HOST+'/allele/summary?'+urllib.parse.urlencode({'markerId':marker})
        try:
            page=_parse_html(fetch(summary))
            allele_id=_find_exact_allele_id(page,symbol)
            if not allele_id:
                unavailable.append({'request':'MGI_ALLELE_DISCOVERY','stock_id':stock,'allele_symbol':symbol,'reason':'EXACT_ALLELE_NOT_UNAMBIGUOUS_IN_MARKER_ALLELE_SUMMARY','source_url':summary})
                continue
        except (ValueError,OSError,TypeError,UnicodeError,TimeoutError) as ex:
            unavailable.append({'request':'MGI_ALLELE_DISCOVERY','stock_id':stock,'allele_symbol':symbol,'error_type':type(ex).__name__})
            continue
        detail='https://'+_MGI_HOST+'/allele/'+allele_id
        try:
            page=_parse_html(fetch(detail))
            text=page.plain()
            if allele_id not in text or not (
                _normal_symbol(symbol) in _normal_symbol(text[:1900])
                or (_normal_symbol(item['gene_symbol']) in _normal_symbol(text[:1400])
                    and _normal_symbol(symbol.split('<')[1][:-1]) in _normal_symbol(text[:1400]))):
                unavailable.append({'request':'MGI_ALLELE_DETAIL','stock_id':stock,'allele_id':allele_id,'reason':'ALLELE_ID_OR_SYMBOL_NOT_IN_PAGE'})
                continue
            record={'id':allele_id,'type':'MGI_allele','allele_symbol':symbol,**base,
                'source_url':detail,'discovery_url':summary,'verification':'HTTP_MGI_ALLELE_ID_AND_SYMBOL_MATCHED',
                'mutation_and_references_excerpt':_excerpt(page,'Mutation',3300)}
            _append_unique(verified,record)
        except (ValueError,OSError,TypeError,UnicodeError,TimeoutError) as ex:
            unavailable.append({'request':'MGI_ALLELE_DETAIL','stock_id':stock,'allele_id':allele_id,'error_type':type(ex).__name__})
            continue
        phenotype='https://'+_MGI_HOST+'/marker/phenotypes/'+marker
        try:
            page=_parse_html(fetch(phenotype))
            genotypes=_find_genotypes(page,symbol)
            if not genotypes:
                unavailable.append({'request':'MGI_GENOTYPE_DISCOVERY','stock_id':stock,'allele_id':allele_id,'reason':'NO_EXACT_LINKED_GENOTYPE_FOR_ALLELE','source_url':phenotype})
            for geno in genotypes:
                url='https://'+_MGI_HOST+'/allele/genoview/'+geno
                gp=_parse_html(fetch(url))
                plain=gp.plain()
                if geno not in plain or _normal_symbol(symbol) not in _normal_symbol(plain):
                    unavailable.append({'request':'MGI_GENOTYPE_DETAIL','stock_id':stock,'genotype_id':geno,'reason':'GENOTYPE_ID_OR_ALLELE_SYMBOL_NOT_IN_PAGE'})
                    continue
                record={'id':geno,'type':'MGI_genotype_phenotype',**base,'allele_id':allele_id,
                        'source_url':url,'discovery_url':phenotype,
                        'verification':'HTTP_MGI_GENOTYPE_ID_AND_ALLELE_SYMBOL_MATCHED',
                        'genotype_background_phenotype_excerpt':_excerpt(gp,'Genotype',4200),
                        'not_distributed_stock_measurement':True}
                _append_unique(verified,record)
        except (ValueError,OSError,TypeError,UnicodeError,TimeoutError) as ex:
            unavailable.append({'request':'MGI_GENOTYPE_LOOKUP','stock_id':stock,'allele_id':allele_id,'error_type':type(ex).__name__})
    context['allele_lookup_status']='MATCHED_PUBLIC_ALLELE_OR_GENOTYPE' if any(z['type'] in ('MGI_allele','MGI_genotype_phenotype') for z in verified) else ('ATTEMPTED_UNVERIFIED' if fetched else 'NO_STOCK_ALLELE_RESOLVED')
    return context
