#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Streamlit UI: MONDO term search -> Step3 pipeline -> visualization

v5.63_submission_FIXED
fix62: phenotype keyword search is auxiliary; unified candidate review order preserves existing Step3/first-stage LLM candidate order.
- Restores original concept: single app that runs (1) term search (2) step3 pipeline (3) visualization
- Uses Step3 outputs (summary_stats_*.csv, details_table_*.csv) as primary source of truth
- Provides two views:
  A) 網羅統計（Models/ID:UNKNOWN を含む）  : Step3 summary_stats + details_table
  B) 遺伝子関連（Genes != ID:UNKNOWN）      : details_table filtered
- Plot downloads: PNG/SVG/PDF (requires kaleido for static export)

NOTE:
- This app expects the following scripts to exist locally (paths configurable in sidebar):
  * search_cli_hybrid_v08_term.py
  * bioresourceKG_dataPipelineValidation_v05_local_port_STRICT_usability_v8_fixed20_seed_intersection_FIXED.py
"""

from __future__ import annotations

import io
import json
import math
import os
import re
import sqlite3
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st
import requests

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

try:
    from cryptography.fernet import Fernet
except Exception:
    Fernet = None

# 描画ガード閾値（正常動作優先）
MONDO_COUNT_WARN = 25
MONDO_COUNT_HARD = 30
MAX_RBRC_PER_MONDO_WARN = 50
MAX_RBRC_PER_MONDO_HARD = 150
ROOT_UNION_WARN = 80
ROOT_UNION_HARD = 150


# -----------------------------
# Utilities
# -----------------------------

def _iri_to_obo_format(iri: str) -> str:
    """Convert MONDO IRI to obo:MONDO_XXXXXXX format for display."""
    try:
        tail = iri.rsplit('/', 1)[-1]
        if tail.startswith('MONDO_'):
            return 'obo:' + tail
    except Exception:
        pass
    return iri

def _find_mondo_ontology_file() -> Optional[Path]:
    """Return mondo.owl or mondo.json in current working directory if present."""
    cwd = Path.cwd()
    for name in ("mondo.owl", "mondo.json"):
        p = cwd / name
        if p.exists() and p.is_file():
            return p
    return None


@st.cache_data(show_spinner=False)
def _load_mondo_subclass_edges_cached(mondo_path: str, mtime: float) -> Dict[str, List[str]]:
    """Load rdfs:subClassOf edges from MONDO ontology.

    Returns adjacency mapping: parent_mondo_id -> [child_mondo_id, ...]
    (both in MONDO_0000000 form).
    """
    # mtime is part of cache key; not used otherwise.
    _ = mtime

    from rdflib import Graph
    from rdflib.namespace import RDFS

    g = Graph()
    p = Path(mondo_path)

    # mondo.owl is typically RDF/XML; mondo.json may be JSON-LD.
    # Try a few parsers for robustness.
    parse_attempts = []
    if p.suffix.lower() == ".owl":
        parse_attempts = ["xml", "turtle", "json-ld"]
    else:
        parse_attempts = ["json-ld", "xml", "turtle"]

    last_err: Optional[Exception] = None
    for fmt in parse_attempts:
        try:
            g.parse(str(p), format=fmt)
            last_err = None
            break
        except Exception as e:
            last_err = e
            continue
    if last_err is not None:
        raise RuntimeError(f"Failed to parse MONDO ontology: {p.name} ({last_err})")

    mondo_pat = re.compile(r"MONDO[_:]\d+")

    def _to_mondo_id(x: str) -> Optional[str]:
        m = mondo_pat.search(x)
        if not m:
            return None
        return m.group(0).replace(":", "_").upper()

    adj: Dict[str, List[str]] = {}
    for s, o in g.subject_objects(predicate=RDFS.subClassOf):
        # We only keep URIRef->URIRef edges (ignore blank node restrictions)
        s_id = _to_mondo_id(str(s))
        o_id = _to_mondo_id(str(o))
        if not s_id or not o_id:
            continue
        adj.setdefault(o_id, []).append(s_id)  # parent -> child

    # De-duplicate child lists for determinism
    for k in list(adj.keys()):
        adj[k] = sorted(set(adj[k]))
    return adj


def _load_mondo_subclass_edges() -> Optional[Dict[str, List[str]]]:
    """Wrapper that finds mondo.owl/mondo.json and loads subclass adjacency.

    - Returns adjacency dict on success
    - Returns None on failure and stores a human-readable message in st.session_state["mondo_ontology_error"]
    """
    mondo_file = _find_mondo_ontology_file()
    if mondo_file is None:
        st.session_state["mondo_ontology_error"] = "mondo.owl または mondo.json がカレントディレクトリに見つかりません（候補一覧（推定候補のみ）を無効化します）。"
        return None
    try:
        adj = _load_mondo_subclass_edges_cached(str(mondo_file), mondo_file.stat().st_mtime)
        st.session_state.pop("mondo_ontology_error", None)
        return adj
    except Exception as e:
        st.session_state["mondo_ontology_error"] = (f"MONDO オントロジーの読み込みに失敗しました: {e}（候補一覧（推定候補のみ）を無効化します）。" + f" [python={sys.executable}]")
        return None


def _get_descendants(root_mid: str, mondo_edges: dict) -> set:
    """Return all descendant MONDO IDs (MONDO_XXXXXXX) reachable from root_mid via rdfs:subClassOf edges.

    - root_mid: 'MONDO_0004976' like internal ID (NOT full IRI)
    - mondo_edges: dict[parent_mid] -> set/list of child_mid
    """
    if not root_mid or not mondo_edges:
        return set()

    seen = set()
    stack = [root_mid]
    while stack:
        cur = stack.pop()
        for child in mondo_edges.get(cur, []):
            if child not in seen:
                seen.add(child)
                stack.append(child)
    return seen

def _now_tag() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _safe_mkdir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _path_under_base_or_absolute(base_dir: str, path_value: str) -> Path:
    p = Path(path_value).expanduser()
    if p.is_absolute():
        return p
    return Path(base_dir) / p


def _app_log_dir(base_dir: str) -> Path:
    return _path_under_base_or_absolute(base_dir, os.getenv("APP_LOG_DIR", "./log"))


def _llm_outputs_dir(base_dir: str) -> Path:
    return _path_under_base_or_absolute(base_dir, os.getenv("LLM_OUTPUTS_DIR", "llm_outputs"))




def _luna_model_guard(model: str) -> str:
    """Fail closed before every Chat Completions API request."""
    actual = str(model).strip()
    if actual != "gpt-6-luna":
        raise RuntimeError("BLOCK_UNAPPROVED_LLM_MODEL: " + actual)
    return actual


def _get_authenticated_user_id() -> str:
    # Phase 0: local/debug user id.
    # Future: read trusted user id from reverse proxy headers such as
    # X-Forwarded-User or X-Auth-Request-User, only when Streamlit is not
    # directly exposed and the proxy strips client-supplied headers.
    return os.getenv("APP_USER_ID", "").strip()


def _allow_server_openai_key() -> bool:
    return os.getenv("ALLOW_SERVER_OPENAI_KEY", "false").strip().lower() in {"1", "true", "yes"}


def _get_key_store_path() -> Path:
    return Path(os.getenv("OPENAI_KEY_STORE_PATH", "/secrets/openai_keys/openai_keys.sqlite3")).expanduser()


def _get_fernet() -> Optional[object]:
    if Fernet is None:
        return None
    secret = os.getenv("KEY_ENCRYPTION_SECRET", "").strip()
    if not secret or secret == "replace_with_generated_fernet_key":
        return None
    try:
        return Fernet(secret.encode("utf-8"))
    except Exception:
        return None


def _init_openai_key_store() -> None:
    path = _get_key_store_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as con:
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS user_openai_keys (
              user_id TEXT PRIMARY KEY,
              encrypted_api_key TEXT NOT NULL,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )
            """
        )
        con.commit()


def _has_saved_openai_key(user_id: str) -> bool:
    if not user_id:
        return False
    try:
        _init_openai_key_store()
        with sqlite3.connect(_get_key_store_path()) as con:
            row = con.execute(
                "SELECT 1 FROM user_openai_keys WHERE user_id = ? LIMIT 1",
                (user_id,),
            ).fetchone()
        return row is not None
    except Exception:
        return False


def _save_openai_key_for_user(user_id: str, api_key: str) -> None:
    user_id = str(user_id or "").strip()
    api_key = str(api_key or "").strip()
    if not user_id:
        raise ValueError("user_id is required")
    if not api_key:
        raise ValueError("api_key is required")
    fernet = _get_fernet()
    if fernet is None:
        raise RuntimeError("KEY_ENCRYPTION_SECRET is missing or invalid")
    encrypted = fernet.encrypt(api_key.encode("utf-8")).decode("utf-8")
    now = datetime.now().isoformat(timespec="seconds")
    _init_openai_key_store()
    with sqlite3.connect(_get_key_store_path()) as con:
        con.execute(
            """
            INSERT INTO user_openai_keys (user_id, encrypted_api_key, created_at, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
              encrypted_api_key = excluded.encrypted_api_key,
              updated_at = excluded.updated_at
            """,
            (user_id, encrypted, now, now),
        )
        con.commit()


def _load_openai_key_for_user(user_id: str) -> str:
    user_id = str(user_id or "").strip()
    if not user_id:
        return ""
    fernet = _get_fernet()
    if fernet is None:
        return ""
    try:
        _init_openai_key_store()
        with sqlite3.connect(_get_key_store_path()) as con:
            row = con.execute(
                "SELECT encrypted_api_key FROM user_openai_keys WHERE user_id = ?",
                (user_id,),
            ).fetchone()
        if row is None:
            return ""
        return fernet.decrypt(str(row[0]).encode("utf-8")).decode("utf-8").strip()
    except Exception:
        return ""


def _delete_openai_key_for_user(user_id: str) -> None:
    user_id = str(user_id or "").strip()
    if not user_id:
        return
    _init_openai_key_store()
    with sqlite3.connect(_get_key_store_path()) as con:
        con.execute("DELETE FROM user_openai_keys WHERE user_id = ?", (user_id,))
        con.commit()


def _has_usable_user_openai_key() -> bool:
    user_id = _get_authenticated_user_id()
    return bool(user_id and _get_fernet() is not None and _has_saved_openai_key(user_id))


def _get_openai_api_key_for_llm_or_stop() -> str:
    user_id = _get_authenticated_user_id()
    if not user_id:
        st.error("LLM機能を使うには認証済みユーザーIDが必要です。")
        st.stop()

    if _has_saved_openai_key(user_id):
        key = _load_openai_key_for_user(user_id)
        if key:
            return key
        st.error("保存済みAPI keyを読み込めませんでした。再登録してください。")
        st.stop()

    if _allow_server_openai_key():
        server_key = os.getenv("OPENAI_API_KEY", "").strip()
        if server_key:
            return server_key

    st.error("LLM機能を使うには、自分のOpenAI API keyを初回登録してください。")
    st.stop()


def _redact_secret_text(text: str, secrets: Optional[List[str]] = None) -> str:
    if not text:
        return text
    out = str(text)
    for secret in secrets or []:
        if secret:
            out = out.replace(secret, "[REDACTED_OPENAI_API_KEY]")
    out = re.sub("s" + r"k-[A-Za-z0-9_\-]{20,}", "[REDACTED_OPENAI_API_KEY]", out)
    return out


def _subprocess_env(env_extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    env = os.environ.copy()
    if os.getenv("LLM_KEY_MODE", "user_encrypted").strip() == "user_encrypted" and not _allow_server_openai_key():
        env.pop("OPENAI_API_KEY", None)
    if env_extra:
        env.update(env_extra)
    return env


def _render_openai_key_manager() -> None:
    user_id = _get_authenticated_user_id()
    fernet_ready = _get_fernet() is not None
    server_fallback = _allow_server_openai_key()

    st.subheader("LLM API key")
    st.caption("OpenAI API keyはユーザーごとに暗号化保存されます。LLM機能実行時だけ復号して使用します。key本体は画面・ログ・出力ファイルには表示しません。")
    st.write(f"User ID: `{user_id or '(not set)'}`")

    if not user_id:
        st.warning("APP_USER_ID が未設定です。LLM key登録・LLM実行はできません。")
        return
    if not fernet_ready:
        st.warning("KEY_ENCRYPTION_SECRET が未設定または不正です。暗号化key storeを使うにはFernet keyを設定してください。")

    saved = _has_saved_openai_key(user_id)
    st.write(f"Status: `{'saved' if saved else 'not saved'}`")
    st.caption(f"Server key fallback: `{'enabled' if server_fallback else 'disabled'}`")

    api_key_input_key = "openai_api_key_registration_input"
    api_key_input = st.text_input(
        "OpenAI API key",
        value="",
        type="password",
        key=api_key_input_key,
        placeholder="OpenAI API key",
    )
    cols = st.columns(2)
    with cols[0]:
        if st.button("Save / Update key", key="save_openai_api_key", disabled=not fernet_ready):
            try:
                _save_openai_key_for_user(user_id, api_key_input)
                st.session_state.pop(api_key_input_key, None)
                st.success("API keyを暗号化保存しました。")
                st.rerun()
            except Exception as e:
                st.session_state.pop(api_key_input_key, None)
                st.error(f"API keyを保存できませんでした: {type(e).__name__}")
    with cols[1]:
        if st.button("Delete saved key", key="delete_openai_api_key", disabled=not saved):
            _delete_openai_key_for_user(user_id)
            st.success("保存済みAPI keyを削除しました。")
            st.rerun()


def _clean_display_cell(x: object) -> str:
    s = "" if x is None else str(x).strip()
    if not s or s.lower() == "nan" or s == "UNKNOWN":
        return ""
    return s


def _normalize_sunburst_label(x: object, fallback: str) -> str:
    s = _clean_display_cell(x)
    return s if s else fallback


def _find_latest_step3_script(base_dir: str) -> Optional[str]:
    try:
        base = Path(base_dir)
    except Exception:
        return None
    if not base.exists():
        return None
    candidates = sorted(base.glob('bioresourceKG_dataPipelineValidation_v05_local_port_STRICT_usability_v8*.py'))
    if not candidates:
        return None
    stable = [p for p in candidates if p.name.endswith('.STABLE.py')]
    chosen = stable if stable else candidates
    chosen = sorted(chosen, key=lambda p: (p.stat().st_mtime, p.name), reverse=True)
    return chosen[0].name if chosen else None




def _find_latest_optional_csv(base_dir: str, pattern: str) -> Optional[Path]:
    try:
        base = Path(base_dir)
    except Exception:
        return None
    if not base.exists():
        return None
    candidates = [p for p in base.glob(pattern) if p.is_file()]
    if not candidates:
        return None
    candidates = sorted(candidates, key=lambda p: (p.stat().st_mtime, p.name), reverse=True)
    return candidates[0]


def _safe_read_optional_csv(path: Optional[Path]) -> pd.DataFrame:
    if path is None or not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, dtype=str, keep_default_na=False).fillna("")
    except Exception:
        return pd.DataFrame()


def _read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype=str, keep_default_na=False).fillna("")



def load_llm_summary_csvs(base_dir: str, root_mid: str) -> Tuple[pd.DataFrame, pd.DataFrame, Optional[Path], Optional[Path]]:
    root_mid = str(root_mid or '').strip()
    if not root_mid:
        return pd.DataFrame(), pd.DataFrame(), None, None
    summary_path = _find_latest_optional_csv(base_dir, f'strain_summary*{root_mid}*.csv')
    pair_path = _find_latest_optional_csv(base_dir, f'strain_pair_suggestions*{root_mid}*.csv')
    return _safe_read_optional_csv(summary_path), _safe_read_optional_csv(pair_path), summary_path, pair_path


def build_llm_summary_display_df(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    preferred = [
        'strain_id', 'strain_name', 'primary_gene', 'primary_mondo_label', 'sources',
        'recommended_use_tag', 'selection_priority_hint', 'evidence_level', 'source_provenance_level'
    ]
    cols = [c for c in preferred if c in df.columns]
    return df[cols].copy() if cols else df.copy()


def build_llm_pair_display_df(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    preferred = [
        'pair_id',
        'strain_id_a', 'strain_name_a', 'priority_a',
        'strain_id_b', 'strain_name_b', 'priority_b',
        'comparison_theme', 'what_can_be_compared_ja',
        'why_this_pair_ja', 'expected_difference_axis', 'pair_caution_ja',
        'source_provenance_level', 'selected_pair'
    ]
    cols = [c for c in preferred if c in df.columns]
    return df[cols].copy() if cols else df.copy()
def _run_interactive_python(script_path: str, args: List[str], stdin_text: str, cwd: Optional[str] = None, env_extra: Optional[Dict[str, str]] = None) -> Tuple[int, str, str]:
    """Run a python script that reads from stdin (interactive CLI)."""
    cmd = [sys.executable, script_path] + args
    api_key = (env_extra or {}).get("OPENAI_API_KEY", "")
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=cwd,
        env=_subprocess_env(env_extra),
    )
    out, err = proc.communicate(stdin_text)
    out = _redact_secret_text(out, [api_key])
    err = _redact_secret_text(err, [api_key])
    return proc.returncode, out, err


def _filter_noise_from_stdout(text: str) -> str:
    """Streamlit上の表示だけ整形する（実行自体は変えない）。"""
    if not text:
        return text
    text = _redact_secret_text(text)
    drop_substrings = [
        "Loading weights",
        "XLMRobertaModel LOAD REPORT",
        "UNEXPECTED KEYS",
        "MISSING KEYS",
        "Notes:",
        "Some weights of the model checkpoint",
        "were not used when initializing",
        "You should probably TRAIN",
    ]
    lines = []
    for line in text.splitlines():
        if any(s in line for s in drop_substrings):
            continue
        lines.append(line)
    return "\n".join(lines).strip()


def _extract_path_from_stdout(pattern: str, text: str) -> Optional[str]:
    m = re.search(pattern, text)
    if not m:
        return None
    return m.group(1).strip()


def _load_search_results_json(json_path: Path) -> List[dict]:
    data = json.loads(json_path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError("Search JSON is not a list")
    return data


def _drop_all_blank_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Drop columns that are entirely blank (NaN or empty-string).

    If a CLI does not emit a score column, we prefer to hide that column rather
    than showing a fully-empty column.
    """
    if df is None or df.empty:
        return df

    drop_cols = []
    for col in df.columns:
        s = df[col]
        # Treat NaN and empty/whitespace-only strings as blank.
        try:
            as_str = s.astype(str).str.strip()
            blank_mask = s.isna() | as_str.eq("") | as_str.eq("nan")
        except Exception:
            blank_mask = s.isna()
        if bool(blank_mask.all()):
            drop_cols.append(col)

    if drop_cols:
        return df.drop(columns=drop_cols)
    return df


def _make_rank_csv_from_result(rec: dict, out_csv: Path) -> None:
    # Match select_match_cli.py output schema
    row = {
        "rank": 1,
        "term": rec.get("term", ""),
        "label": rec.get("label", ""),
        "iri": rec.get("iri", ""),
        "prop": rec.get("prop", ""),
        "score": rec.get("score", ""),
        "score_bm25": rec.get("score_bm25", ""),
        "score_faiss": rec.get("score_faiss", ""),
    }
    pd.DataFrame([row]).to_csv(out_csv, index=False)


def _parse_mapped_disease_to_id_label(s: str) -> Tuple[str, str]:
    # Expected: "MONDO_0004976: amyotrophic lateral sclerosis"
    if ":" not in s:
        return s.strip(), ""
    mid, label = s.split(":", 1)
    return mid.strip(), label.strip()




# --- MONDO階層（subClassOf）ユーティリティ ---
# MONDO IDの数値並びは階層を表しません。階層集計（rootの閉包）を行う場合は、
# mondo.owl（推奨）または mondo.json をローカルに置いて、それを参照します。

MONDO_IRI_PREFIX = "http://purl.obolibrary.org/obo/MONDO_"


def _iri_to_mondo_id(iri: str) -> str:
    if not iri:
        return ""
    if iri.startswith(MONDO_IRI_PREFIX):
        return iri.split("/")[-1]
    return ""




def _normalize_mondo_id(x: object) -> str:
    """Normalize various MONDO id/IRI formats to 'MONDO_########' (7-digit padding).
    Accepts: 'MONDO_0004976', 'MONDO:0004976', 'obo:MONDO_0004976',
             'http://purl.obolibrary.org/obo/MONDO_0004976', etc.
    Returns '' if not recognized.
    """
    if x is None:
        return ""
    s = str(x).strip()
    if not s:
        return ""
    # Common prefix variants
    s = s.replace("obo:", "")
    # Extract MONDO id pattern
    m = re.search(r"(MONDO[_:])(\d+)", s)
    if not m:
        # IRI form: .../MONDO_0004976
        m2 = re.search(r"(MONDO_)(\d+)", s)
        if not m2:
            return ""
        digits = m2.group(2)
        return f"MONDO_{digits.zfill(7)}"
    digits = m.group(2)
    return f"MONDO_{digits.zfill(7)}"

def _extract_target_mondo_id(stdout: str) -> Optional[str]:
    """Try to extract the target MONDO ID (e.g., 'MONDO_0004976') from CLI stdout."""
    if not stdout:
        return None
    m = re.search(r"\((MONDO_\d+)\)", stdout)
    if m:
        return m.group(1)
    # fallback: first MONDO_ pattern
    m = re.search(r"(MONDO_\d+)", stdout)
    return m.group(1) if m else None

@st.cache_resource(show_spinner=False)
def load_mondo_subclass_graph():
    """Return (children_of, parents_of) for MONDO subclass graph.

    - If mondo.owl exists in CWD, parse with rdflib (preferred)
    - Else, return (None, None)

    Note: Large ontology parse is cached by Streamlit.
    """
    cwd = Path.cwd()
    owl_path = cwd / "mondo.owl"

    # rdflibは標準環境で入っていない可能性があるため optional
    try:
        import rdflib
        from rdflib.namespace import RDFS
        from rdflib.term import BNode
    except Exception:
        return (None, None)

    if not owl_path.exists():
        return (None, None)

    g = rdflib.Graph()
    try:
        g.parse(str(owl_path))
    except Exception:
        return (None, None)

    children_of = {}
    parents_of = {}

    for s, _, o in g.triples((None, RDFS.subClassOf, None)):
        # restriction / blank node を除外
        if isinstance(o, BNode):
            continue

        sid = _iri_to_mondo_id(str(s))
        oid = _iri_to_mondo_id(str(o))
        if not sid or not oid:
            continue

        children_of.setdefault(oid, set()).add(sid)
        parents_of.setdefault(sid, set()).add(oid)

    return (children_of, parents_of)


def get_mondo_descendants(root_mid: str, include_root: bool = True):
    """Return descendant MONDO_ID set (transitive)."""
    if not root_mid:
        return None

    children_of, _ = load_mondo_subclass_graph()
    if children_of is None:
        return None

    seen = set([root_mid]) if include_root else set()
    stack = [root_mid]
    while stack:
        cur = stack.pop()
        for ch in children_of.get(cur, set()):
            if ch in seen:
                continue
            seen.add(ch)
            stack.append(ch)

    return seen

PLOTLY_SOURCE_BASE_COLORS = {
    "MGI": "#4C78A8",
    "Medgen": "#F2CF5B",
    "Models": "#E45756",
}
ROOT_BAR_COLORS = {
    "root配下（内訳）": "#8ecbff",
    "ROOT union（重複除去後）": "#1a73d9",
}


def _hex_to_rgb01(hex_color: str):
    s = str(hex_color).strip().lstrip("#")
    if len(s) != 6:
        return (0.5, 0.5, 0.5)
    return tuple(int(s[i:i+2], 16) / 255.0 for i in (0, 2, 4))


def _rgb01_to_hex(rgb):
    vals = []
    for x in rgb:
        x = max(0.0, min(1.0, float(x)))
        vals.append(f"{int(round(x * 255)):02x}")
    return "#" + "".join(vals)


def _normalize_sources_key(s: str) -> str:
    parts = [p.strip() for p in str(s).split(",") if str(p).strip()]
    parts = sorted(dict.fromkeys(parts))
    return ", ".join(parts)


def _unknown_source_base_color(name: str) -> str:
    import colorsys
    seed = sum(ord(c) for c in str(name))
    hue = (seed % 360) / 360.0
    sat = 0.55
    val = 0.92
    rgb = colorsys.hsv_to_rgb(hue, sat, val)
    return _rgb01_to_hex(rgb)


def _resolve_source_color(source_key: str) -> str:
    key = _normalize_sources_key(source_key)
    if not key:
        return "#999999"
    parts = key.split(", ")
    colors = []
    for p in parts:
        base = PLOTLY_SOURCE_BASE_COLORS.get(p) or _unknown_source_base_color(p)
        colors.append(_hex_to_rgb01(base))
    avg = tuple(sum(c[i] for c in colors) / len(colors) for i in range(3))
    # lighten mixed colors slightly for readability on white background
    lighten = 0.18
    mixed = tuple(avg[i] * (1 - lighten) + 1.0 * lighten for i in range(3))
    return _rgb01_to_hex(mixed)


def _build_source_color_map(values) -> dict:
    keys = []
    for v in values:
        k = _normalize_sources_key(v)
        if k and k not in keys:
            keys.append(k)
    return {k: _resolve_source_color(k) for k in keys}


def _uniq_sorted_rbrc(values):
    return sorted({str(v).strip().removesuffix(".0") for v in values if pd.notna(v) and str(v).strip()})


def _join_full(vals):
    vals = [str(v) for v in vals if str(v).strip()]
    if not vals:
        return ""
    return ", ".join(vals)


def _hover_rbrc_text_full(rbrc_list):
    if not rbrc_list:
        return "(なし)"
    return ", ".join([str(v) for v in rbrc_list if str(v).strip()])


def _merge_source_tokens(series: pd.Series) -> str:
    merged = set()
    for value in series.fillna("").astype(str):
        for part in value.split(","):
            p = part.strip()
            if p:
                merged.add(p)
    return ", ".join(sorted(merged))


def _prepare_sources_aggregated_df(df_details: pd.DataFrame, include_mondo: bool = False) -> pd.DataFrame:
    required = {"RBRC", "Sources"}
    if include_mondo:
        required.add("MONDO_ID")
    if df_details is None or df_details.empty or not required.issubset(df_details.columns):
        return pd.DataFrame()

    work = df_details.copy()
    work["RBRC"] = work["RBRC"].astype(str).str.strip().str.removesuffix(".0")
    work["Sources"] = work["Sources"].astype(str).map(_normalize_sources_key)

    group_cols = ["RBRC"]
    if include_mondo:
        work["MONDO_ID"] = work["MONDO_ID"].astype(str).str.strip()
        group_cols = ["MONDO_ID", "RBRC"]

    rb = (
        work.groupby(group_cols, dropna=False)["Sources"]
        .agg(_merge_source_tokens)
        .reset_index()
    )
    rb["Sources"] = rb["Sources"].astype(str).map(_normalize_sources_key)
    return rb


def _prepare_mondo_rbrc_with_global_sources(
    df_details: pd.DataFrame,
    global_source_df: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """Return one row per (MONDO_ID, RBRC) using a canonical RBRC-level source signature.

    Graph3 is defined on RBRC-level global source signatures.
    To keep Graph4 fully comparable with Graph3 across all MONDO terms,
    each (MONDO_ID, RBRC) pair must inherit the same canonical Sources bucket
    that the RBRC has in the full candidate universe, rather than recomputing
    a disease-local bucket.
    """
    required = {"MONDO_ID", "RBRC", "Sources"}
    if df_details is None or df_details.empty or not required.issubset(df_details.columns):
        return pd.DataFrame()

    work = df_details.copy()
    work["MONDO_ID"] = work["MONDO_ID"].astype(str).str.strip()
    work["RBRC"] = work["RBRC"].astype(str).str.strip().str.removesuffix(".0")
    work["Sources"] = work["Sources"].astype(str).map(_normalize_sources_key)
    work = work[(work["MONDO_ID"] != "") & (work["RBRC"] != "")].copy()
    if work.empty:
        return pd.DataFrame()

    if global_source_df is None:
        global_source_df = _prepare_sources_aggregated_df(work, include_mondo=False)
    else:
        global_source_df = global_source_df.copy()
        if global_source_df.empty or not {"RBRC", "Sources"}.issubset(global_source_df.columns):
            return pd.DataFrame()
        global_source_df["RBRC"] = global_source_df["RBRC"].astype(str).str.strip().str.removesuffix(".0")
        global_source_df["Sources"] = global_source_df["Sources"].astype(str).map(_normalize_sources_key)

    pairs = work[["MONDO_ID", "RBRC"]].drop_duplicates().copy()
    rb = pairs.merge(global_source_df[["RBRC", "Sources"]].drop_duplicates(), on="RBRC", how="left")
    rb["Sources"] = rb["Sources"].fillna("").astype(str).map(_normalize_sources_key)
    return rb


def _extract_seed_mondo_entries_from_step3_stdout(text: str) -> Tuple[List[str], Dict[str, str], Dict[str, str]]:
    if not text:
        return [], {}, {}

    ids: List[str] = []
    label_map: Dict[str, str] = {}
    source_map: Dict[str, str] = {}
    in_section = False

    def _extract_english_label(rest: str) -> str:
        rest = re.sub(r"\s*\[Sources:.*?\]\s*$", "", str(rest)).strip()
        parts = [p.strip() for p in rest.split(",") if p.strip()]
        if not parts:
            return ""
        en_parts = []
        for p in parts:
            if re.search(r"[ぁ-んァ-ン一-龥]", p):
                break
            en_parts.append(p)
        return ", ".join(en_parts).strip()

    for raw_line in str(text).splitlines():
        line = raw_line.rstrip()
        if "[0.1] 疾患関連ヒト遺伝子を持つ MONDO 一覧" in line:
            in_section = True
            continue
        if not in_section:
            continue
        if re.match(r"^\[1\]", line.strip()):
            break

        m = re.match(r"^\s*-\s*(MONDO_\d+)\s*:\s*(.*?)\s*\[Sources:\s*(.*?)\]\s*$", line)
        if not m:
            continue

        mid, rest, src = m.groups()
        mid = mid.strip()
        src = _normalize_sources_key(src.strip())

        if mid not in ids:
            ids.append(mid)

        en_label = _extract_english_label(rest)
        if en_label and en_label != "N/A" and mid not in label_map:
            label_map[mid] = en_label
        if src and mid not in source_map:
            source_map[mid] = src

    return ids, label_map, source_map





def _prepare_plotly_figure_for_export(fig):
    """Return a white-background, high-quality static-export clone of fig."""
    export_fig = go.Figure(fig)
    width = max(int(export_fig.layout.width or 0), 1600)
    height = max(int(export_fig.layout.height or 0), 1000)
    margin = dict(export_fig.layout.margin.to_plotly_json()) if export_fig.layout.margin else {}
    margin = {
        "l": max(int(margin.get("l", 0) or 0), 520),
        "r": max(int(margin.get("r", 0) or 0), 260),
        "t": max(int(margin.get("t", 0) or 0), 90),
        "b": max(int(margin.get("b", 0) or 0), 90),
    }
    export_fig.update_layout(
        template="plotly_white",
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="black", size=16),
        title=dict(x=0.02),
        width=width,
        height=height,
        margin=margin,
        legend=dict(
            bgcolor="rgba(255,255,255,0.9)",
            bordercolor="rgba(0,0,0,0.15)",
            borderwidth=1,
            x=1.02,
            y=1.0,
            xanchor="left",
            yanchor="top",
            traceorder="normal",
        ),
    )
    export_fig.update_xaxes(showgrid=True, gridcolor="rgba(0,0,0,0.10)", zeroline=False, automargin=True)
    export_fig.update_yaxes(automargin=True)

    for tr in export_fig.data:
        name = str(getattr(tr, 'name', '') or '')
        if getattr(tr, "type", "") == "sunburst":
            continue
        if name in ROOT_BAR_COLORS:
            tr.marker.color = ROOT_BAR_COLORS[name]
        elif not getattr(getattr(tr, "marker", None), "color", None):
            tr.marker.color = _resolve_source_color(name)

    return export_fig


@st.cache_data(show_spinner=False)
def _plotly_to_image_cached(fig_json: str, ext: str) -> bytes:
    """Convert Plotly fig (json) to bytes with export-safe styling.

    NOTE: Heavy; cache to avoid repeated conversion across reruns.
    """
    fig = pio.from_json(fig_json)
    export_fig = _prepare_plotly_figure_for_export(fig)
    scale = 3 if ext == "png" else 1
    return pio.to_image(export_fig, format=ext, scale=scale)


def _plotly_download_buttons(fig, basename: str, key_prefix: str) -> None:
    """Provide PNG/SVG/PDF downloads for a Plotly figure (lazy generation).

    - Buttons appear immediately (fast)
    - Image bytes are generated only when the user requests them
    - Requires kaleido
    """
    formats = [("PNG", "png", "image/png"), ("SVG", "svg", "image/svg+xml"), ("PDF", "pdf", "application/pdf")]
    cols = st.columns(3)
    fig_json = fig.to_json()

    st.caption("保存: 形式ボタンで生成 → 生成後にダウンロード")

    for (label, ext, mime), col in zip(formats, cols):
        gen_key = f"{key_prefix}_{ext}_gen"
        data_key = f"{key_prefix}_{ext}_bytes"
        with col:
            if st.button(label, key=gen_key, use_container_width=True):
                try:
                    with st.spinner(f"{label} を生成中..."):
                        st.session_state[data_key] = _plotly_to_image_cached(fig_json, ext)
                except Exception as e:
                    st.session_state.pop(data_key, None)
                    st.warning(f"静的画像の書き出しに失敗しました（kaleido が必要な場合があります）: {e}")

            if data_key in st.session_state:
                st.download_button(
                    f"{label} をダウンロード",
                    data=st.session_state[data_key],
                    file_name=f"{basename}.{ext}",
                    mime=mime,
                    key=f"{key_prefix}_{ext}_dl",
                    use_container_width=True,
                )


def _evaluate_plot_limits(df_details: pd.DataFrame, root_mid: str | None = None) -> dict:
    """Return plotting guard metrics and stop/warn flags.

    - mondo_count: unique MONDO count in df_details
    - max_rbrc_per_mondo: max unique RBRC count among MONDOs
    - root_union_count: unique RBRC count across all rows in df_details
    """
    if df_details is None or df_details.empty or "RBRC" not in df_details.columns:
        return {
            "mondo_count": 0,
            "max_rbrc_per_mondo": 0,
            "root_union_count": 0,
            "warn": False,
            "hard_stop": False,
            "reasons": [],
        }

    work = df_details.copy()
    if "MONDO_ID" in work.columns:
        mids = work["MONDO_ID"].astype(str).map(_normalize_mondo_id)
    elif "Mapped_Disease" in work.columns:
        mids = work["Mapped_Disease"].astype(str).map(_normalize_mondo_id)
    else:
        mids = pd.Series([""] * len(work), index=work.index)
    work = work.assign(_MONDO_ID_NORM=mids)
    work = work[work["_MONDO_ID_NORM"].astype(str).str.strip() != ""].copy()

    mondo_count = int(work["_MONDO_ID_NORM"].nunique()) if not work.empty else 0
    if not work.empty:
        per_mondo = work.groupby("_MONDO_ID_NORM")["RBRC"].nunique()
        max_rbrc_per_mondo = int(per_mondo.max()) if len(per_mondo) else 0
    else:
        max_rbrc_per_mondo = 0
    root_union_count = int(work["RBRC"].dropna().astype(str).nunique()) if not work.empty else 0

    mondo_count_hard = int(st.session_state.get("mondo_count_hard_setting", MONDO_COUNT_HARD))
    max_rbrc_per_mondo_hard = int(st.session_state.get("max_rbrc_per_mondo_hard_setting", MAX_RBRC_PER_MONDO_HARD))
    root_union_hard = int(st.session_state.get("root_union_hard_setting", ROOT_UNION_HARD))

    warn = (mondo_count > MONDO_COUNT_WARN or max_rbrc_per_mondo > MAX_RBRC_PER_MONDO_WARN or root_union_count > ROOT_UNION_WARN)
    hard_stop = (mondo_count > mondo_count_hard or max_rbrc_per_mondo > max_rbrc_per_mondo_hard or root_union_count > root_union_hard)

    reasons = []
    if mondo_count > mondo_count_hard:
        reasons.append(f"検出MONDO件数: {mondo_count}（上限 {mondo_count_hard}）")
    if max_rbrc_per_mondo > max_rbrc_per_mondo_hard:
        reasons.append(f"最大ユニークRBRC件数/MONDO: {max_rbrc_per_mondo}（上限 {max_rbrc_per_mondo_hard}）")
    if root_union_count > root_union_hard:
        reasons.append(f"ROOT union ユニークRBRC件数: {root_union_count}（上限 {root_union_hard}）")

    return {
        "mondo_count": mondo_count,
        "max_rbrc_per_mondo": max_rbrc_per_mondo,
        "root_union_count": root_union_count,
        "warn": warn,
        "hard_stop": hard_stop,
        "reasons": reasons,
    }


def _render_plot_limit_message(metrics: dict) -> None:
    if not metrics:
        return
    mondo_count_hard = int(st.session_state.get("mondo_count_hard_setting", MONDO_COUNT_HARD))
    max_rbrc_per_mondo_hard = int(st.session_state.get("max_rbrc_per_mondo_hard_setting", MAX_RBRC_PER_MONDO_HARD))
    root_union_hard = int(st.session_state.get("root_union_hard_setting", ROOT_UNION_HARD))
    lines = [
        "ヒット件数が多すぎるため、図の生成を停止しました。より下位の疾患語で再検索してください。",
        f"- 検出MONDO件数: {metrics.get('mondo_count', 0)}（上限 {mondo_count_hard}）",
        f"- 最大ユニークRBRC件数/MONDO: {metrics.get('max_rbrc_per_mondo', 0)}（上限 {max_rbrc_per_mondo_hard}）",
        f"- ROOT union ユニークRBRC件数: {metrics.get('root_union_count', 0)}（上限 {root_union_hard}）",
    ]
    st.warning("\n".join(lines))


def _filter_log_text(text: str) -> str:
    """Remove known noisy lines to keep logs readable."""
    if not text:
        return ""
    text = _redact_secret_text(text)

    noisy_regexes = [
        r"^Loading weights:.*$",
        r"^XLMRobertaModel LOAD REPORT.*$",
        r"^Key\s+\|\s+Status.*$",
        r"^[- ]{5,}.*$",
        r"^embeddings\.position_ids\s+\|\s+UNEXPECTED.*$",
        r"^Notes:.*$",
        r"^-\s+UNEXPECTED.*$",
        r"^/.*ElasticsearchWarning:.*$",
        r"^\s+res = self\.es\.search\(.*$",
    ]
    out_lines: List[str] = []
    for line in text.splitlines():
        if any(re.match(rx, line) for rx in noisy_regexes):
            continue
        out_lines.append(line)
    return "\n".join(out_lines).strip()


# -----------------------------
# Domain logic
# -----------------------------

@dataclass
class Step3Outputs:
    log_path: Path
    summary_csv: Path
    details_csv: Path
    stdout: str
    stderr: str
    target_mondo_id: Optional[str] = None  # e.g., 'MONDO_0004976'
    sparql_mouse_rq: Optional[Path] = None
    sparql_seed_rq: Optional[Path] = None
    sparql_queries_json: Optional[Path] = None


def run_step3(step3_script: str, input_csv: Path, cwd: Optional[str] = None, llm_model_symbol_completion: str = "gpt-6-luna", llm_model_gene_explanation: str = "gpt-6-luna", log_dir: Optional[Path] = None, env_extra: Optional[Dict[str, str]] = None) -> Step3Outputs:
    script_path = Path(step3_script)
    if not script_path.is_absolute() and cwd:
        script_path = Path(cwd) / step3_script

    script_text = ""
    try:
        script_text = script_path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        raise RuntimeError(f"Step3 スクリプトを読み込めません: {script_path} / {e}")

    has_externalized_models = (
        "--llm-model-symbol-completion" in script_text
        and "--llm-model-gene-explanation" in script_text
    )
    if not has_externalized_models:
        raise RuntimeError(
            "選択中の Step3 スクリプトは、外出しした LLM モデル引数に未対応です。\n"
            f"選択中: {script_path.name}\n"
            "対応版 Step3 を指定してください。\n"
            "推奨: step3_sparqlonly_fix_allgenes_xsearch_genecount_only_seedmondos_sources_step3_models_externalized_gpt6luna_fix8_extdb_mouse_backfill.py"
        )

    step3_args = [
        "--input-csv", str(input_csv),
        "--llm-model-symbol-completion", str(llm_model_symbol_completion),
        "--llm-model-gene-explanation", str(llm_model_gene_explanation),
    ]
    if log_dir is not None:
        step3_args.extend(["--log-dir", str(log_dir)])

    rc, out, err = _run_interactive_python(
        step3_script,
        step3_args,
        stdin_text="",
        cwd=cwd,
        env_extra=env_extra,
    )
    if rc != 0:
        raise RuntimeError(f"Step3 failed (rc={rc})\n{err}\n{out}")

    summary = _extract_path_from_stdout(r"STATISTICS_CSV_PATH:\s*(.+)", out)
    details = _extract_path_from_stdout(r"DETAILS_CSV_PATH:\s*(.+)", out)
    sparql_mouse = _extract_path_from_stdout(r"SPARQL_MOUSE_RQ_PATH:\s*(.+)", out)
    sparql_seed = _extract_path_from_stdout(r"SPARQL_SEED_RQ_PATH:\s*(.+)", out)
    sparql_manifest = _extract_path_from_stdout(r"SPARQL_QUERIES_JSON_PATH:\s*(.+)", out)
    logp = _extract_path_from_stdout(r"✅\s*解析完了:\s*(.+)", out)

    if not summary or not details or not logp:
        raise RuntimeError(
            "Step3 completed but could not parse output paths.\n"
            "Please confirm Step3 prints STATISTICS_CSV_PATH and DETAILS_CSV_PATH lines."
        )

    return Step3Outputs(
        log_path=Path(summary).parent / Path(logp).name if not Path(logp).is_absolute() else Path(logp),
        summary_csv=Path(summary),
        details_csv=Path(details),
        stdout=out,
        stderr=err,
        target_mondo_id=_extract_target_mondo_id(out),
        sparql_mouse_rq=Path(sparql_mouse) if sparql_mouse else None,
        sparql_seed_rq=Path(sparql_seed) if sparql_seed else None,
        sparql_queries_json=Path(sparql_manifest) if sparql_manifest else None,
    )






def render_configurable_dataframe(
    df: pd.DataFrame,
    *,
    label: str,
    key_prefix: str,
    default_columns=None,
    use_container_width: bool = True,
    hide_index: bool = True,
    selector_expanded: bool = False,
):
    """
    Streamlit の内蔵列選択アイコンに依存せず、
    表示カラムを常に再設定できる表表示 helper。
    """
    if df is None:
        st.info("表示できるデータがありません。")
        return

    if not isinstance(df, pd.DataFrame):
        df = pd.DataFrame(df)

    if len(df.columns) == 0:
        st.info("表示できる列がありません。")
        return

    all_cols = list(df.columns)

    if default_columns is None:
        default_columns = all_cols.copy()
    else:
        default_columns = [c for c in default_columns if c in all_cols]
        if not default_columns:
            default_columns = all_cols.copy()

    # v2: column-selection state key version bump
    # UI が旧列名や旧表示順を保持している場合でも、現行 default_columns へ安全に戻す
    state_key = f"{key_prefix}_visible_cols_state_v2"
    widget_key = f"{key_prefix}_visible_cols_widget_v2"

    def _migrate_cols(cols):
        out = []
        for c in cols:
            if c == "riken_related_mouse_gene_id":
                c = "riken_related_gene_id"
            elif c == "riken_related_mouse_gene_symbol":
                c = "riken_related_gene_symbol"
            if c in all_cols and c not in out:
                out.append(c)
        return out

    if state_key not in st.session_state:
        st.session_state[state_key] = default_columns.copy()

    st.session_state[state_key] = _migrate_cols(st.session_state.get(state_key, default_columns.copy()))
    if not st.session_state[state_key]:
        st.session_state[state_key] = default_columns.copy()

    initial_widget_value = _migrate_cols(st.session_state.get(widget_key, st.session_state[state_key].copy()))
    if not initial_widget_value:
        initial_widget_value = st.session_state[state_key].copy()

    with st.expander(f"⚙️ {label}：表示カラムを選択", expanded=selector_expanded):
        st.caption("表示だけを切り替えます。件数や集計結果は変わりません。")

        cols_btn = st.columns(2)
        with cols_btn[0]:
            if st.button("全カラム表示", key=f"{key_prefix}_show_all", use_container_width=True):
                st.session_state[state_key] = all_cols.copy()
                if widget_key in st.session_state:
                    del st.session_state[widget_key]
                st.rerun()

        with cols_btn[1]:
            if st.button("推奨表示に戻す", key=f"{key_prefix}_reset_default", use_container_width=True):
                st.session_state[state_key] = default_columns.copy()
                if widget_key in st.session_state:
                    del st.session_state[widget_key]
                st.rerun()

        selected_cols = st.multiselect(
            "表示するカラム",
            options=all_cols,
            default=initial_widget_value,
            key=widget_key,
        )

    st.session_state[state_key] = _migrate_cols(selected_cols)

    visible_cols = [c for c in st.session_state[state_key] if c in all_cols]

    if not visible_cols:
        st.warning("表示カラムが 0 件です。少なくとも 1 列は選択してください。")
        return

    st.dataframe(
        df,
        column_order=visible_cols,
        use_container_width=use_container_width,
        hide_index=hide_index,
        key=f"{key_prefix}_df",
    )


def build_rbrc_detail_table(df: pd.DataFrame) -> pd.DataFrame:
    """
    RBRC 詳細表の最終出力を頑健に正規化する。
    - AES を除外
    - textual null を空欄化
    - 旧 riken_related_mouse_gene_* を正式列 riken_related_gene_* に統一
    - 正式列が空のときは extdb 側の gene を使って補完
    - UI/CSV とも同じ列順で出力
    """
    if df is None or len(df) == 0:
        return pd.DataFrame()

    out = df.copy()

    if "RBRC" not in out.columns and "RBRC_ID" in out.columns:
        out = out.rename(columns={"RBRC_ID": "RBRC"})

    # Ensure columns exist
    wanted = [
        "RBRC", "Strain",
        "riken_related_gene_id", "riken_related_gene_symbol",
        "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol",
        "extdb_related_human_gene_id", "extdb_related_human_gene_symbol",
        "Mutation_Type", "Sources", "Mapped_Disease", "MONDO_ID",
        # backward-compatible source columns for migration
        "riken_related_mouse_gene_id", "riken_related_mouse_gene_symbol",
    ]
    for c in wanted:
        if c not in out.columns:
            out[c] = ""

    # Global AES exclusion
    _rbrc = out["RBRC"].fillna("").astype(str).str.strip()
    out = out[~_rbrc.str.startswith("RBRC-AES", na=False)].copy()

    # normalize textual nulls
    for c in out.columns:
        out[c] = (
            out[c]
            .fillna("")
            .astype(str)
            .replace({"nan": "", "NaN": "", "None": "", "<NA>": ""})
            .str.strip()
        )

    def _clean_id_series(s: pd.Series) -> pd.Series:
        return (
            s.astype(str)
             .replace({"nan": "", "NaN": "", "None": "", "<NA>": ""})
             .str.replace(r"ncbigene:(\d+)\.0$", r"ncbigene:\1", regex=True)
             .str.strip()
        )

    def _clean_sym_series(s: pd.Series) -> pd.Series:
        return (
            s.astype(str)
             .replace({"nan": "", "NaN": "", "None": "", "<NA>": ""})
             .str.strip()
        )

    # sanitize source columns
    for c in ["riken_related_gene_id", "riken_related_mouse_gene_id",
              "extdb_related_mouse_gene_id", "extdb_related_human_gene_id"]:
        out[c] = _clean_id_series(out[c])
    for c in ["riken_related_gene_symbol", "riken_related_mouse_gene_symbol",
              "extdb_related_mouse_gene_symbol", "extdb_related_human_gene_symbol"]:
        out[c] = _clean_sym_series(out[c])

    # migrate old riken mouse columns into generic columns if generic is empty
    out["riken_related_gene_id"] = out["riken_related_gene_id"].where(
        out["riken_related_gene_id"].ne(""), out["riken_related_mouse_gene_id"]
    )
    out["riken_related_gene_symbol"] = out["riken_related_gene_symbol"].where(
        out["riken_related_gene_symbol"].ne(""), out["riken_related_mouse_gene_symbol"]
    )

    # robust fallback: generic riken columns should never be blank when another gene id/symbol is present
    # priority: existing generic/old riken > extdb mouse > extdb human
    out["riken_related_gene_id"] = out["riken_related_gene_id"].where(
        out["riken_related_gene_id"].ne(""), out["extdb_related_mouse_gene_id"]
    )
    out["riken_related_gene_id"] = out["riken_related_gene_id"].where(
        out["riken_related_gene_id"].ne(""), out["extdb_related_human_gene_id"]
    )

    out["riken_related_gene_symbol"] = out["riken_related_gene_symbol"].where(
        out["riken_related_gene_symbol"].ne(""), out["extdb_related_mouse_gene_symbol"]
    )
    out["riken_related_gene_symbol"] = out["riken_related_gene_symbol"].where(
        out["riken_related_gene_symbol"].ne(""), out["extdb_related_human_gene_symbol"]
    )

    # If Sources indicates MGI/Medgen and generic id is still empty, leave empty rather than fabricate.
    # Column order is fixed and aligned with UI.
    keep = [
        "RBRC", "Strain",
        "riken_related_gene_id", "riken_related_gene_symbol",
        "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol",
        "extdb_related_human_gene_id", "extdb_related_human_gene_symbol",
        "Mutation_Type", "Sources", "Mapped_Disease", "MONDO_ID"
    ]
    out = out[keep].drop_duplicates().copy()

    sort_cols = [c for c in ["RBRC", "Mapped_Disease", "riken_related_gene_symbol", "Strain"] if c in out.columns]
    if sort_cols:
        out = out.sort_values(sort_cols)

    return out.reset_index(drop=True)

def build_views(summary_csv: Path, details_csv: Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, str]]:
    """Return (A_summary_df, A_details_df, B_details_df, mondo_id->label)."""
    df_sum = pd.read_csv(summary_csv, dtype=str, keep_default_na=False).fillna("")
    df_det = pd.read_csv(details_csv, dtype=str, keep_default_na=False).fillna("")

    # Global AES exclusion: app-wide, immediately after loading details_table
    if "RBRC" in df_det.columns:
        _rbrc_all = df_det["RBRC"].astype(str).str.strip()
        df_det = df_det[~_rbrc_all.str.startswith("RBRC-AES", na=False)].copy()
    # Canonicalize extdb/riken gene columns
    for col in [
        "extdb_related_human_gene_id", "extdb_related_human_gene_symbol",
        "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol",
        "riken_related_gene_id", "riken_related_gene_symbol",
        "riken_related_mouse_gene_id", "riken_related_mouse_gene_symbol",
    ]:
        if col not in df_det.columns:
            df_det[col] = ""

    if (not df_det["riken_related_gene_id"].astype(str).str.strip().any()) and "riken_related_mouse_gene_id" in df_det.columns:
        df_det["riken_related_gene_id"] = df_det["riken_related_mouse_gene_id"]
    if (not df_det["riken_related_gene_symbol"].astype(str).str.strip().any()) and "riken_related_mouse_gene_symbol" in df_det.columns:
        df_det["riken_related_gene_symbol"] = df_det["riken_related_mouse_gene_symbol"]

    # backward compatibility for older files
    rename_map = {}
    if "related_human_gene_id" in df_det.columns and not df_det["extdb_related_human_gene_id"].astype(str).str.strip().any():
        rename_map["related_human_gene_id"] = "extdb_related_human_gene_id"
    if "related_human_gene_symbol" in df_det.columns and not df_det["extdb_related_human_gene_symbol"].astype(str).str.strip().any():
        rename_map["related_human_gene_symbol"] = "extdb_related_human_gene_symbol"
    if "related_mouse_gene_id" in df_det.columns and not df_det["riken_related_gene_id"].astype(str).str.strip().any():
        rename_map["related_mouse_gene_id"] = "riken_related_gene_id"
    if "related_mouse_gene_symbol" in df_det.columns and not df_det["riken_related_gene_symbol"].astype(str).str.strip().any():
        rename_map["related_mouse_gene_symbol"] = "riken_related_gene_symbol"
    if rename_map:
        df_det = df_det.rename(columns=rename_map)

    # Drop duplicate-named columns if any were introduced upstream
    df_det = df_det.loc[:, ~df_det.columns.duplicated()].copy()

    def _norm_count_cell(x):
        s = str(x).strip()
        if not s or s.lower() == "nan":
            return "0"
        if s.endswith(".0") and s[:-2].isdigit():
            return s[:-2]
        return s

    def _norm_gene_id_cell(x):
        s = str(x).strip()
        if not s or s.lower() == "nan" or s == "UNKNOWN":
            return ""
        parts = []
        for p in s.split(","):
            p = p.strip()
            if not p:
                continue
            if p.endswith(".0") and p[:-2].isdigit():
                p = p[:-2]
            parts.append(p)
        return ",".join(parts)

    if "extdb_related_human_gene_id" in df_det.columns:
        df_det["extdb_related_human_gene_id"] = df_det["extdb_related_human_gene_id"].map(_norm_gene_id_cell)
    if "extdb_related_human_gene_symbol" in df_det.columns:
        df_det["extdb_related_human_gene_symbol"] = df_det["extdb_related_human_gene_symbol"].astype(str).str.strip().replace({"nan": "", "NaN": ""})
    if "extdb_related_mouse_gene_id" in df_det.columns:
        df_det["extdb_related_mouse_gene_id"] = (
            df_det["extdb_related_mouse_gene_id"]
            .astype(str)
            .str.replace(r"ncbigene:(\d+)\.0$", r"ncbigene:\1", regex=True)
            .str.strip()
        )
    if "extdb_related_mouse_gene_symbol" in df_det.columns:
        df_det["extdb_related_mouse_gene_symbol"] = df_det["extdb_related_mouse_gene_symbol"].astype(str).str.strip().replace({"nan": "", "NaN": ""})
    if "riken_related_gene_id" in df_det.columns:
        df_det["riken_related_gene_id"] = (
            df_det["riken_related_gene_id"]
            .astype(str)
            .str.replace(r"ncbigene:(\d+)\.0$", r"ncbigene:\1", regex=True)
            .str.strip()
        )
    if "riken_related_gene_symbol" in df_det.columns:
        df_det["riken_related_gene_symbol"] = df_det["riken_related_gene_symbol"].astype(str).str.strip().replace({"nan": "", "NaN": ""})
    # internal compatibility only
    if "extdb_related_mouse_gene_symbol" in df_det.columns:
        df_det["Genes"] = df_det["extdb_related_mouse_gene_symbol"].astype(str).str.strip()


    # count-like columns: keep integer-looking values as integer strings (e.g. 0.0 -> 0)
    for c in df_sum.columns:
        if c.startswith("系統数") or c.endswith("_count") or c == "count":
            df_sum[c] = df_sum[c].map(_norm_count_cell)

    # Build label map from summary (authoritative for display)
    id2label: Dict[str, str] = {}
    if "Mapped_Disease" in df_sum.columns:
        for s in df_sum["Mapped_Disease"].dropna().astype(str).tolist():
            mid, lab = _parse_mapped_disease_to_id_label(s)
            if mid and lab and mid not in id2label:
                id2label[mid] = lab

    # Rebuild summary from AES-filtered details so all app outputs stay aligned
    if {"MONDO_ID", "RBRC"}.issubset(df_det.columns):
        _tmp = df_det.copy()
        _tmp["MONDO_ID"] = _tmp["MONDO_ID"].astype(str).str.strip()
        _tmp["RBRC"] = _tmp["RBRC"].astype(str).str.strip()
        _tmp = _tmp[(_tmp["MONDO_ID"] != "") & (_tmp["RBRC"] != "")]
        if not _tmp.empty:
            _sum = _tmp.groupby("MONDO_ID")["RBRC"].nunique().reset_index(name="系統数")
            def _mid_to_label(mid):
                lab = str(id2label.get(str(mid).strip(), "") or "").strip()
                return f"{mid}: {lab}" if lab else str(mid).strip()
            _sum["Mapped_Disease"] = _sum["MONDO_ID"].map(_mid_to_label)
            df_sum = _sum[["Mapped_Disease", "系統数"]].copy()
            df_sum["系統数"] = df_sum["系統数"].astype(str)

        # IMPORTANT:
        # details_table 由来の詳細CSV/UIでも Mapped_Disease を必ず埋める。
        # これをしないと ROOT/B1/SUBSET の rbrc_detail で Mapped_Disease が空欄になる。
        if "Mapped_Disease" not in df_det.columns:
            df_det["Mapped_Disease"] = ""
        _mid_series = df_det["MONDO_ID"].astype(str).str.strip()
        _mapped_series = df_det["Mapped_Disease"].astype(str).str.strip()
        def _mid_to_label(mid):
            lab = str(id2label.get(str(mid).strip(), "") or "").strip()
            return f"{mid}: {lab}" if lab else str(mid).strip()
        df_det["Mapped_Disease"] = _mapped_series.where(
            _mapped_series != "",
            _mid_series.map(_mid_to_label)
        )

    # Gene-linked view: extdb human / extdb mouse / riken gene のいずれかの遺伝子IDがある行を推定候補とする
    if any(c in df_det.columns for c in ["extdb_related_human_gene_id", "extdb_related_mouse_gene_id", "riken_related_gene_id"]):
        _h = df_det.get("extdb_related_human_gene_id", "").astype(str).str.strip() if "extdb_related_human_gene_id" in df_det.columns else ""
        _em = df_det.get("extdb_related_mouse_gene_id", "").astype(str).str.strip() if "extdb_related_mouse_gene_id" in df_det.columns else ""
        _rm = df_det.get("riken_related_gene_id", "").astype(str).str.strip() if "riken_related_gene_id" in df_det.columns else ""
        if all(isinstance(x, str) for x in [_h, _em, _rm]):
            df_det_gene = df_det.copy()
        else:
            masks = []
            for _x in (_h, _em, _rm):
                if not isinstance(_x, str):
                    masks.append(_x != "")
            m = masks[0]
            for mm in masks[1:]:
                m = m | mm
            df_det_gene = df_det[m].copy()
            if "Sources" in df_det_gene.columns:
                _src = df_det_gene["Sources"].astype(str)
                df_det_gene = df_det_gene[~_src.str.contains(r'(^|,\s*)Models(\s*,|$)', regex=True, na=False)].copy()
    elif "related_gene_id" in df_det.columns:
        df_det_gene = df_det[df_det["related_gene_id"].astype(str).str.strip() != ""].copy()
    else:
        df_det_gene = df_det.copy()

    return df_sum, df_det, df_det_gene, id2label


def plot_source_summary(df_details: pd.DataFrame, title: str):
    # Unique RBRC by aggregated Sources + full hover RBRC list
    if not {"Sources", "RBRC"}.issubset(df_details.columns):
        return None

    rb = _prepare_sources_aggregated_df(df_details, include_mondo=False)
    if rb.empty:
        return None

    tmp = (
        rb.groupby("Sources", dropna=False)["RBRC"]
        .agg(lambda s: _uniq_sorted_rbrc(s))
        .reset_index(name="RBRC_list")
    )
    tmp["ユニーク系統数"] = tmp["RBRC_list"].map(len)
    tmp["RBRC_hover"] = tmp["RBRC_list"].map(_hover_rbrc_text_full)
    tmp["Sources"] = tmp["Sources"].astype(str).map(_normalize_sources_key)
    tmp = tmp.sort_values("ユニーク系統数", ascending=False)

    source_color_map = _build_source_color_map(tmp["Sources"].tolist())
    fig = px.bar(
        tmp,
        x="Sources",
        y="ユニーク系統数",
        title=title,
        color="Sources",
        color_discrete_map=source_color_map,
        custom_data=["Sources", "RBRC_hover"],
    )
    fig.update_traces(
        hovertemplate=(
            "Sources=%{customdata[0]}<br>"
            "ユニーク系統数=%{y}<br>"
            "%{customdata[1]}"
            "<extra></extra>"
        ),
        showlegend=False,
    )
    fig.update_layout(xaxis_title="Sources", yaxis_title="ユニーク系統数（RBRC重複除外）")
    return fig

def plot_disease_distribution(
    df_details: pd.DataFrame,
    id2label: Dict[str, str],
    title: str,
    all_mondo_ids: Optional[List[str]] = None,
    all_mondo_label_map: Optional[Dict[str, str]] = None,
    global_source_df: Optional[pd.DataFrame] = None,
):
    # Graph4 sources must use the same semantics as Graph3:
    # aggregate source tokens at MONDO_ID + RBRC level, not MONDO-only level.
    if not {"MONDO_ID", "RBRC", "Sources"}.issubset(df_details.columns):
        return None

    all_mondo_label_map = all_mondo_label_map or {}

    def _label(mid: str) -> str:
        lab = str(id2label.get(mid, "") or "").strip()
        if not lab:
            lab = str(all_mondo_label_map.get(mid, "") or "").strip()
        return f"{mid}: {lab}" if lab else mid

    rb = _prepare_mondo_rbrc_with_global_sources(df_details, global_source_df=global_source_df)
    if rb.empty:
        return None

    tmp = (
        rb.groupby(["MONDO_ID", "Sources"], dropna=False)["RBRC"]
        .agg(lambda s: _uniq_sorted_rbrc(s))
        .reset_index(name="RBRC_list")
    )
    tmp["count"] = tmp["RBRC_list"].map(len)
    tmp = tmp[tmp["count"] > 0].copy()
    if tmp.empty:
        return None

    tmp["Label"] = tmp["MONDO_ID"].astype(str).map(_label)
    tmp["RBRC_hover"] = tmp["RBRC_list"].map(_hover_rbrc_text_full)
    tmp["Sources"] = tmp["Sources"].astype(str).map(_normalize_sources_key)

    totals = (
        tmp.groupby(["MONDO_ID", "Label"], dropna=False)["count"]
        .sum()
        .reset_index()
        .sort_values(["count", "Label"], ascending=[False, True])
    )
    category_order = totals["Label"].tolist()
    tmp["Label"] = pd.Categorical(tmp["Label"], categories=category_order, ordered=True)

    source_color_map = _build_source_color_map(tmp["Sources"].tolist())
    fig = px.bar(
        tmp,
        x="count",
        y="Label",
        color="Sources",
        color_discrete_map=source_color_map,
        orientation="h",
        title=title,
        custom_data=["MONDO_ID", "Sources", "RBRC_hover"],
    )
    fig.update_traces(
        hovertemplate=(
            "<b>%{y}</b><br>"
            "Sources=%{customdata[1]}<br>"
            "ユニーク系統数=%{x}<br>"
            "%{customdata[2]}"
            "<extra></extra>"
        )
    )
    plot_height = max(520, 28 * max(len(category_order), 1) + 140)
    fig.update_layout(
        xaxis_title="系統数（ユニークRBRC）",
        yaxis_title="",
        height=plot_height,
        yaxis=dict(categoryorder="array", categoryarray=category_order, automargin=True),
    )
    return fig


def plot_root_union_bar(root_mid: str, root_label: str, count: int, title: str):
    """Single-bar plot for ROOT-union count (root + descendants)."""
    disp = f"{root_mid}: {root_label}" if root_label else root_mid
    df = pd.DataFrame([{ "Label": disp + " [ROOT union]", "count": int(count)}])
    fig = px.bar(
        df,
        x="count",
        y="Label",
        orientation="h",
        title=title,
        hover_data={"count": True, "Label": True},
    )
    fig.update_layout(xaxis_title="系統数（ユニークRBRC）", yaxis_title="")
    return fig




def build_source_summary_table(df_details: pd.DataFrame) -> pd.DataFrame:
    if not {"Sources", "RBRC"}.issubset(df_details.columns):
        return pd.DataFrame()

    rb = _prepare_sources_aggregated_df(df_details, include_mondo=False)
    if rb.empty:
        return pd.DataFrame()

    tmp = (
        rb.groupby("Sources", dropna=False)["RBRC"]
        .agg(lambda s: _uniq_sorted_rbrc(s))
        .reset_index(name="該当RBRC")
    )
    tmp["Sources"] = tmp["Sources"].astype(str).map(_normalize_sources_key)
    tmp["ユニーク系統数"] = tmp["該当RBRC"].map(len)
    tmp["該当RBRC"] = tmp["該当RBRC"].map(_join_full)
    return tmp[["Sources", "ユニーク系統数", "該当RBRC"]].sort_values("ユニーク系統数", ascending=False).reset_index(drop=True)


def build_disease_distribution_table(
    df_details: pd.DataFrame,
    id2label: Dict[str, str],
    all_mondo_ids: Optional[List[str]] = None,
    all_mondo_label_map: Optional[Dict[str, str]] = None,
    global_source_df: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    if not {"MONDO_ID", "RBRC", "Sources"}.issubset(df_details.columns):
        return pd.DataFrame()

    all_mondo_label_map = all_mondo_label_map or {}

    def _label(mid: str) -> str:
        lab = str(id2label.get(mid, "") or "").strip()
        if not lab:
            lab = str(all_mondo_label_map.get(mid, "") or "").strip()
        return f"{mid}: {lab}" if lab else mid

    rb = _prepare_mondo_rbrc_with_global_sources(df_details, global_source_df=global_source_df)
    if rb.empty:
        return pd.DataFrame()

    tmp = (
        rb.groupby(["MONDO_ID", "Sources"], dropna=False)["RBRC"]
        .agg(lambda s: _uniq_sorted_rbrc(s))
        .reset_index(name="該当RBRC")
    )
    tmp["系統数"] = tmp["該当RBRC"].map(len)
    tmp = tmp[tmp["系統数"] > 0].copy()
    if tmp.empty:
        return pd.DataFrame()

    tmp["Label"] = tmp["MONDO_ID"].astype(str).map(_label)
    tmp["Sources"] = tmp["Sources"].astype(str).map(_normalize_sources_key)
    tmp["該当RBRC"] = tmp["該当RBRC"].map(_join_full)

    totals = (
        tmp.groupby(["MONDO_ID", "Label"], dropna=False)["系統数"]
        .sum()
        .reset_index()
        .sort_values(["系統数", "Label"], ascending=[False, True])
    )
    order_map = {mid: i for i, mid in enumerate(totals["MONDO_ID"].tolist())}
    tmp["_ord"] = tmp["MONDO_ID"].astype(str).map(lambda x: order_map.get(x, 10**9))

    return (
        tmp[["Label", "MONDO_ID", "Sources", "系統数", "該当RBRC", "_ord"]]
        .sort_values(["_ord", "Sources"], ascending=[True, True])
        .drop(columns=["_ord"])
        .reset_index(drop=True)
    )


def build_root_union_source_table(df_root: pd.DataFrame, root_mid: str, id2label: Dict[str, str]) -> pd.DataFrame:
    if df_root is None or df_root.empty or "RBRC" not in df_root.columns:
        return pd.DataFrame()

    root_label = str(id2label.get(root_mid, "") or "").strip()
    label = f"{root_mid}: {root_label}".rstrip(": ") + " [ROOT union]"
    return pd.DataFrame([{
        "Label": label,
        "系統数": int(df_root["RBRC"].dropna().astype(str).nunique()),
        "該当RBRC": _join_full(_uniq_sorted_rbrc(df_root["RBRC"].tolist())),
    }])


def build_sunburst_source_table(df_details_gene: pd.DataFrame) -> pd.DataFrame:
    needed = {"MONDO_ID", "Mutation_Type", "Strain", "RBRC"}
    if df_details_gene is None or df_details_gene.empty or not needed.issubset(df_details_gene.columns):
        return pd.DataFrame()

    df = df_details_gene.copy()
    df = df[df["MONDO_ID"].astype(str).str.len() > 0].copy()
    if df.empty:
        return pd.DataFrame()

    df["RBRC"] = (
        df["RBRC"].astype(str).str.strip().str.replace(r"\.0$", "", regex=True)
    )
    gene_candidates = [
        "extdb_related_human_gene_symbol",
        "extdb_related_mouse_gene_symbol",
        "riken_related_gene_symbol",
        "Genes",
    ]
    def _pick_gene_label(row):
        for c in gene_candidates:
            if c in row.index:
                s = _clean_display_cell(row.get(c, ""))
                if s:
                    return s
        return "遺伝子未設定"

    df["遺伝子"] = df.apply(_pick_gene_label, axis=1)
    df["変異型"] = df["Mutation_Type"].map(lambda x: _normalize_sunburst_label(x, "未分類"))
    df["系統名"] = df["Strain"].map(lambda x: _normalize_sunburst_label(x, "名称未設定"))
    df["葉ID"] = df["RBRC"].astype(str)
    keep = [c for c in ["MONDO_ID", "遺伝子", "変異型", "系統名", "RBRC", "葉ID"] if c in df.columns]
    return df[keep].drop_duplicates().reset_index(drop=True)

def plot_sunburst_gene_hierarchy(df_details_gene: pd.DataFrame, id2label: Dict[str, str], root_mondo_id: str):
    import plotly.graph_objects as go

    needed = {"MONDO_ID", "Mutation_Type", "Strain", "RBRC"}
    if not needed.issubset(df_details_gene.columns):
        return None

    root_display = root_mondo_id

    df = df_details_gene.copy()
    df = df[df["MONDO_ID"].astype(str).str.len() > 0].copy()
    if df.empty:
        return None

    df["RBRC"] = (
        df["RBRC"]
        .astype(str)
        .str.strip()
        .str.replace(r"\.0$", "", regex=True)
    )

    gene_candidates = [
        "extdb_related_human_gene_symbol",
        "extdb_related_mouse_gene_symbol",
        "riken_related_gene_symbol",
        "Genes",
    ]
    def _pick_gene_label(row):
        for c in gene_candidates:
            if c in row.index:
                s = _clean_display_cell(row.get(c, ""))
                if s:
                    return s
        return "遺伝子未設定"

    df["_GENE_LABEL"] = df.apply(_pick_gene_label, axis=1)
    df["_MUT_LABEL"] = df["Mutation_Type"].map(lambda x: _normalize_sunburst_label(x, "未分類"))
    df["_STRAIN_LABEL"] = df["Strain"].map(lambda x: _normalize_sunburst_label(x, "名称未設定"))

    # 葉は path + RBRC で一意化
    df["_leaf"] = df["RBRC"].astype(str)
    df = df.drop_duplicates(subset=["MONDO_ID", "_GENE_LABEL", "_MUT_LABEL", "_STRAIN_LABEL", "_leaf"]).copy()

    def _uniq_sorted_rbrc(values):
        vals = sorted({str(v).strip().removesuffix(".0") for v in values if pd.notna(v) and str(v).strip()})
        return vals

    def _hover_rbrc_text(rbrc_list):
        if not rbrc_list:
            return ""
        return ", ".join([str(v) for v in rbrc_list if str(v).strip()])

    nodes = []

    all_rbrc = _uniq_sorted_rbrc(df["RBRC"])
    nodes.append({
        "id": root_display,
        "parent": "",
        "label": root_display,
        "value": 0,
        "count_display": len(all_rbrc),
        "hover_text": _hover_rbrc_text(all_rbrc),
    })

    for mondo_node, d_mondo in df.groupby("MONDO_ID", dropna=False):
        mondo_node = "" if pd.isna(mondo_node) else str(mondo_node)
        mondo_id = f"mondo::{mondo_node}"
        mondo_rbrc = _uniq_sorted_rbrc(d_mondo["RBRC"])
        nodes.append({
            "id": mondo_id,
            "parent": root_display,
            "label": mondo_node,
            "value": 0,
            "count_display": len(mondo_rbrc),
            "hover_text": _hover_rbrc_text(mondo_rbrc),
        })

        for gene, d_gene in d_mondo.groupby("_GENE_LABEL", dropna=False):
            gene = "" if pd.isna(gene) else str(gene)
            gene_id = f"{mondo_id}::gene::{gene}"
            gene_rbrc = _uniq_sorted_rbrc(d_gene["RBRC"])
            nodes.append({
                "id": gene_id,
                "parent": mondo_id,
                "label": gene,
                "value": 0,
                "count_display": len(gene_rbrc),
                "hover_text": _hover_rbrc_text(gene_rbrc),
            })

            for mutation_type, d_mut in d_gene.groupby("_MUT_LABEL", dropna=False):
                mutation_type = "" if pd.isna(mutation_type) else str(mutation_type)
                mut_id = f"{gene_id}::mut::{mutation_type}"
                mut_rbrc = _uniq_sorted_rbrc(d_mut["RBRC"])
                nodes.append({
                    "id": mut_id,
                    "parent": gene_id,
                    "label": mutation_type,
                    "value": 0,
                    "count_display": len(mut_rbrc),
                    "hover_text": _hover_rbrc_text(mut_rbrc),
                })

                for strain, d_strain in d_mut.groupby("_STRAIN_LABEL", dropna=False):
                    strain = "" if pd.isna(strain) else str(strain)
                    strain_id = f"{mut_id}::strain::{strain}"
                    strain_rbrc = _uniq_sorted_rbrc(d_strain["RBRC"])
                    nodes.append({
                        "id": strain_id,
                        "parent": mut_id,
                        "label": strain,
                        "value": len(strain_rbrc),
                        "count_display": len(strain_rbrc),
                        "hover_text": _hover_rbrc_text(strain_rbrc),
                    })

    node_df = pd.DataFrame(nodes)

    fig = go.Figure(go.Sunburst(
        ids=node_df["id"],
        parents=node_df["parent"],
        labels=node_df["label"],
        values=node_df["value"],
        branchvalues="remainder",
        hovertext=node_df["hover_text"],
        customdata=node_df[["count_display"]],
        hovertemplate=(
            "<b>%{label}</b><br>"
            "%{hovertext}<br>"
            "count=%{customdata[0]}<extra></extra>"
        ),
    ))

    fig.update_layout(margin=dict(t=10, l=10, r=10, b=10))
    return fig

# -----------------------------
# Streamlit UI
# -----------------------------

st.set_page_config(page_title="MONDO Mouse App fix89", layout="wide")

st.title("MONDO Mouse App (LLM Unified On-Demand fix89: stage1 phenotype presearch unified reflection fix)")
st.caption("Step1: 疾患名検索 → Step3: 解析 → 可視化。LLM は提案 / おすすめ / ペアでオンデマンド実行します。旧LLM CSV入力欄は削除済みです。")

# BEGIN MANUAL_8504_INTAKE_V06: Isolated operational test, full JSON source, format-neutral receiver.
from manual_8504_intake_v10 import render_manual_8504_intake as _render_manual_8504_intake
with st.expander("8504出力ファイルを手動で受け取り、LLMで解釈・整理する", expanded=True):
    _render_manual_8504_intake(
        st=st, OpenAI=OpenAI,
        get_api_key=_get_openai_api_key_for_llm_or_stop,
        model_guard=_luna_model_guard,
    )
# END MANUAL_8504_INTAKE_V06


with st.sidebar:
    st.header("システム設定")
    _render_openai_key_manager()

    st.markdown("---")

    # Step1 検索パラメータ（CLIに渡す。未対応なら自動でfallback）
    top_k = st.number_input("top_k（重複除去後の件数）", min_value=1, max_value=100, value=10, step=1)
    lambda_hybrid = st.slider(
        "lambda_hybrid（0.0=FAISSのみ / 1.0=BM25のみ。初期設定は0.25）",
        min_value=0.0,
        max_value=1.0,
        value=0.25,
        step=0.01,
    )
    show_n = st.number_input("候補の表示件数", min_value=1, max_value=100, value=10, step=1)

    st.caption("図生成停止の上限設定")
    mondo_count_hard_setting = st.number_input("検出MONDO件数の上限", min_value=1, max_value=1000, value=MONDO_COUNT_HARD, step=1)
    max_rbrc_per_mondo_hard_setting = st.number_input("最大ユニークRBRC件数/MONDO の上限", min_value=1, max_value=10000, value=MAX_RBRC_PER_MONDO_HARD, step=1)
    root_union_hard_setting = st.number_input("ROOT union ユニークRBRC件数の上限", min_value=1, max_value=10000, value=ROOT_UNION_HARD, step=1)


    if st.button("全リセット"):
        for k in list(st.session_state.keys()):
            del st.session_state[k]
        st.rerun()

    st.divider()

    default_base_dir = os.getenv("APP_BASE_DIR", str(Path.cwd()))
    base_dir = st.text_input("作業ディレクトリ (cwd)", value=default_base_dir)

    search_script = st.text_input("Step1 検索スクリプト", value="search_cli_hybrid_v08_term_HITTERM_MERGED.py")
    _latest_step3 = _find_latest_step3_script(base_dir)
    _default_step3 = "step3_sparqlonly_fix_allgenes_xsearch_genecount_only_seedmondos_sources_step3_models_externalized_gpt6luna_fix8_extdb_mouse_backfill.py"
    step3_script = st.text_input(
        "Step3 解析スクリプト",
        value=_default_step3,
        help="既定では現在の推奨 Step3 を表示します。必要に応じて変更できます。",
    )
    _step3_path = Path(base_dir) / step3_script
    if not _step3_path.exists():
        st.error(f"Step3 スクリプトが見つかりません: {_step3_path}")
    elif step3_script != _default_step3:
        st.warning(
            f"現在は既定値ではなく {step3_script} を参照しています。"
            " Step3 モデル設定を使うには、モデル引数対応版 Step3 を指定してください。"
        )
    default_outputs_dir = os.getenv("APP_OUTPUTS_DIR", "outputs")
    outputs_dir = st.text_input("outputs ディレクトリ", value=default_outputs_dir)
    debug_show_stdout = st.checkbox("デバッグ: 実行ログ(stdout/stderr)を表示", value=False)

    st.markdown("---")
    st.subheader("LLM モデル設定")
    step3_symbol_model = st.text_input(
        "Step3 遺伝子記号補完モデル",
        value=st.session_state.get("step3_symbol_model", "gpt-6-luna"),
        help="Step3 の遺伝子記号補完に使う正式な OpenAI モデル名を指定します。",
    )
    step3_gene_explanation_model = st.text_input(
        "Step3 遺伝子機能解説モデル",
        value=st.session_state.get("step3_gene_explanation_model", "gpt-6-luna"),
        help="Step3 の遺伝子機能解説に使う正式な OpenAI モデル名を指定します。",
    )
    llm_single_model = st.text_input(
        "単独候補 LLM モデル",
        value=st.session_state.get("llm_single_model", "gpt-6-luna"),
        help="単独候補の詳細要約に使う正式な OpenAI モデル名を指定します。",
    )
    llm_pair_model = st.text_input(
        "比較ペア LLM モデル",
        value=st.session_state.get("llm_pair_model", "gpt-6-luna"),
        help="比較ペアの要約に使う正式な OpenAI モデル名を指定します。",
    )
    st.session_state["step3_symbol_model"] = str(step3_symbol_model).strip() or "gpt-6-luna"
    st.session_state["step3_gene_explanation_model"] = str(step3_gene_explanation_model).strip() or "gpt-6-luna"
    st.session_state["llm_single_model"] = str(llm_single_model).strip() or "gpt-6-luna"
    st.session_state["llm_pair_model"] = str(llm_pair_model).strip() or "gpt-6-luna"

    st.session_state["mondo_count_hard_setting"] = int(mondo_count_hard_setting)
    st.session_state["max_rbrc_per_mondo_hard_setting"] = int(max_rbrc_per_mondo_hard_setting)
    st.session_state["root_union_hard_setting"] = int(root_union_hard_setting)

    st.markdown("---")
    st.subheader("後段専用（既存成果物から開始）")
    st.caption("Step1 / Step3 を再実行せずに、既存ファイルから LLM 要約だけを実行する場合は、原則として details_table を指定します。比較ペアを使う場合は比較提案 CSV を追加指定します。summary_stats と Step3 ログは補助情報です。")
    with st.expander("各ファイルの説明", expanded=True):
        st.markdown(
            "- **既存 details_table CSV パス**: Step3 の詳細表です。`details_table_MONDO_...csv` を入れます。\n"
            "- **既存 summary_stats CSV パス**: Step3 の集計表です。`summary_stats_MONDO_...csv` を入れます。\n"
            "- **既存 Step3 ログ パス**: Step3 実行時のログです。`run_v8_fixed3_MONDO_...log` を入れます。\n"
            "- **既存 比較提案 CSV パス**: 後段スクリプト v5 の比較提案です。`strain_pair_suggestions_MONDO_...csv` を入れます。\n"
            "- **比較提案 CSV** は空欄でも可です。空欄なら `llm_outputs/selection` から自動検出します。"
        )

    existing_details_csv_input = st.text_input(
        "既存 details_table CSV パス（必須）",
        value="",
        placeholder="/Users/.../details_table_MONDO_0005148_20260402_050817.csv",
        help="Step3 の詳細表です。details_table_*.csv を指定します。",
    )
    existing_summary_csv_input = st.text_input(
        "既存 summary_stats CSV パス（任意）",
        value="",
        placeholder="/Users/.../summary_stats_MONDO_0005148_20260402_050817.csv",
        help="Step3 の集計表です。summary_stats_*.csv を指定します。",
    )
    existing_step3_log_input = st.text_input(
        "既存 Step3 ログ パス（任意）",
        value="",
        placeholder="/Users/.../run_v8_fixed3_MONDO_0005148_20260402_050817.log",
        help="Step3 の実行ログです。run_v8_fixed3_*.log を指定します。",
    )
    existing_pair_csv_input = st.text_input(
        "既存 比較提案 CSV パス（任意）",
        value="",
        placeholder="/Users/.../llm_outputs/selection/strain_pair_suggestions_MONDO_0005148_20260403_121752.csv",
        help="後段スクリプト v5 の比較提案です。strain_pair_suggestions_*.csv を指定します。空欄なら llm_outputs/selection から自動検出します。",
    )

    st.markdown("---")
    st.caption("※ PNG/SVG/PDF ダウンロードには kaleido が必要です（plotly静的書き出し）。")


# Session state
if "search_json_path" not in st.session_state:
    st.session_state.search_json_path = None
if "search_results" not in st.session_state:
    st.session_state.search_results = None
if "selected_result" not in st.session_state:
    st.session_state.selected_result = None
if "rank_csv_path" not in st.session_state:
    st.session_state.rank_csv_path = None
if "step3_outputs" not in st.session_state:
    st.session_state.step3_outputs = None
if "step1_out" not in st.session_state:
    st.session_state.step1_out = ""
if "step1_err" not in st.session_state:
    st.session_state.step1_err = ""
if "step1_rc" not in st.session_state:
    st.session_state.step1_rc = None
if "step1_used_optional" not in st.session_state:
    st.session_state.step1_used_optional = None
if "step3_out" not in st.session_state:
    st.session_state.step3_out = ""
if "step3_err" not in st.session_state:
    st.session_state.step3_err = ""

if "step3_rc" not in st.session_state:
    st.session_state.step3_rc = None


def _resolve_optional_user_csv(path_str: str, base_dir_str: str) -> Optional[Path]:
    s = str(path_str or "").strip()
    if not s:
        return None
    p = Path(s)
    if not p.is_absolute():
        p = Path(base_dir_str) / p
    return p


def _load_log_text(log_path: Optional[Path]) -> str:
    if log_path is None or not log_path.exists():
        return ""
    return log_path.read_text(encoding="utf-8", errors="replace")


def _extract_mondo_label_from_log(log_text: str, mondo_id: str) -> str:
    mid = str(mondo_id or "").strip()
    if not mid or not log_text:
        return ""
    pat = re.compile(rf"-\s*{re.escape(mid)}\s*:\s*(.*?)\s*\[Sources:\s*.*?\]\s*$")
    for line in str(log_text).splitlines():
        m = pat.search(line)
        if m:
            return str(m.group(1)).strip()
    return ""


def _split_mondo_ids(value: object) -> List[str]:
    ids = []
    for part in re.split(r"[,;|\s]+", str(value or "")):
        v = _normalize_mondo_id(part.strip())
        if v and re.match(r"^MONDO_\d+$", v):
            ids.append(v)
    return list(dict.fromkeys(ids))


def _mondo_id_label_text_from_log(log_text: str, mondo_ids: object) -> str:
    """Return semicolon-separated MONDO ID: label entries for display.

    This is used to make fallback/descendant disease hits interpretable in
    candidate details, e.g. MONDO_0012790 -> ALS type 10.
    """
    ids = _split_mondo_ids(mondo_ids)
    entries = []
    for mid in ids:
        label = _extract_mondo_label_from_log(log_text, mid)
        entries.append(f"{mid}: {label}" if label else mid)
    return "; ".join(entries)



def _llm_status_from_summary_csv(df_summary: pd.DataFrame) -> Tuple[bool, str]:
    if df_summary is None or df_summary.empty:
        return False, "LLM 系統要約 CSV が空です。"
    if "llm_worked" not in df_summary.columns:
        return False, "LLM 実行判定列 llm_worked が summary CSV にありません。"
    vals = df_summary["llm_worked"].astype(str).str.strip().str.lower().unique().tolist()
    if len(vals) == 1 and vals[0] == "true":
        return True, ""
    reason = ""
    if "llm_failure_reason" in df_summary.columns:
        rs = [str(x).strip() for x in df_summary["llm_failure_reason"].astype(str).tolist() if str(x).strip()]
        if rs:
            reason = " / ".join(sorted(dict.fromkeys(rs)))
    if not reason:
        reason = f"llm_worked={vals}"
    return False, reason


def _llm_client(require_key: bool = False) -> Optional[object]:
    if OpenAI is None:
        if require_key:
            st.error("openai パッケージを利用できないためLLM機能を実行できません。")
            st.stop()
        return None
    if require_key:
        api_key = _get_openai_api_key_for_llm_or_stop()
        return OpenAI(api_key=api_key)
    user_id = _get_authenticated_user_id()
    api_key = _load_openai_key_for_user(user_id) if user_id and _has_saved_openai_key(user_id) else ""
    if not api_key and _allow_server_openai_key():
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        return None
    return OpenAI(api_key=api_key)





APPLICATION_TAG_JA = {
    "Mouse Models for Human Disease": "疾患モデル用途",
    "Diabetes and Obesity Research": "糖尿病・肥満研究向き",
    "Metabolism Research": "代謝研究向き",
    "Cre/loxP system": "Cre/loxP解析向き",
    "Cre driver": "Creドライバー系統",
    "FLP/frt system": "FLP/frt解析向き",
    "Fluorescent Proteins/lacZ System": "可視化・レポーター用途",
    "Immunology and Inflammation Research": "免疫・炎症研究向き",
    "Neurobiology Research": "神経研究向き",
    "Cancer Research": "がん研究向き",
    "Reproductive Engineering": "生殖工学用途",
    "Developmental Biology Research": "発生生物学研究向き",
    "Cardiovascular Research": "循環器研究向き",
    "Behavioral Research": "行動解析向き",
}


def _normalize_application_value(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def _application_tags_ja(applications: object) -> str:
    vals = []
    if isinstance(applications, (list, tuple, set)):
        raw_vals = list(applications)
    else:
        raw_vals = re.split(r"[;|]+", str(applications or ""))
    for raw in raw_vals:
        app = _normalize_application_value(raw)
        if not app:
            continue
        tag = APPLICATION_TAG_JA.get(app, app)
        if tag not in vals:
            vals.append(tag)
    return " / ".join(vals)


def _application_interpretation_ja(applications: object) -> str:
    tags = _application_tags_ja(applications)
    if not tags:
        return ""
    notes = []
    tag_set = set([x.strip() for x in tags.split("/") if x.strip()])
    if "疾患モデル用途" in tag_set:
        notes.append("疾患モデル用途として登録されている。")
    if "糖尿病・肥満研究向き" in tag_set:
        notes.append("糖尿病・肥満研究用途として登録されている。")
    if "代謝研究向き" in tag_set:
        notes.append("代謝研究用途として登録されている。")
    if any(x in tag_set for x in ["Cre/loxP解析向き", "Creドライバー系統", "FLP/frt解析向き"]):
        notes.append("条件付き解析・交配実験の用途も確認する。")
    if "可視化・レポーター用途" in tag_set:
        notes.append("可視化・レポーター用途としての利用可能性がある。")
    if not notes:
        notes.append("研究用途情報として候補解釈の補助に利用できる。")
    return " ".join(notes)


@st.cache_data(show_spinner=False, ttl=3600)
def _fetch_applications_for_strains_cached(
    strain_ids: Tuple[str, ...],
    endpoint: str = "https://knowledge.brc.riken.jp/sparql",
    timeout_sec: float = 20.0,
) -> Dict[str, List[str]]:
    """Fetch xsearch:application for RBRC mouse resources.

    application is treated as research-use metadata. It is not used as phenotype
    evidence and does not directly determine selection_priority_hint.
    """
    ids = []
    for raw in strain_ids or ():
        sid = str(raw or "").strip()
        if sid and sid not in ids:
            ids.append(sid)
    result: Dict[str, List[str]] = {sid: [] for sid in ids}
    if not ids:
        return result

    iri_by_sid = {sid: _app_resource_iri_from_strain_id(sid) for sid in ids}
    sid_by_iri = {iri: sid for sid, iri in iri_by_sid.items() if iri}
    chunks = [ids[i:i + 50] for i in range(0, len(ids), 50)]
    for chunk in chunks:
        values = []
        for sid in chunk:
            iri = iri_by_sid.get(sid, "")
            if iri:
                values.append(f"<{iri}>")
        if not values:
            continue
        query = f"""
PREFIX xsearch: <http://metadb.riken.jp/terms/xsearch#>
SELECT DISTINCT ?mouse ?application
WHERE {{
  VALUES ?mouse {{ {' '.join(values)} }}
  ?mouse xsearch:application ?application .
}}
ORDER BY ?mouse ?application
""".strip()
        try:
            resp = requests.post(
                endpoint,
                data={"query": query, "format": "application/sparql-results+json"},
                timeout=timeout_sec,
                headers={"Accept": "application/sparql-results+json"},
            )
            resp.raise_for_status()
            obj = resp.json()
            bindings = (((obj or {}).get("results") or {}).get("bindings") or [])
            for b in bindings:
                mouse = str((((b or {}).get("mouse") or {}).get("value")) or "").strip()
                app = _normalize_application_value((((b or {}).get("application") or {}).get("value")) or "")
                sid = sid_by_iri.get(mouse, "")
                if sid and app and app not in result.setdefault(sid, []):
                    result[sid].append(app)
        except Exception:
            # Do not stop the app when optional application metadata is unavailable.
            continue
    return result


def _add_application_columns_to_overview_df(df: pd.DataFrame) -> pd.DataFrame:
    """Add RIKEN BRC xsearch:application metadata as research-use information.

    This function only adds display/input columns. It does not change candidate
    extraction, selection_priority_hint, source_provenance_level, or phenotype_support_level.
    """
    if df is None or df.empty:
        return df
    out = df.copy()
    if "strain_id" not in out.columns:
        out["applications"] = ""
        out["application_tags_ja"] = ""
        out["application_interpretation_ja"] = ""
        return out
    strain_ids = tuple(out["strain_id"].astype(str).str.strip().dropna().tolist())
    app_map = _fetch_applications_for_strains_cached(strain_ids)
    apps_col = []
    tags_col = []
    interp_col = []
    for sid in out["strain_id"].astype(str).str.strip().tolist():
        apps = app_map.get(sid, []) or []
        apps_text = "; ".join(apps)
        apps_col.append(apps_text)
        tags_col.append(_application_tags_ja(apps))
        interp_col.append(_application_interpretation_ja(apps))
    out["applications"] = apps_col
    out["application_tags_ja"] = tags_col
    out["application_interpretation_ja"] = interp_col
    return out



def _fix77_is_fallback_variation_class(value: object) -> bool:
    """Return True for values that should not be treated as real strain type data.

    fix77: Other/General was previously used as a fallback when the real BRC
    resource type was not attached.  For research outputs, fallback values must
    not masquerade as source data.
    """
    text = re.sub(r"\s+", " ", str(value or "").strip().lower())
    return text in {"other/general", "other", "general", "その他", "一般", "その他・一般", "unknown", "nan", "none", "null"}


def _fix77_resource_type_display(meta: Dict[str, Any]) -> str:
    """Prefer the English BRC resource type label, then Japanese label, then IRI local part."""
    en = str((meta or {}).get("resource_type_label_en", "") or "").strip()
    ja = str((meta or {}).get("resource_type_label_ja", "") or "").strip()
    iri = str((meta or {}).get("resource_type_iri", "") or "").strip()
    if en:
        return en
    if ja:
        return ja
    if iri:
        return iri.rsplit("#", 1)[-1].rsplit("/", 1)[-1]
    return ""


@st.cache_data(show_spinner=False, ttl=3600)
def _fix77_fetch_resource_types_for_strains_cached(
    strain_ids: Tuple[str, ...],
    endpoint: str = "https://knowledge.brc.riken.jp/sparql",
    timeout_sec: float = 30.0,
) -> Dict[str, Dict[str, str]]:
    """Fetch BRC xsearch resource type labels for RBRC mouse resources.

    Source graph and predicate are fixed to the RIKEN BRC triple store:
      GRAPH <http://metadb.riken.jp/db/xsearch_animal>
      xsearch:resourceTypeLink -> rdfs:label

    This function is deterministic metadata retrieval.  It does not ask the LLM
    to infer mutation type.  When no value is retrieved, callers must keep the
    value empty/Unknown rather than falling back to Other/General.
    """
    ids: List[str] = []
    for raw in strain_ids or ():
        sid = str(raw or "").strip()
        if sid and sid not in ids:
            ids.append(sid)
    result: Dict[str, Dict[str, str]] = {
        sid: {
            "resource_type_iri": "",
            "resource_type_label_en": "",
            "resource_type_label_ja": "",
            "resource_type_labels": "",
            "variation_class_raw": "",
            "variation_class_normalized": "Unknown",
            "variation_class_source": "xsearch_animal resourceTypeLink rdfs:label",
            "variation_class_status": "not_retrieved",
        }
        for sid in ids
    }
    if not ids:
        return result

    iri_by_sid = {sid: _app_resource_iri_from_strain_id(sid) for sid in ids}
    sid_by_iri = {iri: sid for sid, iri in iri_by_sid.items() if iri}
    chunks = [ids[i:i + 50] for i in range(0, len(ids), 50)]
    for chunk in chunks:
        values = []
        for sid in chunk:
            iri = iri_by_sid.get(sid, "")
            if iri:
                values.append(f"<{iri}>")
        if not values:
            continue
        query = f"""
PREFIX xsearch: <http://metadb.riken.jp/terms/xsearch#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT DISTINCT ?mouse ?resource_type ?resource_type_label
WHERE {{
  GRAPH <http://metadb.riken.jp/db/xsearch_animal> {{
    VALUES ?mouse {{ {' '.join(values)} }}
    ?mouse xsearch:resourceTypeLink ?resource_type .
    ?resource_type rdfs:label ?resource_type_label .
  }}
}}
ORDER BY ?mouse ?resource_type ?resource_type_label
""".strip()
        try:
            resp = requests.post(
                endpoint,
                data={"query": query, "format": "application/sparql-results+json"},
                timeout=timeout_sec,
                headers={"Accept": "application/sparql-results+json"},
            )
            resp.raise_for_status()
            obj = resp.json()
            bindings = (((obj or {}).get("results") or {}).get("bindings") or [])
            for b in bindings:
                mouse = str((((b or {}).get("mouse") or {}).get("value")) or "").strip()
                sid = sid_by_iri.get(mouse, "")
                if not sid:
                    continue
                rt = str((((b or {}).get("resource_type") or {}).get("value")) or "").strip()
                lab_obj = ((b or {}).get("resource_type_label") or {})
                lab = str((lab_obj.get("value") if isinstance(lab_obj, dict) else "") or "").strip()
                lang = str((lab_obj.get("xml:lang") if isinstance(lab_obj, dict) else "") or "").strip().lower()
                cur = result.setdefault(sid, {})
                if rt and not str(cur.get("resource_type_iri", "")).strip():
                    cur["resource_type_iri"] = rt
                if lab:
                    labels = [x for x in str(cur.get("resource_type_labels", "") or "").split(" | ") if x]
                    if lab not in labels:
                        labels.append(lab)
                    cur["resource_type_labels"] = " | ".join(labels)
                    if lang.startswith("en") and not str(cur.get("resource_type_label_en", "")).strip():
                        cur["resource_type_label_en"] = lab
                    elif lang.startswith("ja") and not str(cur.get("resource_type_label_ja", "")).strip():
                        cur["resource_type_label_ja"] = lab
                display = _fix77_resource_type_display(cur)
                if display:
                    cur["variation_class_raw"] = display
                    cur["variation_class_normalized"] = display
                    cur["variation_class_status"] = "resolved"
        except Exception:
            # Resource type metadata is important, but unavailability of the
            # endpoint must not crash the app.  The status column preserves the
            # retrieval failure for audit instead of silently using Other/General.
            for sid in chunk:
                if sid in result and result[sid].get("variation_class_status") != "resolved":
                    result[sid]["variation_class_status"] = "not_retrieved"
            continue
    return result


def _fix77_add_resource_type_columns_to_overview_df(df: pd.DataFrame) -> pd.DataFrame:
    """Attach BRC resource type metadata and replace fallback variation_class.

    fix77 policy:
      * Use xsearch:resourceTypeLink/rdfs:label as the authoritative source for
        strain/resource type when available.
      * Do not use Other/General as a fallback when metadata is missing.
      * Keep raw labels and source/status columns for auditability.
    """
    if df is None or df.empty:
        return df
    out = df.copy()
    for col in [
        "resource_type_iri", "resource_type_label_en", "resource_type_label_ja", "resource_type_labels",
        "variation_class_raw", "variation_class_normalized", "variation_class_source", "variation_class_status",
    ]:
        if col not in out.columns:
            out[col] = ""
    if "strain_id" not in out.columns:
        return out

    strain_ids = tuple(out["strain_id"].astype(str).str.strip().dropna().tolist())
    rt_map = _fix77_fetch_resource_types_for_strains_cached(strain_ids)
    for idx, row in out.iterrows():
        sid = str(row.get("strain_id", "") or "").strip()
        meta = rt_map.get(sid, {}) or {}
        existing_variation = str(row.get("variation_class", "") or "").strip()
        resolved = str(meta.get("variation_class_status", "") or "") == "resolved"
        if resolved:
            display = _fix77_resource_type_display(meta)
            out.at[idx, "resource_type_iri"] = meta.get("resource_type_iri", "")
            out.at[idx, "resource_type_label_en"] = meta.get("resource_type_label_en", "")
            out.at[idx, "resource_type_label_ja"] = meta.get("resource_type_label_ja", "")
            out.at[idx, "resource_type_labels"] = meta.get("resource_type_labels", "")
            out.at[idx, "variation_class_raw"] = display
            out.at[idx, "variation_class_normalized"] = display
            out.at[idx, "variation_class_source"] = "xsearch_animal resourceTypeLink rdfs:label"
            out.at[idx, "variation_class_status"] = "resolved"
            out.at[idx, "variation_class"] = display
        else:
            out.at[idx, "variation_class_source"] = "xsearch_animal resourceTypeLink rdfs:label"
            out.at[idx, "variation_class_status"] = "not_retrieved"
            if existing_variation and not _fix77_is_fallback_variation_class(existing_variation):
                out.at[idx, "variation_class_raw"] = existing_variation
                out.at[idx, "variation_class_normalized"] = existing_variation
                out.at[idx, "variation_class_status"] = "existing_input_only"
            else:
                out.at[idx, "variation_class_raw"] = ""
                out.at[idx, "variation_class_normalized"] = "Unknown"
                out.at[idx, "variation_class"] = ""
    return out


def _fetch_mp_labels_for_resource(
    resource_iri: str,
    endpoint: str = "https://knowledge.brc.riken.jp/sparql",
    timeout_sec: float = 20.0,
) -> Dict[str, object]:
    iri = str(resource_iri or "").strip()
    if not iri:
        return {"mp_ids": [], "mp_labels": [], "error": "empty resource iri"}

    query = f"""
PREFIX sio: <http://semanticscience.org/resource/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT DISTINCT ?mp ?label_mp
WHERE {{
  GRAPH <http://metadb.riken.jp/db/xsearch_animal>{{
    VALUES ?mouse {{ <{iri}> }}
    ?mouse sio:SIO_001279/sio:SIO_000255 ?mp .
  }}
  GRAPH <http://metadb.riken.jp/ontology/MP_international>{{
    ?mp rdfs:label ?label_mp .
    FILTER(lang(?label_mp) = "" || langMatches(lang(?label_mp), "en") || langMatches(lang(?label_mp), "ja"))
  }}
}}
ORDER BY ?mp ?label_mp
""".strip()

    try:
        resp = requests.get(
            endpoint,
            params={"query": query, "format": "application/sparql-results+json"},
            timeout=timeout_sec,
            headers={"Accept": "application/sparql-results+json"},
        )
        resp.raise_for_status()
        obj = resp.json()
        bindings = (((obj or {}).get("results") or {}).get("bindings") or [])
        mp_ids = []
        mp_labels = []
        for b in bindings:
            mp = str((((b or {}).get("mp") or {}).get("value")) or "").strip()
            lab = str((((b or {}).get("label_mp") or {}).get("value")) or "").strip()
            if mp and mp not in mp_ids:
                mp_ids.append(mp)
            if lab and lab not in mp_labels:
                mp_labels.append(lab)
        return {"mp_ids": mp_ids, "mp_labels": mp_labels, "error": ""}
    except Exception as e:
        return {"mp_ids": [], "mp_labels": [], "error": f"{type(e).__name__}: {e}"}


def _obo_local_id_from_iri(value: object) -> str:
    """Return local OBO identifier such as MP_0006194 from an IRI or ID-like string."""
    text = str(value or "").strip()
    if not text:
        return ""
    m = re.search(r"([A-Za-z]+[_:]\d+)$", text)
    if not m:
        return text
    return m.group(1).replace(":", "_")


def _obo_iri_from_local_id(local_id: object) -> str:
    local = _obo_local_id_from_iri(local_id)
    if not local:
        return ""
    return f"http://purl.obolibrary.org/obo/{local}"


@st.cache_data(show_spinner=False, ttl=3600)
def _fetch_disease_hpo_mp_mapping_cached(
    mondo_ids: tuple,
    endpoint: str = "https://knowledge.brc.riken.jp/sparql",
    timeout_sec: float = 30.0,
) -> Dict[str, object]:
    """Fetch disease HPO terms and mapped MP terms using MONDO -> HPO -> MP graphs.

    This is the generic phenotype-support pathway. It intentionally avoids
    disease-specific keyword dictionaries. If no mapping or no overlap is found,
    downstream logic must remain conservative.
    """
    mids: List[str] = []
    for raw in mondo_ids or ():
        mid = _normalize_mondo_id(str(raw or "").strip())
        if mid and re.match(r"^MONDO_\d+$", mid) and mid not in mids:
            mids.append(mid)
    result: Dict[str, object] = {
        "mondo_ids": mids,
        "hpo_ids": [],
        "mp_ids": [],
        "pairs": [],
        "error": "",
    }
    if not mids:
        return result
    values = " ".join(f"<{_obo_iri_from_local_id(mid)}>" for mid in mids)
    query = f"""
PREFIX biolink: <https://w3id.org/biolink/vocab/>
SELECT DISTINCT ?mondo ?hp ?mp
WHERE {{
  GRAPH <http://metadb.riken.jp/db/disease_hpo_fromHpoa> {{
    VALUES ?mondo {{ {values} }}
    ?mondo biolink:has_phenotype ?hp .
    FILTER STRSTARTS(STR(?mondo), "http://purl.obolibrary.org/obo/MONDO_")
  }}
  GRAPH <http://metadb.riken.jp/db/hp_mp_mapping_textBased> {{
    ?hp <http://example.org/predicates/mapping> ?mp .
  }}
}}
ORDER BY ?mondo ?hp ?mp
""".strip()
    try:
        resp = requests.get(
            endpoint,
            params={"query": query, "format": "application/sparql-results+json"},
            timeout=timeout_sec,
            headers={"Accept": "application/sparql-results+json"},
        )
        resp.raise_for_status()
        obj = resp.json()
        bindings = (((obj or {}).get("results") or {}).get("bindings") or [])
        hpo_ids: List[str] = []
        mp_ids: List[str] = []
        pairs: List[Dict[str, str]] = []
        for b in bindings:
            mondo = _obo_local_id_from_iri((((b or {}).get("mondo") or {}).get("value")) or "")
            hp = _obo_local_id_from_iri((((b or {}).get("hp") or {}).get("value")) or "")
            mp = _obo_local_id_from_iri((((b or {}).get("mp") or {}).get("value")) or "")
            if hp and hp not in hpo_ids:
                hpo_ids.append(hp)
            if mp and mp not in mp_ids:
                mp_ids.append(mp)
            if mondo or hp or mp:
                pairs.append({"mondo_id": mondo, "hpo_id": hp, "mp_id": mp})
        result.update({"hpo_ids": hpo_ids, "mp_ids": mp_ids, "pairs": pairs})
    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"
    return result


def _phenotype_support_from_hpo_mp_mapping(
    candidate_mp_ids: List[str],
    disease_mapped_mp_ids: List[str],
) -> str:
    """Generic phenotype-support level from exact MP overlap.

    No disease-specific keyword dictionary is used. Exact overlap means the
    candidate has an MP term that is also mapped from an HPO phenotype associated
    with the target or mapped MONDO disease.
    """
    cand = {_obo_local_id_from_iri(x) for x in (candidate_mp_ids or []) if _obo_local_id_from_iri(x)}
    mapped = {_obo_local_id_from_iri(x) for x in (disease_mapped_mp_ids or []) if _obo_local_id_from_iri(x)}
    if cand and mapped and cand.intersection(mapped):
        return "high"
    return "low_or_unknown"


def _mp_summary_ja(
    mp_labels: List[str],
    hint: str,
    disease_context: object = "",
    candidate_mp_ids: Optional[List[str]] = None,
    disease_mapped_mp_ids: Optional[List[str]] = None,
    overlap_mp_ids: Optional[List[str]] = None,
    mapping_error: str = "",
) -> str:
    """Summarize MP evidence using generic MONDO->HPO->MP mapping.

    This function intentionally avoids disease-specific wording such as diabetes
    or ALS. Disease support is stated only when candidate MP IDs overlap with
    MP IDs mapped from disease HPO annotations.
    """
    labels = [str(x).strip() for x in (mp_labels or []) if str(x).strip()]
    disease = str(disease_context or "").strip()
    target = f"対象疾患（{disease}）" if disease else "対象疾患"
    head = " / ".join(labels[:5])
    cand_count = len([x for x in (candidate_mp_ids or []) if str(x).strip()])
    mapped_count = len([x for x in (disease_mapped_mp_ids or []) if str(x).strip()])
    overlap = [_obo_local_id_from_iri(x) for x in (overlap_mp_ids or []) if _obo_local_id_from_iri(x)]
    overlap = list(dict.fromkeys(overlap))

    if not labels:
        if mapping_error:
            return f"MP未取得のため、表現型面は未評価。HPO-MP対応取得エラー: {mapping_error}"
        return "MP未取得のため、表現型面は未評価。"

    if hint == "high" and overlap:
        return (
            f"候補系統のMPと、{target}に紐づくHPOから変換したMPに一致があるため、"
            f"表現型面で疾患と整合する可能性がある。"
            f"一致MP: {', '.join(overlap[:8])}。主な候補MP: {head}"
        )

    if mapped_count == 0:
        extra = f" HPO-MP対応取得エラー: {mapping_error}" if mapping_error else ""
        return (
            f"MPは取得できたが、{target}に対するHPO由来MP対応を取得できないため、"
            f"表現型面の整合性はこの情報だけでは判断できない。主な候補MP: {head}.{extra}"
        )

    return (
        f"MPは取得できたが、候補MP（{cand_count}件）と{target}に紐づくHPO由来MP（{mapped_count}件）との"
        f"直接一致は確認できなかった。表現型面の整合性は未評価または限定的。主な候補MP: {head}"
    )


def _initial_phenotype_support_source(
    *,
    mp_labels: Optional[List[str]] = None,
    disease_hpo_ids: Optional[List[str]] = None,
    disease_mapped_mp_ids: Optional[List[str]] = None,
    overlap_mp_ids: Optional[List[str]] = None,
    mapping_error: str = "",
) -> str:
    """Return provenance category for phenotype_support_level before LLM assistance."""
    if overlap_mp_ids:
        return "hpoa_hpo_mp_exact"
    if not mp_labels:
        return "mp_unavailable"
    if mapping_error:
        return "mapping_error"
    if not disease_hpo_ids or not disease_mapped_mp_ids:
        return "mapping_unavailable"
    return "mp_available_no_direct_support"


def _phenotype_support_source_text_ja(value: str) -> str:
    mapping = {
        "hpoa_hpo_mp_exact": "HPOA由来の疾患HPOをHPO-MP mappingでMPへ変換し、候補MPとの直接一致を確認した。",
        "llm_inferred_hpo_mp_support_high": "HPOA/HPO-MP mappingの直接一致はないが、第2段階LLMが生成した対象疾患関連表現型キーワードと、実在する候補MPラベルとの意味的整合性が高いと評価した。",
        "llm_inferred_hpo_mp_support_medium": "HPOA/HPO-MP mappingの直接一致はないが、第2段階LLMが生成した対象疾患関連表現型キーワードと、実在する候補MPラベルとの意味的整合性が一部あると評価した。",
        "llm_keyword_candidate_hpo_mp_selected": "HPOA由来HPOをHPO-MP mappingで変換したMPが候補MPと一致した。",
        "llm_keyword_candidate_mp_selected": "LLM生成表現型キーワードと実在する候補MPラベルが一致または強く包含関係にあった。",
        "llm_keyword_candidate_mp_label_match": "LLM生成表現型キーワードと実在する候補MPラベルに明確なラベル一致または包含関係を確認した。",
        "llm_candidate_bounded_no_overlap": "LLM生成表現型キーワードからSPARQLで実在HPO/MP候補を取得し、候補リスト内限定でLLMが選択したが、候補MPとのID一致は確認できなかった。",
        "llm_semantic_support_only": "候補リスト内限定のHPO/MP一致はないが、LLMが候補MPラベルと疾患表現型キーワードの意味的関連を補助コメントとして示した。",
        "llm_inferred_low_support": "HPOA/HPO-MP mappingの直接一致はなく、第2段階LLMが生成した対象疾患関連表現型キーワードとの意味的整合性も限定的または判断困難と評価した。",
        "broad_or_indirect_phenotype_terms_only": "一致した表現型語が致死性・浸透率などの広い語または間接語に限られるため、疾患特異的な表現型補強としては扱いません。",
        "mp_available_no_direct_support": "MPは取得できたが、HPOA由来HPO-MP mappingとの直接一致は確認できない。",
        "mapping_unavailable": "候補MPは取得できたが、対象疾患に対するHPOAまたはHPO-MP mappingが取得できない。",
        "mapping_error": "HPOA/HPO-MP mapping取得時にエラーが発生した。",
        "mp_unavailable": "候補系統のMPが取得できない。",
    }
    return mapping.get(str(value or "").strip(), "")


def _sanitize_llm_phenotype_text_no_ids(value: object) -> str:
    """Remove ontology IDs/IRIs from LLM phenotype text.

    LLM output is allowed to contain label-level phenotype terms only. Any
    HP_/MP_ identifiers or OBO IRIs are discarded because IDs must come only
    from SPARQL-verified sources.
    """
    text = str(value or "")
    text = re.sub(r"https?://purl\.obolibrary\.org/obo/[A-Za-z]+_\d+", "", text)
    text = re.sub(r"\bHP_\d{7}\b", "", text)
    text = re.sub(r"\bMP_\d{7}\b", "", text)
    text = re.sub(r"\s{2,}", " ", text).strip(" ;,、。")
    return text



def _fix81_clean_export_text(value: object) -> str:
    """Clean human-facing/exported phenotype detail text without changing meaning.

    This is a presentation/export cleanup only.  It removes accidental list
    markers embedded in inline values and replaces obsolete historical version
    wording with a version-neutral phrase.
    """
    text = str(value or "")
    if not text:
        return ""
    text = text.replace("fix37では", "現行仕様では")
    text = text.replace("fix37", "現行仕様")
    # Remove bullet markers that were accidentally preserved inside inline fields.
    text = re.sub(r"(?m)(^|[|])\s*[-•・]\s+", r"\1 ", text)
    text = re.sub(r"(?m)^\s*[-•・]\s+", "", text)
    text = re.sub(r"\s*\|\s*", " | ", text)
    text = re.sub(r"\s*;\s*", "; ", text)
    text = re.sub(r"\s+([、。])", r"\1", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip()





def _fix82_split_display_terms(value: object) -> List[str]:
    """Split exported phenotype labels for count/denominator display.

    This helper is only for audit text in integrated_candidate_interpretation.md/json.
    It does not change search, scoring, ranking, or LLM prompts.
    """
    text = _fix81_clean_export_text(value)
    if not text:
        return []
    # Preserve term-internal hyphens; split only on separators used by app outputs.
    parts = re.split(r"\s*\|\s*|;|；|,|、|\n+", text)
    out: List[str] = []
    seen: set[str] = set()
    for part in parts:
        term = str(part or "").strip(" \t\r\n。.")
        term = re.sub(r"^[\s\-‐‑–—−•・]+", "", term).strip(" \t\r\n。.")
        if not term or term.lower() in {"nan", "none", "null", "(未記載)"}:
            continue
        key = term.casefold()
        if key not in seen:
            seen.add(key)
            out.append(term)
    return out


def _fix82_join_terms(values: object) -> str:
    terms = _fix82_split_display_terms(values)
    return " | ".join(terms)


def _fix82_len_terms(values: object) -> int:
    return len(_fix82_split_display_terms(values))


def _fix82_count_overlap_terms(overlap_terms: List[str], reference_terms: List[str]) -> int:
    ref = {str(x).casefold() for x in reference_terms if str(x).strip()}
    return sum(1 for x in overlap_terms if str(x).casefold() in ref)


def _fix82_build_phenotype_keyword_denominator_summary(
    single_record: Dict[str, Any],
    phenotype_record: Dict[str, Any],
    unified_record: Dict[str, Any],
) -> Dict[str, Any]:
    """Build a human/audit summary of second-stage phenotype keyword matching.

    The main purpose is to show not only a matched count but also the denominator
    and the actual matched labels/MP concepts in integrated Markdown output.
    """
    ja_terms = _fix82_split_display_terms(single_record.get("llm_generated_disease_phenotype_keywords_ja"))
    en_terms = _fix82_split_display_terms(single_record.get("llm_generated_disease_phenotype_keywords_en"))
    overlap_terms = _fix82_split_display_terms(single_record.get("llm_keyword_candidate_mp_label_overlap_terms"))
    overlap_pairs = _fix82_split_display_terms(single_record.get("llm_keyword_candidate_mp_label_overlap_pairs"))
    candidate_mp_labels = _fix82_split_display_terms(single_record.get("candidate_mp_labels_for_keyword_scoring"))

    matched_mp_ids = _fix82_split_display_terms(
        phenotype_record.get("matched_mp_ids") or unified_record.get("matched_mp_ids")
    )
    matched_mp_labels = _fix82_split_display_terms(
        phenotype_record.get("matched_mp_labels") or unified_record.get("matched_mp_labels") or unified_record.get("matched_mp_labels_short")
    )

    label_match_count_raw = single_record.get("llm_keyword_candidate_mp_label_overlap_count")
    try:
        label_match_count = int(float(str(label_match_count_raw).strip())) if str(label_match_count_raw or "").strip() else len(overlap_terms)
    except Exception:
        label_match_count = len(overlap_terms)

    ja_match_count = _fix82_count_overlap_terms(overlap_terms, ja_terms)
    en_match_count = _fix82_count_overlap_terms(overlap_terms, en_terms)
    total_generated_label_count = len(ja_terms) + len(en_terms)
    unique_mp_count = len(matched_mp_ids)
    high_mp_count_value = phenotype_record.get("unique_high_relevance_mp_count") or unified_record.get("unique_high_relevance_mp_count")
    try:
        high_mp_count = int(float(str(high_mp_count_value).strip())) if str(high_mp_count_value or "").strip() else None
    except Exception:
        high_mp_count = None

    summary_parts: List[str] = []
    if ja_terms:
        summary_parts.append(f"日本語キーワード {len(ja_terms)}件中 {ja_match_count}件が候補MPラベルと一致")
    if en_terms:
        summary_parts.append(f"英語キーワード {len(en_terms)}件中 {en_match_count}件が候補MPラベルと一致")
    if total_generated_label_count:
        summary_parts.append(f"日英ラベル合算では {total_generated_label_count}件中 {label_match_count}件が一致")
    if unique_mp_count:
        summary_parts.append(f"一致MP概念数は {unique_mp_count}件")
    if high_mp_count is not None:
        summary_parts.append(f"高関連MP概念数は {high_mp_count}件")

    return {
        "role_ja": "第2段階LLMが生成した表現型キーワードと、選択候補自身の実在MPラベルとの照合内訳。何件中何件が一致したかを監査可能にするための要約です。",
        "llm_generated_disease_phenotype_keywords_ja": ja_terms or None,
        "llm_generated_disease_phenotype_keywords_en": en_terms or None,
        "generated_keyword_count_ja": len(ja_terms),
        "generated_keyword_count_en": len(en_terms),
        "generated_keyword_count_total_label_level": total_generated_label_count,
        "candidate_mp_labels_for_keyword_scoring": candidate_mp_labels or None,
        "matched_label_terms": overlap_terms or None,
        "matched_label_pairs": overlap_pairs or None,
        "matched_label_count": label_match_count,
        "matched_label_count_ja": ja_match_count,
        "matched_label_count_en": en_match_count,
        "matched_mp_ids": matched_mp_ids or None,
        "matched_mp_labels": matched_mp_labels or None,
        "unique_matched_mp_id_count": unique_mp_count if unique_mp_count else None,
        "unique_high_relevance_mp_count": high_mp_count,
        "counting_policy_ja": "ラベル一致数は日本語・英語ラベルを別々に数えます。一方、MP概念数は一意なMP IDで数えます。例: 高血糖/hyperglycemia が同じ MP_0001559 に対応する場合、ラベル一致は2件でもMP概念は1件です。",
        "summary_ja": " / ".join(summary_parts) if summary_parts else None,
    }




def _fix88_normalize_stage1_phenotype_keyword_payload_for_export(keyword_payload: Any) -> Dict[str, Any]:
    """Return a compact audit payload for the 5-0 pre-second-stage phenotype keyword search.

    fix88 is export-only. It preserves the existing search, matching, scoring,
    ranking, and LLM prompts, and only copies the already-generated 5-0 keyword
    payload into downstream downloadable outputs.
    """
    if not isinstance(keyword_payload, dict):
        return {}

    ja_terms = _fix82_split_display_terms(keyword_payload.get("llm_generated_disease_phenotype_keywords_ja"))
    en_terms = _fix82_split_display_terms(keyword_payload.get("llm_generated_disease_phenotype_keywords_en"))
    basis = _fix81_clean_export_text(keyword_payload.get("keyword_generation_basis_ja"))
    use_policy = _fix81_clean_export_text(keyword_payload.get("use_policy_ja"))
    caution = _fix81_clean_export_text(keyword_payload.get("caution_ja"))
    stage = _fix81_clean_export_text(keyword_payload.get("phenotype_keyword_stage")) or "after_stage1_before_single_candidate_llm_detail"
    target_mondo_id = _fix81_clean_export_text(keyword_payload.get("target_mondo_id"))
    model = _fix81_clean_export_text(keyword_payload.get("llm_model"))

    if not ja_terms and not en_terms and not basis:
        return {}

    return {
        "role_ja": "5-0画面で表示される、第1段階LLM後・第2段階LLM前の表現型キーワード探索に使ったLLM生成キーワード、生成根拠、使用方針を保存する監査用ブロックです。",
        "phenotype_keyword_stage": stage,
        "target_mondo_id": target_mondo_id or None,
        "llm_model": model or None,
        "llm_generated_disease_phenotype_keywords_ja": ja_terms or None,
        "llm_generated_disease_phenotype_keywords_en": en_terms or None,
        "generated_keyword_count_ja": len(ja_terms),
        "generated_keyword_count_en": len(en_terms),
        "generated_keyword_count_total_label_level": len(ja_terms) + len(en_terms),
        "keyword_generation_basis_ja": basis or None,
        "use_policy_ja": use_policy or "第2段階LLMの実行前に、遺伝子・既知根拠と表現型一致を併用して候補を確認します。実行後の後付け再順位づけには使いません。",
        "caution_ja": caution or None,
        "identifier_policy_ja": "HPO ID、MP ID、IRI、MONDO ID、GeneIDなどの識別子はLLMに生成させず、検索語としてはラベル文字列のみを扱います。IDとして保存・使用する値は既存データまたはSPARQL等で取得された実在IDに限ります。",
        "ranking_policy_ja": "このキーワード集合は第2段階LLM前の候補確認材料であり、第2段階LLM実行後の後付け再順位づけには使いません。",
    }


def _fix88_render_stage1_phenotype_keyword_payload_md(payload: Dict[str, Any]) -> str:
    """Render the fix88 5-0 keyword audit block as a standalone Markdown file."""
    block = _fix88_normalize_stage1_phenotype_keyword_payload_for_export(payload)

    def _v(value: Any) -> str:
        text = _fix58_clean_scalar(value)
        return text if text else "(未記載)"

    lines: List[str] = [
        "# 第1段階後・第2段階LLM前 表現型キーワード探索サマリー",
        "",
        f"- target_mondo_id: {_v(block.get('target_mondo_id') or payload.get('target_mondo_id'))}",
        f"- phenotype_keyword_stage: {_v(block.get('phenotype_keyword_stage'))}",
        f"- llm_model: {_v(block.get('llm_model'))}",
        "- file_role: 5-0画面で表示される、探索に使った表現型キーワードと生成根拠を人が読める形で保存するMarkdown。",
        "",
        "## 1. 日本語キーワード",
        "",
        _v(_fix82_join_terms(block.get("llm_generated_disease_phenotype_keywords_ja"))),
        "",
        f"- 件数: {_v(block.get('generated_keyword_count_ja'))}",
        "",
        "## 2. 英語キーワード",
        "",
        _v(_fix82_join_terms(block.get("llm_generated_disease_phenotype_keywords_en"))),
        "",
        f"- 件数: {_v(block.get('generated_keyword_count_en'))}",
        "",
        "## 3. 生成根拠",
        "",
        _v(block.get("keyword_generation_basis_ja")),
        "",
        "## 4. 使用方針",
        "",
        _v(block.get("use_policy_ja")),
        "",
        "## 5. 注意事項",
        "",
        _v(block.get("caution_ja")),
        "",
        "## 6. 識別子・順位づけポリシー",
        "",
        f"- 識別子ポリシー: {_v(block.get('identifier_policy_ja'))}",
        f"- 順位づけポリシー: {_v(block.get('ranking_policy_ja'))}",
    ]
    return "\n".join(lines).strip() + "\n"


def _fix89_first_nonempty(values: List[Any]) -> str:
    """Return the first non-empty scalar value as text."""
    for value in values:
        try:
            if pd.isna(value):
                continue
        except Exception:
            pass
        text = str(value or "").strip()
        if text and text.lower() not in {"nan", "none", "null"}:
            return text
    return ""


def _fix89_union_pipe_values(values: List[Any]) -> str:
    """Union pipe-separated values while preserving first-seen order."""
    out: List[str] = []
    seen: set[str] = set()
    for value in values:
        for item in _split_multi_value_text(value):
            key = str(item).casefold()
            if key not in seen:
                seen.add(key)
                out.append(str(item))
    return " | ".join(out)


def _fix89_best_priority(values: List[Any]) -> str:
    """Return the strongest phenotype-candidate priority label in a merged group."""
    order = {
        "最優先確認候補": 0,
        "優先確認候補": 1,
        "確認候補": 2,
        "判断保留": 3,
        "低優先候補": 4,
        "未評価": 5,
    }
    best = ""
    best_rank = 999
    for value in values:
        text = str(value or "").strip()
        if not text:
            continue
        rank = order.get(text, 99)
        if rank < best_rank:
            best = text
            best_rank = rank
    return best


def _fix89_numeric_max(values: List[Any]) -> str:
    """Return max integer-like value as string for merged phenotype search rows."""
    max_value: Optional[int] = None
    for value in values:
        try:
            text = str(value or "").strip()
            if not text:
                continue
            n = int(float(text))
        except Exception:
            continue
        max_value = n if max_value is None else max(max_value, n)
    return "" if max_value is None else str(max_value)


def _fix89_mark_phenotype_search_stage(
    df: Optional[pd.DataFrame],
    *,
    stage_code: str,
    stage_label_ja: str,
) -> pd.DataFrame:
    """Attach an explicit phenotype-search stage label to a search dataframe."""
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        return pd.DataFrame()
    out = df.copy()
    if "strain_id" not in out.columns:
        return out
    out["phenotype_search_stage"] = out.get("phenotype_search_stage", "").astype(str) if "phenotype_search_stage" in out.columns else ""
    out["phenotype_search_stage_ja"] = out.get("phenotype_search_stage_ja", "").astype(str) if "phenotype_search_stage_ja" in out.columns else ""
    out.loc[out["phenotype_search_stage"].astype(str).str.strip() == "", "phenotype_search_stage"] = stage_code
    out.loc[out["phenotype_search_stage_ja"].astype(str).str.strip() == "", "phenotype_search_stage_ja"] = stage_label_ja
    return out


def _fix89_union_phenotype_search_results(
    stage1_presearch_df: Optional[pd.DataFrame],
    post_second_stage_df: Optional[pd.DataFrame],
) -> pd.DataFrame:
    """Union 5-0 disease-level and 5-1 candidate-level phenotype search results.

    fix89: unified_candidates must not be built only from the 5-1 candidate-level
    keyword search.  5-0 disease-level presearch candidates are the earlier,
    broader phenotype-derived discovery set and must be reflected in
    unified_candidates_review.csv/full.json/debug.csv.  This helper preserves
    all 5-0 rows and adds 5-1 rows when available; duplicate strain rows are
    merged by unioning matched keywords/MP evidence.
    """
    frames: List[pd.DataFrame] = []
    stage1 = _fix89_mark_phenotype_search_stage(
        stage1_presearch_df,
        stage_code="5-0_disease_level_pre_second_stage",
        stage_label_ja="5-0 疾患レベル表現型キーワード探索",
    )
    post = _fix89_mark_phenotype_search_stage(
        post_second_stage_df,
        stage_code="5-1_candidate_level_post_second_stage",
        stage_label_ja="5-1 候補レベル表現型キーワード照合後の補足探索",
    )
    for frame in (stage1, post):
        if frame is not None and isinstance(frame, pd.DataFrame) and not frame.empty:
            frames.append(frame.copy())
    if not frames:
        return pd.DataFrame()
    all_cols: List[str] = []
    for frame in frames:
        for col in frame.columns:
            if col not in all_cols:
                all_cols.append(col)
    concat = pd.concat([f.reindex(columns=all_cols) for f in frames], ignore_index=True).fillna("")
    if "strain_id" not in concat.columns:
        return concat
    concat["strain_id"] = concat["strain_id"].astype(str).str.strip()
    concat = concat[concat["strain_id"] != ""].copy()
    if concat.empty:
        return concat

    pipe_cols = {
        "matched_keywords", "matched_mp_ids", "matched_mp_labels", "matched_mp_id_label_pairs",
        "match_types", "phenotype_relevance_levels", "phenotype_specificity_levels",
        "phenotype_roles_ja", "phenotype_relevance_reason_ja", "resource_iri",
        "phenotype_search_stage", "phenotype_search_stage_ja", "phenotype_candidate_source_ja",
    }
    numeric_max_cols = {
        "phenotype_candidate_rank_score", "high_relevance_mp_count", "medium_relevance_mp_count",
        "specific_mp_count", "moderately_specific_mp_count", "broad_or_very_broad_mp_count",
        "unique_high_relevance_mp_count", "unique_medium_relevance_mp_count",
    }
    rows: List[Dict[str, Any]] = []
    for sid, sub in concat.groupby("strain_id", sort=True):
        rec: Dict[str, Any] = {"strain_id": sid}
        for col in all_cols:
            if col == "strain_id":
                continue
            values = sub[col].tolist() if col in sub.columns else []
            if col == "novelty_status":
                vals = [str(x or "").strip() for x in values]
                rec[col] = "候補一覧外" if "候補一覧外" in vals else ("既存候補" if "既存候補" in vals else _fix89_first_nonempty(values))
            elif col == "phenotype_candidate_priority":
                rec[col] = _fix89_best_priority(values)
            elif col in pipe_cols:
                rec[col] = _fix89_union_pipe_values(values)
            elif col in numeric_max_cols:
                rec[col] = _fix89_numeric_max(values)
            else:
                rec[col] = _fix89_first_nonempty(values)

        # Recompute unique MP count from the merged MP ID column so a merged row
        # does not undercount concepts when 5-0 and 5-1 contribute different MP terms.
        mp_ids = _split_multi_value_text(rec.get("matched_mp_ids", ""))
        if mp_ids:
            rec["unique_matched_mp_id_count"] = str(len(mp_ids))
        elif "unique_matched_mp_id_count" in sub.columns:
            rec["unique_matched_mp_id_count"] = _fix89_numeric_max(sub["unique_matched_mp_id_count"].tolist())
        if not str(rec.get("phenotype_candidate_source_ja", "")).strip():
            rec["phenotype_candidate_source_ja"] = "表現型キーワード由来"
        rows.append(rec)
    out = pd.DataFrame(rows)
    if "novelty_status" in out.columns:
        order = {"候補一覧外": 0, "既存候補": 1}
        out["_fix89_ord"] = out["novelty_status"].map(lambda x: order.get(str(x), 9))
        out = out.sort_values(["_fix89_ord", "strain_id"]).drop(columns=["_fix89_ord"]).reset_index(drop=True)
    return out


def _fix89_stage1_presearch_coverage_summary(
    stage1_presearch_df: Optional[pd.DataFrame],
    unified_df: Optional[pd.DataFrame],
) -> Dict[str, Any]:
    """Report whether 5-0 presearch candidates were preserved in unified output."""
    if stage1_presearch_df is None or not isinstance(stage1_presearch_df, pd.DataFrame) or stage1_presearch_df.empty or "strain_id" not in stage1_presearch_df.columns:
        return {
            "stage1_presearch_rows": 0,
            "stage1_presearch_unique_strain_count": 0,
            "unified_contains_all_stage1_presearch_strains": None,
            "missing_stage1_presearch_strain_ids": [],
            "note_ja": "5-0 疾患レベル表現型キーワード探索結果が渡されていないため、統合候補一覧への反映確認は未実施です。",
        }
    stage1_ids = sorted({str(x).strip() for x in stage1_presearch_df["strain_id"].tolist() if str(x).strip()})
    unified_ids: set[str] = set()
    if unified_df is not None and isinstance(unified_df, pd.DataFrame) and not unified_df.empty and "strain_id" in unified_df.columns:
        unified_ids = {str(x).strip() for x in unified_df["strain_id"].tolist() if str(x).strip()}
    missing = [sid for sid in stage1_ids if sid not in unified_ids]
    return {
        "stage1_presearch_rows": int(len(stage1_presearch_df)),
        "stage1_presearch_unique_strain_count": int(len(stage1_ids)),
        "unified_unique_strain_count": int(len(unified_ids)),
        "unified_contains_all_stage1_presearch_strains": bool(not missing),
        "missing_stage1_presearch_strain_ids": missing,
        "note_ja": "5-0 疾患レベル表現型キーワード探索で検出された候補が unified_candidates に全件反映されているかを確認する監査項目です。",
    }

def _fix85_conclusion_denominator_sentence(summary: Dict[str, Any]) -> str:
    """Return a single concise denominator sentence for ## 1 conclusion.

    This is presentation-only: it summarizes the already-computed fix81/fix84
    matching result. It does not change search, matching, scoring, ranking, or
    any phenotype candidate extraction logic.
    """
    if not isinstance(summary, dict) or not summary:
        return ""
    try:
        ja_total = int(summary.get("generated_keyword_count_ja") or 0)
        ja_match = int(summary.get("matched_label_count_ja") or 0)
        en_total = int(summary.get("generated_keyword_count_en") or 0)
        en_match = int(summary.get("matched_label_count_en") or 0)
    except Exception:
        return ""
    unique_mp_raw = summary.get("unique_matched_mp_id_count")
    try:
        unique_mp = int(unique_mp_raw) if unique_mp_raw is not None and str(unique_mp_raw).strip() else 0
    except Exception:
        unique_mp = 0
    if ja_total <= 0 and en_total <= 0:
        return ""
    parts: List[str] = []
    if ja_total > 0:
        parts.append(f"日本語{ja_total}件中{ja_match}件")
    if en_total > 0:
        parts.append(f"英語{en_total}件中{en_match}件")
    if not parts:
        return ""
    if unique_mp > 0:
        return f"第2段階LLMで生成した表現型キーワードとの照合では、{'、'.join(parts)}が候補MPラベルと一致し、一意なMP概念として{unique_mp}件が対応しました。"
    return f"第2段階LLMで生成した表現型キーワードとの照合では、{'、'.join(parts)}が候補MPラベルと一致しました。"

def _split_llm_keyword_terms(value: object) -> List[str]:
    """Split LLM-generated phenotype keyword labels into de-duplicated terms.

    The second-stage LLM sometimes returns labels separated by spaced hyphens
    (e.g. "hyperglycemia - increased glycosylated hemoglobin level").
    The phenotype-keyword SPARQL search is exact-match based, so such strings
    must be split into individual labels before querying.  Hyphens inside terms
    without surrounding spaces are preserved.
    """
    text = _sanitize_llm_phenotype_text_no_ids(value)
    if not text:
        return []
    text = re.sub(r"\s+[\-‐‑–—−]\s+", ";", text)
    parts = re.split(r"[;；,、\n/・]+", text)
    out: List[str] = []
    for part in parts:
        term = str(part or "").strip(" \t\r\n。.")
        term = re.sub(r"^[\s\-‐‑–—−•・]+", "", term).strip(" \t\r\n。.")
        if len(term) < 2:
            continue
        if term not in out:
            out.append(term)
    return out[:20]


def _fix72_stage1_context_columns_from_row(row: Any) -> Dict[str, Any]:
    """Return first-stage gene context columns for pre-second-stage selection tables.

    The pre_second_stage_candidate_selection.csv is used before the second-stage
    LLM execution.  It must therefore preserve the first-stage LLM gene context
    that explains why an existing gene/known-evidence candidate was selected.
    This helper only copies/parses existing fields; it does not infer new genes,
    IDs, or biological explanations.
    """
    try:
        rec = row.to_dict() if hasattr(row, "to_dict") else dict(row or {})
    except Exception:
        rec = {}

    ctx = _fix61_load_stage1_gene_context(rec)
    if not isinstance(ctx, dict):
        ctx = {}

    def _first(*vals: Any) -> str:
        for v in vals:
            if v is None:
                continue
            try:
                if pd.isna(v):
                    continue
            except Exception:
                pass
            s = str(v).strip()
            if s and s.lower() not in {"nan", "none", "<na>"}:
                return s
        return ""

    raw_available = str(rec.get("stage1_gene_context_available", "") or "").strip().lower()
    available = bool(ctx.get("available")) or raw_available in {"true", "1", "yes", "y"}

    ctx_sources = ctx.get("sources")
    if isinstance(ctx_sources, list):
        ctx_sources_text = ", ".join([str(x).strip() for x in ctx_sources if str(x).strip()])
    else:
        ctx_sources_text = _first(ctx_sources)

    gene = _first(ctx.get("gene_symbol"), rec.get("stage1_gene_symbol"), rec.get("primary_gene"))
    human_gene_id = _first(ctx.get("human_gene_id"), rec.get("stage1_human_gene_id"))
    gene_id_iri = _first(ctx.get("gene_id_iri"), rec.get("stage1_gene_id_iri"))
    gene_sources = _first(ctx_sources_text, rec.get("stage1_gene_sources"), rec.get("sources"))
    matched_mouse_count = _first(ctx.get("matched_mouse_count"), rec.get("stage1_matched_mouse_count"))
    matched_mouse_record_count = _first(ctx.get("matched_mouse_record_count"), rec.get("stage1_matched_mouse_record_count"))
    selected_in_list = _first(ctx.get("selected_candidate_in_stage1_matched_mouse_list"), rec.get("stage1_selected_candidate_in_matched_mouse_list"))
    explanation = _first(ctx.get("stage1_biological_explanation_ja"), rec.get("stage1_biological_explanation_ja"))

    short = _fix61_stage1_context_short_text(ctx)
    if not short:
        parts = []
        if gene:
            parts.append(gene + (f" (GeneID:{human_gene_id})" if human_gene_id else ""))
        if gene_sources:
            parts.append(f"Sources: {gene_sources}")
        if matched_mouse_count:
            parts.append(f"対応マウス数: {matched_mouse_count}件")
        if explanation:
            parts.append(explanation)
        short = " / ".join(parts)

    return {
        "stage1_gene_context_available": "true" if available else "false",
        "stage1_gene_symbol": gene,
        "stage1_human_gene_id": human_gene_id,
        "stage1_gene_id_iri": gene_id_iri,
        "stage1_gene_sources": gene_sources,
        "stage1_matched_mouse_count": matched_mouse_count,
        "stage1_matched_mouse_record_count": matched_mouse_record_count,
        "stage1_selected_candidate_in_matched_mouse_list": selected_in_list,
        "stage1_biological_explanation_ja": explanation,
        "stage1_gene_context_source_ja": _first(rec.get("stage1_gene_context_source_ja"), ctx.get("source_note_ja"), "第1段階LLMの利用者向けログまたは第1段階後の遺伝子機能補完から取得。取得できない値は空欄のままにする。"),
        "stage1_gene_context_short_ja": short,
    }


def _fix72_empty_stage1_context_columns() -> Dict[str, Any]:
    """Blank first-stage context columns for phenotype-only comparison candidates."""
    return {
        "stage1_gene_context_available": "false",
        "stage1_gene_symbol": "",
        "stage1_human_gene_id": "",
        "stage1_gene_id_iri": "",
        "stage1_gene_sources": "",
        "stage1_matched_mouse_count": "",
        "stage1_matched_mouse_record_count": "",
        "stage1_selected_candidate_in_matched_mouse_list": "",
        "stage1_biological_explanation_ja": "",
        "stage1_gene_context_source_ja": "第1段階候補一覧外の表現型由来候補のため、第1段階遺伝子根拠は未付与。",
        "stage1_gene_context_short_ja": "",
    }




def _fix73_mutation_mode_columns_from_row(row: Any, *, phenotype_only: bool = False) -> Dict[str, Any]:
    """Return mutation/strain-type interpretation columns for pre-second-stage selection.

    These columns are used as explicit, limited auxiliary evidence for candidate
    review before the second-stage LLM.  They do not by themselves establish
    disease-model validity and must not replace gene/known-evidence or phenotype
    evidence.  The function only reads existing row fields; it does not infer or
    fabricate strain type from external sources.
    """
    try:
        rec = row.to_dict() if hasattr(row, "to_dict") else dict(row or {})
    except Exception:
        rec = {}

    def _first(*vals: Any) -> str:
        for v in vals:
            try:
                if pd.isna(v):
                    continue
            except Exception:
                pass
            s = str(v or "").strip()
            if s and s.lower() not in {"nan", "none", "null"}:
                return s
        return ""

    resource_type_iri = _first(rec.get("resource_type_iri"))
    resource_type_label_en = _first(rec.get("resource_type_label_en"))
    resource_type_label_ja = _first(rec.get("resource_type_label_ja"))
    resource_type_labels = _first(rec.get("resource_type_labels"))
    variation_class_raw = _first(rec.get("variation_class_raw"))
    variation_class_normalized = _first(rec.get("variation_class_normalized"))
    variation_class_source = _first(rec.get("variation_class_source"))
    variation_class_status = _first(rec.get("variation_class_status"))

    variation_class = _first(
        variation_class_normalized if variation_class_status == "resolved" else "",
        resource_type_label_en,
        resource_type_label_ja,
        rec.get("variation_class"),
        rec.get("Variation_Class"),
        rec.get("strain_type"),
        rec.get("Strain_Type"),
        rec.get("Mutation_Type"),
    )
    if variation_class_status != "resolved" and _fix77_is_fallback_variation_class(variation_class):
        variation_class = ""
    if not variation_class_raw and variation_class:
        variation_class_raw = variation_class
    if not variation_class_normalized:
        variation_class_normalized = variation_class if variation_class else "Unknown"
    if not variation_class_status:
        variation_class_status = "resolved" if resource_type_iri or resource_type_label_en or resource_type_label_ja else ("existing_input_only" if variation_class else "not_retrieved")
    if not variation_class_source:
        variation_class_source = "xsearch_animal resourceTypeLink rdfs:label" if variation_class_status == "resolved" else ""

    mutation_type = _first(
        rec.get("mutation_type"),
        rec.get("Mutation_Type"),
        rec.get("mutation_mode"),
        variation_class,
    )

    if phenotype_only:
        return {
            "variation_class": variation_class,
            "mutation_type": mutation_type,
            "resource_type_iri": resource_type_iri,
            "resource_type_label_en": resource_type_label_en,
            "resource_type_label_ja": resource_type_label_ja,
            "resource_type_labels": resource_type_labels,
            "variation_class_raw": variation_class_raw,
            "variation_class_normalized": variation_class_normalized,
            "variation_class_source": variation_class_source,
            "variation_class_status": variation_class_status,
            "mutation_mode_available": "false",
            "mutation_mode_use_tag_ja": "第1段階候補外のため未評価",
            "strain_type_interpretation_ja": "表現型キーワード由来のみの候補であり、第1段階候補表に由来する変異様式・系統タイプ情報は未付与。",
            "mutation_mode_rank_role_ja": "候補確認順には使用しない。遺伝子・既知根拠候補との比較材料として別途系統詳細を確認する。",
            "mutation_mode_caution_ja": "表現型一致だけで疾患モデル妥当性を判断しない。変異様式、系統詳細、文献、入手性を追加確認する。",
            "mutation_mode_component": 0.0,
            "mutation_mode_component_basis_ja": "候補一覧外のため、前段候補選定スコアには変異様式成分を加算しない。",
        }

    combined = f"{variation_class} {mutation_type} {resource_type_label_en} {resource_type_label_ja} {resource_type_labels}".lower()
    combined_norm = re.sub(r"[^0-9a-zA-Zぁ-んァ-ヶ一-龥/+_-]+", " ", combined)

    chemically_induced_terms = ["chemically induced", "chemical induced", "chemical-induced", "chemical_induced", "化学誘発"]
    direct_terms = [
        "targeted", "targeted mutation", "crispr", "cas9", "crisper", "gene trap",
        "knockout", "knock out", "knock-out", "knockin", "knock in", "knock-in",
        "tm1", "tm2", "null mutation", "deletion", "insertion",
    ]
    conditional_terms = [
        "transgene", "transgenic", "tg", "cre", "loxp", "lox", "flp", "frt",
        "reporter", "fluorescent", "gfp", "rfp", "lacz", "lac z", "knock-in reporter",
    ]
    spontaneous_terms = ["spontaneous", "spontaneous mutation"]
    background_terms = ["congenic", "consomic", "inbred", "wild-derived", "wild derived", "substrain", "background"]

    def _has_any(keys: List[str]) -> bool:
        return any(k in combined_norm for k in keys)

    if not variation_class and not mutation_type:
        use_tag = "変異様式未取得"
        interpretation = "第1段階候補表に変異様式・系統タイプ情報が確認できない。"
        role = "候補確認順には使用しない。"
        component = 0.0
        basis = "変異様式情報がないため加算なし。"
    elif _has_any(chemically_induced_terms):
        use_tag = "化学誘発系統"
        interpretation = "RIKEN BRC の resourceTypeLink で Chemically induced strain / 化学誘発系統 として取得された候補。化学誘発変異により得られた系統として、原因変異、表現型、疾患関連性を系統詳細・原典で確認する。"
        role = "標的遺伝子改変系統とは異なるため、同等候補群内では原因変異・表現型原典・背景系統を確認するための補助軸として扱う。"
        component = 12.0
        basis = "化学誘発系統として、変異様式確認用の補助成分 +12。"
    elif _has_any(direct_terms):
        use_tag = "疾患関連遺伝子の機能解析向き"
        interpretation = "Targeted Mutation、CRISPR/Cas9、Gene Trap、KO/KI等に該当する可能性があり、主関連遺伝子の機能解析に使いやすい候補として読む。"
        role = "同等候補群内で先に詳細確認する候補を選ぶ際の補助軸。疾患関連遺伝子・既知根拠を上書きしない。"
        component = 15.0
        basis = "直接的な遺伝子改変系統として、前段候補確認用の補助成分 +15。"
    elif _has_any(spontaneous_terms):
        use_tag = "既知表現型・自然変異確認向き"
        interpretation = "自然発生変異系統として、既知表現型や疾患モデル性がある場合は有力な確認対象になり得る。"
        role = "既知根拠・表現型一致と併せて確認順を補助する。原因性や疾患再現性は別途確認する。"
        component = 12.0
        basis = "自然変異系統として、既知表現型確認の補助成分 +12。"
    elif _has_any(conditional_terms):
        use_tag = "条件付き解析・可視化・交配用途向き"
        interpretation = "Transgene、Cre/loxP、FLP/frt、Reporter等に該当する可能性があり、病態モデル本体というより条件付き解析、可視化、交配、補助解析の用途として読む。"
        role = "代表疾患モデル候補の自動昇格ではなく、実験設計上の用途や比較軸として扱う。"
        component = 6.0
        basis = "条件付き解析・可視化・交配用途として、限定的な補助成分 +6。"
    elif _has_any(background_terms):
        use_tag = "背景系統・修飾因子比較向き"
        interpretation = "Congenic、Inbred、Wild-derived等に該当する可能性があり、遺伝的背景、修飾因子、比較実験の観点で確認する。"
        role = "疾患モデル本体として自動昇格せず、比較候補・背景効果確認候補として扱う。"
        component = 3.0
        basis = "背景・比較用途として、低い補助成分 +3。"
    elif "other" in combined_norm or "general" in combined_norm or "その他" in combined_norm or "一般" in combined_norm:
        use_tag = "その他・一般系統"
        interpretation = "Other/General等の一般的な系統区分であり、変異様式だけでは候補の研究用途を強く判断できない。"
        role = "候補確認順には原則として加点しない。遺伝子根拠、表現型一致、applicationを優先して読む。"
        component = 0.0
        basis = "その他・一般区分のため加算なし。"
    else:
        use_tag = "変異様式要確認"
        interpretation = "変異様式・系統タイプは取得できたが、用途カテゴリを保守的に一意分類しない。系統詳細で確認する。"
        role = "確認材料として表示するが、候補確認順への加点は最小限にする。"
        component = 1.0
        basis = "未分類の変異様式として、監査用の最小補助成分 +1。"

    return {
        "variation_class": variation_class,
        "mutation_type": mutation_type,
        "resource_type_iri": resource_type_iri,
        "resource_type_label_en": resource_type_label_en,
        "resource_type_label_ja": resource_type_label_ja,
        "resource_type_labels": resource_type_labels,
        "variation_class_raw": variation_class_raw,
        "variation_class_normalized": variation_class_normalized,
        "variation_class_source": variation_class_source,
        "variation_class_status": variation_class_status,
        "mutation_mode_available": "true" if (variation_class or mutation_type) else "false",
        "mutation_mode_use_tag_ja": use_tag,
        "strain_type_interpretation_ja": interpretation,
        "mutation_mode_rank_role_ja": role,
        "mutation_mode_caution_ja": "変異様式・系統タイプは候補の用途・代表性・比較軸を説明する補助根拠であり、それだけで疾患モデル妥当性、疾患原因性、候補優劣を断定しない。",
        "mutation_mode_component": float(component),
        "mutation_mode_component_basis_ja": basis,
    }


def _sparql_literal(value: str) -> str:
    return '"' + str(value or "").replace('\\', '\\\\').replace('"', '\\"') + '"'



def _normalize_label_for_match(value: object) -> str:
    '''Normalize phenotype labels for deterministic keyword/label matching.'''
    text = str(value or '').lower()
    text = re.sub(r'https?://\S+', ' ', text)
    text = re.sub(r'\b(?:hp|mp)_\d+\b', ' ', text, flags=re.IGNORECASE)
    text = re.sub(r'[^0-9a-zA-Zぁ-んァ-ヶ一-龥]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


def _candidate_mp_label_keyword_overlap(keywords: List[str], candidate_mp_labels: str) -> Dict[str, object]:
    '''Find transparent label-level overlaps between LLM keywords and candidate MP labels.'''
    labels_text = str(candidate_mp_labels or '')
    label_parts = [x.strip() for x in re.split(r'[|;]+', labels_text) if x.strip()]
    kw_parts = [str(x or '').strip() for x in (keywords or []) if str(x or '').strip()]
    overlaps: List[str] = []
    pairs: List[str] = []
    for kw in kw_parts:
        nkw = _normalize_label_for_match(kw)
        if not nkw or len(nkw) < 2:
            continue
        for lab in label_parts:
            nlab = _normalize_label_for_match(lab)
            if not nlab or len(nlab) < 2:
                continue
            if nkw == nlab or nkw in nlab or nlab in nkw:
                if kw not in overlaps:
                    overlaps.append(kw)
                pair = f'{kw} <-> {lab}'
                if pair not in pairs:
                    pairs.append(pair)
    return {'terms': overlaps, 'pairs': pairs, 'count': len(overlaps)}


def _sparql_get_json(endpoint: str, query: str, timeout_sec: float) -> Dict[str, object]:
    resp = requests.get(
        endpoint,
        params={'query': query, 'format': 'application/sparql-results+json'},
        timeout=timeout_sec,
        headers={'Accept': 'application/sparql-results+json'},
    )
    resp.raise_for_status()
    return resp.json()


def _parse_ontology_candidate_bindings(bindings: list, keyword: str, match_type: str, limit: int) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    seen = set()
    for b in bindings or []:
        iri = str((((b or {}).get('term') or {}).get('value')) or '').strip()
        label = str((((b or {}).get('label') or {}).get('value')) or '').strip()
        syn = str((((b or {}).get('synonym') or {}).get('value')) or '').strip()
        local_id = _obo_local_id_from_iri(iri)
        if not iri or not local_id or not label:
            continue
        key = (keyword.lower(), local_id)
        if key in seen:
            continue
        seen.add(key)
        out.append({'keyword': keyword, 'id': local_id, 'iri': iri, 'label': label, 'synonym': syn, 'match_type': match_type})
        if len(out) >= limit:
            break
    return out


@st.cache_data(show_spinner=False, ttl=3600)
def _fetch_ontology_label_candidates_cached(
    keywords: tuple,
    ontology_prefix: str,
    endpoint: str = 'https://knowledge.brc.riken.jp/sparql',
    timeout_sec: float = 12.0,
    limit_per_keyword: int = 12,
) -> List[Dict[str, str]]:
    '''Resolve LLM phenotype keywords to existing HPO/MP candidates robustly.'''
    prefix = 'HP' if str(ontology_prefix).upper().startswith('HP') else 'MP'
    raw_terms: List[str] = []
    for raw in keywords or ():
        t = str(raw or '').strip()
        if t and t.lower() not in {x.lower() for x in raw_terms}:
            raw_terms.append(t)
    terms = raw_terms[:20]
    if not terms:
        return []

    out: List[Dict[str, str]] = []
    errors: List[str] = []
    global_seen = set()

    def add_candidates(cands: List[Dict[str, str]]):
        for c in cands:
            key = (str(c.get('keyword', '')).lower(), str(c.get('id', '')))
            if not c.get('id') or key in global_seen:
                continue
            global_seen.add(key)
            out.append(c)

    for term in terms:
        lit = _sparql_literal(term)
        stage_defs = [
            ('label_exact', f'''PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT DISTINCT ?term ?label ?synonym
WHERE {{
  ?term rdfs:label ?label .
  FILTER STRSTARTS(STR(?term), "http://purl.obolibrary.org/obo/{prefix}_")
  FILTER(LCASE(STR(?label)) = LCASE({lit}))
}}
ORDER BY ?label
LIMIT {max(5, min(limit_per_keyword, 20))}'''),
            ('synonym_exact', f'''PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX oboInOwl: <http://www.geneontology.org/formats/oboInOwl#>
SELECT DISTINCT ?term ?label ?synonym
WHERE {{
  ?term rdfs:label ?label .
  ?term oboInOwl:hasExactSynonym ?synonym .
  FILTER STRSTARTS(STR(?term), "http://purl.obolibrary.org/obo/{prefix}_")
  FILTER(LCASE(STR(?synonym)) = LCASE({lit}))
}}
ORDER BY ?label
LIMIT {max(5, min(limit_per_keyword, 20))}'''),
            ('label_contains', f'''PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT DISTINCT ?term ?label ?synonym
WHERE {{
  ?term rdfs:label ?label .
  FILTER STRSTARTS(STR(?term), "http://purl.obolibrary.org/obo/{prefix}_")
  FILTER(CONTAINS(LCASE(STR(?label)), LCASE({lit})) || CONTAINS(LCASE({lit}), LCASE(STR(?label))))
}}
ORDER BY ?label
LIMIT {max(8, min(limit_per_keyword, 20))}'''),
            ('synonym_contains', f'''PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX oboInOwl: <http://www.geneontology.org/formats/oboInOwl#>
SELECT DISTINCT ?term ?label ?synonym
WHERE {{
  ?term rdfs:label ?label .
  ?term oboInOwl:hasExactSynonym ?synonym .
  FILTER STRSTARTS(STR(?term), "http://purl.obolibrary.org/obo/{prefix}_")
  FILTER(CONTAINS(LCASE(STR(?synonym)), LCASE({lit})) || CONTAINS(LCASE({lit}), LCASE(STR(?synonym))))
}}
ORDER BY ?label
LIMIT {max(8, min(limit_per_keyword, 20))}'''),
        ]
        for match_type, query in stage_defs:
            try:
                obj = _sparql_get_json(endpoint, query, timeout_sec)
                bindings = (((obj or {}).get('results') or {}).get('bindings') or [])
                add_candidates(_parse_ontology_candidate_bindings(bindings, term, match_type, limit_per_keyword))
            except Exception as e:
                errors.append(f'{prefix}:{term}:{match_type}:{type(e).__name__}')

    if errors:
        out.append({'diagnostic_error': ' ; '.join(errors[:30])})
    return out


@st.cache_data(show_spinner=False, ttl=3600)
def _map_hpo_candidates_to_mp_cached(
    hpo_ids: tuple,
    endpoint: str = "https://knowledge.brc.riken.jp/sparql",
    timeout_sec: float = 30.0,
) -> List[Dict[str, str]]:
    """Map verified HPO IDs to MP IDs using hp_mp_mapping_textBased graph."""
    ids: List[str] = []
    for raw in hpo_ids or ():
        hid = _obo_local_id_from_iri(raw)
        if hid and re.match(r"^HP_\d+$", hid) and hid not in ids:
            ids.append(hid)
    if not ids:
        return []
    values = " ".join(f"<{_obo_iri_from_local_id(hid)}>" for hid in ids)
    query = f"""
SELECT DISTINCT ?hpo ?mp
WHERE {{
  GRAPH <http://metadb.riken.jp/db/hp_mp_mapping_textBased> {{
    VALUES ?hpo {{ {values} }}
    ?hpo <http://example.org/predicates/mapping> ?mp .
  }}
}}
ORDER BY ?hpo ?mp
""".strip()
    try:
        resp = requests.get(
            endpoint,
            params={"query": query, "format": "application/sparql-results+json"},
            timeout=timeout_sec,
            headers={"Accept": "application/sparql-results+json"},
        )
        resp.raise_for_status()
        obj = resp.json()
        bindings = (((obj or {}).get("results") or {}).get("bindings") or [])
        out: List[Dict[str, str]] = []
        seen = set()
        for b in bindings:
            hpo = _obo_local_id_from_iri((((b or {}).get("hpo") or {}).get("value")) or "")
            mp = _obo_local_id_from_iri((((b or {}).get("mp") or {}).get("value")) or "")
            if hpo and mp and (hpo, mp) not in seen:
                seen.add((hpo, mp))
                out.append({"hpo_id": hpo, "mp_id": mp})
        return out
    except Exception as e:
        return [{"error": f"{type(e).__name__}: {e}"}]



def _rbrc_id_from_mouse_iri(value: object) -> str:
    """Extract RBRC-style strain ID from a RIKEN BRC mouse resource IRI."""
    text = str(value or "").strip()
    if not text:
        return ""
    last = text.rstrip("/").split("/")[-1]
    m = re.search(r"(RBRC[-A-Za-z0-9]+)", last)
    return m.group(1) if m else last


def _format_rows_compact(rows: List[Dict[str, str]], *, max_items: int = 30) -> str:
    """Compact rows for display/JSON fields without hiding diagnostics in CSV."""
    if not rows:
        return ""
    parts = []
    for r in rows[:max_items]:
        sid = str(r.get("strain_id", "")).strip()
        mp = str(r.get("matched_mp_label", "")).strip()
        kw = str(r.get("matched_keyword", "")).strip()
        status = str(r.get("novelty_status", "")).strip()
        item = sid
        if mp:
            item += f" / {mp}"
        if kw:
            item += f" / keyword={kw}"
        if status:
            item += f" / {status}"
        parts.append(item)
    if len(rows) > max_items:
        parts.append(f"... 他{len(rows) - max_items}件")
    return " | ".join(parts)


@st.cache_data(show_spinner=False, ttl=3600)
def _search_mice_by_mp_label_exact_cached(
    keywords: tuple,
    existing_strain_ids: tuple,
    endpoint: str = "https://knowledge.brc.riken.jp/sparql",
    timeout_sec: float = 60.0,
) -> Dict[str, object]:
    """Find RBRC mouse resources whose MP label/exact synonym matches LLM phenotype keywords.

    This is the first implementation of phenotype-keyword-driven candidate discovery.
    It intentionally uses exact label/exact-synonym matching only. It does not ask the
    LLM to create ontology IDs, and it does not use broad fuzzy SPARQL search.
    """
    kws = []
    for k in keywords or ():
        t = _sanitize_llm_phenotype_text_no_ids(k).strip()
        if len(t) < 2:
            continue
        if t not in kws:
            kws.append(t)
    existing = {str(x).strip() for x in (existing_strain_ids or ()) if str(x).strip()}
    result: Dict[str, object] = {
        "keywords": kws,
        "rows": [],
        "error": "",
        "query_mode": "mp_label_or_exact_synonym_exact_match",
    }
    if not kws:
        return result

    values = " ".join(_sparql_literal(k) for k in kws)
    query = f"""
PREFIX sio: <http://semanticscience.org/resource/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX oboInOwl: <http://www.geneontology.org/formats/oboInOwl#>
SELECT DISTINCT ?mouse ?mp ?mp_label ?kw ?match_type
WHERE {{
  VALUES ?kw {{ {values} }}
  GRAPH <http://metadb.riken.jp/ontology/MP_international> {{
    {{
      ?mp rdfs:label ?mp_label .
      FILTER(lang(?mp_label) = "" || langMatches(lang(?mp_label), "en") || langMatches(lang(?mp_label), "ja"))
      FILTER(LCASE(STR(?mp_label)) = LCASE(STR(?kw)))
      BIND("label_exact" AS ?match_type)
    }}
    UNION
    {{
      ?mp oboInOwl:hasExactSynonym ?mp_label .
      FILTER(LCASE(STR(?mp_label)) = LCASE(STR(?kw)))
      BIND("exact_synonym" AS ?match_type)
    }}
  }}
  GRAPH <http://metadb.riken.jp/db/xsearch_animal> {{
    ?mouse sio:SIO_001279/sio:SIO_000255 ?mp .
  }}
}}
ORDER BY ?kw ?mp ?mouse
""".strip()
    try:
        resp = requests.get(
            endpoint,
            params={"query": query, "format": "application/sparql-results+json"},
            timeout=timeout_sec,
            headers={"Accept": "application/sparql-results+json"},
        )
        resp.raise_for_status()
        obj = resp.json()
        bindings = (((obj or {}).get("results") or {}).get("bindings") or [])
        rows: List[Dict[str, str]] = []
        seen = set()
        for b in bindings:
            mouse_iri = str((((b or {}).get("mouse") or {}).get("value")) or "").strip()
            mp_iri = str((((b or {}).get("mp") or {}).get("value")) or "").strip()
            mp_label = str((((b or {}).get("mp_label") or {}).get("value")) or "").strip()
            kw = str((((b or {}).get("kw") or {}).get("value")) or "").strip()
            match_type = str((((b or {}).get("match_type") or {}).get("value")) or "").strip()
            sid = _rbrc_id_from_mouse_iri(mouse_iri)
            if not sid:
                continue
            key = (sid, mp_iri, mp_label, kw, match_type)
            if key in seen:
                continue
            seen.add(key)
            novelty = "既存候補" if sid in existing else "候補一覧外"
            rows.append({
                "strain_id": sid,
                "resource_iri": mouse_iri,
                "matched_keyword": kw,
                "matched_mp_id": _obo_local_id_from_iri(mp_iri),
                "matched_mp_iri": mp_iri,
                "matched_mp_label": mp_label,
                "match_type": match_type,
                "novelty_status": novelty,
            })
        result["rows"] = rows
    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"
    return result





def _fix71_keyword_value_to_terms(value: object) -> List[str]:
    """Return robust phenotype keyword terms from scalar/list/JSON-list values.

    fix71 minimal:
    - The stage1 phenotype keyword LLM can return JSON arrays.
    - The old path converted list values to strings such as
      "['高血糖', '耐糖能異常']" and passed them to exact MP label search.
    - Exact search must receive one phenotype label per term.
    - This helper never fabricates ontology IDs; HP/MP/MONDO IDs and IRIs are removed.
    """
    import ast as _ast
    import json as _json
    import re as _re

    if value is None:
        return []

    if isinstance(value, (list, tuple, set)):
        raw_items = list(value)
    else:
        text = _sanitize_llm_phenotype_text_no_ids(value)
        text = str(text or "").strip()
        if not text or text.lower() in {"nan", "none", "null"}:
            return []
        parsed = None
        if (text.startswith("[") and text.endswith("]")) or (text.startswith("(") and text.endswith(")")):
            for parser in (_json.loads, _ast.literal_eval):
                try:
                    parsed = parser(text)
                    break
                except Exception:
                    parsed = None
        if isinstance(parsed, (list, tuple, set)):
            raw_items = list(parsed)
        else:
            text = _re.sub(r"\s+[\-‐‑–—−]\s+", ";", text)
            raw_items = _re.split(r"[;；,，、\n\r\t/・]+", text)

    out: List[str] = []
    for item in raw_items:
        term = _sanitize_llm_phenotype_text_no_ids(item)
        term = str(term or "").strip(" \t\r\n。.'\"[](){}")
        term = _re.sub(r"^[-*・]+", "", term).strip()
        term = _re.sub(r"\s+", " ", term).strip()
        if len(term) < 2:
            continue
        if term.lower() in {"nan", "none", "null"}:
            continue
        if _re.search(r"\b(HP|MP|MONDO)[:_]\d+\b", term, flags=_re.I):
            continue
        if term.startswith("http://") or term.startswith("https://"):
            continue
        if term not in out:
            out.append(term)
    return out[:40]

def _build_phenotype_keyword_new_candidate_df(
    summary_row: Dict[str, str],
    existing_candidate_ids: List[str],
) -> pd.DataFrame:
    """Build a new-candidate search table from LLM phenotype keywords.

    The search target is RBRC mice having MP terms whose label/exact synonym
    exactly matches one of the LLM-generated phenotype keyword labels.
    """
    terms_ja = _fix71_keyword_value_to_terms(summary_row.get("llm_generated_disease_phenotype_keywords_ja", "") or summary_row.get("llm_inferred_hpo_phenotype_terms_ja", ""))
    terms_en = _fix71_keyword_value_to_terms(summary_row.get("llm_generated_disease_phenotype_keywords_en", "") or summary_row.get("llm_inferred_hpo_phenotype_terms_en", ""))
    keywords = list(dict.fromkeys(terms_ja + terms_en))
    res = _search_mice_by_mp_label_exact_cached(tuple(keywords), tuple(existing_candidate_ids))
    rows = list(res.get("rows", []) or [])
    if not rows:
        if res.get("error"):
            return pd.DataFrame([{
                "diagnostic": "MP label/exact synonym 完全一致検索に失敗しました",
                "error": str(res.get("error", "")),
                "keywords_used": " | ".join(keywords),
            }])
        return pd.DataFrame(columns=[
            "strain_id", "novelty_status", "matched_keyword", "matched_mp_id", "matched_mp_label", "match_type", "resource_iri"
        ])
    df = pd.DataFrame(rows)
    # Aggregate to one row per strain while retaining all matched terms.
    agg_rows = []
    for sid, sub in df.groupby("strain_id", sort=True):
        status = "候補一覧外" if (sub["novelty_status"].astype(str) == "候補一覧外").any() else "既存候補"
        # Keep both unique MP IDs and unique labels for readability, but also keep
        # ID-label pairs so downstream unique counts are computed by MP ID, not by
        # duplicated Japanese/English labels for the same MP term.
        mp_pairs = []
        for _, r in sub.iterrows():
            mid = str(r.get("matched_mp_id", "") or "").strip()
            lab = str(r.get("matched_mp_label", "") or "").strip()
            if mid or lab:
                mp_pairs.append(f"{mid} :: {lab}")
        agg_rows.append({
            "strain_id": sid,
            "novelty_status": status,
            "matched_keywords": " | ".join(list(dict.fromkeys(sub["matched_keyword"].astype(str).tolist()))),
            "matched_mp_ids": " | ".join(list(dict.fromkeys(sub["matched_mp_id"].astype(str).tolist()))),
            "matched_mp_labels": " | ".join(list(dict.fromkeys(sub["matched_mp_label"].astype(str).tolist()))),
            "matched_mp_id_label_pairs": " | ".join(list(dict.fromkeys(mp_pairs))),
            "match_types": " | ".join(list(dict.fromkeys(sub["match_type"].astype(str).tolist()))),
            "resource_iri": " | ".join(list(dict.fromkeys(sub["resource_iri"].astype(str).tolist()))),
        })
    out = pd.DataFrame(agg_rows)
    if not out.empty:
        order = {"候補一覧外": 0, "既存候補": 1}
        out["_ord"] = out["novelty_status"].map(lambda x: order.get(str(x), 9))
        out = out.sort_values(["_ord", "strain_id"]).drop(columns=["_ord"]).reset_index(drop=True)
    out.attrs["search_keywords"] = keywords
    out.attrs["search_error"] = str(res.get("error", ""))
    out.attrs["query_mode"] = str(res.get("query_mode", ""))
    return out


def _split_pipe_terms(value: object) -> List[str]:
    parts = [str(x).strip() for x in re.split(r"\s*\|\s*", str(value or ""))]
    return [x for x in parts if x and x.lower() != "nan"]


def _mp_id_label_pairs_from_row(row: pd.Series) -> List[Tuple[str, str]]:
    """Return (mp_id, label) pairs preserving the ID-label mapping.

    The display columns `matched_mp_ids` and `matched_mp_labels` are de-duplicated
    independently for readability, so their list positions cannot be used to infer
    mapping when Japanese/English labels point to the same MP ID.  The
    `matched_mp_id_label_pairs` column, added in fix44, preserves that mapping.
    """
    pairs: List[Tuple[str, str]] = []
    raw_pairs = _split_pipe_terms(row.get("matched_mp_id_label_pairs", ""))
    for item in raw_pairs:
        if " :: " in item:
            mid, lab = item.split(" :: ", 1)
        elif "::" in item:
            mid, lab = item.split("::", 1)
        else:
            continue
        mid = str(mid or "").strip()
        lab = str(lab or "").strip()
        if mid or lab:
            pairs.append((mid, lab))
    if pairs:
        return list(dict.fromkeys(pairs))

    # Fallback for older CSVs without the pair column.  This preserves previous
    # behavior but is less reliable when there are multiple labels for one MP ID.
    labels = _split_pipe_terms(row.get("matched_mp_labels", ""))
    ids = _split_pipe_terms(row.get("matched_mp_ids", ""))
    if len(ids) == 1 and len(labels) > 1:
        return [(ids[0], lab) for lab in labels]
    return [(ids[i] if i < len(ids) else "", lab) for i, lab in enumerate(labels)]


def _phenotype_candidate_rank_score(
    *,
    high_n: int,
    med_n: int,
    specific_n: int,
    moderately_specific_n: int,
    broad_n: int,
    novelty_status: str,
    matched_mp_count: int,
) -> int:
    """Rank phenotype-keyword candidates for display.

    The score is not a biological validity score. It is a display-oriented
    prioritization score based on the number of disease-relevant MP matches,
    specificity, and whether the candidate is outside the existing Step3 list.
    """
    score = int(high_n) * 100 + int(med_n) * 40
    score += int(specific_n) * 25 + int(moderately_specific_n) * 12
    score += max(0, int(matched_mp_count) - 1) * 15
    if str(novelty_status).strip() == "候補一覧外":
        score += 10
    # Broad MP terms should not be mechanically discarded, but they should not
    # outrank equally relevant and more specific terms without additional support.
    score -= min(int(broad_n), 3) * 5
    return max(score, 0)


def _rank_candidate_priority_from_relevance(
    levels: List[str],
    *,
    specific_n: int = 0,
    moderately_specific_n: int = 0,
    broad_n: int = 0,
    novelty_status: str = "",
    matched_mp_count: int = 0,
    high_n_override: Optional[int] = None,
    med_n_override: Optional[int] = None,
) -> str:
    lv = [str(x or "").strip().lower() for x in levels]
    high_n = int(high_n_override) if high_n_override is not None else lv.count("high")
    med_n = int(med_n_override) if med_n_override is not None else lv.count("medium")
    score = _phenotype_candidate_rank_score(
        high_n=high_n, med_n=med_n, specific_n=specific_n,
        moderately_specific_n=moderately_specific_n, broad_n=broad_n,
        novelty_status=novelty_status, matched_mp_count=matched_mp_count,
    )
    # A single broad/very_broad MP should be reviewed, but should not become a
    # top-priority candidate without another disease-relevant or specific signal.
    if high_n == 1 and matched_mp_count <= 1 and broad_n >= 1 and specific_n == 0 and moderately_specific_n == 0:
        return "確認候補"
    if high_n >= 3 or score >= 260:
        return "最優先確認候補"
    if high_n >= 1 or score >= 120:
        return "優先確認候補"
    if med_n >= 1 or score >= 40:
        return "確認候補"
    if "uncertain" in lv:
        return "判断保留"
    if "low" in lv:
        return "低優先候補"
    return "未評価"


def _evaluate_mp_relevance_for_disease_with_llm(
    *,
    disease_label: str,
    phenotype_keywords_ja: List[str],
    phenotype_keywords_en: List[str],
    mp_items: List[Dict[str, object]],
    model: str,
) -> Dict[str, Dict[str, str]]:
    """Evaluate disease-context relevance and specificity of matched MP terms.

    This evaluates only MP terms already retrieved from the endpoint. The LLM must
    not generate HPO/MP identifiers or new ontology terms.
    """
    client = _llm_client(require_key=True)
    if client is None:
        return {}
    clean_items = []
    for it in mp_items or []:
        label = str(it.get("mp_label", "") or "").strip()
        if not label:
            continue
        clean_items.append({
            "mp_id": str(it.get("mp_id", "") or "").strip(),
            "mp_label": label,
            "matched_keywords": list(dict.fromkeys([str(x).strip() for x in (it.get("matched_keywords") or []) if str(x).strip()])),
            "hit_count": int(it.get("hit_count", 0) or 0),
            "new_candidate_count": int(it.get("new_candidate_count", 0) or 0),
            "known_candidate_count": int(it.get("known_candidate_count", 0) or 0),
        })
    if not clean_items:
        return {}
    payload = {
        "target_disease_label": disease_label,
        "llm_generated_phenotype_keywords_ja": phenotype_keywords_ja,
        "llm_generated_phenotype_keywords_en": phenotype_keywords_en,
        "matched_mp_terms": clean_items,
        "instruction_ja": (
            "各MP用語について、対象疾患の表現型としての関連性と特異性を評価してください。"
            "広いMP（例: 致死、体重変化、成長遅延）を機械的に低評価にせず、対象疾患文脈で重要かを判断してください。"
            "ただし疾患モデル妥当性や原因性は断定しないでください。"
        ),
    }
    system = (
        "あなたは疾患モデルマウス候補探索におけるMP表現型の疾患文脈評価を行います。"
        "入力されたMP用語だけを評価し、HPO ID、HPO IRI、MP ID、MP IRI、新しいオントロジーIDを生成してはいけません。"
        "出力はJSONのみ。キー evaluations に配列を入れてください。"
        "各要素は mp_label, phenotype_relevance_level, phenotype_specificity_level, phenotype_role_ja, phenotype_relevance_reason_ja を含めます。"
        "phenotype_relevance_level は high / medium / low / uncertain。"
        "phenotype_specificity_level は specific / moderately_specific / broad / very_broad。"
        "phenotype_role_ja は 中核表現型 / 関連表現型 / 非特異的表現型 / 判断保留 のいずれかを基本にしてください。"
    )
    try:
        resp = client.chat.completions.create(service_tier="default", 
            model=_luna_model_guard(model),
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
            ],
            response_format={"type": "json_object"},
        )
        obj = _parse_json_object_safely(resp.choices[0].message.content or "{}")
    except Exception as e:
        return {"__error__": {"phenotype_relevance_reason_ja": f"MP関連性LLM評価エラー: {type(e).__name__}: {e}"}}
    evals = obj.get("evaluations", [])
    if not isinstance(evals, list):
        return {}
    allowed_labels = {str(x.get("mp_label", "")).strip(): str(x.get("mp_id", "")).strip() for x in clean_items}
    out: Dict[str, Dict[str, str]] = {}
    valid_rel = {"high", "medium", "low", "uncertain"}
    valid_spec = {"specific", "moderately_specific", "broad", "very_broad"}
    for ev in evals:
        if not isinstance(ev, dict):
            continue
        label = str(ev.get("mp_label", "") or "").strip()
        if label not in allowed_labels:
            continue
        rel = str(ev.get("phenotype_relevance_level", "uncertain") or "uncertain").strip().lower()
        spec = str(ev.get("phenotype_specificity_level", "broad") or "broad").strip().lower()
        if rel not in valid_rel:
            rel = "uncertain"
        if spec not in valid_spec:
            spec = "broad"
        reason = _sanitize_llm_phenotype_text_no_ids(str(ev.get("phenotype_relevance_reason_ja", "") or "").strip())
        role = str(ev.get("phenotype_role_ja", "") or "").strip()
        out[label] = {
            "mp_id": allowed_labels.get(label, ""),
            "phenotype_relevance_level": rel,
            "phenotype_specificity_level": spec,
            "phenotype_role_ja": role,
            "phenotype_relevance_reason_ja": reason,
        }
    return out


def _attach_llm_mp_relevance_to_search_df(
    search_df: pd.DataFrame,
    summary_row: Dict[str, str],
    model: str,
) -> pd.DataFrame:
    """Add LLM disease-context MP relevance columns to phenotype keyword search results."""
    if search_df is None or search_df.empty or "matched_mp_labels" not in search_df.columns:
        return search_df
    out = search_df.copy()
    if "diagnostic" in out.columns and len(out) == 1:
        return out
    terms_ja = _split_llm_keyword_terms(summary_row.get("llm_generated_disease_phenotype_keywords_ja", "") or summary_row.get("llm_inferred_hpo_phenotype_terms_ja", ""))
    terms_en = _split_llm_keyword_terms(summary_row.get("llm_generated_disease_phenotype_keywords_en", "") or summary_row.get("llm_inferred_hpo_phenotype_terms_en", ""))
    disease_label = str(summary_row.get("primary_mondo_label", "") or summary_row.get("target_disease_label", "") or "").strip()
    mp_map: Dict[str, Dict[str, object]] = {}
    for _, row in out.iterrows():
        pairs = _mp_id_label_pairs_from_row(row)
        kws = _split_pipe_terms(row.get("matched_keywords", ""))
        status = str(row.get("novelty_status", "") or "").strip()
        seen_labels_for_row = set()
        for mid, lab in pairs:
            if not lab or lab in seen_labels_for_row:
                continue
            seen_labels_for_row.add(lab)
            rec = mp_map.setdefault(lab, {"mp_label": lab, "mp_id": mid, "matched_keywords": [], "hit_count": 0, "new_candidate_count": 0, "known_candidate_count": 0})
            if mid and not rec.get("mp_id"):
                rec["mp_id"] = mid
            rec["matched_keywords"] = list(dict.fromkeys(list(rec.get("matched_keywords") or []) + kws))
            rec["hit_count"] = int(rec.get("hit_count", 0) or 0) + 1
            if status == "候補一覧外":
                rec["new_candidate_count"] = int(rec.get("new_candidate_count", 0) or 0) + 1
            elif status == "既存候補":
                rec["known_candidate_count"] = int(rec.get("known_candidate_count", 0) or 0) + 1
    eval_map = _evaluate_mp_relevance_for_disease_with_llm(
        disease_label=disease_label,
        phenotype_keywords_ja=terms_ja,
        phenotype_keywords_en=terms_en,
        mp_items=list(mp_map.values()),
        model=model,
    )
    err = (eval_map.get("__error__") or {}).get("phenotype_relevance_reason_ja", "") if isinstance(eval_map, dict) else ""
    rel_col=[]; spec_col=[]; role_col=[]; reason_col=[]; prio_col=[]; score_col=[]; high_col=[]; med_col=[]; broad_col=[]; specific_col=[]; moderate_specific_col=[]
    unique_mp_count_col=[]; unique_high_col=[]; unique_medium_col=[]
    for _, row in out.iterrows():
        pairs = _mp_id_label_pairs_from_row(row)
        rels=[]; specs=[]; roles=[]; reasons=[]
        high_n=0; med_n=0; broad_n=0; specific_n=0; moderately_specific_n=0
        unique_keys=[]; unique_high=set(); unique_medium=set(); unique_specific=set(); unique_moderately_specific=set(); unique_broad=set()
        seen_label_status = set()
        for mid, lab in pairs:
            ev = eval_map.get(lab, {}) if isinstance(eval_map, dict) else {}
            rel = str(ev.get("phenotype_relevance_level", "未評価") or "未評価")
            spec = str(ev.get("phenotype_specificity_level", "未評価") or "未評価")
            role = str(ev.get("phenotype_role_ja", "未評価") or "未評価")
            reason = str(ev.get("phenotype_relevance_reason_ja", "") or "")
            mp_key = mid if str(mid).strip() else lab
            if mp_key and mp_key not in unique_keys:
                unique_keys.append(mp_key)
            if err and not reason:
                reason = err
            rels.append(f"{lab}: {rel}")
            specs.append(f"{lab}: {spec}")
            roles.append(f"{lab}: {role}")
            if reason:
                reasons.append(f"{lab}: {reason}")
            # Label-level counts are retained for diagnostics, but increment at most
            # once per label per row.  Ranking and unique_* counts use MP IDs below.
            label_status_key = (lab, rel, spec)
            if label_status_key in seen_label_status:
                continue
            seen_label_status.add(label_status_key)
            if rel == "high":
                high_n += 1
                if mp_key:
                    unique_high.add(mp_key)
            if rel == "medium":
                med_n += 1
                if mp_key:
                    unique_medium.add(mp_key)
            if spec == "specific":
                specific_n += 1
                if mp_key:
                    unique_specific.add(mp_key)
            if spec == "moderately_specific":
                moderately_specific_n += 1
                if mp_key:
                    unique_moderately_specific.add(mp_key)
            if spec in {"broad", "very_broad"}:
                broad_n += 1
                if mp_key:
                    unique_broad.add(mp_key)
        rel_values = [x.split(": ",1)[1] for x in rels if ": " in x]
        matched_mp_count = len(unique_keys)
        novelty_status = str(row.get("novelty_status", "") or "").strip()
        score = _phenotype_candidate_rank_score(
            high_n=len(unique_high), med_n=len(unique_medium), specific_n=len(unique_specific),
            moderately_specific_n=len(unique_moderately_specific), broad_n=len(unique_broad),
            novelty_status=novelty_status, matched_mp_count=matched_mp_count,
        )
        rel_col.append(" | ".join(rels))
        spec_col.append(" | ".join(specs))
        role_col.append(" | ".join(roles))
        reason_col.append(" | ".join(reasons))
        prio_col.append(_rank_candidate_priority_from_relevance(
            rel_values, specific_n=len(unique_specific), moderately_specific_n=len(unique_moderately_specific),
            broad_n=len(unique_broad), novelty_status=novelty_status, matched_mp_count=matched_mp_count,
            high_n_override=len(unique_high), med_n_override=len(unique_medium),
        ))
        score_col.append(score)
        high_col.append(high_n); med_col.append(med_n); broad_col.append(broad_n); specific_col.append(specific_n); moderate_specific_col.append(moderately_specific_n)
        unique_mp_count_col.append(matched_mp_count); unique_high_col.append(len(unique_high)); unique_medium_col.append(len(unique_medium))
    out["phenotype_candidate_priority"] = prio_col
    out["phenotype_candidate_rank_score"] = score_col
    out["high_relevance_mp_count"] = high_col
    out["medium_relevance_mp_count"] = med_col
    out["specific_mp_count"] = specific_col
    out["moderately_specific_mp_count"] = moderate_specific_col
    out["broad_or_very_broad_mp_count"] = broad_col
    out["unique_matched_mp_id_count"] = unique_mp_count_col
    out["unique_high_relevance_mp_count"] = unique_high_col
    out["unique_medium_relevance_mp_count"] = unique_medium_col
    out["phenotype_relevance_levels"] = rel_col
    out["phenotype_specificity_levels"] = spec_col
    out["phenotype_roles_ja"] = role_col
    out["phenotype_relevance_reason_ja"] = reason_col
    order = {"候補一覧外": 0, "既存候補": 1}
    prio_order = {"最優先確認候補": 0, "優先確認候補": 1, "確認候補": 2, "判断保留": 3, "低優先候補": 4, "未評価": 5, "表現型優先候補": 1}
    if "novelty_status" in out.columns:
        out["_novelty_ord"] = out["novelty_status"].map(lambda x: order.get(str(x), 9))
    else:
        out["_novelty_ord"] = 9
    out["_prio_ord"] = out["phenotype_candidate_priority"].map(lambda x: prio_order.get(str(x), 9))
    out = out.sort_values(["_novelty_ord", "_prio_ord", "phenotype_candidate_rank_score", "high_relevance_mp_count", "medium_relevance_mp_count", "strain_id"], ascending=[True, True, False, False, False, True]).drop(columns=["_novelty_ord", "_prio_ord"]).reset_index(drop=True)
    return out


def _format_candidate_list_for_llm(cands: List[Dict[str, str]], max_items: int = 40) -> List[Dict[str, str]]:
    out = []
    for c in cands or []:
        if c.get("error"):
            continue
        out.append({"id": str(c.get("id", "")), "label": str(c.get("label", "")), "keyword": str(c.get("keyword", "")), "match_type": str(c.get("match_type", ""))})
        if len(out) >= max_items:
            break
    return out


def _parse_json_object_safely(text: str) -> Dict[str, object]:
    try:
        return json.loads(text or "{}")
    except Exception:
        m = re.search(r"\{.*\}", text or "", flags=re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return {}
    return {}


def _select_bounded_ontology_candidates_with_llm(
    *,
    disease_label: str,
    phenotype_keywords_ja: List[str],
    phenotype_keywords_en: List[str],
    candidate_mp_labels: str,
    hpo_candidates: List[Dict[str, str]],
    mp_candidates: List[Dict[str, str]],
    model: str,
    timeout_sec: float = 45.0,
) -> Dict[str, object]:
    """Ask LLM to select only from SPARQL-retrieved HPO/MP candidate lists."""
    client = _llm_client(require_key=True)
    if client is None:
        return {"selected_hpo_ids": [], "selected_mp_ids": [], "reason_ja": "OPENAI_API_KEY 未設定のため候補内選択は未実行。", "confidence": "low_or_unknown"}
    hpo_for_llm = _format_candidate_list_for_llm(hpo_candidates)
    mp_for_llm = _format_candidate_list_for_llm(mp_candidates)
    if not hpo_for_llm and not mp_for_llm:
        return {"selected_hpo_ids": [], "selected_mp_ids": [], "reason_ja": "SPARQLでHPO/MP候補が取得できなかったため候補内選択は未実行。", "confidence": "low_or_unknown"}
    payload = {
        "disease_label": disease_label,
        "llm_generated_keywords_ja": phenotype_keywords_ja,
        "llm_generated_keywords_en": phenotype_keywords_en,
        "candidate_mouse_mp_labels": candidate_mp_labels,
        "hpo_candidates_from_sparql": hpo_for_llm,
        "mp_candidates_from_sparql": mp_for_llm,
    }
    system = (
        "あなたは表現型オントロジー候補の選択補助を行います。"
        "HPO/MP IDを新規生成してはいけません。候補リストに存在するIDだけを selected_hpo_ids / selected_mp_ids に含めてください。"
        "候補リスト外のID、IRI、HP_ や MP_ 形式の新規IDは絶対に出力しないでください。"
        "対象疾患とLLM生成表現型キーワード、および候補マウスMPラベルを比較し、意味的に対応する候補だけを選択してください。"
        "JSONのみを返してください。キーは selected_hpo_ids, selected_mp_ids, reason_ja, confidence です。"
        "confidence は high / medium / low_or_unknown のいずれかです。"
    )
    try:
        resp = client.chat.completions.create(service_tier="default", 
            model=_luna_model_guard(model),
            timeout=timeout_sec,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
            response_format={"type": "json_object"},
        )
        obj = _parse_json_object_safely(resp.choices[0].message.content or "{}")
    except Exception as e:
        return {"selected_hpo_ids": [], "selected_mp_ids": [], "reason_ja": f"候補内選択LLM実行エラー: {type(e).__name__}: {e}", "confidence": "low_or_unknown"}
    allowed_hpo = {str(c.get("id")) for c in hpo_for_llm if c.get("id")}
    allowed_mp = {str(c.get("id")) for c in mp_for_llm if c.get("id")}
    raw_hpo = obj.get("selected_hpo_ids", [])
    raw_mp = obj.get("selected_mp_ids", [])
    if isinstance(raw_hpo, str):
        raw_hpo = re.split(r"[;,、\s]+", raw_hpo)
    if isinstance(raw_mp, str):
        raw_mp = re.split(r"[;,、\s]+", raw_mp)
    selected_hpo = [x for x in [str(v).strip() for v in (raw_hpo or [])] if x in allowed_hpo]
    selected_mp = [x for x in [str(v).strip() for v in (raw_mp or [])] if x in allowed_mp]
    conf = str(obj.get("confidence", "low_or_unknown") or "low_or_unknown").strip().lower()
    if conf not in {"high", "medium", "low_or_unknown"}:
        conf = "low_or_unknown"
    reason = _sanitize_llm_phenotype_text_no_ids(obj.get("reason_ja", ""))
    return {"selected_hpo_ids": list(dict.fromkeys(selected_hpo)), "selected_mp_ids": list(dict.fromkeys(selected_mp)), "reason_ja": reason, "confidence": conf}


def _apply_candidate_bounded_phenotype_mapping(row: Dict[str, str], *, model: str = "gpt-6-luna") -> Dict[str, str]:
    """Score phenotype support using LLM-generated phenotype keywords and real candidate MP labels.

    fix37 policy:
      * Do NOT run broad ontology-label SPARQL searches here.
      * Do NOT ask the LLM to create or choose HPO/MP IDs here.
      * Use already available, traceable HPOA->HPO-MP exact overlap when present.
      * Otherwise, use LLM-generated disease phenotype keyword labels and compare them
        against the candidate's existing MP labels. This generalizes the earlier
        diabetes-specific hard-coded keyword check without hard-coding disease names.

    HPO/MP IDs used for scoring must come from existing data/SPARQL-derived fields,
    not from LLM output.
    """
    out = dict(row)

    # Candidate MP labels are existing annotations for the selected mouse strain.
    mp_labels_text = str(out.get("evidence_mp_labels", "") or "").strip()

    # Keywords are generated by the second-stage LLM as labels only; sanitize any
    # accidental IDs/IRIs before they are used or saved.
    terms_ja = _split_llm_keyword_terms(_sanitize_llm_phenotype_text_no_ids(out.get("llm_inferred_hpo_phenotype_terms_ja", "")))
    terms_en = _split_llm_keyword_terms(_sanitize_llm_phenotype_text_no_ids(out.get("llm_inferred_hpo_phenotype_terms_en", "")))
    all_terms = list(dict.fromkeys(terms_ja + terms_en))

    # Exact ID-based support from HPOA-derived HPO -> MP mapping is still the most traceable route.
    existing_overlap = str(out.get("phenotype_mapping_overlap_mp_ids", "") or "").strip()

    # Direct label overlap is the general replacement for the old diabetes-specific keyword list.
    # Example: LLM keyword "高血糖" / "hyperglycemia" vs candidate MP label
    # "hyperglycemia | 高血糖".
    label_overlap = _candidate_mp_label_keyword_overlap(all_terms, mp_labels_text)
    overlap_count = int(label_overlap.get("count", 0) or 0)
    overlap_terms = list(label_overlap.get("terms", []) or [])
    overlap_pairs = list(label_overlap.get("pairs", []) or [])

    out["llm_generated_disease_phenotype_keywords_ja"] = "、".join(terms_ja)
    out["llm_generated_disease_phenotype_keywords_en"] = "; ".join(terms_en)
    out["candidate_mp_labels_for_keyword_scoring"] = mp_labels_text
    out["llm_keyword_candidate_mp_label_overlap_terms"] = " | ".join(overlap_terms)
    out["llm_keyword_candidate_mp_label_overlap_pairs"] = " | ".join(overlap_pairs)
    out["llm_keyword_candidate_mp_label_overlap_count"] = str(overlap_count)

    # These fields are kept for compatibility, but broad ontology SPARQL mapping is intentionally not run in the current second-stage phenotype evaluation.
    out["sparql_hpo_candidates_from_llm_keywords"] = "未実行: 現行仕様では広域HPOラベル検索SPARQLを第2段階評価に使用しない"
    out["sparql_mp_candidates_from_llm_keywords"] = "未実行: 現行仕様では広域MPラベル検索SPARQLを第2段階評価に使用しない"
    out["llm_selected_hpo_candidate_ids"] = ""
    out["llm_selected_mp_candidate_ids"] = ""
    out["mapped_mp_from_llm_selected_hpo"] = ""
    out["phenotype_keyword_candidate_overlap_mp_ids"] = existing_overlap
    out["candidate_bounded_llm_mapping_reason_ja"] = (
        "現行仕様では、広域HPO/MP候補検索ではなく、LLM生成表現型キーワードと実在する候補MPラベルの照合、"
        "およびHPOA由来HPO→MP mappingの既存一致を用いる。LLMはHPO/MP IDを生成しない。"
    )
    out["candidate_bounded_llm_mapping_confidence"] = "not_used"

    # Scoring hierarchy.
    if existing_overlap:
        out["phenotype_support_level"] = "high"
        out["phenotype_support_text_ja"] = _phenotype_support_text_ja("high")
        out["phenotype_support_source"] = "hpoa_hpo_mp_exact"
        out["evidence_mp_summary_ja"] = (
            "HPOA由来HPOをHPO-MP mappingで変換したMPと候補MPに直接一致が確認された。"
            f"一致MP: {existing_overlap}。"
        )
    elif overlap_count > 0:
        out["phenotype_support_level"] = "high"
        out["phenotype_support_text_ja"] = _phenotype_support_text_ja("high")
        out["phenotype_support_source"] = "llm_keyword_candidate_mp_label_match"
        out["evidence_mp_summary_ja"] = (
            "第2段階LLMが対象疾患に関連する表現型キーワードをラベルとして生成し、"
            "それらと実在する候補MPラベルとの明確な一致または包含関係を確認した。"
            f"一致語: {out['llm_keyword_candidate_mp_label_overlap_terms']}。"
            "この評価はHPO/MP IDの新規生成ではなく、候補MPラベルとLLM生成キーワードの照合に基づく。"
        )
    else:
        confidence = str(out.get("llm_inferred_phenotype_confidence", "") or "").strip().lower()
        alignment = _sanitize_llm_phenotype_text_no_ids(out.get("llm_inferred_phenotype_alignment_ja", ""))
        if confidence in {"high", "medium"} and mp_labels_text and alignment:
            out["phenotype_support_level"] = "medium"
            out["phenotype_support_text_ja"] = _phenotype_support_text_ja("medium")
            out["phenotype_support_source"] = "llm_semantic_support_no_label_overlap"
            out["evidence_mp_summary_ja"] = (
                "HPOA由来HPO-MP mappingで候補MPとの直接一致はなく、LLM生成表現型キーワードと候補MPラベルの明確な文字列一致も確認できなかった。"
                "ただし、第2段階LLMは候補MPラベルと対象疾患表現型の意味的関連を補助的に示した。"
                f"LLM評価: {alignment}"
            )
        else:
            out["phenotype_support_level"] = "low_or_unknown"
            out["phenotype_support_source"] = "mp_available_no_direct_support" if mp_labels_text else "mp_unavailable"
            out["phenotype_support_text_ja"] = _phenotype_support_text_ja("mp_available_limited" if mp_labels_text else "mp_unavailable")
            if mp_labels_text:
                out["evidence_mp_summary_ja"] = (
                    "MPは取得済みだが、HPOA由来HPO-MP mapping一致、またはLLM生成表現型キーワードと候補MPラベルの明確な一致は確認できなかった。"
                )
            else:
                out["evidence_mp_summary_ja"] = "MP未取得のため、表現型面は未評価。"

    out["phenotype_support_source_text_ja"] = _phenotype_support_source_text_ja(out.get("phenotype_support_source", ""))
    out = _fix68_apply_broad_phenotype_downgrade(out)
    return out


_FIX68_BROAD_OR_INDIRECT_PHENOTYPE_TERMS = {
    "lethality",
    "prenatal lethality",
    "embryonic lethality",
    "perinatal lethality",
    "postnatal lethality",
    "complete penetrance",
    "incomplete penetrance",
    "penetrance",
    "viability",
    "mortality",
    "致死性",
    "胎生致死",
    "出生前致死",
    "完全浸透",
    "不完全浸透",
    "浸透率",
}


def _fix68_split_phenotype_terms(value: Any) -> List[str]:
    """Split stored phenotype keyword strings without inventing new terms."""
    text = str(value or "").strip()
    if not text:
        return []
    text = re.sub(r"\s+", " ", text)
    raw = re.split(r"\s*\|\s*|\s*;\s*|\s*,\s*|\s*、\s*|\s*/\s*", text)
    out: List[str] = []
    seen = set()
    for x in raw:
        t = str(x or "").strip().strip("。 .")
        if not t:
            continue
        k = t.lower()
        if k not in seen:
            seen.add(k)
            out.append(t)
    return out


def _fix68_is_broad_or_indirect_term(term: Any) -> bool:
    t = str(term or "").strip().lower()
    if not t:
        return False
    if t in _FIX68_BROAD_OR_INDIRECT_PHENOTYPE_TERMS:
        return True
    # Keep this conservative: only downgrade clearly broad/indirect terms.
    return bool(re.fullmatch(r".*\b(lethality|penetrance|viability|mortality)\b.*", t))


def _fix68_broad_or_indirect_terms_only(row: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """Return True only when all positive phenotype overlaps are broad/indirect.

    This prevents ALS-like cases from being labeled as phenotype_support_level=high
    solely because terms such as lethality or penetrance matched candidate MP labels.
    It does not affect disease-specific phenotype matches such as hyperglycemia.
    """
    terms: List[str] = []
    for key in (
        "llm_keyword_candidate_mp_label_overlap_terms",
        "keyword_overlap_terms",
        "phenotype_keyword_candidate_overlap_terms",
    ):
        terms.extend(_fix68_split_phenotype_terms((row or {}).get(key)))
    # For exact HPOA-HPO-MP ID overlap, do not downgrade only from labels unless
    # the textual overlap terms are available and broad; ID-level evidence remains traceable.
    if not terms:
        return False, []
    seen = set()
    unique_terms = []
    for term in terms:
        k = term.lower()
        if k not in seen:
            seen.add(k)
            unique_terms.append(term)
    if unique_terms and all(_fix68_is_broad_or_indirect_term(t) for t in unique_terms):
        return True, unique_terms
    return False, unique_terms


def _fix68_apply_broad_phenotype_downgrade(row: Dict[str, str]) -> Dict[str, str]:
    """Downgrade phenotype high calls based only on broad/indirect phenotype terms."""
    out = dict(row)
    level = str(out.get("phenotype_support_level", "") or "").strip().lower()
    source = str(out.get("phenotype_support_source", "") or "").strip()
    is_broad_only, terms = _fix68_broad_or_indirect_terms_only(out)
    if level == "high" and is_broad_only and source != "hpoa_hpo_mp_exact":
        term_text = " | ".join(terms)
        out["phenotype_support_level"] = "low_or_indirect"
        out["phenotype_support_text_ja"] = _phenotype_support_text_ja("low_or_indirect")
        out["phenotype_support_source"] = "broad_or_indirect_phenotype_terms_only"
        out["phenotype_support_source_text_ja"] = _phenotype_support_source_text_ja(out.get("phenotype_support_source", ""))
        out["broad_or_indirect_phenotype_terms"] = term_text
        out["phenotype_specificity_warning_ja"] = (
            "一致した表現型語が広い語または間接語に限られるため、対象疾患に特異的な表現型補強としては扱いません。"
        )
        out["evidence_mp_summary_ja"] = (
            f"候補自身のMP/表現型注釈に一致語（{term_text}）はありますが、"
            "致死性・浸透率などの広い語または間接語に限られます。"
            "対象疾患に特異的な運動機能障害、代謝異常などの中核表現型一致とは区別し、"
            "表現型面からの補強は限定的として扱います。"
        )
    else:
        out.setdefault("broad_or_indirect_phenotype_terms", " | ".join([t for t in terms if _fix68_is_broad_or_indirect_term(t)]))
    return out

def _add_llm_phenotype_keyword_audit_fields(row: Dict[str, str]) -> Dict[str, str]:
    """Expose LLM-generated phenotype keywords and MP labels used for scoring.

    These fields are intentionally user-visible and saved to Markdown/JSON so
    the user can verify what the LLM generated and what candidate MP labels were
    compared. LLM-generated terms are labels/keywords only; IDs/IRIs are removed
    before storage.
    """
    out = dict(row)
    terms = _sanitize_llm_phenotype_text_no_ids(out.get("llm_inferred_hpo_phenotype_terms_ja", ""))
    alignment = _sanitize_llm_phenotype_text_no_ids(out.get("llm_inferred_phenotype_alignment_ja", ""))
    caution = _sanitize_llm_phenotype_text_no_ids(out.get("llm_inferred_phenotype_caution_ja", ""))
    mp_labels = str(out.get("evidence_mp_labels", "") or "").strip()
    confidence = str(out.get("llm_inferred_phenotype_confidence", "") or "").strip()
    source = str(out.get("phenotype_support_source", "") or "").strip()
    level = str(out.get("phenotype_support_level", "") or "").strip()

    out["llm_generated_disease_phenotype_keywords_ja"] = terms
    out["candidate_mp_labels_for_keyword_scoring"] = mp_labels
    out["llm_generated_phenotype_keywords_note_ja"] = (
        "第2段階LLMが対象疾患ラベルから生成した表現型キーワードです。"
        "HPO ID、HPO IRI、MP ID、MP IRIはLLMに生成させず、保存前にも除去します。"
    )

    basis_parts = []
    if terms:
        basis_parts.append(f"LLM生成表現型キーワード: {terms}")
    else:
        basis_parts.append("LLM生成表現型キーワード: （未記載）")
    if mp_labels:
        basis_parts.append(f"照合対象の候補MPラベル: {mp_labels}")
    else:
        basis_parts.append("照合対象の候補MPラベル: （MP未取得）")
    if alignment:
        basis_parts.append(f"LLMによるキーワード-MP整合性評価: {alignment}")
    if str(out.get("llm_generated_disease_phenotype_keywords_en", "") or "").strip():
        basis_parts.append(f"LLM生成表現型キーワード（英語）: {str(out.get('llm_generated_disease_phenotype_keywords_en')).strip()}")
    if str(out.get("sparql_hpo_candidates_from_llm_keywords", "") or "").strip():
        basis_parts.append(f"SPARQL取得HPO候補: {str(out.get('sparql_hpo_candidates_from_llm_keywords')).strip()}")
    if str(out.get("llm_selected_hpo_candidate_ids", "") or "").strip():
        basis_parts.append(f"LLM選択HPO候補ID（候補リスト内限定）: {str(out.get('llm_selected_hpo_candidate_ids')).strip()}")
    if str(out.get("mapped_mp_from_llm_selected_hpo", "") or "").strip():
        basis_parts.append(f"LLM選択HPO由来MP: {str(out.get('mapped_mp_from_llm_selected_hpo')).strip()}")
    if str(out.get("sparql_mp_candidates_from_llm_keywords", "") or "").strip():
        basis_parts.append(f"SPARQL取得MP候補: {str(out.get('sparql_mp_candidates_from_llm_keywords')).strip()}")
    if str(out.get("llm_selected_mp_candidate_ids", "") or "").strip():
        basis_parts.append(f"LLM選択MP候補ID（候補リスト内限定）: {str(out.get('llm_selected_mp_candidate_ids')).strip()}")
    if str(out.get("phenotype_keyword_candidate_overlap_mp_ids", "") or "").strip():
        basis_parts.append(f"候補MPとの一致MP: {str(out.get('phenotype_keyword_candidate_overlap_mp_ids')).strip()}")
    if str(out.get("candidate_bounded_llm_mapping_reason_ja", "") or "").strip():
        basis_parts.append(f"候補内選択理由: {str(out.get('candidate_bounded_llm_mapping_reason_ja')).strip()}")
    if confidence:
        basis_parts.append(f"LLM整合性信頼度: {confidence}")
    if level:
        basis_parts.append(f"最終表現型支持レベル: {level}")
    if source:
        basis_parts.append(f"表現型支持の根拠区分: {source}")
    if caution:
        basis_parts.append(f"注意: {caution}")
    out["phenotype_keyword_scoring_basis_ja"] = " / ".join(basis_parts)
    return out

def _apply_llm_phenotype_assistance(row: Dict[str, str]) -> Dict[str, str]:
    """Use LLM-generated disease phenotype keywords for phenotype support.

    The LLM is allowed to generate disease-relevant phenotype *labels/keywords*
    and compare them against real candidate MP labels. It must not generate or
    return HPO/MP identifiers or IRIs. Verified HPOA->HPO-MP exact overlap is
    preserved as the strongest traceable evidence, but LLM keyword-based support
    may also set phenotype_support_level to high when the semantic match is
    explicitly high and grounded in the candidate's existing MP labels.
    """
    out = dict(row)
    for k in (
        "llm_inferred_hpo_phenotype_terms_ja",
        "llm_inferred_phenotype_alignment_ja",
        "llm_inferred_phenotype_caution_ja",
    ):
        out[k] = _sanitize_llm_phenotype_text_no_ids(out.get(k, ""))

    current = str(out.get("phenotype_support_level", "") or "").strip()
    if current == "high":
        out.setdefault("phenotype_support_source", "hpoa_hpo_mp_exact")
        out["phenotype_support_source_text_ja"] = _phenotype_support_source_text_ja(out.get("phenotype_support_source", ""))
        out = _fix68_apply_broad_phenotype_downgrade(out)
        out = _add_llm_phenotype_keyword_audit_fields(out)
        out = _reconcile_single_candidate_free_text(out)
        return out

    mp_labels = str(out.get("evidence_mp_labels", "") or "").strip()
    if not mp_labels:
        out.setdefault("phenotype_support_source", "mp_unavailable")
        out["phenotype_support_source_text_ja"] = _phenotype_support_source_text_ja(out.get("phenotype_support_source", ""))
        out = _add_llm_phenotype_keyword_audit_fields(out)
        out = _reconcile_single_candidate_free_text(out)
        return out

    bounded_source = str(out.get("phenotype_support_source", "") or "").strip()
    if bounded_source in {"llm_candidate_bounded_no_overlap"}:
        out["phenotype_support_source_text_ja"] = _phenotype_support_source_text_ja(out.get("phenotype_support_source", ""))
        out = _add_llm_phenotype_keyword_audit_fields(out)
        out = _reconcile_single_candidate_free_text(out)
        return out

    confidence = str(out.get("llm_inferred_phenotype_confidence", "") or "").strip().lower()
    alignment = str(out.get("llm_inferred_phenotype_alignment_ja", "") or "").strip()
    terms = str(out.get("llm_inferred_hpo_phenotype_terms_ja", "") or "").strip()
    prefix = "HPOA由来HPO-MP mappingで候補MPとの直接一致は確認できなかった。"

    if confidence == "high" and alignment:
        out["phenotype_support_level"] = "high"
        out["phenotype_support_text_ja"] = _phenotype_support_text_ja("high")
        out["phenotype_support_source"] = "llm_inferred_hpo_mp_support_high"
        out["evidence_mp_summary_ja"] = (
            f"{prefix} ただし、第2段階LLMが対象疾患に関連する表現型キーワードをラベルとして生成し、"
            "実在する候補MPラベルとの意味的整合性が高いと評価した。"
            "この評価はHPO/MP IDやIRIの生成に基づくものではなく、候補MPラベルと疾患表現型キーワードの照合に基づく補助評価である。"
            f"LLM生成表現型キーワード: {terms or '（未記載）'}。LLM評価: {alignment}"
        )
    elif confidence == "medium" and alignment:
        out["phenotype_support_level"] = "medium"
        out["phenotype_support_text_ja"] = _phenotype_support_text_ja("medium")
        out["phenotype_support_source"] = "llm_inferred_hpo_mp_support_medium"
        out["evidence_mp_summary_ja"] = (
            f"{prefix} 第2段階LLMが対象疾患に関連する表現型キーワードをラベルとして生成し、"
            "実在する候補MPラベルとの意味的整合性が一部あると評価した。"
            "この評価は補助評価であり、疾患再現性を断定しない。"
            f"LLM生成表現型キーワード: {terms or '（未記載）'}。LLM評価: {alignment}"
        )
    elif confidence in {"low", "low_or_unknown", "uncertain", "unknown"}:
        out["phenotype_support_level"] = "low_or_unknown"
        out["phenotype_support_text_ja"] = _phenotype_support_text_ja("mp_available_limited" if mp_labels else "mp_unavailable")
        out["phenotype_support_source"] = "llm_inferred_low_support"
        if alignment:
            out["evidence_mp_summary_ja"] = (
                f"{prefix} 第2段階LLMが対象疾患に関連する表現型キーワードをラベルとして生成したが、"
                "実在する候補MPラベルとの直接的な意味的整合性は限定的または判断困難と評価した。"
                f"LLM生成表現型キーワード: {terms or '（未記載）'}。LLM評価: {alignment}"
            )
    out["phenotype_support_source_text_ja"] = _phenotype_support_source_text_ja(out.get("phenotype_support_source", ""))
    out = _fix68_apply_broad_phenotype_downgrade(out)
    out = _add_llm_phenotype_keyword_audit_fields(out)
    out = _reconcile_single_candidate_free_text(out)
    return out


def _reconcile_single_candidate_free_text(row: Dict[str, str]) -> Dict[str, str]:
    """Make free-text summary consistent with final structured phenotype fields."""
    out = dict(row)
    level = str(out.get("phenotype_support_level", "") or "").strip() or "low_or_unknown"
    text = str(out.get("phenotype_support_text_ja", "") or _phenotype_support_text_ja(level)).strip()
    source = str(out.get("phenotype_support_source", "") or "").strip()
    source_text = str(out.get("phenotype_support_source_text_ja", "") or _phenotype_support_source_text_ja(source)).strip()
    mp_summary = str(out.get("evidence_mp_summary_ja", "") or "").strip()
    gene = str(out.get("primary_gene", "") or "").strip()
    disease = str(out.get("primary_mondo_label", "") or "").strip()
    sources = str(out.get("sources", "") or "").strip()
    priority = str(out.get("selection_priority_hint", "") or "").strip()
    rec = str(out.get("llm_recommendation_display_ja", "") or "").strip()

    caution_base = str(out.get("caution_ja", "") or "").strip()
    caution_parts = [
        "本情報だけで疾患原因性やモデル妥当性は断定できません。",
        f"表現型支持レベルは {level}（{text}）です。",
    ]
    if source_text:
        caution_parts.append(f"表現型支持の根拠区分: {source}。{source_text}")
    if mp_summary:
        caution_parts.append(f"MP評価: {mp_summary}")
    # Preserve non-phenotype caution sentences if present, but remove stale level references.
    caution_base = re.sub(r"phenotype_support_level\s*(?:は|も)?\s*(high|medium|low_or_unknown)", "", caution_base)
    if caution_base and "表現型" not in caution_base and caution_base not in caution_parts:
        caution_parts.insert(0, caution_base)
    out["caution_ja"] = " ".join([x for x in caution_parts if x]).strip()

    key_bits = []
    if disease:
        key_bits.append(f"疾患名: {disease}")
    if gene:
        key_bits.append(f"主関連遺伝子: {gene}")
    if sources:
        key_bits.append(f"根拠情報源: {sources}")
    key_bits.append(f"表現型支持レベル: {level}")
    if source:
        key_bits.append(f"表現型支持根拠: {source}")
    if str(out.get("recommended_use_tag", "") or "").strip():
        key_bits.append(f"recommended_use_tag: {str(out.get('recommended_use_tag')).strip()}")
    if priority:
        key_bits.append(f"selection_priority_hint: {priority}")
    if rec:
        key_bits.append(f"LLM推奨: {rec}")
    out["key_points_ja"] = " / ".join(key_bits)
    return out

def _pair_option_label(row: pd.Series) -> str:
    pair_id = str(row.get("pair_id", "")).strip()
    a = str(row.get("strain_id_a", "")).strip() or str(row.get("strain_name_a", "")).strip() or "A"
    b = str(row.get("strain_id_b", "")).strip() or str(row.get("strain_name_b", "")).strip() or "B"
    pa = str(row.get("priority_a", "")).strip()
    pb = str(row.get("priority_b", "")).strip()
    theme = str(row.get("comparison_theme", "")).strip()
    parts = [pair_id] if pair_id else []
    aa = f"{a} [{pa}]" if pa else a
    bb = f"{b} [{pb}]" if pb else b
    parts.append(f"{aa} vs {bb}")
    if theme:
        parts.append(theme)
    return " | ".join(parts)


def _find_summary_row_by_strain_id(df_llm_summary: pd.DataFrame, strain_id: str) -> Dict[str, str]:
    if df_llm_summary is None or df_llm_summary.empty or "strain_id" not in df_llm_summary.columns:
        return {}
    sub = df_llm_summary[df_llm_summary["strain_id"].astype(str).str.strip() == str(strain_id).strip()].head(1)
    if sub.empty:
        return {}
    row = sub.iloc[0]
    return {str(k): str(v).strip() for k, v in row.to_dict().items()}


def _parse_pair_llm_json(content: str) -> Dict[str, str]:
    obj = json.loads(content)
    fields = [
        "why_this_pair_ja",
        "what_can_be_compared_ja",
        "expected_difference_axis",
        "pair_caution_ja",
        "shared_context",
        "difference_context",
    ]
    out = {}
    for f in fields:
        out[f] = str(obj.get(f, "")).strip()
    missing = [f for f, v in out.items() if not v]
    if missing:
        raise RuntimeError("pair summary missing fields: " + ", ".join(missing))
    return out


def _generate_pair_summary_with_llm(
    pair_row: pd.Series,
    df_llm_summary: pd.DataFrame,
    *,
    model: str = "gpt-6-luna",
    timeout_sec: float = 60.0,
) -> Dict[str, str]:
    client = _llm_client(require_key=True)
    if client is None:
        raise RuntimeError("OPENAI_API_KEY 未設定または openai パッケージ未利用")

    strain_id_a = str(pair_row.get("strain_id_a", "")).strip()
    strain_id_b = str(pair_row.get("strain_id_b", "")).strip()
    row_a = _find_summary_row_by_strain_id(df_llm_summary, strain_id_a)
    row_b = _find_summary_row_by_strain_id(df_llm_summary, strain_id_b)

    user_payload = {
        "pair": {str(k): str(v).strip() for k, v in pair_row.to_dict().items()},
        "strain_a_summary": row_a,
        "strain_b_summary": row_b,
    }

    system = (
        "あなたは研究者向けのバイオリソース選定支援アシスタントです。"
        "与えられた比較提案行と系統要約行だけを根拠に、日本語で簡潔に比較要約を作成してください。"
        "断定を避け、推測は最小限にしてください。"
        "必ずJSONのみを返し、次のキーをすべて含めてください: "
        "why_this_pair_ja, what_can_be_compared_ja, expected_difference_axis, pair_caution_ja, shared_context, difference_context"
    )

    resp = client.chat.completions.create(service_tier="default", 
        model=_luna_model_guard(model),
        timeout=timeout_sec,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)},
        ],
        response_format={"type": "json_object"},
    )
    content = (resp.choices[0].message.content or "").strip()
    out = _parse_pair_llm_json(content)
    out["pair_llm_worked"] = "true"
    out["pair_llm_failure_reason"] = ""
    out["pair_llm_model"] = model
    return out



def _app_pick_primary_gene(sub: pd.DataFrame) -> Tuple[str, str]:
    candidate_cols = [
        "extdb_related_human_gene_symbol",
        "extdb_related_mouse_gene_symbol",
        "riken_related_gene_symbol",
        "Genes",
    ]
    genes: List[str] = []
    for col in candidate_cols:
        if col not in sub.columns:
            continue
        for raw in sub[col].astype(str).tolist():
            parts = [str(x).strip() for x in str(raw).split(",") if str(x).strip()]
            genes.extend(parts)
    uniq = []
    seen = set()
    for g in genes:
        if g in seen:
            continue
        seen.add(g)
        uniq.append(g)
    primary = uniq[0] if uniq else ""
    others = ", ".join(uniq[1:]) if len(uniq) > 1 else ""
    return primary, others


def _app_pick_primary_mondo(sub: pd.DataFrame, target_mondo: str) -> Tuple[str, str]:
    mids = []
    if "MONDO_ID" in sub.columns:
        mids = [_normalize_mondo_id(v) for v in sub["MONDO_ID"].astype(str).tolist()]
    mids = [m for m in mids if m]
    uniq = []
    seen = set()
    for m in mids:
        if m in seen:
            continue
        seen.add(m)
        uniq.append(m)
    if target_mondo and target_mondo in uniq:
        primary = target_mondo
        rest = [m for m in uniq if m != target_mondo]
    else:
        primary = uniq[0] if uniq else target_mondo
        rest = uniq[1:] if len(uniq) > 1 else []
    return primary, ", ".join(rest)


def _app_selection_priority_hint(primary_mondo_id: str, target_mondo: str, primary_gene: str, sources: str) -> str:
    src_set = {x.strip().lower() for x in str(sources).split(",") if x.strip()}
    direct = bool(primary_mondo_id and target_mondo and primary_mondo_id == target_mondo)
    core = bool(primary_gene)
    has_multiple_or_model_evidence = (len(src_set) >= 2) or ("models" in src_set)

    if direct and core and has_multiple_or_model_evidence:
        return "最優先候補"
    if direct and core:
        return "有力候補"
    if core and len(src_set) >= 2:
        return "比較候補"
    if core:
        return "補助候補"
    return "探索候補"


def _selection_priority_explanation_ja(value: str) -> str:
    mapping = {
        "最優先候補": "最初に詳細を確認する候補。対象疾患との関連が明確で、主関連遺伝子から見て研究目的に合う可能性が高いもの。",
        "有力候補": "対象疾患との関連が示されており、候補として優先的に確認する価値があるもの。研究目的との対応は追加情報で確認する。",
        "比較候補": "主関連遺伝子、変異型、系統背景、解析用途などが他候補と異なり、候補間比較によって研究目的に合うか判断しやすい候補。",
        "補助候補": "対象疾患の代表候補というより、関連する病態経路、修飾因子、合併症、炎症・代謝・神経などの周辺メカニズム、または解析補助・交配・観察に有用な候補。",
        "探索候補": "既知根拠だけでは位置づけが十分に確立していないが、遺伝子・関連経路などから探索的に確認する価値がある候補。疾患モデルとしての妥当性は追加検証を前提とする。",
    }
    return mapping.get(str(value or "").strip(), "")


def _source_provenance_level_from_sources(sources: str) -> str:
    src_set = {x.strip().lower() for x in str(sources).split(",") if x.strip()}
    if ("models" in src_set) or (len(src_set) >= 2):
        return "stronger"
    if len(src_set) == 1:
        return "limited"
    return "limited"


def _source_provenance_label_ja(value: str) -> str:
    mapping = {
        "stronger": "複数根拠あり",
        "mixed": "複数情報あり",
        "limited": "単一根拠中心",
    }
    return mapping.get(str(value or "").strip(), "")


def _source_provenance_explanation_ja(value: str) -> str:
    mapping = {
        "stronger": "MGI、MedGen、既知モデル情報など、複数の情報源または異なる種類の根拠により候補として支持されている。",
        "mixed": "複数の関連情報はあるが、情報源や根拠の種類が限定的で、対象疾患との対応は追加確認が望まれる。",
        "limited": "主に単一の情報源または限られた関連情報に基づいて提示されている。候補としては有用だが、文献・表現型・実験背景などの追加確認が重要である。",
    }
    return mapping.get(str(value or "").strip(), "")


def _phenotype_support_text_ja(value: str) -> str:
    mapping = {
        "high": "表現型面で疾患と整合する可能性が高い",
        "medium": "表現型情報はあるが、疾患との直接的な整合性は限定的",
        "low_or_indirect": "一致する表現型語はあるが、広い語または間接語に限られ、疾患特異的な表現型補強は限定的",
        "low_or_unknown": "MP未取得、または取得済みMPと対象疾患表現型との整合性が限定的",
        "mp_available_limited": "MPは取得済みだが、対象疾患との表現型整合性は限定的",
        "mp_unavailable": "MP未取得のため表現型面は未評価",
    }
    return mapping.get(str(value or "").strip(), "")



def _recommended_use_tag_explanation_ja(value: str) -> str:
    """Return user-facing definitions for recommended_use_tag values.

    The label 病態中核遺伝子 is kept intentionally, but defined as an
    operational label for this system. It must not be interpreted as a
    definitive causal-gene or disease-model-validity claim.
    """
    mapping = {
        "病態中核遺伝子": (
            "本システムで、対象疾患に関連があると想定され、候補評価の中心的な手がかりとして扱う遺伝子。"
            "主関連遺伝子のうち、複数根拠または既知モデル情報などにより、病態理解・候補確認の軸として優先的に読むものを指します。"
            "疾患原因性、単独原因遺伝子性、またはマウス系統の疾患モデル妥当性を断定する用語ではありません。"
        ),
        "比較対象向き": "他候補との比較によって研究目的への適合性を判断しやすい候補。",
        "補助候補寄り": "疾患の代表候補というより、関連経路・修飾因子・解析補助などの確認に有用な候補。",
        "探索候補寄り": "既知根拠だけでは位置づけが十分に確立していないが、探索的に確認する価値がある候補。",
        "有力候補": "対象疾患との関連が示されており、優先的に確認する価値がある候補。",
    }
    return mapping.get(str(value or "").strip(), "")


def _has_multiple_sources_or_model_evidence(sources: object) -> bool:
    """Return True when the candidate is supported by multiple source classes or Models.

    This is used only for the conservative first-stage annotation of
    recommended_use_tag. It does not change selection_priority_hint.
    """
    norm = _normalize_sources_for_grouping(sources)
    items = [x for x in norm.split("|") if x]
    if "Models" in items:
        return True
    return len(set(items)) >= 2


def _conservative_recommended_use_tag(row: pd.Series) -> str:
    """Conservative first-stage label for research positioning.

    We keep the existing label 病態中核遺伝子, but only assign it when the
    candidate has a primary gene, directly matches a disease concept, and is
    supported by multiple source classes or Models. This label is a reference
    annotation and does not by itself determine selection_priority_hint.
    """
    gene = str(row.get("primary_gene", "")).strip()
    mondo = str(row.get("primary_mondo_id", "")).strip()
    if gene and mondo and _has_multiple_sources_or_model_evidence(row.get("sources", "")):
        return "病態中核遺伝子"
    return ""


def _conservative_recommended_use_reason_ja(row: pd.Series) -> str:
    tag = str(row.get("recommended_use_tag", "")).strip()
    if not tag:
        return ""
    gene = str(row.get("primary_gene", "")).strip()
    sources = str(row.get("sources", "")).strip()
    apps = str(row.get("application_tags_ja", "")).strip()
    reason = (
        f"{gene} を主関連遺伝子とし、{sources} を根拠として確認する。"
        "対象疾患の病態理解や候補評価で中心的な手がかりとなる可能性があるため、"
        f"研究上の位置づけを {tag} として表示する。"
        "このラベルは疾患原因性やモデル妥当性を断定するものではない。"
    )
    if apps:
        reason += f" 用途情報: {apps}。"
    return reason


def _add_recommended_use_columns_to_overview_df(df: pd.DataFrame) -> pd.DataFrame:
    """Add conservative first-stage recommended_use_tag columns to overview_df.

    Existing non-empty values are preserved. This makes the first-stage candidate
    list carry the same research-positioning label that the second-stage detail
    view explains, without letting the label alter selection_priority_hint.
    """
    if df is None or df.empty:
        return df
    out = df.copy()
    for col in ["primary_gene", "primary_mondo_id", "sources", "application_tags_ja"]:
        if col not in out.columns:
            out[col] = ""
    if "recommended_use_tag" not in out.columns:
        out["recommended_use_tag"] = ""
    if "recommended_use_tag_explanation_ja" not in out.columns:
        out["recommended_use_tag_explanation_ja"] = ""
    if "recommended_use_reason_ja" not in out.columns:
        out["recommended_use_reason_ja"] = ""

    for idx, row in out.iterrows():
        current = str(row.get("recommended_use_tag", "")).strip()
        if not current:
            tag = _conservative_recommended_use_tag(row)
            out.at[idx, "recommended_use_tag"] = tag
        else:
            tag = current
        if tag and not str(out.at[idx, "recommended_use_tag_explanation_ja"]).strip():
            out.at[idx, "recommended_use_tag_explanation_ja"] = _recommended_use_tag_explanation_ja(tag)
        if tag and not str(out.at[idx, "recommended_use_reason_ja"]).strip():
            out.at[idx, "recommended_use_reason_ja"] = _conservative_recommended_use_reason_ja(out.loc[idx])
    return out

def _normalize_sources_for_grouping(sources: object) -> str:
    """Normalize sources for equivalent-candidate grouping.

    This is intentionally display-independent: "MGI, Medgen" and
    "Medgen, MGI" should be treated as the same group.
    """
    items = []
    for part in re.split(r"[,|;/]+", str(sources or "")):
        v = part.strip()
        if v:
            items.append(v)
    # Preserve canonical spelling when possible, but sort case-insensitively.
    canonical = {}
    for v in items:
        key = v.lower()
        if key == "medgen":
            canonical[key] = "Medgen"
        elif key == "mgi":
            canonical[key] = "MGI"
        elif key == "models":
            canonical[key] = "Models"
        else:
            canonical[key] = v
    return "|".join(canonical[k] for k in sorted(canonical.keys()))


def _normalize_value_for_grouping(value: object) -> str:
    v = str(value or "").strip()
    return re.sub(r"\s+", " ", v)


def _normalize_multivalue_for_grouping(value: object) -> str:
    items = []
    for part in re.split(r"[,|;/]+", str(value or "")):
        v = _normalize_value_for_grouping(part)
        if v:
            items.append(v)
    return "|".join(sorted(set(items), key=lambda x: x.lower()))


def _make_llm_equivalent_group_key(row: pd.Series) -> str:
    parts = [
        _normalize_value_for_grouping(row.get("primary_mondo_id", "")),
        _normalize_value_for_grouping(row.get("primary_gene", "")),
        _normalize_sources_for_grouping(row.get("sources", "")),
        _normalize_multivalue_for_grouping(row.get("variation_class", "")),
        _normalize_value_for_grouping(row.get("selection_priority_hint", "")),
    ]
    return "||".join(parts)


def _llm_group_label_ja(row: pd.Series) -> str:
    parts = []
    for col in ["primary_gene", "sources", "variation_class", "selection_priority_hint"]:
        v = str(row.get(col, "")).strip()
        if v:
            parts.append(v)
    return " / ".join(parts)


def _shorten_member_list(members: List[str], *, limit: int = 8) -> str:
    vals = [str(x).strip() for x in members if str(x).strip()]
    vals = list(dict.fromkeys(vals))
    if len(vals) <= limit:
        return ", ".join(vals)
    return ", ".join(vals[:limit]) + f", ... 他{len(vals) - limit}件"


_GENE_DIVERSITY_AXIS_JA = {
    "GCK": "GCK / グルコース感知・糖代謝",
    "IL6": "IL6 / 炎症・免疫応答",
    "PDX1": "PDX1 / 膵β細胞・膵発生",
    "ENPP1": "ENPP1 / インスリン抵抗性・代謝制御",
    "ADIPOQ": "ADIPOQ / 脂肪細胞・アディポカイン・代謝制御",
    "INSR": "INSR / インスリンシグナル",
    "KCNJ11": "KCNJ11 / インスリン分泌・膵β細胞機能",
    "ABCC8": "ABCC8 / インスリン分泌・膵β細胞機能",
    "INS": "INS / インスリン産生",
}


def _gene_diversity_axis_ja(primary_gene: object) -> str:
    gene = str(primary_gene or "").strip()
    if not gene:
        return ""
    return _GENE_DIVERSITY_AXIS_JA.get(gene.upper(), f"{gene} / 遺伝子軸")


def _llm_recommendation_reason_category_ja(row: pd.Series, *, group_size: int, is_recommended: bool) -> str:
    if not is_recommended:
        return ""
    priority = str(row.get("selection_priority_hint", "")).strip()
    use_tag = str(row.get("recommended_use_tag", "")).strip()
    if priority != "最優先候補":
        return "候補多様性の確保"
    if group_size > 1:
        return "同等候補群の代表"
    if use_tag:
        return "主要候補の代表"
    return "代表候補"


def _llm_recommendation_reason_ja(row: pd.Series, *, group_size: int, is_recommended: bool, representative: str) -> str:
    if not is_recommended:
        if representative:
            return "同じ同等候補群にLLM推奨代表候補があります。この候補が低評価または除外されたことを意味しません。"
        return "第1段階LLMの代表候補には選定されていません。これは低評価や除外を意味するものではありません。"
    gene = str(row.get("primary_gene", "")).strip()
    sources = str(row.get("sources", "")).strip()
    variation = str(row.get("variation_class", "")).strip()
    priority = str(row.get("selection_priority_hint", "")).strip()
    axis = _gene_diversity_axis_ja(gene)
    category = _llm_recommendation_reason_category_ja(row, group_size=group_size, is_recommended=is_recommended)
    base = "第1段階LLMが、先に詳細確認する代表候補として選定した候補です。"
    attrs = []
    if gene:
        attrs.append(f"主関連遺伝子={gene}")
    if sources:
        attrs.append(f"根拠情報源={sources}")
    if variation:
        attrs.append(f"系統タイプ={variation}")
    if priority:
        attrs.append(f"選択優先区分={priority}")
    attr_text = "、".join(attrs)
    if category == "候補多様性の確保":
        return (
            f"{base}{axis} という確認軸を含めることで、最優先候補だけでは拾いにくい生物学的観点を確認するための代表候補として扱います。"
            f"属性: {attr_text}。この説明は候補属性に基づく補足であり、候補の優劣や疾患モデル妥当性を断定するものではありません。"
        )
    if group_size > 1:
        return (
            f"{base}{axis} の同等候補群（{group_size}件）から、先に詳細確認する代表候補として扱います。"
            f"属性: {attr_text}。同等候補群の他候補が低評価または除外されたことを意味しません。"
        )
    return (
        f"{base}{axis} の観点から詳細確認する候補として扱います。"
        f"属性: {attr_text}。この説明は候補属性に基づく補足であり、候補の優劣や疾患モデル妥当性を断定するものではありません。"
    )


def _add_llm_recommendation_group_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Add user-facing columns that explain LLM recommendation as representative selection.

    Existing values are not overwritten except for adding new columns. The internal
    `recommended_marker` remains unchanged for compatibility; display text is held in
    `llm_recommendation_display_ja`.
    """
    if df is None or df.empty:
        return df
    out = df.copy()
    required = ["primary_mondo_id", "primary_gene", "sources", "variation_class", "selection_priority_hint", "strain_id"]
    for col in required:
        if col not in out.columns:
            out[col] = ""
    if "recommended_marker" not in out.columns:
        out["recommended_marker"] = ""

    out["llm_equivalent_group_key"] = out.apply(_make_llm_equivalent_group_key, axis=1)
    out["llm_equivalent_group_label_ja"] = out.apply(_llm_group_label_ja, axis=1)
    out["llm_recommendation_role"] = "未選定"
    out["llm_representative_strain_id"] = ""
    out["llm_equivalent_group_size"] = "1"
    out["llm_equivalent_group_members"] = ""
    out["llm_equivalent_group_members_short"] = ""
    out["llm_recommendation_display_ja"] = ""
    out["llm_recommendation_note_ja"] = ""
    out["llm_recommendation_reason_category_ja"] = ""
    out["llm_recommendation_diversity_axis_ja"] = ""
    out["llm_recommendation_reason_ja"] = ""

    for group_key, idxs in out.groupby("llm_equivalent_group_key", sort=False).groups.items():
        idx_list = list(idxs)
        members = out.loc[idx_list, "strain_id"].astype(str).str.strip().tolist()
        members = [m for m in members if m]
        members_unique = list(dict.fromkeys(members))
        group_size = len(members_unique)

        rec_mask = out.loc[idx_list, "recommended_marker"].astype(str).str.strip() != ""
        rep_ids = out.loc[idx_list, "strain_id"][rec_mask].astype(str).str.strip().tolist()
        rep_ids = [x for x in rep_ids if x]
        representative = rep_ids[0] if rep_ids else ""

        for idx in idx_list:
            sid = str(out.at[idx, "strain_id"]).strip()
            group_label = str(out.at[idx, "llm_equivalent_group_label_ja"]).strip()
            out.at[idx, "llm_equivalent_group_size"] = str(group_size)
            out.at[idx, "llm_equivalent_group_members"] = ", ".join(members_unique)
            out.at[idx, "llm_equivalent_group_members_short"] = _shorten_member_list([m for m in members_unique if m != sid], limit=8)
            out.at[idx, "llm_representative_strain_id"] = representative

            is_recommended = bool(str(out.at[idx, "recommended_marker"]).strip())
            if is_recommended:
                out.at[idx, "llm_recommendation_role"] = "代表候補"
                out.at[idx, "llm_representative_strain_id"] = sid
                out.at[idx, "llm_recommendation_display_ja"] = "LLM推奨（代表候補）"
                if group_size > 1:
                    note = (
                        f"この候補は、{group_label} の同等候補群から、先に詳細確認する代表候補として選定されています。"
                        f"同等候補数は{group_size}件です。"
                    )
                else:
                    note = "この候補は、第1段階LLMにより先に詳細確認する候補として選定されています。"
            elif representative:
                out.at[idx, "llm_recommendation_role"] = "同等候補"
                out.at[idx, "llm_recommendation_display_ja"] = f"同等候補（代表: {representative}）"
                note = (
                    f"この候補は、LLM推奨代表候補 {representative} と同じ {group_label} の候補群に属します。"
                    "LLM推奨が付いていないことは、低評価や除外を意味しません。"
                )
            else:
                out.at[idx, "llm_recommendation_role"] = "未選定"
                out.at[idx, "llm_recommendation_display_ja"] = ""
                note = "第1段階LLMの代表候補には選定されていません。これは低評価や除外を意味するものではありません。"
            out.at[idx, "llm_recommendation_note_ja"] = note
            out.at[idx, "llm_recommendation_reason_category_ja"] = _llm_recommendation_reason_category_ja(
                out.loc[idx], group_size=group_size, is_recommended=is_recommended
            )
            out.at[idx, "llm_recommendation_diversity_axis_ja"] = _gene_diversity_axis_ja(out.at[idx, "primary_gene"])
            out.at[idx, "llm_recommendation_reason_ja"] = _llm_recommendation_reason_ja(
                out.loc[idx], group_size=group_size, is_recommended=is_recommended, representative=representative
            )
    return out


def _app_selection_reason_short(primary_gene: str, sources: str, variation_class: str, primary_mondo_id: str) -> str:
    parts = []
    if str(primary_gene).strip():
        parts.append(f"遺伝子={str(primary_gene).strip()}")
    if str(sources).strip():
        parts.append(f"Sources={str(sources).strip()}")
    if str(variation_class).strip():
        parts.append(f"Variation={str(variation_class).strip()}")
    if str(primary_mondo_id).strip():
        parts.append(f"MONDO={str(primary_mondo_id).strip()}")
    return " | ".join(parts)


def _app_resource_iri_from_strain_id(strain_id: str) -> str:
    sid = str(strain_id or "").strip()
    if not sid:
        return ""
    return f"http://metadb.riken.jp/db/rikenbrc_mouse/{sid}"


def _extract_log_lines_for_strain_app(log_text: str, strain_id: str, limit: int = 8) -> str:
    if not log_text or not strain_id:
        return ""
    lines = []
    for line in str(log_text).splitlines():
        if str(strain_id) in line:
            lines.append(line.strip())
            if len(lines) >= limit:
                break
    return " | ".join(lines)


def build_app_overview_table(details_df: pd.DataFrame, target_mondo: str) -> pd.DataFrame:
    work = details_df.copy()
    for col in ["RBRC", "Strain", "MONDO_ID", "Sources", "Mutation_Type"]:
        if col not in work.columns:
            work[col] = ""

    work["RBRC"] = work["RBRC"].astype(str).str.strip()
    work["Strain"] = work["Strain"].astype(str).str.strip()
    work["MONDO_ID"] = work["MONDO_ID"].astype(str).map(_normalize_mondo_id)
    work["Sources"] = work["Sources"].astype(str).map(_normalize_sources_key)
    work["Mutation_Type"] = work["Mutation_Type"].astype(str).str.strip()
    work = work[work["RBRC"] != ""].copy()

    rows = []
    grouped = list(work.groupby("RBRC", sort=True))
    for idx, (strain_id, sub) in enumerate(grouped, start=1):
        strain_name = str(sub["Strain"].iloc[0]).strip() if not sub.empty else ""
        primary_gene, other_genes = _app_pick_primary_gene(sub)
        primary_mondo_id, related_mondo_ids = _app_pick_primary_mondo(sub, target_mondo)
        sources = _merge_source_tokens(sub["Sources"])
        variation_class = _join_full(sorted({str(x).strip() for x in sub["Mutation_Type"].astype(str).tolist() if str(x).strip()}))
        hint = _app_selection_priority_hint(primary_mondo_id, target_mondo, primary_gene, sources)
        rows.append({
            "row_no": str(idx),
            "strain_id": strain_id,
            "strain_name": strain_name,
            "primary_gene": primary_gene,
            "other_genes": other_genes,
            "primary_mondo_id": primary_mondo_id,
            "related_mondo_ids": related_mondo_ids,
            "sources": sources,
            "variation_class": variation_class,
            "selection_priority_hint": hint,
            "selection_reason_short": _app_selection_reason_short(primary_gene, sources, variation_class, primary_mondo_id),
        })

    out = pd.DataFrame(rows)
    if not out.empty:
        order = {
            "最優先候補": 0,
            "有力候補": 1,
            "比較候補": 2,
            "補助候補": 3,
            "探索候補": 4,
        }
        out["_ord"] = out["selection_priority_hint"].map(lambda x: order.get(str(x), 99))
        out = out.sort_values(["_ord", "strain_id"]).drop(columns=["_ord"]).reset_index(drop=True)
        out["row_no"] = [str(i) for i in range(1, len(out) + 1)]
    out = _fix77_add_resource_type_columns_to_overview_df(out)
    if not out.empty:
        out["selection_reason_short"] = out.apply(
            lambda r: _app_selection_reason_short(
                str(r.get("primary_gene", "") or ""),
                str(r.get("sources", "") or ""),
                str(r.get("variation_class", "") or ""),
                str(r.get("primary_mondo_id", "") or ""),
            ),
            axis=1,
        )
    out = _add_recommended_use_columns_to_overview_df(out)
    return out



def _fix61_primary_gene_symbol(value: Any) -> str:
    """Return the first usable gene symbol without inventing identifiers."""
    text = str(value or "").strip()
    if not text:
        return ""
    text = re.split(r"[|;,/\s]+", text)[0].strip()
    text = re.sub(r"[^A-Za-z0-9_.-]", "", text)
    return text


def _fix61_parse_stage1_gene_context(log_text: Any, gene_symbol: Any, selected_strain_id: Any = "") -> Dict[str, Any]:
    """Extract first-stage LLM gene context from the Step3 user-facing log.

    This is deterministic parsing of existing log content. It does not create
    external IDs except an NCBI Gene URL when a numeric GeneID is already present.
    """
    text = str(log_text or "")
    gene = _fix61_primary_gene_symbol(gene_symbol)
    sid = str(selected_strain_id or "").strip()
    out: Dict[str, Any] = {
        "available": False,
        "gene_symbol": gene or None,
        "human_gene_id": None,
        "gene_id_iri": None,
        "sources": [],
        "matched_mouse_count": None,
        "matched_mouse_count_reported_in_log": None,
        "matched_mouse_record_count": None,
        "stage1_biological_explanation_ja": None,
        "matched_mouse_ids": [],
        "matched_mouse_records": [],
        "matched_mouse_records_all": [],
        "selected_candidate_in_stage1_matched_mouse_list": None,
        "interpretation_role_ja": (
            "第一段階LLMで生成された疾患関連遺伝子の生物学的説明と、"
            "その遺伝子に対応する候補マウス群です。選択候補を疾患研究候補として読むための主要な遺伝子根拠として扱います。"
        ),
        "source_note_ja": "run_v8_fixed3 形式の利用者向け要約ログから決定論的に抽出。ログにない値は生成しません。",
    }
    if not text or not gene:
        return out

    esc = re.escape(gene)
    m = re.search(
        rf"^\s*-\s*{esc}\s*\(GeneID:(?P<geneid>[^)]+)\)\s*\[対応マウス数:(?P<count>\d+)件\]\s*\[Sources:\s*(?P<sources>[^\]]+)\]\s*:\s*(?P<explanation>.+?)\s*$",
        text,
        flags=re.MULTILINE,
    )
    if m:
        gid_raw = str(m.group("geneid") or "").strip()
        gid_num = re.sub(r"^ncbigene:", "", gid_raw).strip()
        out["available"] = True
        out["human_gene_id"] = gid_num or gid_raw or None
        if gid_num and re.fullmatch(r"\d+", gid_num):
            out["gene_id_iri"] = f"https://www.ncbi.nlm.nih.gov/gene/{gid_num}"
        if str(m.group("count")).isdigit():
            out["matched_mouse_count_reported_in_log"] = int(m.group("count"))
            out["matched_mouse_count"] = int(m.group("count"))
        out["sources"] = [x.strip() for x in re.split(r"[,;|]", str(m.group("sources") or "")) if x.strip()]
        out["stage1_biological_explanation_ja"] = str(m.group("explanation") or "").strip()

    sec = re.search(
        rf"^\s*■\s*{esc}\s*\(GeneID:(?P<geneid>[^)]+)\)\s*:\s*対応マウス\s*(?P<count>\d+)\s*件\s*(?P<body>.*?)(?=^\s*■\s*|^\s*\[[0-9]+(?:\.[0-9]+)?\]\s*|\Z)",
        text,
        flags=re.MULTILINE | re.DOTALL,
    )
    if sec:
        gid_raw = str(sec.group("geneid") or "").strip()
        gid_num = re.sub(r"^ncbigene:", "", gid_raw).strip()
        out["available"] = True
        if not out.get("human_gene_id"):
            out["human_gene_id"] = gid_num or gid_raw or None
            if gid_num and re.fullmatch(r"\d+", gid_num):
                out["gene_id_iri"] = f"https://www.ncbi.nlm.nih.gov/gene/{gid_num}"
        if str(sec.group("count")).isdigit():
            out["matched_mouse_count_reported_in_log"] = int(sec.group("count"))
            if out.get("matched_mouse_count") is None:
                out["matched_mouse_count"] = int(sec.group("count"))
        body = sec.group("body") or ""
        records = []
        for line in body.splitlines():
            lm = re.match(r"^\s*-\s*(?P<strain>RBRC[^\s]+)\s*\((?P<name>.*)\)\s*(?P<rest>\[Sources:.*)$", line.strip())
            if not lm:
                continue
            rest = lm.group("rest") or ""
            src_m = re.search(r"\[Sources:\s*([^\]]+)\]", rest)
            mondo_m = re.search(r"\[Mapped Disease:\s*([^\]]+)\]", rest)
            rec = {
                "strain_id": lm.group("strain").strip(),
                "strain_name": lm.group("name").strip(),
                "sources": [x.strip() for x in re.split(r"[,;|]", src_m.group(1)) if x.strip()] if src_m else [],
                "mapped_disease": mondo_m.group(1).strip() if mondo_m else None,
            }
            records.append(rec)
        # The Step3 log may list the same strain multiple times through different
        # mapped diseases or sources. For user-facing interpretation, count unique
        # strain IDs; preserve the raw records for auditability.
        out["matched_mouse_records_all"] = records
        out["matched_mouse_record_count"] = len(records)
        unique_records: List[Dict[str, Any]] = []
        seen_strains: set = set()
        for rec in records:
            rec_sid = str(rec.get("strain_id", "") or "").strip()
            if not rec_sid or rec_sid in seen_strains:
                continue
            seen_strains.add(rec_sid)
            same_records = [r for r in records if str(r.get("strain_id", "") or "").strip() == rec_sid]
            merged_sources: List[str] = []
            mapped_diseases: List[str] = []
            for r in same_records:
                for s in r.get("sources") or []:
                    if s and s not in merged_sources:
                        merged_sources.append(s)
                md = str(r.get("mapped_disease") or "").strip()
                if md and md not in mapped_diseases:
                    mapped_diseases.append(md)
            merged = dict(rec)
            merged["sources"] = merged_sources
            merged["mapped_diseases"] = mapped_diseases
            if len(mapped_diseases) == 1:
                merged["mapped_disease"] = mapped_diseases[0]
            elif len(mapped_diseases) > 1:
                merged["mapped_disease"] = " | ".join(mapped_diseases)
            unique_records.append(merged)
        out["matched_mouse_records"] = unique_records
        out["matched_mouse_ids"] = [r["strain_id"] for r in unique_records]
        if unique_records:
            out["matched_mouse_count"] = len(unique_records)

    if sid:
        ids = set(str(x).strip() for x in out.get("matched_mouse_ids") or [])
        out["selected_candidate_in_stage1_matched_mouse_list"] = sid in ids if ids else None
    return out


def _fix61_load_stage1_gene_context(record: Dict[str, Any]) -> Dict[str, Any]:
    """Load stage1 gene context from a record, accepting JSON text or dict."""
    if not isinstance(record, dict):
        return {}
    raw = record.get("stage1_gene_context") or record.get("stage1_gene_context_json") or ""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str) and raw.strip():
        try:
            obj = json.loads(raw)
            return obj if isinstance(obj, dict) else {}
        except Exception:
            return {}
    return {}


def _fix61_stage1_context_short_text(ctx: Dict[str, Any]) -> str:
    if not isinstance(ctx, dict) or not ctx.get("available"):
        return ""
    gene = _fix58_clean_scalar(ctx.get("gene_symbol"))
    gid = _fix58_clean_scalar(ctx.get("human_gene_id"))
    sources = ", ".join(ctx.get("sources") or []) if isinstance(ctx.get("sources"), list) else _fix58_clean_scalar(ctx.get("sources"))
    count = ctx.get("matched_mouse_count")
    exp = _fix58_clean_scalar(ctx.get("stage1_biological_explanation_ja"))
    parts = []
    if gene:
        parts.append(f"{gene}" + (f" (GeneID:{gid})" if gid else ""))
    if sources:
        parts.append(f"Sources: {sources}")
    if count is not None:
        parts.append(f"対応マウス数: {count}件")
    if exp:
        parts.append(exp)
    return " / ".join(parts)

def _build_single_strain_record_for_llm(
    overview_df: pd.DataFrame,
    details_df: pd.DataFrame,
    log_text: str,
    strain_id: str,
    target_mondo: str,
) -> Dict[str, str]:
    sid = str(strain_id or "").strip()
    if not sid:
        return {}

    if overview_df is None or overview_df.empty or "strain_id" not in overview_df.columns:
        return {}

    ov = overview_df[overview_df["strain_id"].astype(str).str.strip() == sid].head(1)
    if ov.empty:
        return {}
    ov_row = ov.iloc[0]

    sub = details_df[details_df["RBRC"].astype(str).str.strip() == sid].copy()
    primary_mondo_id = str(ov_row.get("primary_mondo_id", "")).strip() or str(target_mondo or "").strip()
    primary_mondo_label = _extract_mondo_label_from_log(log_text, primary_mondo_id) or primary_mondo_id

    resource_iri = _app_resource_iri_from_strain_id(sid)
    mp_res = _fetch_mp_labels_for_resource(resource_iri)
    mp_ids = mp_res.get("mp_ids", []) or []
    mp_labels = mp_res.get("mp_labels", []) or []
    all_mondo_ids_for_label = ", ".join([x for x in [primary_mondo_id, str(ov_row.get("related_mondo_ids", "")).strip()] if x])
    mapped_mondo_id_labels = _mondo_id_label_text_from_log(log_text, all_mondo_ids_for_label)
    stage1_gene_context = _fix61_parse_stage1_gene_context(log_text, str(ov_row.get("primary_gene", "")).strip(), sid)
    disease_mondo_ids = tuple(_split_mondo_ids(all_mondo_ids_for_label))
    hpo_mp_res = _fetch_disease_hpo_mp_mapping_cached(disease_mondo_ids)
    disease_hpo_ids = hpo_mp_res.get("hpo_ids", []) or []
    disease_mapped_mp_ids = hpo_mp_res.get("mp_ids", []) or []
    mapping_error = str(hpo_mp_res.get("error", "") or "")
    candidate_mp_local_ids = [_obo_local_id_from_iri(x) for x in mp_ids]
    mapped_mp_set = {_obo_local_id_from_iri(x) for x in disease_mapped_mp_ids}
    overlap_mp_ids = [x for x in candidate_mp_local_ids if x and x in mapped_mp_set]
    overlap_mp_ids = list(dict.fromkeys(overlap_mp_ids))
    mp_hint = _phenotype_support_from_hpo_mp_mapping(candidate_mp_local_ids, disease_mapped_mp_ids)
    mp_summary = _mp_summary_ja(
        mp_labels,
        mp_hint,
        primary_mondo_label,
        candidate_mp_ids=candidate_mp_local_ids,
        disease_mapped_mp_ids=disease_mapped_mp_ids,
        overlap_mp_ids=overlap_mp_ids,
        mapping_error=mapping_error,
    )

    row = {
        "strain_id": sid,
        "resource_iri": resource_iri,
        "strain_name": str(ov_row.get("strain_name", "")).strip(),
        "primary_mondo_id": primary_mondo_id,
        "primary_mondo_label": primary_mondo_label,
        "related_mondo_ids": str(ov_row.get("related_mondo_ids", "")).strip(),
        "mapped_mondo_id_labels": mapped_mondo_id_labels,
        "sources": str(ov_row.get("sources", "")).strip(),
        "variation_class": str(ov_row.get("variation_class", "")).strip(),
        "resource_type_iri": str(ov_row.get("resource_type_iri", "")).strip(),
        "resource_type_label_en": str(ov_row.get("resource_type_label_en", "")).strip(),
        "resource_type_label_ja": str(ov_row.get("resource_type_label_ja", "")).strip(),
        "resource_type_labels": str(ov_row.get("resource_type_labels", "")).strip(),
        "variation_class_raw": str(ov_row.get("variation_class_raw", "")).strip(),
        "variation_class_normalized": str(ov_row.get("variation_class_normalized", "")).strip(),
        "variation_class_source": str(ov_row.get("variation_class_source", "")).strip(),
        "variation_class_status": str(ov_row.get("variation_class_status", "")).strip(),
        "applications": str(ov_row.get("applications", "")).strip(),
        "application_tags_ja": str(ov_row.get("application_tags_ja", "")).strip(),
        "application_interpretation_ja": str(ov_row.get("application_interpretation_ja", "")).strip(),
        "primary_gene": str(ov_row.get("primary_gene", "")).strip(),
        "other_genes": str(ov_row.get("other_genes", "")).strip(),
        "stage1_gene_context_json": json.dumps(stage1_gene_context, ensure_ascii=False),
        "stage1_gene_context_available": "true" if stage1_gene_context.get("available") else "false",
        "stage1_gene_symbol": str(stage1_gene_context.get("gene_symbol") or ""),
        "stage1_human_gene_id": str(stage1_gene_context.get("human_gene_id") or ""),
        "stage1_gene_id_iri": str(stage1_gene_context.get("gene_id_iri") or ""),
        "stage1_gene_sources": ", ".join(stage1_gene_context.get("sources") or []) if isinstance(stage1_gene_context.get("sources"), list) else str(stage1_gene_context.get("sources") or ""),
        "stage1_matched_mouse_count": str(stage1_gene_context.get("matched_mouse_count") or ""),
        "stage1_biological_explanation_ja": str(stage1_gene_context.get("stage1_biological_explanation_ja") or ""),
        "stage1_selected_candidate_in_matched_mouse_list": str(stage1_gene_context.get("selected_candidate_in_stage1_matched_mouse_list") if stage1_gene_context.get("selected_candidate_in_stage1_matched_mouse_list") is not None else ""),
        "recommended_use_tag": str(ov_row.get("recommended_use_tag", "")).strip(),
        "recommended_use_tag_explanation_ja": str(ov_row.get("recommended_use_tag_explanation_ja", "")).strip(),
        "selection_priority_hint": str(ov_row.get("selection_priority_hint", "")).strip(),
        "selection_priority_explanation_ja": "",
        "recommended_use_reason_ja": str(ov_row.get("recommended_use_reason_ja", "")).strip(),
        "gene_importance_level": "",
        "gene_importance_assessment_ja": "",
        "gene_importance_note_ja": "遺伝子重要度は第二段階LLMによる参考評価であり、selection_priority_hint や LLM推奨の判定には影響しません。",
        "recommended_reason_short": str(ov_row.get("recommended_reason_short", "")).strip(),
        "recommended_marker": str(ov_row.get("recommended_marker", "")).strip(),
        "llm_recommendation_role": str(ov_row.get("llm_recommendation_role", "")).strip(),
        "llm_recommendation_display_ja": str(ov_row.get("llm_recommendation_display_ja", "")).strip(),
        "llm_recommendation_note_ja": str(ov_row.get("llm_recommendation_note_ja", "")).strip(),
        "llm_recommendation_reason_category_ja": str(ov_row.get("llm_recommendation_reason_category_ja", "")).strip(),
        "llm_recommendation_diversity_axis_ja": str(ov_row.get("llm_recommendation_diversity_axis_ja", "")).strip(),
        "llm_recommendation_reason_ja": str(ov_row.get("llm_recommendation_reason_ja", "")).strip(),
        "llm_representative_strain_id": str(ov_row.get("llm_representative_strain_id", "")).strip(),
        "llm_equivalent_group_label_ja": str(ov_row.get("llm_equivalent_group_label_ja", "")).strip(),
        "llm_equivalent_group_size": str(ov_row.get("llm_equivalent_group_size", "")).strip(),
        "llm_equivalent_group_members_short": str(ov_row.get("llm_equivalent_group_members_short", "")).strip(),
        "llm_equivalent_group_members": str(ov_row.get("llm_equivalent_group_members", "")).strip(),
        "evidence_level": str(ov_row.get("sources", "")).strip().replace(", ", "+"),
        "source_provenance_level": "",
        "source_provenance_label_ja": "",
        "source_provenance_explanation_ja": "",
        "interpretation_risk": "",
        "feature_summary_ja": "",
        "research_usefulness_ja": "",
        "caution_ja": "",
        "key_points_ja": "",
        "evidence_step3_1_1": _extract_log_lines_for_strain_app(log_text, sid, limit=4),
        "evidence_step3_2": _extract_log_lines_for_strain_app(log_text, sid, limit=8),
        "evidence_details_table": _join_full([
            _join_full(sub[col].astype(str).tolist())
            for col in sub.columns[: min(6, len(sub.columns))]
        ]),
        "evidence_external": "",
        "evidence_mp_ids": " | ".join([str(x) for x in mp_ids]),
        "evidence_mp_labels": " | ".join([str(x) for x in mp_labels]),
        "disease_hpo_ids_from_hpoa": " | ".join([str(x) for x in disease_hpo_ids]),
        "disease_mapped_mp_ids_from_hpo_mp": " | ".join([str(x) for x in disease_mapped_mp_ids]),
        "phenotype_mapping_overlap_mp_ids": " | ".join([str(x) for x in overlap_mp_ids]),
        "phenotype_mapping_error": mapping_error,
        "phenotype_support_source": _initial_phenotype_support_source(
            mp_labels=mp_labels,
            disease_hpo_ids=disease_hpo_ids,
            disease_mapped_mp_ids=disease_mapped_mp_ids,
            overlap_mp_ids=overlap_mp_ids,
            mapping_error=mapping_error,
        ),
        "phenotype_support_source_text_ja": "",
        "llm_inferred_hpo_phenotype_terms_ja": "",
        "llm_inferred_hpo_phenotype_terms_en": "",
        "llm_inferred_phenotype_alignment_ja": "",
        "llm_inferred_phenotype_confidence": "",
        "llm_inferred_phenotype_caution_ja": "LLMはHPO ID/IRIを生成しません。HPO/MP IDとして扱う値は、SPARQLで取得・確認されたものに限定します。",
        "llm_generated_disease_phenotype_keywords_ja": "",
        "llm_generated_disease_phenotype_keywords_en": "",
        "sparql_hpo_candidates_from_llm_keywords": "",
        "llm_selected_hpo_candidate_ids": "",
        "mapped_mp_from_llm_selected_hpo": "",
        "sparql_mp_candidates_from_llm_keywords": "",
        "llm_selected_mp_candidate_ids": "",
        "phenotype_keyword_candidate_overlap_mp_ids": "",
        "llm_keyword_candidate_mp_label_overlap_terms": "",
        "llm_keyword_candidate_mp_label_overlap_pairs": "",
        "llm_keyword_candidate_mp_label_overlap_count": "",
        "candidate_bounded_llm_mapping_reason_ja": "",
        "candidate_bounded_llm_mapping_confidence": "",
        "candidate_mp_labels_for_keyword_scoring": "",
        "phenotype_keyword_scoring_basis_ja": "",
        "llm_generated_phenotype_keywords_note_ja": "",
        "evidence_mp_summary_ja": mp_summary,
        "mp_count": str(len(mp_labels)),
        "phenotype_support_level": mp_hint,
        "phenotype_support_text_ja": _phenotype_support_text_ja(mp_hint),
        "llm_worked": "false",
        "llm_failure_reason": "",
        "llm_model": "",
        "llm_request_count": "0",
        "llm_success_count": "0",
        "llm_error_count": "0",
    }

    row["selection_priority_explanation_ja"] = _selection_priority_explanation_ja(row["selection_priority_hint"])

    if not row.get("recommended_use_tag"):
        row["recommended_use_tag"] = _conservative_recommended_use_tag(pd.Series(row))
    if row.get("recommended_use_tag") and not row.get("recommended_use_tag_explanation_ja"):
        row["recommended_use_tag_explanation_ja"] = _recommended_use_tag_explanation_ja(row["recommended_use_tag"])
    if row.get("recommended_use_tag") and not row.get("recommended_use_reason_ja"):
        row["recommended_use_reason_ja"] = _conservative_recommended_use_reason_ja(pd.Series(row))

    row["source_provenance_level"] = _source_provenance_level_from_sources(row["sources"])
    row["source_provenance_label_ja"] = _source_provenance_label_ja(row["source_provenance_level"])
    row["source_provenance_explanation_ja"] = _source_provenance_explanation_ja(row["source_provenance_level"])
    row["interpretation_risk"] = row["source_provenance_explanation_ja"]

    return row


def _build_record_payload_app(row: Dict[str, str]) -> str:
    keys = [
        "strain_id", "resource_iri", "strain_name",
        "primary_mondo_id", "primary_mondo_label", "related_mondo_ids", "mapped_mondo_id_labels",
        "sources", "variation_class", "resource_type_iri", "resource_type_label_en", "resource_type_label_ja", "resource_type_labels", "variation_class_raw", "variation_class_normalized", "variation_class_source", "variation_class_status", "applications", "application_tags_ja", "application_interpretation_ja",
        "primary_gene", "other_genes",
        "stage1_gene_symbol", "stage1_human_gene_id", "stage1_gene_id_iri", "stage1_gene_sources",
        "stage1_matched_mouse_count", "stage1_biological_explanation_ja", "stage1_selected_candidate_in_matched_mouse_list",
        "recommended_use_tag", "recommended_use_tag_explanation_ja", "recommended_use_reason_ja",
        "gene_importance_level", "gene_importance_assessment_ja", "gene_importance_note_ja",
        "selection_priority_hint", "selection_priority_explanation_ja",
        "llm_recommendation_display_ja", "llm_recommendation_role", "llm_representative_strain_id",
        "llm_equivalent_group_size", "llm_equivalent_group_members_short", "llm_recommendation_note_ja",
        "llm_recommendation_reason_category_ja", "llm_recommendation_diversity_axis_ja", "llm_recommendation_reason_ja",
        "evidence_level", "source_provenance_level",
        "source_provenance_label_ja", "source_provenance_explanation_ja", "interpretation_risk",
        "evidence_step3_1_1", "evidence_step3_2",
        "evidence_details_table", "evidence_external",
        "evidence_mp_labels", "evidence_mp_summary_ja", "phenotype_support_level", "phenotype_support_text_ja",
        "phenotype_support_source", "llm_inferred_phenotype_confidence",
        "llm_inferred_hpo_phenotype_terms_ja", "llm_inferred_hpo_phenotype_terms_en",
        "llm_generated_disease_phenotype_keywords_ja", "llm_generated_disease_phenotype_keywords_en",
        "candidate_mp_labels_for_keyword_scoring", "sparql_hpo_candidates_from_llm_keywords",
        "llm_selected_hpo_candidate_ids", "mapped_mp_from_llm_selected_hpo",
        "sparql_mp_candidates_from_llm_keywords", "llm_selected_mp_candidate_ids",
        "phenotype_keyword_candidate_overlap_mp_ids", "llm_keyword_candidate_mp_label_overlap_terms",
        "llm_keyword_candidate_mp_label_overlap_pairs", "llm_keyword_candidate_mp_label_overlap_count",
        "candidate_bounded_llm_mapping_reason_ja",
    ]
    lines = []
    for k in keys:
        v = str(row.get(k, "")).strip()
        if v:
            lines.append(f"{k}: {v}")
    return "\n".join(lines)


def _parse_single_llm_text_app(content: str) -> Dict[str, str]:
    out = {
        "feature_summary_ja": "",
        "research_usefulness_ja": "",
        "caution_ja": "",
        "key_points_ja": "",
        "gene_importance_level": "",
        "gene_importance_assessment_ja": "",
        "llm_inferred_hpo_phenotype_terms_ja": "",
        "llm_inferred_hpo_phenotype_terms_en": "",
        "llm_inferred_phenotype_alignment_ja": "",
        "llm_inferred_phenotype_confidence": "",
        "llm_inferred_phenotype_caution_ja": "",
    }
    mapping = {
        "FEATURE_SUMMARY_JA": "feature_summary_ja",
        "RESEARCH_USEFULNESS_JA": "research_usefulness_ja",
        "CAUTION_JA": "caution_ja",
        "KEY_POINTS_JA": "key_points_ja",
        "GENE_IMPORTANCE_LEVEL": "gene_importance_level",
        "GENE_IMPORTANCE_ASSESSMENT_JA": "gene_importance_assessment_ja",
        "LLM_INFERRED_HPO_PHENOTYPE_TERMS_JA": "llm_inferred_hpo_phenotype_terms_ja",
        "LLM_INFERRED_HPO_PHENOTYPE_TERMS_EN": "llm_inferred_hpo_phenotype_terms_en",
        "LLM_INFERRED_PHENOTYPE_ALIGNMENT_JA": "llm_inferred_phenotype_alignment_ja",
        "LLM_INFERRED_PHENOTYPE_CONFIDENCE": "llm_inferred_phenotype_confidence",
        "LLM_INFERRED_PHENOTYPE_CAUTION_JA": "llm_inferred_phenotype_caution_ja",
    }
    current = None
    for raw in str(content or "").splitlines():
        line = raw.rstrip()
        m = re.match(r"^(FEATURE_SUMMARY_JA|RESEARCH_USEFULNESS_JA|CAUTION_JA|KEY_POINTS_JA|GENE_IMPORTANCE_LEVEL|GENE_IMPORTANCE_ASSESSMENT_JA|LLM_INFERRED_HPO_PHENOTYPE_TERMS_JA|LLM_INFERRED_HPO_PHENOTYPE_TERMS_EN|LLM_INFERRED_PHENOTYPE_ALIGNMENT_JA|LLM_INFERRED_PHENOTYPE_CONFIDENCE|LLM_INFERRED_PHENOTYPE_CAUTION_JA)\s*:\s*(.*)$", line)
        if m:
            current = mapping[m.group(1)]
            out[current] = m.group(2).strip()
        elif current is not None and line.strip():
            out[current] = (out[current] + " " + line.strip()).strip()
    return out


def _generate_single_strain_summary_with_llm(
    record: Dict[str, str],
    *,
    model: str = "gpt-6-luna",
    timeout_sec: float = 60.0,
) -> Dict[str, str]:
    client = _llm_client(require_key=True)
    if client is None:
        raise RuntimeError("OPENAI_API_KEY 未設定または openai パッケージ未利用")

    system = (
        "あなたは研究者向けのバイオリソース選定支援アシスタントです。"
        "与えられた情報だけに基づいて日本語で簡潔に整理してください。"
        "MGI と MedGen に優劣はつけず、複数の情報源または異なる種類の根拠で支持される場合はその旨として扱ってください。"
        "selection_priority_hint は候補確認の優先度と役割、source_provenance_level は根拠情報源の構成、phenotype_support_level はMP表現型情報に基づく整合性を示します。これらを混同しないでください。"
        "recommended_use_tag は selection_priority_hint の言い換えではなく、候補の研究上の位置づけ・用途を示すラベルです。"
        "病態中核遺伝子は、本システムで対象疾患に関連があると想定され、病態理解・候補確認の中心的な確認軸として扱う遺伝子を示す操作的ラベルです。疾患原因性やモデル妥当性を断定するものではありません。"
        "gene_importance_level と gene_importance_assessment_ja は、第二段階LLMによる参考評価です。selection_priority_hint、recommended_marker、LLM推奨、同等候補群の判定には影響しません。"
        "stage1_biological_explanation_ja が与えられている場合、それは第一段階LLMで得られた疾患関連遺伝子の生物学的説明です。候補マウスを疾患研究候補として読む主要な遺伝子根拠として必ず利用し、表現型情報だけで説明しないでください。"
        "gene_importance_level は high / medium / low_or_uncertain のいずれかで返してください。highでも疾患原因性やモデル妥当性を断定しないでください。"
        "LLM推奨は候補の優劣を確定するラベルではなく、同等候補群から先に詳細確認する代表候補を示す場合があります。同等候補は低評価や除外ではありません。"
        "primary_mondo_label に疾患名が入っている場合、疾患名はその値を使ってください。"
        "MP要約やphenotype_support_levelは、まず候補MPとMONDO→HPO→MP mappingの一致情報を根拠に扱ってください。"
        "ただし、HPOAおよびHPO-MP mappingのカバレッジは限定的であるため、直接一致がない場合は、対象疾患に関連する表現型キーワードをラベルとして生成し、実在する候補MPラベルとの意味的整合性を補助評価してください。"
        "重要: HPO ID、HPO IRI、MP ID、MP IRIを絶対に生成・推測・補完しないでください。HP_0000000 のようなID形式や http://purl.obolibrary.org/obo/HP_... のようなIRIを出力してはいけません。"
        "LLM_INFERRED_HPO_PHENOTYPE_TERMS_JA には、対象疾患に関連するHPO相当の表現型キーワード・概念名を日本語ラベルとして列挙してください。IDやIRIは書かないでください。このキーワード列はユーザーに表示・保存され、表現型評価の検証に用いられます。候補MPラベルとの照合に使った観点が分かるよう、過不足なく簡潔に列挙してください。"
        "LLM_INFERRED_HPO_PHENOTYPE_TERMS_EN には、同じ表現型キーワードをHPO/MPラベル検索に使いやすい英語ラベルとして列挙してください。ここにもIDやIRIは絶対に書かないでください。"
        "この後の処理では、あなたが生成した英語/日本語キーワードを、実在する候補MPラベルおよびHPOA由来HPO→MP mapping結果と照合します。あなたはHPO/MP IDやIRIを作らないでください。"
        "候補MPラベルが、生成した対象疾患関連表現型キーワードと明確に一致または強く意味的整合する場合、LLM_INFERRED_PHENOTYPE_CONFIDENCE は high としてよいです。部分的・間接的なら medium、弱いまたは判断困難なら low_or_unknown としてください。"
        "LLM_INFERRED_PHENOTYPE_CONFIDENCE は high / medium / low_or_unknown のいずれかで返してください。"
        "MONDO ID が与えられていて primary_mondo_label もある場合に、『疾患名を特定できない』とは書かないでください。"
        "断定を避け、推測は最小限にしてください。"
        "次の10行見出しを必ずこの順で出してください。"
        "FEATURE_SUMMARY_JA:, RESEARCH_USEFULNESS_JA:, CAUTION_JA:, KEY_POINTS_JA:, GENE_IMPORTANCE_LEVEL:, GENE_IMPORTANCE_ASSESSMENT_JA:, LLM_INFERRED_HPO_PHENOTYPE_TERMS_JA:, LLM_INFERRED_HPO_PHENOTYPE_TERMS_EN:, LLM_INFERRED_PHENOTYPE_ALIGNMENT_JA:, LLM_INFERRED_PHENOTYPE_CONFIDENCE:, LLM_INFERRED_PHENOTYPE_CAUTION_JA:"
    )
    user = _build_record_payload_app(record)
    resp = client.chat.completions.create(service_tier="default", 
        model=_luna_model_guard(model),
        timeout=timeout_sec,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    )
    content = (resp.choices[0].message.content or "").strip()
    parsed = _parse_single_llm_text_app(content)
    missing = [k for k, v in parsed.items() if not str(v).strip()]
    if missing:
        raise RuntimeError("LLM response missing fields: " + ", ".join(missing))
    out = dict(record)
    out.update(parsed)
    out = _apply_candidate_bounded_phenotype_mapping(out, model=model)
    out = _apply_llm_phenotype_assistance(out)
    out["llm_worked"] = "true"
    out["llm_failure_reason"] = ""
    out["llm_model"] = model
    out["llm_request_count"] = "1"
    out["llm_success_count"] = "1"
    out["llm_error_count"] = "0"
    return out


def _render_single_summary_content(summary_row: Dict[str, str], *, key_prefix: str, root_mid_for_name: str, section_title: str) -> None:
    st.markdown(f"#### {section_title}")
    title_parts = []
    if str(summary_row.get("strain_id", "")).strip():
        title_parts.append(str(summary_row.get("strain_id", "")).strip())
    if str(summary_row.get("strain_name", "")).strip():
        title_parts.append(str(summary_row.get("strain_name", "")).strip())
    if title_parts:
        st.markdown(f"**{' / '.join(title_parts)}**")

    detail_fields = [
        ("特徴の要約", "feature_summary_ja"),
        ("疾患研究での活用可能性", "research_usefulness_ja"),
        ("注意点", "caution_ja"),
        ("要点", "key_points_ja"),
        ("主関連遺伝子", "primary_gene"),
        ("主対象疾患", "primary_mondo_label"),
        ("対応疾患ID・ラベル", "mapped_mondo_id_labels"),
        ("選択優先区分", "selection_priority_hint"),
        ("選択優先区分の説明", "selection_priority_explanation_ja"),
        ("推奨用途タグ", "recommended_use_tag"),
        ("推奨用途タグの説明", "recommended_use_tag_explanation_ja"),
        ("推奨用途タグの理由", "recommended_use_reason_ja"),
        ("遺伝子重要度（参考値）", "gene_importance_level"),
        ("遺伝子重要度の説明", "gene_importance_assessment_ja"),
        ("遺伝子重要度の注意", "gene_importance_note_ja"),
        ("研究用途情報（application）", "applications"),
        ("用途タグ", "application_tags_ja"),
        ("用途情報の解釈", "application_interpretation_ja"),
        ("推奨理由", "recommended_reason_short"),
        ("LLM推奨の位置づけ", "llm_recommendation_display_ja"),
        ("LLM推奨の説明", "llm_recommendation_note_ja"),
        ("LLM推奨理由カテゴリ", "llm_recommendation_reason_category_ja"),
        ("LLM推奨の確認軸", "llm_recommendation_diversity_axis_ja"),
        ("LLM推奨理由", "llm_recommendation_reason_ja"),
        ("同等候補群", "llm_equivalent_group_label_ja"),
        ("同等候補数", "llm_equivalent_group_size"),
        ("同等候補", "llm_equivalent_group_members_short"),
        ("代表候補ID", "llm_representative_strain_id"),
        ("根拠レベル", "source_provenance_label_ja"),
        ("根拠レベル（内部値）", "source_provenance_level"),
        ("根拠レベルの説明", "source_provenance_explanation_ja"),
        ("表現型評価", "phenotype_support_text_ja"),
        ("MP要約", "evidence_mp_summary_ja"),
        ("MP件数", "mp_count"),
        ("表現型支持レベル（内部値）", "phenotype_support_level"),
        ("表現型支持の根拠区分", "phenotype_support_source"),
        ("表現型支持の根拠説明", "phenotype_support_source_text_ja"),
        ("LLM生成表現型キーワード（日本語・評価に使用・ラベルのみ）", "llm_generated_disease_phenotype_keywords_ja"),
        ("LLM生成表現型キーワード（英語・SPARQL検索用）", "llm_generated_disease_phenotype_keywords_en"),
        ("SPARQL取得HPO候補（LLMキーワード由来）", "sparql_hpo_candidates_from_llm_keywords"),
        ("LLM選択HPO候補ID（候補リスト内限定）", "llm_selected_hpo_candidate_ids"),
        ("LLM選択HPO由来MP", "mapped_mp_from_llm_selected_hpo"),
        ("SPARQL取得MP候補（LLMキーワード由来）", "sparql_mp_candidates_from_llm_keywords"),
        ("LLM選択MP候補ID（候補リスト内限定）", "llm_selected_mp_candidate_ids"),
        ("候補MPとの一致MP", "phenotype_keyword_candidate_overlap_mp_ids"),
        ("LLMキーワードと候補MPラベルの一致語", "llm_keyword_candidate_mp_label_overlap_terms"),
        ("LLMキーワードと候補MPラベルの一致ペア", "llm_keyword_candidate_mp_label_overlap_pairs"),
        ("LLMキーワードと候補MPラベルの一致数", "llm_keyword_candidate_mp_label_overlap_count"),
        ("候補内限定LLMマッピング理由", "candidate_bounded_llm_mapping_reason_ja"),
        ("照合対象の候補MPラベル", "candidate_mp_labels_for_keyword_scoring"),
        ("表現型キーワード照合の根拠", "phenotype_keyword_scoring_basis_ja"),
        ("LLM生成表現型キーワードの注意", "llm_generated_phenotype_keywords_note_ja"),
        ("LLM推定HPO相当表現型（ラベルのみ・互換項目）", "llm_inferred_hpo_phenotype_terms_ja"),
        ("LLM表現型整合性評価", "llm_inferred_phenotype_alignment_ja"),
        ("LLM表現型整合性信頼度", "llm_inferred_phenotype_confidence"),
        ("LLM表現型評価の注意", "llm_inferred_phenotype_caution_ja"),
        ("疾患HPO ID（HPOA由来）", "disease_hpo_ids_from_hpoa"),
        ("疾患由来MP ID（HPO-MP mapping）", "disease_mapped_mp_ids_from_hpo_mp"),
        ("候補MPと疾患由来MPの一致", "phenotype_mapping_overlap_mp_ids"),
        ("HPO-MP mapping取得エラー", "phenotype_mapping_error"),
        ("内部根拠", "evidence_step3_2"),
        ("details_table 根拠", "evidence_details_table"),
        ("LLM モデル", "llm_model"),
        ("LLM 実行成否", "llm_worked"),
        ("LLM 失敗理由", "llm_failure_reason"),
    ]
    detail_pairs = []
    for field_label, field_name in detail_fields:
        val = str(summary_row.get(field_name, "")).strip()
        if val:
            detail_pairs.append((field_label, field_name, val))
            st.markdown(f"**{field_label}**")
            st.write(val)

    if detail_pairs:
        # fix50: JSON is the machine/audit counterpart of the Markdown output.
        # It must not drop second-stage LLM phenotype fields or phenotype-derived
        # candidate-search context.  detail_internal/detail_ja keep the same
        # human-visible fields as Markdown, while full_record_internal preserves
        # every non-empty value in summary_row for audit and downstream processing.
        # fix54: Explicitly state that single_candidate JSON is an integrated
        # candidate detail.  Phenotype fields in this file are auxiliary evidence
        # added after gene/disease candidate selection; they must not be read as
        # direct gene-disease evidence.
        full_record_internal = {
            str(k): str(v).strip()
            for k, v in dict(summary_row).items()
            if str(v).strip()
        }
        phenotype_audit_keys = [
            "phenotype_support_level",
            "phenotype_support_text_ja",
            "phenotype_support_source",
            "phenotype_support_source_text_ja",
            "evidence_mp_ids",
            "evidence_mp_labels",
            "evidence_mp_summary_ja",
            "disease_hpo_ids_from_hpoa",
            "disease_mapped_mp_ids_from_hpo_mp",
            "phenotype_mapping_overlap_mp_ids",
            "phenotype_mapping_error",
            "llm_generated_disease_phenotype_keywords_ja",
            "llm_generated_disease_phenotype_keywords_en",
            "llm_inferred_hpo_phenotype_terms_ja",
            "llm_inferred_hpo_phenotype_terms_en",
            "llm_inferred_phenotype_alignment_ja",
            "llm_inferred_phenotype_confidence",
            "llm_inferred_phenotype_caution_ja",
            "candidate_mp_labels_for_keyword_scoring",
            "llm_keyword_candidate_mp_label_overlap_terms",
            "llm_keyword_candidate_mp_label_overlap_pairs",
            "llm_keyword_candidate_mp_label_overlap_count",
            "phenotype_keyword_scoring_basis_ja",
        ]

        def _fix55_val(key: str) -> str:
            return _fix81_clean_export_text(full_record_internal.get(key, ""))

        _fix55_strain = _fix55_val("strain_id") or str(summary_row.get("strain_id", "")).strip()
        _fix55_gene = _fix55_val("primary_gene")
        _fix55_disease = _fix55_val("primary_mondo_label") or _fix55_val("mapped_mondo_id_labels") or str(root_mid_for_name or "").strip()
        _fix55_sources = _fix55_val("sources")
        _fix55_applications = _fix55_val("applications")
        _fix55_priority = _fix55_val("selection_priority_hint") or _fix55_val("llm_recommendation_display_ja")
        _fix55_mp_summary = _fix55_val("evidence_mp_summary_ja")
        _fix55_pheno_text = _fix55_val("phenotype_support_text_ja")
        _fix55_overlap_terms = _fix55_val("llm_keyword_candidate_mp_label_overlap_terms")
        _fix55_overlap_pairs = _fix55_val("llm_keyword_candidate_mp_label_overlap_pairs")
        _fix61_stage1_ctx = _fix61_load_stage1_gene_context(summary_row)
        _fix61_stage1_txt = _fix61_stage1_context_short_text(_fix61_stage1_ctx)

        _fix55_next_action_parts = []
        _fix55_pheno_level = _fix55_val("phenotype_support_level").lower()
        if _fix55_gene:
            _fix55_next_action_parts.append("遺伝子・変異内容と疾患病態の対応を確認する")
        if _fix55_overlap_terms or _fix55_overlap_pairs:
            _fix55_next_action_parts.append("一致MPと実験で測定したい表現型指標を照合する")
        elif _fix55_mp_summary:
            if _fix55_pheno_level in {"low_or_unknown", "low_or_indirect", "mp_available_limited", "medium"}:
                _fix55_next_action_parts.append("候補MPが対象疾患表現型と整合しない理由と原典を確認する")
            else:
                _fix55_next_action_parts.append("候補MPと実験で測定したい表現型指標を照合する")
        if _fix55_applications:
            _fix55_next_action_parts.append("application と入手性を確認する")
        if not _fix55_next_action_parts:
            _fix55_next_action_parts.append("系統詳細、根拠ソース、文献、入手性を確認する")

        _fix55_research_interpretation_parts = []
        if _fix55_gene and _fix55_sources:
            _fix55_research_interpretation_parts.append(
                f"{_fix55_strain} は、{_fix55_disease} に対して、主関連遺伝子 {_fix55_gene} が {_fix55_sources} 由来の既知根拠で結び付く候補です。"
            )
        elif _fix55_gene:
            _fix55_research_interpretation_parts.append(
                f"{_fix55_strain} は、{_fix55_disease} に対して、主関連遺伝子 {_fix55_gene} に基づいて優先確認する候補です。"
            )
        else:
            _fix55_research_interpretation_parts.append(
                f"{_fix55_strain} は、{_fix55_disease} に対して候補として抽出された系統です。"
            )
        if _fix61_stage1_ctx.get("available") and _fix61_stage1_ctx.get("stage1_biological_explanation_ja"):
            _fix55_research_interpretation_parts.append(
                f"第一段階LLMでは、{_fix61_stage1_ctx.get('gene_symbol') or _fix55_gene} について『{_fix61_stage1_ctx.get('stage1_biological_explanation_ja')}』と説明されており、この情報を疾患研究候補として読む主要な遺伝子根拠として扱います。"
            )
        if _fix61_stage1_ctx.get("selected_candidate_in_stage1_matched_mouse_list") is True:
            _fix55_research_interpretation_parts.append(
                "この候補は、第一段階で抽出された同一遺伝子対応マウス群に含まれます。"
            )
        if _fix55_mp_summary:
            if _fix55_val("phenotype_support_level").lower() in {"low_or_unknown", "low_or_indirect", "mp_available_limited", "medium"}:
                _fix55_research_interpretation_parts.append(
                    f"表現型面では、候補系統に付与されたMP情報として {_fix55_mp_summary} が確認されています。このため、この候補は表現型根拠で強く支持された候補ではなく、主に疾患遺伝子・既知根拠の軸で確認する候補です。"
                )
            else:
                _fix55_research_interpretation_parts.append(
                    f"表現型面では、候補系統に付与されたMP情報として {_fix55_mp_summary} が確認できます。"
                )
        elif _fix55_pheno_text:
            _fix55_research_interpretation_parts.append(
                f"表現型面では、{_fix55_pheno_text}"
            )
        if _fix55_overlap_terms:
            _fix55_research_interpretation_parts.append(
                f"疾患から想定される表現型キーワードとの一致語は {_fix55_overlap_terms} です。"
            )
        if _fix55_applications:
            _fix55_research_interpretation_parts.append(
                f"研究用途情報として { _fix55_applications } が登録されているため、用途面でも最初に確認する価値があります。"
            )
        if _fix55_priority:
            _fix55_research_interpretation_parts.append(f"確認順の目安は {_fix55_priority} です。")
        _fix55_research_interpretation_ja = "".join(_fix55_research_interpretation_parts)
        _fix55_reading_guide_ja = (
            "このファイルは、選択した1候補について『なぜ候補として見るのか』を読む主出力です。"
            "最初に research_interpretation_ja、次に detail_ja の主関連遺伝子・根拠レベル・表現型評価・MP要約・研究用途情報を確認してください。"
            "phenotype_audit_internal と full_record_internal は監査・再現確認用であり、通常の候補判断では最後に確認します。"
        )
        _fix55_next_action_ja = " / ".join(_fix55_next_action_parts)

        _fix56_candidate_summary = {
            "strain_id": _fix55_strain or None,
            "strain_name": _fix55_val("strain_name") or None,
            "variation_class": _fix55_val("variation_class") or None,
            "resource_type_iri": _fix55_val("resource_type_iri") or None,
            "resource_type_label_en": _fix55_val("resource_type_label_en") or None,
            "resource_type_label_ja": _fix55_val("resource_type_label_ja") or None,
            "variation_class_raw": _fix55_val("variation_class_raw") or None,
            "variation_class_normalized": _fix55_val("variation_class_normalized") or None,
            "variation_class_source": _fix55_val("variation_class_source") or None,
            "variation_class_status": _fix55_val("variation_class_status") or None,
            "primary_gene": _fix55_gene or None,
            "sources": _fix55_sources or None,
            "stage1_gene_context": _fix61_stage1_ctx if _fix61_stage1_ctx.get("available") else None,
            "selection_priority_hint": _fix55_val("selection_priority_hint") or None,
            "llm_recommendation_display_ja": _fix55_val("llm_recommendation_display_ja") or None,
            "applications": _fix55_applications or None,
            "resource_iri": _fix55_val("resource_iri") or None,
        }
        _fix56_llm_assessment = {
            "recommended_use_tag": _fix55_val("recommended_use_tag") or None,
            "recommended_use_tag_explanation_ja": _fix55_val("recommended_use_tag_explanation_ja") or None,
            "reason_category_ja": _fix55_val("llm_recommendation_reason_category_ja") or None,
            "diversity_axis_ja": _fix55_val("llm_recommendation_diversity_axis_ja") or None,
            "reason_ja": _fix55_val("llm_recommendation_reason_ja") or None,
            "limitation_ja": _fix55_val("limitation_ja") or None,
            "next_action_ja": _fix55_next_action_ja,
        }
        _fix56_selected_candidate_phenotype = {
            "scope_ja": "選択候補そのものに付与・集約されている表現型/MP情報です。表現型キーワード由来の追加候補探索結果ではありません。",
            "phenotype_support_level": _fix55_val("phenotype_support_level") or None,
            "phenotype_support_text_ja": _fix55_pheno_text or None,
            "evidence_mp_summary_ja": _fix55_mp_summary or None,
            "evidence_mp_ids": _fix55_val("evidence_mp_ids") or None,
            "evidence_mp_labels": _fix55_val("evidence_mp_labels") or None,
            "keyword_overlap_terms": _fix55_overlap_terms or None,
            "keyword_overlap_pairs": _fix55_overlap_pairs or None,
            "scoring_basis_ja": _fix58_normalize_phenotype_support_text(_fix55_val("phenotype_keyword_scoring_basis_ja"), _fix55_val("phenotype_support_level")) or None,
        }
        _fix61_stage1_gene_evidence = {
            "role_ja": "第一段階LLMで生成された疾患関連遺伝子の説明と、同一遺伝子対応マウス群。選択候補の疾患研究上の根拠を読む主要な入力です。",
            "context": _fix61_stage1_ctx if _fix61_stage1_ctx.get("available") else None,
            "short_text_ja": _fix61_stage1_txt or None,
        }

        # fix81: Keep the screen-visible phenotype matching/audit text in the
        # downloadable files.  The Markdown stores a compact selected-candidate
        # summary, while JSON preserves all non-empty screen-rendered fields for
        # auditability.  This is deterministic copying from summary_row; no new
        # LLM inference is introduced here.
        _fix80_screen_rendered_fields = [
            {
                "label_ja": str(field_label),
                "field_name": str(field_name),
                "value": _fix81_clean_export_text(value),
            }
            for field_label, field_name, value in detail_pairs
        ]

        def _fix81_labels_from_overlap_pairs(pairs_text: str) -> str:
            labels = []
            for pair in str(pairs_text or "").split("|"):
                if "<->" in pair:
                    lab = pair.split("<->", 1)[1].strip()
                    lab = _fix81_clean_export_text(lab)
                    if lab and lab not in labels:
                        labels.append(lab)
            return " | ".join(labels)

        _fix81_candidate_mp_label_overlap_labels = _fix81_labels_from_overlap_pairs(_fix55_overlap_pairs)
        _fix81_candidate_overlap_display = (
            _fix55_val("phenotype_keyword_candidate_overlap_mp_ids")
            or (f"候補MPラベル照合: {_fix81_candidate_mp_label_overlap_labels}" if _fix81_candidate_mp_label_overlap_labels else "")
        )

        _fix80_phenotype_keyword_raw = {
            "scope_ja": "5-1画面に表示される表現型キーワード照合・MP照合のうち、選択候補1件に対応する監査用要約です。表現型キーワード由来の追加候補探索全体は含めません。",
            "interpretation_note_ja": "表現型一致はLLM生成キーワードと既存MP/表現型ラベルの照合に基づく補助根拠であり、疾患モデル妥当性の直接証明ではありません。",
            "phenotype_support_level": _fix55_val("phenotype_support_level"),
            "phenotype_support_text_ja": _fix55_pheno_text,
            "phenotype_support_source": _fix55_val("phenotype_support_source"),
            "phenotype_support_source_text_ja": _fix55_val("phenotype_support_source_text_ja"),
            "llm_generated_disease_phenotype_keywords_ja": _fix55_val("llm_generated_disease_phenotype_keywords_ja"),
            "llm_generated_disease_phenotype_keywords_en": _fix55_val("llm_generated_disease_phenotype_keywords_en"),
            "llm_generated_phenotype_keywords_note_ja": _fix55_val("llm_generated_phenotype_keywords_note_ja"),
            "candidate_mp_labels_for_keyword_scoring": _fix55_val("candidate_mp_labels_for_keyword_scoring"),
            "phenotype_keyword_candidate_overlap_mp_ids": _fix55_val("phenotype_keyword_candidate_overlap_mp_ids"),
            "candidate_mp_label_overlap_labels": _fix81_candidate_mp_label_overlap_labels,
            "candidate_mp_overlap_display": _fix81_candidate_overlap_display,
            "llm_keyword_candidate_mp_label_overlap_terms": _fix55_overlap_terms,
            "llm_keyword_candidate_mp_label_overlap_pairs": _fix55_overlap_pairs,
            "llm_keyword_candidate_mp_label_overlap_count": _fix55_val("llm_keyword_candidate_mp_label_overlap_count"),
            "phenotype_keyword_scoring_basis_ja": _fix58_normalize_phenotype_support_text(_fix55_val("phenotype_keyword_scoring_basis_ja"), _fix55_val("phenotype_support_level")),
            "candidate_bounded_llm_mapping_reason_ja": _fix55_val("candidate_bounded_llm_mapping_reason_ja"),
            "llm_inferred_hpo_phenotype_terms_ja": _fix55_val("llm_inferred_hpo_phenotype_terms_ja"),
            "llm_inferred_phenotype_alignment_ja": _fix55_val("llm_inferred_phenotype_alignment_ja"),
            "llm_inferred_phenotype_confidence": _fix55_val("llm_inferred_phenotype_confidence"),
            "llm_inferred_phenotype_caution_ja": _fix55_val("llm_inferred_phenotype_caution_ja"),
            "disease_hpo_ids_from_hpoa": _fix55_val("disease_hpo_ids_from_hpoa"),
            "disease_mapped_mp_ids_from_hpo_mp": _fix55_val("disease_mapped_mp_ids_from_hpo_mp"),
            "phenotype_mapping_overlap_mp_ids": _fix55_val("phenotype_mapping_overlap_mp_ids"),
            "phenotype_mapping_error": _fix55_val("phenotype_mapping_error"),
            "sparql_hpo_candidates_from_llm_keywords": _fix55_val("sparql_hpo_candidates_from_llm_keywords"),
            "llm_selected_hpo_candidate_ids": _fix55_val("llm_selected_hpo_candidate_ids"),
            "mapped_mp_from_llm_selected_hpo": _fix55_val("mapped_mp_from_llm_selected_hpo"),
            "sparql_mp_candidates_from_llm_keywords": _fix55_val("sparql_mp_candidates_from_llm_keywords"),
            "llm_selected_mp_candidate_ids": _fix55_val("llm_selected_mp_candidate_ids"),
            "evidence_mp_summary_ja": _fix55_mp_summary,
            "evidence_mp_ids": _fix55_val("evidence_mp_ids"),
            "evidence_mp_labels": _fix55_val("evidence_mp_labels"),
        }
        _fix80_phenotype_keyword_match_evidence = {
            k: (v if v not in {""} else None)
            for k, v in _fix80_phenotype_keyword_raw.items()
            if v not in {""}
        }

        detail_json = {
            "schema_version": "selected_candidate_llm_detail_v1_fix81",
            "file_role_ja": "第2段階LLMによる選択候補1件の詳細評価。追加候補探索全体は含めませんが、5-1画面に表示される選択候補自身の表現型キーワード照合根拠は保存します。",
            "term_definitions": _fix58_domain_term_definitions(),
            "target": {
                "target_mondo_id": str(root_mid_for_name or "").strip(),
                "selected_candidate_id": str(summary_row.get("strain_id", "")).strip(),
            },
            "machine_reading_order": [
                "candidate_summary",
                "research_interpretation_ja",
                "llm_assessment",
                "stage1_gene_evidence",
                "selected_candidate_phenotype_annotations",
                "phenotype_keyword_match_evidence_for_selected_candidate",
                "screen_rendered_fields",
                "provenance",
            ],
            "candidate_summary": _fix56_candidate_summary,
            "research_interpretation_ja": _fix55_research_interpretation_ja,
            "llm_assessment": _fix56_llm_assessment,
            "stage1_gene_evidence": _fix61_stage1_gene_evidence,
            "selected_candidate_phenotype_annotations": _fix56_selected_candidate_phenotype,
            "phenotype_keyword_match_evidence_for_selected_candidate": _fix80_phenotype_keyword_match_evidence,
            "screen_rendered_fields": _fix80_screen_rendered_fields,
            "field_notes_ja": {
                "candidate_summary": "候補の基本情報。まずここで候補ID、遺伝子、根拠ソース、用途を確認します。",
                "llm_assessment": "LLMがこの候補をどう位置付けたかを保存します。",
                "stage1_gene_evidence": "第一段階LLM成果から抽出した疾患関連遺伝子の説明・GeneID・Sources・対応マウス数です。",
                "selected_candidate_phenotype_annotations": "この候補自身のMP・表現型注釈です。追加候補探索CSV/JSONの結果とは分けて解釈します。",
                "phenotype_keyword_match_evidence_for_selected_candidate": "5-1画面に表示される表現型キーワード照合・MP照合のうち、選択候補1件に対応する監査用要約です。",
                "screen_rendered_fields": "5-1画面で実際に表示対象になった非空フィールドをラベル付きで保存した監査用リストです。",
                "provenance": "生成条件と元フィールドの最小記録です。",
            },
            "provenance": {
                "llm_model": _fix55_val("llm_model") or None,
                "llm_worked": _fix55_val("llm_worked") or None,
                "source_columns_used": [field_name for _, field_name, _ in detail_pairs],
            },
        }
        md_lines = [
            "# 選択候補 LLM 詳細評価",
            "",
            f"- target_mondo_id: {str(root_mid_for_name or '').strip()}",
            f"- selected_candidate_id: {str(summary_row.get('strain_id', '')).strip()}",
            "- file_role: 第2段階LLMによる選択候補1件の詳細評価。追加候補探索全体は含めませんが、5-1画面に表示される選択候補自身の表現型キーワード照合根拠は保存します。",
            "- paired_machine_file: `*_selected_candidate_llm_detail.json`",
            "",
            "## 1. 候補の基本情報",
            "",
            f"- strain_id: {_fix55_strain}",
            f"- strain_name: {_fix55_val('strain_name') or '(未記載)'}",
            f"- variation_class: {_fix55_val('variation_class') or '(未記載)'}",
            f"- resource_type_label_en: {_fix55_val('resource_type_label_en') or '(未記載)'}",
            f"- resource_type_label_ja: {_fix55_val('resource_type_label_ja') or '(未記載)'}",
            f"- variation_class_status: {_fix55_val('variation_class_status') or '(未記載)'}",
            f"- primary_gene: {_fix55_gene or '(未記載)'}",
            f"- sources: {_fix55_sources or '(未記載)'}",
            f"- selection_priority_hint: {_fix55_val('selection_priority_hint') or '(未記載)'}",
            f"- llm_recommendation_display_ja: {_fix55_val('llm_recommendation_display_ja') or '(未記載)'}",
            f"- applications: {_fix55_applications or '(未記載)'}",
            f"- resource_iri: {_fix55_val('resource_iri') or '(未記載)'}",
            "",
            "## 2. 第一段階LLMの疾患関連遺伝子根拠",
            "",
            f"- gene_symbol: {_fix61_stage1_ctx.get('gene_symbol') or _fix55_gene or '(未記載)'}",
            f"- human_gene_id: {_fix61_stage1_ctx.get('human_gene_id') or '(未記載)'}",
            f"- gene_id_iri: {_fix61_stage1_ctx.get('gene_id_iri') or '(未記載)'}",
            f"- sources: {', '.join(_fix61_stage1_ctx.get('sources') or []) if isinstance(_fix61_stage1_ctx.get('sources'), list) else (_fix61_stage1_ctx.get('sources') or '(未記載)')}",
            f"- matched_mouse_count: {_fix61_stage1_ctx.get('matched_mouse_count') if _fix61_stage1_ctx.get('matched_mouse_count') is not None else '(未記載)'}",
            f"- matched_mouse_record_count: {_fix61_stage1_ctx.get('matched_mouse_record_count') if _fix61_stage1_ctx.get('matched_mouse_record_count') is not None else '(未記載)'}",
            f"- selected_candidate_in_stage1_matched_mouse_list: {_fix61_stage1_ctx.get('selected_candidate_in_stage1_matched_mouse_list') if _fix61_stage1_ctx.get('selected_candidate_in_stage1_matched_mouse_list') is not None else '(未記載)'}",
            f"- biological_explanation_ja: {_fix61_stage1_ctx.get('stage1_biological_explanation_ja') or '(未記載)'}",
            "",
            "## 3. 研究上の読み取り",
            "",
            _fix55_research_interpretation_ja,
            "",
            "## 4. LLM 評価",
            "",
            f"- recommended_use_tag: {_fix55_val('recommended_use_tag') or '(未記載)'}",
            f"- reason_category_ja: {_fix55_val('llm_recommendation_reason_category_ja') or '(未記載)'}",
            f"- diversity_axis_ja: {_fix55_val('llm_recommendation_diversity_axis_ja') or '(未記載)'}",
            f"- reason_ja: {_fix55_val('llm_recommendation_reason_ja') or '(未記載)'}",
            "",
            "## 5. この候補自身の表現型/MP注釈",
            "",
            "この章は、選択候補そのものに付与・集約されている表現型/MP情報です。表現型キーワード由来の追加候補探索結果ではありません。",
            "",
            f"- phenotype_support_level: {_fix55_val('phenotype_support_level') or '(未記載)'}",
            f"- phenotype_support_text_ja: {_fix55_pheno_text or '(未記載)'}",
            f"- evidence_mp_summary_ja: {_fix55_mp_summary or '(未記載)'}",
            f"- keyword_overlap_terms: {_fix55_overlap_terms or '(未記載)'}",
            "",
            "## 6. 表現型キーワード照合の根拠",
            "",
            "この章は、5-1画面に表示される表現型キーワード照合のうち、選択候補1件に対応する要約です。追加候補探索全体の一覧ではありません。",
            "",
            f"- LLM生成表現型キーワード（日本語）: {_fix55_val('llm_generated_disease_phenotype_keywords_ja') or '(未記載)'}",
            f"- LLM生成表現型キーワード（英語）: {_fix55_val('llm_generated_disease_phenotype_keywords_en') or '(未記載)'}",
            f"- 照合対象の候補MPラベル: {_fix55_val('candidate_mp_labels_for_keyword_scoring') or '(未記載)'}",
            f"- 候補MPとの一致MP: {_fix81_candidate_overlap_display or '(未記載)'}",
            f"- LLMキーワードと候補MPラベルの一致語: {_fix55_overlap_terms or '(未記載)'}",
            f"- LLMキーワードと候補MPラベルの一致ペア: {_fix55_overlap_pairs or '(未記載)'}",
            f"- LLMキーワードと候補MPラベルの一致数: {_fix55_val('llm_keyword_candidate_mp_label_overlap_count') or '(未記載)'}",
            f"- 表現型キーワード照合の根拠: {_fix58_normalize_phenotype_support_text(_fix55_val('phenotype_keyword_scoring_basis_ja'), _fix55_val('phenotype_support_level')) or '(未記載)'}",
            f"- 候補内限定LLMマッピング理由: {_fix55_val('candidate_bounded_llm_mapping_reason_ja') or '(未記載)'}",
            f"- LLM表現型整合性評価: {_fix55_val('llm_inferred_phenotype_alignment_ja') or '(未記載)'}",
            f"- LLM表現型整合性信頼度: {_fix55_val('llm_inferred_phenotype_confidence') or '(未記載)'}",
            f"- LLM表現型評価の注意: {_fix55_val('llm_inferred_phenotype_caution_ja') or '(未記載)'}",
            "- 注意: 表現型一致は補助根拠であり、疾患モデル妥当性の直接証明ではありません。",
            "",
            "## 7. 次に確認すること",
            "",
            _fix55_next_action_ja,
            "",
        ]
        detail_md = "\n".join(md_lines).strip() + "\n"

        detail_base = str(summary_row.get("strain_id", "")).strip() or "selected_strain"
        detail_ts = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
        st.markdown("📥 保存:")
        dl_cols = st.columns(2)
        with dl_cols[0]:
            st.download_button(
                "Markdown保存（選択候補LLM詳細評価）",
                data=detail_md.encode("utf-8"),
                file_name=f"{detail_ts}_{root_mid_for_name}_{detail_base}_selected_candidate_llm_detail.md",
                mime="text/markdown",
                key=f"{key_prefix}_dl_md_{detail_ts}_{detail_base}",
                use_container_width=True,
            )
        with dl_cols[1]:
            st.download_button(
                "JSON保存（選択候補LLM詳細評価）",
                data=json.dumps(detail_json, ensure_ascii=False, indent=2).encode("utf-8"),
                file_name=f"{detail_ts}_{root_mid_for_name}_{detail_base}_selected_candidate_llm_detail.json",
                mime="application/json",
                key=f"{key_prefix}_dl_json_{detail_ts}_{detail_base}",
                use_container_width=True,
            )




def _split_multi_value_text(value: Any) -> List[str]:
    """Split pipe/semicolon/comma separated cells while preserving readable tokens."""
    if value is None:
        return []
    try:
        if pd.isna(value):
            return []
    except Exception:
        pass
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "null"}:
        return []
    # Prefer pipe and semicolon separators because labels often contain spaces.
    parts = []
    for chunk in re.split(r"\s*[|;]\s*", text):
        chunk = chunk.strip()
        if chunk:
            parts.append(chunk)
    if not parts:
        parts = [text]
    seen = set()
    out = []
    for item in parts:
        key = item.lower()
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def _shorten_multi_value_text(value: Any, *, max_items: int = 4, max_chars: int = 120) -> str:
    """Create a compact, human-readable summary for review CSV columns."""
    items = _split_multi_value_text(value)
    if not items:
        return ""
    shown = items[:max_items]
    text = " | ".join(shown)
    if len(items) > max_items:
        text += f" | ... 他{len(items) - max_items}件"
    if len(text) > max_chars:
        text = text[: max_chars - 1].rstrip() + "…"
    return text


def _cell_text(row: pd.Series, col: str) -> str:
    value = row.get(col, "")
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    text = str(value).strip()
    if text.lower() in {"nan", "none", "null"}:
        return ""
    return text


def _bool_from_cell(value: Any) -> bool:
    """Normalize booleans read from pandas cells, CSV strings, or Python bools."""
    try:
        if pd.isna(value):
            return False
    except Exception:
        pass
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        try:
            return float(value) != 0.0
        except Exception:
            return False
    text = str(value or "").strip().lower()
    if text in {"true", "1", "yes", "y", "t"}:
        return True
    if text in {"false", "0", "no", "n", "f", "", "nan", "none", "null"}:
        return False
    return False


def _int_from_cell(value: Any, default: int = 0) -> int:
    try:
        if pd.isna(value):
            return default
    except Exception:
        pass
    try:
        return int(round(float(str(value).strip())))
    except Exception:
        return default


def _is_broad_or_very_broad_phenotype_row(row: pd.Series) -> bool:
    """Return True only when phenotype support is broad/very broad without specific support."""
    specificity_items = [x.lower() for x in _split_multi_value_text(row.get("phenotype_specificity_levels", ""))]
    specificity_text = " | ".join(specificity_items)
    broad_n = _int_from_cell(row.get("broad_or_very_broad_mp_count", 0))
    specific_n = _int_from_cell(row.get("specific_mp_count", 0))
    moderately_specific_n = _int_from_cell(row.get("moderately_specific_mp_count", 0))
    matched_n = _int_from_cell(row.get("unique_matched_mp_id_count", 0))
    has_specific_text = any((": specific" in x) or (": moderately_specific" in x) for x in specificity_items)
    has_broad_text = ("broad" in specificity_text) or ("very_broad" in specificity_text)
    if matched_n <= 0:
        return False
    if specific_n > 0 or moderately_specific_n > 0 or has_specific_text:
        return False
    if broad_n > 0 and matched_n <= max(broad_n, 1):
        return True
    if has_broad_text:
        return True
    return False



def _fix60_known_model_or_gene_axis_label(row: pd.Series) -> Tuple[str, str, str]:
    """Return human-readable known-evidence axis labels without calling no-gene model rows gene evidence.

    This is intentionally display-only. It does not change candidate selection or scoring.
    """
    primary_gene = _cell_text(row, "primary_gene")
    sources = _cell_text(row, "sources")
    source_text = sources.lower()
    has_model_source = ("models" in source_text) or ("model" in source_text) or ("既知モデル" in sources)
    if primary_gene:
        return (
            "疾患関連遺伝子・既知根拠",
            "疾患関連遺伝子・既知根拠由来",
            "Step3/既存候補側で、疾患関連遺伝子・MGI/MedGen等の根拠により抽出。",
        )
    if has_model_source:
        return (
            "既知モデル・疾患根拠",
            "既知モデル・疾患根拠由来",
            "Step3/既存候補側で、Models等の既知モデル・疾患根拠により抽出。主関連遺伝子が空の場合は、疾患関連遺伝子由来とは分けて読む。",
        )
    return (
        "既知根拠",
        "既知根拠由来",
        "Step3/既存候補側で、既知根拠により抽出。主関連遺伝子が空の場合は、疾患関連遺伝子由来とは分けて読む。",
    )


def _fix60_top_records_for_context(df: pd.DataFrame, *, n: int = 3) -> List[Dict[str, Any]]:
    """Return a compact, JSON-safe list of top displayed candidates for comparison context.

    fix67: The order here is the preserved display/review order. The phenotype-adjusted
    auxiliary score is included under an explicitly non-ranking name only when present.
    """
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        return []
    records: List[Dict[str, Any]] = []
    cols = [c for c in [
        "strain_id", "integrated_candidate_priority",
        "candidate_origin_ja", "evidence_basis_ja", "primary_gene", "sources",
        "phenotype_candidate_priority", "matched_keywords_short", "matched_mp_labels_short",
        "limitation_ja", "check_next_action_ja", "resource_iri",
    ] if c in df.columns]
    for i, (_, row) in enumerate(df.head(n).iterrows(), start=1):
        rec = {"display_order_rank": i}
        for c in cols:
            val = _cell_text(row, c)
            if val:
                rec[c] = val
        aux = _cell_text(row, "candidate_check_order_score")
        if aux:
            rec["auxiliary_phenotype_adjusted_score"] = aux
        if rec:
            records.append(rec)
    return records


def _fix60_selected_vs_integrated_top_comparison(
    unified_df: pd.DataFrame,
    selected_strain_id: str,
) -> Dict[str, Any]:
    """Explain the selected representative candidate against the displayed unified table.

    fix67: The unified table preserves the Step3/first-stage candidate order for existing
    candidates. It is not a re-ranking instruction for second-stage LLM execution.
    """
    selected = str(selected_strain_id or "").strip()
    result: Dict[str, Any] = {
        "selected_candidate_id": selected or None,
        "display_top_candidate_id": None,
        "same_as_display_top": None,
        "selected_candidate_display_rank_in_integrated": None,
        "selected_candidate_detected_by_phenotype_keyword_search": None,
        "comparison_scope_ja": "この比較は、統合候補一覧の表示順と補助根拠を説明するものです。第2段階LLMの再実行順位や疾患モデル妥当性順位ではありません。",
        "comparison_statement_ja": None,
        "top_displayed_candidates": [],
    }
    if unified_df is None or not isinstance(unified_df, pd.DataFrame) or unified_df.empty or "strain_id" not in unified_df.columns:
        result["comparison_statement_ja"] = "統合候補一覧がないため、選択候補と統合候補一覧の関係は判定できません。"
        return result

    df = unified_df.copy()
    df["strain_id"] = df["strain_id"].astype(str).str.strip()
    df = df[df["strain_id"] != ""].reset_index(drop=True)
    if df.empty:
        result["comparison_statement_ja"] = "統合候補一覧が空のため、選択候補と統合候補一覧の関係は判定できません。"
        return result

    top_id = str(df.iloc[0].get("strain_id", "")).strip()
    result["display_top_candidate_id"] = top_id or None
    result["same_as_display_top"] = bool(selected and top_id and selected == top_id)
    result["top_displayed_candidates"] = _fix60_top_records_for_context(df, n=3)

    selected_rows = df.index[df["strain_id"] == selected].tolist() if selected else []
    selected_rank = int(selected_rows[0] + 1) if selected_rows else None
    result["selected_candidate_display_rank_in_integrated"] = selected_rank
    selected_row = df.iloc[selected_rows[0]] if selected_rows else None
    if selected_row is not None:
        result["selected_candidate_detected_by_phenotype_keyword_search"] = _bool_from_cell(selected_row.get("phenotype_keyword_candidate_flag", False))
        selected_origin = _cell_text(selected_row, "candidate_origin_ja")
        selected_priority = _cell_text(selected_row, "integrated_candidate_priority")
        selected_aux = _cell_text(selected_row, "candidate_check_order_score")
    else:
        result["selected_candidate_detected_by_phenotype_keyword_search"] = None
        selected_origin = ""
        selected_priority = ""
        selected_aux = ""

    top_row = df.iloc[0]
    top_origin = _cell_text(top_row, "candidate_origin_ja")
    top_priority = _cell_text(top_row, "integrated_candidate_priority")
    top_basis = _cell_text(top_row, "evidence_basis_ja")
    top_aux = _cell_text(top_row, "candidate_check_order_score")

    if result["same_as_display_top"]:
        result["comparison_statement_ja"] = (
            f"選択候補 {selected} は、第1段階LLM由来の表示順を維持した統合候補一覧で表示順1位です。"
            f"統合優先度は {selected_priority or top_priority or '未記載'} です。"
            f"補助スコアは {selected_aux or top_aux or '未記載'} ですが、これは候補確認用の補助値であり、"
            "第2段階LLMを再実行するための順位でも、疾患モデル妥当性の定量順位でもありません。"
        )
    elif selected_rank:
        pheno_msg = "表現型キーワード探索でも検出されています" if result["selected_candidate_detected_by_phenotype_keyword_search"] else "表現型キーワード探索では検出されていません"
        result["comparison_statement_ja"] = (
            f"第2段階LLMの選択候補は {selected}（統合候補一覧の表示順 {selected_rank} 位、{selected_origin or selected_priority or '由来未記載'}）です。"
            f"一覧の表示順1位は {top_id}（{top_origin or top_priority or '由来未記載'}）です。"
            f"選択候補は {pheno_msg}。"
            f"表示順1位候補の主な根拠は {top_basis or '未記載'} です。"
            "この表の表示順は既存候補の上流順位を保持しつつ、表現型キーワード一致を補助注釈として加えるためのものです。"
        )
    else:
        result["comparison_statement_ja"] = (
            f"第2段階LLMの選択候補 {selected or '(未記載)'} は、統合候補一覧内で確認できませんでした。"
            f"統合候補一覧の表示順1位は {top_id or '(未記載)'} です。入力ファイルの対応関係を確認してください。"
        )
    return result


def _fix60_top_strain_ids_by_novelty(df: pd.DataFrame) -> Dict[str, List[str]]:
    """Return top strain IDs separated by all/new/known for phenotype keyword summary JSON."""
    if df is None or not isinstance(df, pd.DataFrame) or df.empty or "strain_id" not in df.columns:
        return {"top_all_strain_ids": [], "top_new_candidate_strain_ids": [], "top_known_candidate_strain_ids": []}
    all_ids = df["strain_id"].astype(str).head(20).tolist()
    if "novelty_status" not in df.columns:
        return {"top_all_strain_ids": all_ids, "top_new_candidate_strain_ids": [], "top_known_candidate_strain_ids": []}
    nov = df["novelty_status"].astype(str)
    return {
        "top_all_strain_ids": all_ids,
        "top_new_candidate_strain_ids": df.loc[nov == "候補一覧外", "strain_id"].astype(str).head(20).tolist(),
        "top_known_candidate_strain_ids": df.loc[nov == "既存候補", "strain_id"].astype(str).head(20).tolist(),
    }

def _build_integrated_candidate_fields(row: pd.Series) -> Dict[str, Any]:
    """Build review-oriented integrated evidence fields for one unified candidate row."""
    g = _bool_from_cell(row.get("gene_disease_candidate_flag", False))
    p = _bool_from_cell(row.get("phenotype_keyword_candidate_flag", False))
    primary_gene = _cell_text(row, "primary_gene")
    sources = _cell_text(row, "sources")
    mapped = _cell_text(row, "mapped_mondo_id_labels")
    selection = _cell_text(row, "selection_priority_hint")
    source_label = _cell_text(row, "source_provenance_label_ja")
    llm_rec = _cell_text(row, "llm_recommendation_display_ja")
    pheno_priority = _cell_text(row, "phenotype_candidate_priority")
    matched_labels = _cell_text(row, "matched_mp_labels")
    matched_keywords = _cell_text(row, "matched_keywords")
    matched_pairs = _cell_text(row, "matched_mp_id_label_pairs")
    relevance_reason = _cell_text(row, "phenotype_relevance_reason_ja")
    applications = _cell_text(row, "applications") or _cell_text(row, "application_tags_ja")
    high_n = _int_from_cell(row.get("unique_high_relevance_mp_count", 0))
    medium_n = _int_from_cell(row.get("unique_medium_relevance_mp_count", 0))
    matched_n = _int_from_cell(row.get("unique_matched_mp_id_count", 0))
    broad_only = _is_broad_or_very_broad_phenotype_row(row)

    known_axis_label, known_axis_source_label, known_axis_path = _fix60_known_model_or_gene_axis_label(row)
    if g and p:
        origin_category = "both"
        origin_ja = f"両方（{known_axis_label} + 表現型キーワード）"
        evidence_path = f"既存候補として抽出され、LLM生成表現型キーワードと候補MPラベルの一致も確認。既存候補側の根拠軸は {known_axis_label}。表現型一致は直接疾患根拠ではなく補助根拠として扱う。"
    elif g:
        origin_category = "gene_disease_only"
        origin_ja = f"{known_axis_label}のみ"
        evidence_path = known_axis_path
    elif p:
        origin_category = "phenotype_only"
        origin_ja = "表現型キーワード由来のみ"
        evidence_path = "第2段階LLMが生成した疾患関連表現型キーワードと候補MPラベルの一致により抽出。疾患モデル妥当性は未確認。"
    else:
        origin_category = "unknown"
        origin_ja = "由来未分類"
        evidence_path = "候補由来を判定できません。"

    gene_basis_parts = []
    if primary_gene:
        gene_basis_parts.append(f"主関連遺伝子={primary_gene}")
    if sources:
        gene_basis_parts.append(f"根拠情報源={sources}")
    if mapped:
        gene_basis_parts.append(f"対応疾患={_shorten_multi_value_text(mapped, max_items=2, max_chars=80)}")
    if source_label:
        gene_basis_parts.append(f"根拠レベル={source_label}")
    gene_basis = "、".join(gene_basis_parts)

    short_keywords = _shorten_multi_value_text(matched_keywords, max_items=4, max_chars=100)
    short_labels = _shorten_multi_value_text(matched_labels, max_items=4, max_chars=120)
    short_pairs = _shorten_multi_value_text(matched_pairs, max_items=4, max_chars=140)
    pheno_basis_parts = []
    if short_keywords:
        pheno_basis_parts.append(f"一致キーワード={short_keywords}")
    if short_labels:
        pheno_basis_parts.append(f"一致MP={short_labels}")
    if high_n:
        pheno_basis_parts.append(f"高関連MP数={high_n}")
    elif matched_n:
        pheno_basis_parts.append(f"一致MP数={matched_n}")
    if broad_only:
        pheno_basis_parts.append("特異性=広い表現型のみ")
    pheno_basis = "、".join(pheno_basis_parts)

    if g and p:
        evidence_basis = " / ".join([x for x in [gene_basis, pheno_basis] if x])
    elif g:
        evidence_basis = gene_basis or "疾患関連遺伝子・既知根拠由来候補。"
    elif p:
        evidence_basis = pheno_basis or "表現型キーワード由来候補。"
    else:
        evidence_basis = "根拠情報が不足しています。"

    # Score is a check-order aid, not model validity. Broad-only phenotype support is penalized.
    pheno_score = _int_from_cell(row.get("phenotype_candidate_rank_score", 0))
    score = 100 if (g and p) else 70 if g else 50 if p else 0
    if selection == "最優先候補":
        score += 20
    elif selection:
        score += 10
    if llm_rec:
        score += 10
    score += min(high_n, 5) * 8
    score += min(medium_n, 5) * 3
    score += min(pheno_score, 20)
    if broad_only:
        score -= 18
    score = max(0, int(score))

    if g and p:
        if broad_only:
            priority = "総合確認候補"
            limitation = "遺伝子根拠と表現型キーワード一致はありますが、表現型が広いため総合最優先とはしません。疾患モデル妥当性は文献・系統詳細で確認してください。"
        elif high_n >= 2 and (selection == "最優先候補" or llm_rec):
            priority = "総合最優先確認候補"
            limitation = "遺伝子・疾患根拠と疾患関連表現型のラベル一致があります。ただし表現型一致はLLMキーワード照合由来の補助根拠であり、疾患モデル妥当性は文献・系統詳細で確認してください。"
        else:
            priority = "総合優先確認候補"
            limitation = "遺伝子・疾患根拠と表現型一致の両方がありますが、総合最優先とするには根拠強度・特異性・原典確認が必要です。"
        next_action = "系統詳細、変異内容、表現型原典、利用可能性を優先的に確認する。"
    elif g:
        priority = "遺伝子根拠優先候補"
        limitation = "既知根拠由来の候補ですが、この統合表では表現型キーワード由来の一致が確認されていない可能性があります。"
        next_action = "疾患関連遺伝子・対応疾患・根拠ソースを確認し、必要に応じてMP表現型を追加確認する。"
    elif p and (high_n >= 2 or pheno_priority == "最優先確認候補") and not broad_only:
        priority = "表現型根拠優先候補"
        limitation = "表現型一致は強い一方、疾患関連遺伝子・文献根拠は別途確認が必要です。"
        next_action = "一致MPの原典、系統詳細、関連遺伝子、application、文献情報を確認する。"
    elif p:
        priority = "追加確認候補"
        limitation = "表現型一致に基づく補助候補です。疾患モデルとしての妥当性は未確認です。"
        next_action = "一致MPが対象疾患の中核表現型か、また広すぎる表現型だけでないかを確認する。"
    else:
        priority = "参考候補"
        limitation = "候補根拠が限定的です。"
        next_action = "元データを確認する。"

    relevance_summary = _shorten_multi_value_text(relevance_reason, max_items=1, max_chars=160)
    if not relevance_summary and pheno_basis:
        relevance_summary = pheno_basis

    note_parts = []
    if priority:
        note_parts.append(priority)
    if origin_ja:
        note_parts.append(origin_ja)
    if applications:
        note_parts.append(f"用途={_shorten_multi_value_text(applications, max_items=2, max_chars=80)}")
    note = " / ".join(note_parts)

    return {
        "candidate_origin_category": origin_category,
        "candidate_origin_ja": origin_ja,
        "integrated_candidate_priority": priority,
        "candidate_check_order_score": int(score),
        "evidence_path_ja": evidence_path,
        "evidence_basis_ja": evidence_basis,
        "matched_mp_labels_short": short_labels,
        "matched_keywords_short": short_keywords,
        "matched_mp_id_label_pairs_short": short_pairs,
        "phenotype_relevance_summary_ja": relevance_summary,
        "limitation_ja": limitation,
        "check_next_action_ja": next_action,
        "note_ja": note,
    }


def _build_unified_gene_phenotype_candidate_df(
    overview_df: pd.DataFrame,
    phenotype_df: pd.DataFrame,
) -> pd.DataFrame:
    """Build an integrated candidate table for candidate review, structured record, and validation outputs.

    The output keeps candidate origin explicit and adds explanation-oriented fields so
    the result can function as a research review dataset rather than a simple merge.
    """
    gene_df = pd.DataFrame()
    pheno_df = pd.DataFrame()

    if overview_df is not None and not overview_df.empty and "strain_id" in overview_df.columns:
        keep_gene_cols = [c for c in [
            "strain_id", "strain_name", "primary_gene", "sources", "mapped_mondo_id_labels",
            "variation_class", "resource_type_iri", "resource_type_label_en", "resource_type_label_ja",
            "resource_type_labels", "variation_class_raw", "variation_class_normalized",
            "variation_class_source", "variation_class_status",
            "selection_priority_hint", "source_provenance_label_ja",
            "source_provenance_level", "recommended_use_tag", "recommended_use_tag_explanation_ja",
            "llm_recommendation_display_ja", "llm_recommendation_reason_category_ja",
            "llm_recommendation_diversity_axis_ja", "llm_recommendation_reason_ja",
            "applications", "application_tags_ja", "application_interpretation_ja",
            "resource_iri", "strain_url",
        ] if c in overview_df.columns]
        gene_df = overview_df[keep_gene_cols].copy()
        gene_df["strain_id"] = gene_df["strain_id"].astype(str).str.strip()
        gene_df = gene_df[gene_df["strain_id"] != ""].drop_duplicates(subset=["strain_id"], keep="first").reset_index(drop=True)
        # fix62: preserve the original Step3 / first-stage LLM candidate order.
        # Phenotype-keyword search is auxiliary evidence and must not reorder
        # existing gene/known-evidence candidates.
        gene_df["gene_candidate_original_rank"] = range(1, len(gene_df) + 1)
        gene_df["gene_disease_candidate_flag"] = True
        gene_df["gene_disease_candidate_source_ja"] = gene_df.apply(lambda r: _fix60_known_model_or_gene_axis_label(r)[1], axis=1)

    if phenotype_df is not None and not phenotype_df.empty and "strain_id" in phenotype_df.columns:
        keep_pheno_cols = [c for c in [
            "strain_id", "novelty_status", "phenotype_candidate_priority", "phenotype_candidate_rank_score",
            "unique_matched_mp_id_count", "unique_high_relevance_mp_count", "unique_medium_relevance_mp_count",
            "high_relevance_mp_count", "medium_relevance_mp_count", "specific_mp_count",
            "moderately_specific_mp_count", "broad_or_very_broad_mp_count",
            "matched_keywords", "matched_mp_ids", "matched_mp_labels", "matched_mp_id_label_pairs",
            "match_types", "phenotype_relevance_levels", "phenotype_specificity_levels",
            "phenotype_roles_ja", "phenotype_relevance_reason_ja", "resource_iri",
            "phenotype_search_stage", "phenotype_search_stage_ja",
        ] if c in phenotype_df.columns]
        pheno_df = phenotype_df[keep_pheno_cols].copy()
        pheno_df["strain_id"] = pheno_df["strain_id"].astype(str).str.strip()
        pheno_df = pheno_df[pheno_df["strain_id"] != ""].drop_duplicates(subset=["strain_id"], keep="first").reset_index(drop=True)
        # fix62: keep phenotype search rank only as an auxiliary rank for
        # phenotype-derived additional candidates, not as a replacement for
        # existing candidate order.
        pheno_df["phenotype_auxiliary_rank"] = range(1, len(pheno_df) + 1)
        pheno_df["phenotype_keyword_candidate_flag"] = True
        pheno_df["phenotype_candidate_source_ja"] = "表現型キーワード由来"

    if gene_df.empty and pheno_df.empty:
        return pd.DataFrame()
    if gene_df.empty:
        merged = pheno_df.copy()
        merged["gene_disease_candidate_flag"] = False
        merged["gene_disease_candidate_source_ja"] = ""
    elif pheno_df.empty:
        merged = gene_df.copy()
        merged["phenotype_keyword_candidate_flag"] = False
        merged["phenotype_candidate_source_ja"] = ""
    else:
        merged = pd.merge(gene_df, pheno_df, on="strain_id", how="outer", suffixes=("", "_phenotype"))

    for col in ["gene_disease_candidate_flag", "phenotype_keyword_candidate_flag"]:
        if col not in merged.columns:
            merged[col] = False
        merged[col] = merged[col].fillna(False).astype(bool)
    for col in ["gene_disease_candidate_source_ja", "phenotype_candidate_source_ja", "novelty_status"]:
        if col not in merged.columns:
            merged[col] = ""
        merged[col] = merged[col].fillna("")

    merged.loc[(merged["phenotype_keyword_candidate_flag"]) & (merged["novelty_status"] == "") & (merged["gene_disease_candidate_flag"]), "novelty_status"] = "既存候補"
    merged.loc[(merged["phenotype_keyword_candidate_flag"]) & (merged["novelty_status"] == "") & (~merged["gene_disease_candidate_flag"]), "novelty_status"] = "候補一覧外"

    if "gene_candidate_original_rank" not in merged.columns:
        merged["gene_candidate_original_rank"] = ""
    if "phenotype_auxiliary_rank" not in merged.columns:
        merged["phenotype_auxiliary_rank"] = ""
    merged["review_order_basis_ja"] = merged.apply(
        lambda r: (
            "既存候補はStep3/第1段階LLM由来の候補順を維持し、表現型キーワード一致は補助注釈として付与。"
            if _bool_from_cell(r.get("gene_disease_candidate_flag", False))
            else "表現型キーワード探索で追加検出された候補。既存候補の後に補助確認候補として表示。"
        ),
        axis=1,
    )

    integrated_fields = merged.apply(lambda row: pd.Series(_build_integrated_candidate_fields(row)), axis=1)
    merged = pd.concat([merged.drop(columns=[c for c in integrated_fields.columns if c in merged.columns], errors="ignore"), integrated_fields], axis=1)

    # fix62 stable user-oriented sort:
    # 1) existing Step3 / first-stage LLM candidates keep their original order;
    # 2) phenotype keyword evidence is displayed as auxiliary annotation for those candidates;
    # 3) phenotype-only additional candidates are appended after existing candidates.
    # This prevents auxiliary phenotype matching from demoting a selected representative candidate.
    priority_order = {
        "総合最優先確認候補": 0,
        "総合優先確認候補": 1,
        "総合確認候補": 2,
        "遺伝子根拠優先候補": 3,
        "表現型根拠優先候補": 4,
        "追加確認候補": 5,
        "参考候補": 6,
    }
    if "resource_iri" not in merged.columns:
        merged["resource_iri"] = ""
    if "resource_iri_phenotype" in merged.columns:
        merged["resource_iri"] = merged["resource_iri"].fillna("").astype(str).str.strip()
        merged["resource_iri_phenotype"] = merged["resource_iri_phenotype"].fillna("").astype(str).str.strip()
        merged.loc[merged["resource_iri"] == "", "resource_iri"] = merged.loc[merged["resource_iri"] == "", "resource_iri_phenotype"]
    merged["resource_iri"] = merged["resource_iri"].fillna("").astype(str).str.strip()
    missing_resource = merged["resource_iri"] == ""
    if missing_resource.any() and "strain_id" in merged.columns:
        merged.loc[missing_resource, "resource_iri"] = merged.loc[missing_resource, "strain_id"].apply(_app_resource_iri_from_strain_id)
    merged["resource_iri_status"] = merged["resource_iri"].map(lambda x: "resolved" if str(x).strip() else "not_resolved")
    merged["resource_iri_resolution_reason"] = merged["resource_iri_status"].map(lambda x: "MetaDB strain IRI resolved from strain_id" if x == "resolved" else "source table did not provide a resolvable strain IRI")

    merged["_sort_existing_axis"] = merged["gene_disease_candidate_flag"].map(lambda x: 0 if _bool_from_cell(x) else 1)
    merged["_sort_gene_original_rank"] = merged["gene_candidate_original_rank"].apply(lambda x: _int_from_cell(x, 999999))
    merged["_sort_phenotype_aux_rank"] = merged["phenotype_auxiliary_rank"].apply(lambda x: _int_from_cell(x, 999999))
    merged["_sort_priority"] = merged["integrated_candidate_priority"].map(priority_order).fillna(9).astype(int)
    merged["_sort_score"] = merged["candidate_check_order_score"].apply(lambda x: _int_from_cell(x, 0))
    merged = merged.sort_values(
        by=["_sort_existing_axis", "_sort_gene_original_rank", "_sort_phenotype_aux_rank", "_sort_priority", "_sort_score", "strain_id"],
        ascending=[True, True, True, True, False, True],
    ).drop(columns=["_sort_existing_axis", "_sort_gene_original_rank", "_sort_phenotype_aux_rank", "_sort_priority", "_sort_score"], errors="ignore")

    preferred = [
        "strain_id", "candidate_origin_category", "candidate_origin_ja", "integrated_candidate_priority",
        "candidate_check_order_score", "gene_candidate_original_rank", "phenotype_auxiliary_rank",
        "review_order_basis_ja", "evidence_path_ja", "evidence_basis_ja",
        "primary_gene", "sources", "variation_class", "resource_type_iri", "resource_type_label_en", "resource_type_label_ja",
        "variation_class_raw", "variation_class_normalized", "variation_class_source", "variation_class_status",
        "mapped_mondo_id_labels", "selection_priority_hint",
        "source_provenance_label_ja", "llm_recommendation_display_ja",
        "phenotype_candidate_priority", "phenotype_search_stage_ja", "unique_high_relevance_mp_count", "unique_matched_mp_id_count",
        "matched_mp_labels_short", "matched_keywords_short", "phenotype_relevance_summary_ja",
        "applications", "note_ja", "limitation_ja", "check_next_action_ja", "resource_iri",
        "resource_iri_status", "resource_iri_resolution_reason",
        "gene_disease_candidate_flag", "phenotype_keyword_candidate_flag", "novelty_status",
        "matched_keywords", "matched_mp_ids", "matched_mp_labels", "matched_mp_id_label_pairs",
        "phenotype_relevance_levels", "phenotype_specificity_levels", "phenotype_relevance_reason_ja",
    ]
    ordered = [c for c in preferred if c in merged.columns] + [c for c in merged.columns if c not in preferred]
    return merged[ordered].reset_index(drop=True)


def _format_integer_like_for_export(value: Any) -> str:
    """Format count/score values for user-facing CSV/JSON without trailing .0."""
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    s = str(value).strip()
    if s == "" or s.lower() in {"nan", "none", "null"}:
        return ""
    try:
        f = float(s)
        if not math.isfinite(f):
            return ""
        return str(int(round(f)))
    except Exception:
        return s


def _prepare_unified_gene_phenotype_export_df(df: pd.DataFrame) -> pd.DataFrame:
    """Prepare a full/debug unified candidate table for export."""
    if df is None or df.empty:
        return pd.DataFrame()

    out = df.copy()

    integer_like_cols = [
        "phenotype_candidate_rank_score",
        "candidate_check_order_score",
        "unique_matched_mp_id_count",
        "unique_high_relevance_mp_count",
        "unique_medium_relevance_mp_count",
        "high_relevance_mp_count",
        "medium_relevance_mp_count",
        "specific_mp_count",
        "moderately_specific_mp_count",
        "broad_or_very_broad_mp_count",
    ]
    for col in integer_like_cols:
        if col in out.columns:
            out[col] = out[col].apply(_format_integer_like_for_export)

    for col in ["gene_disease_candidate_flag", "phenotype_keyword_candidate_flag"]:
        if col in out.columns:
            out[col] = out[col].map(lambda x: "true" if _bool_from_cell(x) else "false")

    out = out.fillna("")
    return out


def _prepare_unified_candidates_review_df(df: pd.DataFrame) -> pd.DataFrame:
    """Prepare the compact candidate-review CSV for researchers.

    This is intentionally not the full table. It keeps the evidence route, evidence
    basis, key gene evidence, key phenotype evidence, limitations, and next action.
    """
    if df is None or df.empty:
        return pd.DataFrame()
    export_df = _prepare_unified_gene_phenotype_export_df(df)
    review_cols = [
        "strain_id",
        "candidate_origin_ja",
        "integrated_candidate_priority",
        "gene_candidate_original_rank",
        "phenotype_auxiliary_rank",
        "review_order_basis_ja",
        "evidence_path_ja",
        "evidence_basis_ja",
        "primary_gene",
        "sources",
        "variation_class",
        "resource_type_label_ja",
        "variation_class_status",
        "mapped_mondo_id_labels",
        "selection_priority_hint",
        "source_provenance_label_ja",
        "llm_recommendation_display_ja",
        "phenotype_candidate_priority",
        "phenotype_search_stage_ja",
        "unique_high_relevance_mp_count",
        "unique_matched_mp_id_count",
        "matched_mp_labels_short",
        "matched_keywords_short",
        "phenotype_relevance_summary_ja",
        "applications",
        "limitation_ja",
        "check_next_action_ja",
        "resource_iri",
        "resource_iri_status",
        "resource_iri_resolution_reason",
    ]
    review_df = export_df[[c for c in review_cols if c in export_df.columns]].copy()

    # Display/export only:
    # avoid Streamlit/Arrow conversion errors caused by mixed numeric and empty-string values.
    if "phenotype_auxiliary_rank" in review_df.columns:
        def _format_phenotype_auxiliary_rank_for_display(value):
            if pd.isna(value):
                return ""
            text = str(value).strip()
            if text == "" or text.lower() in {"nan", "none", "<na>"}:
                return ""
            try:
                number = float(text)
                if number.is_integer():
                    return str(int(number))
            except Exception:
                pass
            return text

        review_df["phenotype_auxiliary_rank"] = review_df[
            "phenotype_auxiliary_rank"
        ].apply(_format_phenotype_auxiliary_rank_for_display).astype("string")

    return review_df



def _obo_iri_from_local_id(local_id: str) -> str:
    token = str(local_id or "").strip()
    if not token:
        return ""
    if token.startswith("http://") or token.startswith("https://"):
        return token
    m = re.search(r"\b([A-Z]+)_([0-9]{7})\b", token)
    if not m:
        return ""
    return f"http://purl.obolibrary.org/obo/{m.group(1)}_{m.group(2)}"


def _build_matched_mp_terms_from_row(row: pd.Series) -> List[Dict[str, Any]]:
    """Build MP term objects so MP IDs and labels are not positionally ambiguous."""
    ids = _split_multi_value_text(row.get("matched_mp_ids", ""))
    pairs = _split_multi_value_text(row.get("matched_mp_id_label_pairs", ""))
    keywords = _split_multi_value_text(row.get("matched_keywords", ""))
    relevance_levels = _split_multi_value_text(row.get("phenotype_relevance_levels", ""))
    specificity_levels = _split_multi_value_text(row.get("phenotype_specificity_levels", ""))

    order: List[str] = []
    by_id: Dict[str, Dict[str, Any]] = {}

    def ensure(mp_id: str) -> Dict[str, Any]:
        mp_id = str(mp_id or "").strip()
        if not mp_id:
            mp_id = "unresolved"
        if mp_id not in by_id:
            order.append(mp_id)
            by_id[mp_id] = {
                "mp_id": mp_id if mp_id != "unresolved" else None,
                "mp_iri": _obo_iri_from_local_id(mp_id) or None,
                "labels": [],
                "matched_keywords": [],
                "relevance_levels": [],
                "specificity_levels": [],
            }
        return by_id[mp_id]

    for mp_id in ids:
        ensure(mp_id)

    for pair in pairs:
        if "::" in pair:
            left, right = pair.split("::", 1)
            item = ensure(left.strip())
            label = right.strip()
            if label and label not in item["labels"]:
                item["labels"].append(label)
            if label and label in keywords and label not in item["matched_keywords"]:
                item["matched_keywords"].append(label)

    # Attach unpaired keyword labels by exact label match when possible.
    for kw in keywords:
        attached = False
        for item in by_id.values():
            if kw in item["labels"]:
                if kw not in item["matched_keywords"]:
                    item["matched_keywords"].append(kw)
                attached = True
                break
        if not attached and len(by_id) == 1:
            item = next(iter(by_id.values()))
            if kw not in item["matched_keywords"]:
                item["matched_keywords"].append(kw)

    for level_text, key in [(relevance_levels, "relevance_levels"), (specificity_levels, "specificity_levels")]:
        for level in level_text:
            label = level.split(":", 1)[0].strip() if ":" in level else ""
            for item in by_id.values():
                if label and label in item["labels"]:
                    if level not in item[key]:
                        item[key].append(level)
                    break

    return [by_id[k] for k in order]

def _build_unified_candidates_full_json_payload(
    *,
    unified_df: pd.DataFrame,
    review_df: pd.DataFrame,
    target_mondo_id: str,
    selected_item: str,
    stage1_phenotype_keyword_payload: Optional[Dict[str, Any]] = None,
    stage1_presearch_df: Optional[pd.DataFrame] = None,
) -> Dict[str, Any]:
    """Build a structured JSON payload for the integrated candidate dataset."""
    full_df = _prepare_unified_gene_phenotype_export_df(unified_df)
    review_export_df = _prepare_unified_gene_phenotype_export_df(review_df)
    stage1_keyword_export = _fix88_normalize_stage1_phenotype_keyword_payload_for_export(stage1_phenotype_keyword_payload or {})

    def _value_counts(col: str) -> Dict[str, int]:
        if full_df.empty or col not in full_df.columns:
            return {}
        vc = full_df[col].astype(str).replace({"": "(blank)"}).value_counts()
        return {str(k): int(v) for k, v in vc.items()}

    def _list_from_cell(value: Any) -> List[str]:
        return _split_multi_value_text(value)

    records: List[Dict[str, Any]] = []
    for _, row in full_df.iterrows():
        record = {
            "strain_id": _cell_text(row, "strain_id"),
            "candidate_origin": {
                "category": _cell_text(row, "candidate_origin_category"),
                "label_ja": _cell_text(row, "candidate_origin_ja"),
                "evidence_path_ja": _cell_text(row, "evidence_path_ja"),
            },
            "gene_disease_evidence": {
                "is_present": _bool_from_cell(row.get("gene_disease_candidate_flag", False)),
                "primary_gene": _cell_text(row, "primary_gene") or None,
                "sources": _cell_text(row, "sources") or None,
                "mapped_mondo_id_labels": _cell_text(row, "mapped_mondo_id_labels") or None,
                "selection_priority_hint": _cell_text(row, "selection_priority_hint") or None,
                "source_provenance_label_ja": _cell_text(row, "source_provenance_label_ja") or None,
                "llm_recommendation_display_ja": _cell_text(row, "llm_recommendation_display_ja") or None,
                "applications": _cell_text(row, "applications") or None,
            },
            "phenotype_evidence": {
                "is_present": _bool_from_cell(row.get("phenotype_keyword_candidate_flag", False)),
                "phenotype_candidate_priority": _cell_text(row, "phenotype_candidate_priority") or None,
                "phenotype_search_stage": _cell_text(row, "phenotype_search_stage") or None,
                "phenotype_search_stage_ja": _cell_text(row, "phenotype_search_stage_ja") or None,
                "matched_keywords": _list_from_cell(row.get("matched_keywords", "")),
                "matched_mp_ids": _list_from_cell(row.get("matched_mp_ids", "")),
                "matched_mp_labels": _list_from_cell(row.get("matched_mp_labels", "")),
                "matched_mp_id_label_pairs": _list_from_cell(row.get("matched_mp_id_label_pairs", "")),
                "matched_mp_terms": _build_matched_mp_terms_from_row(row),
                "support_type": "llm_keyword_to_candidate_mp_label_match" if _bool_from_cell(row.get("phenotype_keyword_candidate_flag", False)) else None,
                "direct_disease_phenotype_support": False if _bool_from_cell(row.get("phenotype_keyword_candidate_flag", False)) else None,
                "unique_matched_mp_id_count": _int_from_cell(row.get("unique_matched_mp_id_count", 0)),
                "unique_high_relevance_mp_count": _int_from_cell(row.get("unique_high_relevance_mp_count", 0)),
                "unique_medium_relevance_mp_count": _int_from_cell(row.get("unique_medium_relevance_mp_count", 0)),
                "phenotype_relevance_levels": _list_from_cell(row.get("phenotype_relevance_levels", "")),
                "phenotype_specificity_levels": _list_from_cell(row.get("phenotype_specificity_levels", "")),
                "phenotype_relevance_reason_ja": _cell_text(row, "phenotype_relevance_reason_ja") or None,
            },
            "integrated_assessment": {
                "priority": _cell_text(row, "integrated_candidate_priority") or None,
                "candidate_check_order_score": _int_from_cell(row.get("candidate_check_order_score", 0)),
                "evidence_basis_ja": _cell_text(row, "evidence_basis_ja") or None,
                "phenotype_relevance_summary_ja": _cell_text(row, "phenotype_relevance_summary_ja") or None,
                "limitation_ja": _cell_text(row, "limitation_ja") or None,
                "check_next_action_ja": _cell_text(row, "check_next_action_ja") or None,
                "note_ja": _cell_text(row, "note_ja") or None,
            },
            "links": {
                "resource_iri": _cell_text(row, "resource_iri") or None,
                "resource_iri_status": _cell_text(row, "resource_iri_status") or None,
                "resource_iri_resolution_reason": _cell_text(row, "resource_iri_resolution_reason") or None,
                "strain_url": _cell_text(row, "strain_url") or None,
            },
        }
        records.append(record)

    payload: Dict[str, Any] = {
        "schema_version": "unified_candidates_v1_fix89",
        "table_type": "unified_candidate_outputs",
        "target": {
            "target_mondo_id": str(target_mondo_id or ""),
            "target_mondo_iri": _obo_iri_from_local_id(str(target_mondo_id or "")) or None,
            "selected_item": str(selected_item or ""),
        },
        "stage1_pre_second_stage_phenotype_keyword_search_summary": stage1_keyword_export or None,
        "summary": {
            "total_candidates": int(len(full_df)),
            "review_rows": int(len(review_export_df)),
            "origin_counts": _value_counts("candidate_origin_ja"),
            "origin_category_counts": _value_counts("candidate_origin_category"),
            "novelty_counts": _value_counts("novelty_status"),
            "integrated_priority_counts": _value_counts("integrated_candidate_priority"),
            "phenotype_priority_counts": _value_counts("phenotype_candidate_priority"),
            "phenotype_search_stage_counts": _value_counts("phenotype_search_stage_ja"),
            "stage1_presearch_unified_coverage": _fix89_stage1_presearch_coverage_summary(stage1_presearch_df, full_df),
            "top_strain_ids": review_export_df["strain_id"].astype(str).head(20).tolist() if "strain_id" in review_export_df.columns else [],
            "selected_vs_integrated_top_comparison": _fix60_selected_vs_integrated_top_comparison(full_df, selected_item),
        },
        "review_columns": list(review_export_df.columns),
        "debug_columns": list(full_df.columns),
        "file_set_guide_ja": {
            "unified_candidates_review.csv": "主出力。研究者が候補集合を確認・比較するための候補確認用CSVです。通常はこのファイルを最初に読みます。",
            "unified_candidates_full.json": "構造化記録。GUI表示・レビューCSVの根拠を機械処理しやすい形で保存するJSONです。再解析、監査、下流処理で使います。",
            "unified_candidates_debug.csv": "検証用全列CSV。スコア、内部フラグ、短縮前の列などを含め、開発者・検証者が不整合を追跡するために使います。通常の候補選定では主出力にしません。"
        },
        "column_definitions_ja": {
            "candidate_origin_ja": "候補がどの経路で出たか。疾患関連遺伝子・既知根拠、既知モデル・疾患根拠、表現型キーワード由来、両方、の区別です。primary_gene が空で Models 等のみの場合は、疾患関連遺伝子由来とは分けて表示します。",
            "candidate_origin_category": "candidate_origin_ja の機械処理用カテゴリ。gene_disease_only, phenotype_only, both。表示ラベルでは、primary_gene の有無と sources により既知モデル・疾患根拠を疾患関連遺伝子根拠から分けます。",
            "integrated_candidate_priority": "遺伝子根拠と表現型キーワード一致を統合した確認優先度ラベルです。",
            "candidate_check_order_score": "debug/full用の補助スコアです。主出力CSVの順位列ではなく、疾患モデル妥当性そのものの定量値でもありません。",
            "evidence_path_ja": "候補が出た経路の説明です。",
            "evidence_basis_ja": "候補確認時に見る主要根拠の要約です。",
            "novelty_status": "表現型キーワード由来候補が第1段階候補一覧内か外かを示します。候補一覧外=追加候補、既存候補=第1段階候補にも存在。",
            "phenotype_candidate_priority": "表現型キーワード一致に基づく確認優先度です。遺伝子根拠の強さとは別軸です。",
            "phenotype_search_stage_ja": "表現型一致が 5-0 疾患レベル表現型キーワード探索由来か、5-1 候補レベル表現型キーワード照合後の補足探索由来かを示します。",
            "resource_iri": "候補系統のリソースIRIです。"
        },
        "records": records,
        "notes": {
            "score_note_ja": "candidate_check_order_score は debug/full 用の補助値です。主出力CSVでは表示せず、疾患モデル妥当性順位や第2段階LLM再実行順位として使いません。",
            "limitation_ja": "表現型キーワード由来候補は、疾患モデルとしての妥当性を断定するものではありません。遺伝子・文献・系統詳細・applicationを追加確認してください。",
            "review_csv_note_ja": "候補集合を比較するときの主出力は unified_candidates_review.csv です。選択候補1件のLLM評価は selected_candidate_llm_detail.md/json、表現型キーワード由来の追加探索は phenotype_keyword_candidate_search_summary.json/csv、機械処理・監査は full.json/debug.csv を確認してください。",
        },
    }
    return payload


def _build_unified_gene_phenotype_json_payload(
    *,
    unified_df: pd.DataFrame,
    display_df: pd.DataFrame,
    target_mondo_id: str,
    selected_item: str,
) -> Dict[str, Any]:
    """Backward-compatible wrapper for older calls."""
    return _build_unified_candidates_full_json_payload(
        unified_df=unified_df,
        review_df=display_df,
        target_mondo_id=target_mondo_id,
        selected_item=selected_item,
    )


def _fix58_clean_scalar(value: Any) -> str:
    """Return a stable display string for JSON/Markdown export."""
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    text = str(value).strip()
    if text.lower() in {"nan", "none", "null"}:
        return ""
    return text


def _fix58_clean_record_from_mapping(mapping: Any) -> Dict[str, str]:
    if mapping is None:
        return {}
    if isinstance(mapping, pd.Series):
        src = mapping.to_dict()
    elif isinstance(mapping, dict):
        src = mapping
    else:
        return {}
    return {str(k): _fix58_clean_scalar(v) for k, v in src.items() if _fix58_clean_scalar(v)}


def _fix58_first_matching_row(df: Any, strain_id: str) -> Dict[str, str]:
    if df is None or not isinstance(df, pd.DataFrame) or df.empty or "strain_id" not in df.columns:
        return {}
    sid = str(strain_id or "").strip()
    if not sid:
        return {}
    sub = df[df["strain_id"].astype(str).str.strip() == sid]
    if sub.empty:
        return {}
    return _fix58_clean_record_from_mapping(sub.iloc[0])


def _fix58_short_list_text(value: Any, *, max_items: int = 6) -> str:
    items = _split_multi_value_text(value)
    if not items:
        return ""
    shown = items[:max_items]
    text = " | ".join(shown)
    if len(items) > max_items:
        text += f" | ... 他{len(items) - max_items}件"
    return text


def _fix58_source_entries(sources_text: Any) -> List[Dict[str, Any]]:
    sources = _split_multi_value_text(sources_text)
    if not sources:
        return []
    out = []
    for source in sources:
        out.append({
            "label": source,
            "url": None,
            "role_ja": "疾患関連遺伝子・既知根拠ソース。入力データ内にURLがある場合のみ別途記録します。",
        })
    return out


def _fix58_url_reference_entries(*records: Dict[str, str]) -> List[Dict[str, Any]]:
    pattern = re.compile(r"https?://[^\s\]|,;<>\)\}\]]+")
    seen = set()
    refs: List[Dict[str, Any]] = []
    for record in records:
        for key, value in (record or {}).items():
            for url in pattern.findall(str(value or "")):
                clean_url = url.rstrip(".。")
                if clean_url not in seen:
                    seen.add(clean_url)
                    refs.append({"label": str(key), "url": clean_url, "role_ja": "入力データ由来URL/IRI"})
    return refs


def _fix58_build_references_and_materials(
    *,
    target_mondo_id: str,
    selected_strain_id: str,
    single_record: Dict[str, str],
    phenotype_record: Dict[str, str],
    unified_record: Dict[str, str],
) -> Dict[str, Any]:
    resource_iri = (
        single_record.get("resource_iri")
        or phenotype_record.get("resource_iri")
        or unified_record.get("resource_iri")
        or ""
    )
    strain_url = (
        single_record.get("strain_url")
        or phenotype_record.get("strain_url")
        or unified_record.get("strain_url")
        or ""
    )
    source_text = single_record.get("sources") or unified_record.get("sources") or ""
    literature_refs: List[Dict[str, Any]] = []
    for rec_name, record in [
        ("selected_candidate", single_record),
        ("phenotype_keyword_candidate_search", phenotype_record),
        ("unified_candidate", unified_record),
    ]:
        for key, value in (record or {}).items():
            lk = str(key).lower()
            if any(token in lk for token in ["pmid", "doi", "publication", "literature", "reference"]):
                val = _fix58_clean_scalar(value)
                if val:
                    literature_refs.append({"source_record": rec_name, "field": str(key), "value": val})
    return {
        "source_policy": "Only URLs, IRIs, file names, PMID, DOI, or reference labels already present in the input evidence package are included. The LLM and deterministic renderer must not generate external URLs or identifiers.",
        "candidate_resource": {
            "label": "candidate resource",
            "url": resource_iri or strain_url or None,
            "role_ja": "系統・リソース確認用。resource_iri または strain_url が入力に存在する場合のみ記録。",
        },
        "evidence_source_links": _fix58_source_entries(source_text),
        "input_file_roles": [
            {"file_role": "selected_candidate_llm_detail.md/json", "description_ja": "第2段階LLMによる選択候補1件の詳細評価。"},
            {"file_role": "phenotype_keyword_candidate_search_summary.json/csv", "description_ja": "表現型キーワードから候補を探索した結果。"},
            {"file_role": "unified_candidates_review.csv/full.json/debug.csv", "description_ja": "疾患遺伝子由来候補と表現型キーワード由来候補の統合候補集合。"},
        ],
        "url_or_iri_values_found_in_input": _fix58_url_reference_entries(single_record, phenotype_record, unified_record),
        "literature_references": literature_refs,
        "notes": [
            "MGI、MedGenなどのソース名だけがありURLが入力にない場合、URLは null のままにします。",
            "文献URL、PMID、DOIが入力に存在しない場合、literature_references は空配列です。",
        ],
    }



def _fix58_domain_term_definitions() -> Dict[str, str]:
    """Definitions for recurrent system-specific terms used in outputs."""
    return {
        "主関連遺伝子": (
            "本システムが候補抽出・候補説明で、その系統と対象疾患を結び付ける主要な手がかりとして採用した遺伝子。"
            "主に入力表・MGI・MedGen等の既知根拠から得た候補内の代表遺伝子であり、単独原因遺伝子またはモデル妥当性の断定ではありません。"
        ),
        "病態中核遺伝子": (
            "本システム上の操作的ラベル。対象疾患に関連があると想定され、病態理解・候補確認の中心的な確認軸として扱う遺伝子を指します。"
            "主関連遺伝子より一段強い研究上の位置づけですが、疾患原因性や疾患モデル妥当性を断定するものではありません。"
        ),
        "遺伝子重要度": (
            "主関連遺伝子が対象疾患の病態理解・候補評価にどの程度重要な確認軸になるかを示す第二段階LLMの参考評価。"
            "selection_priority_hint、代表候補選定、同等候補群の判定を直接変更する値ではありません。"
        ),
        "候補一覧外": (
            "第1段階LLMの単独候補一覧には含まれていないが、表現型キーワードと実在MPラベルの一致により追加で見つかった候補。"
            "既存候補より低品質という意味ではなく、発見経路が異なる候補を示します。"
        ),
        "表現型整合性": (
            "疾患から生成した表現型キーワード、または候補自身のMP/表現型注釈が、対象疾患で評価したい表現型とどの程度整合するかを示す評価。"
            "文献・実験による疾患モデル妥当性の直接証明とは区別します。"
        ),
    }


def _fix58_normalize_phenotype_support_text(text: Any, level: Any = "") -> str:
    """Remove contradictory negative wording when structured support is high."""
    s = _fix58_clean_scalar(text)
    lvl = str(level or "").strip().lower()
    if lvl == "high" and s:
        replacements = {
            "表現型面の支持は強くありません": "表現型整合性は高いが、直接的な疾患モデル証明ではありません",
            "表現型面の支持は強くない": "表現型整合性は高いが、直接的な疾患モデル証明ではありません",
            "表現型面の支持は弱い": "表現型整合性は高いが、直接的な疾患モデル証明ではありません",
            "表現型面で強く支持されません": "表現型整合性は高いが、直接的な疾患モデル証明ではありません",
            "表現型面での支持は強くありません": "表現型整合性は高いが、直接的な疾患モデル証明ではありません",
        }
        for a, b in replacements.items():
            s = s.replace(a, b)
    return s



def _fix59_phenotype_support_statement(record: Dict[str, Any]) -> str:
    """Prefer explicit phenotype_support_text_ja over coarse level mapping."""
    text = _fix58_clean_scalar((record or {}).get("phenotype_support_text_ja"))
    if text:
        return text
    return _phenotype_support_text_ja((record or {}).get("phenotype_support_level") or "")


def _fix59_selected_phenotype_interpretation(record: Dict[str, Any], selected_mp_summary: Any, selected_overlap: Any) -> str:
    level = str((record or {}).get("phenotype_support_level") or "").strip().lower()
    support_text = _fix59_phenotype_support_statement(record)
    summary = _fix58_normalize_phenotype_support_text(selected_mp_summary, level)
    overlap = _fix58_clean_scalar(selected_overlap)
    if level == "high":
        if summary:
            return f"選択候補自身の表現型注釈では、{summary}。これは疾患表現型との整合性を高める材料です。ただし、疾患モデル妥当性の直接証明ではありません。"
        if overlap:
            return f"選択候補自身の表現型注釈では、疾患関連キーワードとの一致語として {overlap} が確認されます。これは疾患表現型との整合性を高める材料です。ただし、疾患モデル妥当性の直接証明ではありません。"
    if level in {"low_or_unknown", "low_or_indirect", "mp_available_limited", "medium"}:
        if summary:
            return f"選択候補自身の表現型注釈では、{summary}。したがって、この候補は表現型根拠ではなく、主に疾患遺伝子・既知根拠の軸で確認する候補として読みます。"
        if support_text:
            return f"選択候補自身の表現型注釈は、{support_text}。したがって、この候補は表現型根拠ではなく、主に疾患遺伝子・既知根拠の軸で確認する候補として読みます。"
    if summary or overlap:
        return f"選択候補自身の表現型注釈として {summary or overlap} を確認します。"
    return ""

def _fix58_build_integrated_candidate_interpretation_payload(
    *,
    single_summary_row: Dict[str, Any],
    phenotype_search_df: pd.DataFrame,
    unified_df: pd.DataFrame,
    target_mondo_id: str,
    selected_strain_id: str,
    stage1_phenotype_keyword_payload: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    single_record = _fix58_clean_record_from_mapping(single_summary_row)
    stage1_ctx = _fix61_load_stage1_gene_context(single_record)
    phenotype_record = _fix58_first_matching_row(phenotype_search_df, selected_strain_id)
    unified_record = _fix58_first_matching_row(unified_df, selected_strain_id)
    selected_vs_top = _fix60_selected_vs_integrated_top_comparison(unified_df, selected_strain_id)

    strain_id = selected_strain_id or single_record.get("strain_id") or phenotype_record.get("strain_id") or unified_record.get("strain_id")
    disease = single_record.get("primary_mondo_label") or single_record.get("mapped_mondo_id_labels") or target_mondo_id
    gene = single_record.get("primary_gene") or unified_record.get("primary_gene")
    sources = single_record.get("sources") or unified_record.get("sources")
    applications = single_record.get("applications") or unified_record.get("applications")
    resource_iri = single_record.get("resource_iri") or phenotype_record.get("resource_iri") or unified_record.get("resource_iri")
    selected_mp_summary = single_record.get("evidence_mp_summary_ja") or single_record.get("phenotype_support_text_ja")
    selected_overlap = single_record.get("llm_keyword_candidate_mp_label_overlap_terms") or single_record.get("phenotype_keyword_candidate_overlap_mp_ids")
    matched_keywords = phenotype_record.get("matched_keywords") or unified_record.get("matched_keywords") or unified_record.get("matched_keywords_short")
    matched_mp_labels = phenotype_record.get("matched_mp_labels") or unified_record.get("matched_mp_labels") or unified_record.get("matched_mp_labels_short")
    matched_mp_ids = phenotype_record.get("matched_mp_ids") or unified_record.get("matched_mp_ids")
    phenotype_priority = phenotype_record.get("phenotype_candidate_priority") or unified_record.get("phenotype_candidate_priority")
    integrated_priority = unified_record.get("integrated_candidate_priority") or ""
    evidence_basis = unified_record.get("evidence_basis_ja") or ""
    check_next_action = unified_record.get("check_next_action_ja") or ""
    if not matched_keywords and not matched_mp_labels and str(single_record.get("phenotype_support_level") or "").strip().lower() in {"low_or_unknown", "low_or_indirect", "mp_available_limited", "medium"}:
        check_next_action = "疾患関連遺伝子・変異内容・根拠ソースを確認し、候補MPが対象疾患表現型と整合しない理由および表現型原典を確認する。"

    phenotype_keyword_denominator_summary = _fix82_build_phenotype_keyword_denominator_summary(
        single_record, phenotype_record, unified_record
    )
    stage1_phenotype_keyword_export = _fix88_normalize_stage1_phenotype_keyword_payload_for_export(
        stage1_phenotype_keyword_payload or {}
    )

    interpretation_parts: List[str] = []
    if gene and sources:
        interpretation_parts.append(
            f"{strain_id} は、{disease} に対して、主関連遺伝子 {gene} が {sources} 由来の既知根拠で結び付くため、疾患遺伝子・既知根拠の軸で候補として読めます。"
        )
    elif gene:
        interpretation_parts.append(
            f"{strain_id} は、{disease} に対して、主関連遺伝子 {gene} を手がかりに確認する候補です。"
        )
    else:
        interpretation_parts.append(
            f"{strain_id} は、{disease} に対して候補として抽出された系統です。"
        )
    if stage1_ctx.get("available") and stage1_ctx.get("stage1_biological_explanation_ja"):
        interpretation_parts.append(
            f"第一段階LLMの遺伝子説明では、{stage1_ctx.get('gene_symbol') or gene} は『{stage1_ctx.get('stage1_biological_explanation_ja')}』とされており、これはこの候補を疾患研究候補として読む中核的な遺伝子根拠です。"
        )
    if stage1_ctx.get("selected_candidate_in_stage1_matched_mouse_list") is True:
        interpretation_parts.append(
            f"また、{strain_id} は第一段階で抽出された {stage1_ctx.get('gene_symbol') or gene} 対応マウス群に含まれるため、候補抽出経路と統合解釈が一致しています。"
        )
    if matched_keywords or matched_mp_labels:
        interpretation_parts.append(
            f"表現型キーワード探索では、一致キーワード { _fix58_short_list_text(matched_keywords) or '(未記載)' }、一致MP { _fix58_short_list_text(matched_mp_labels) or _fix58_short_list_text(matched_mp_ids) or '(未記載)' } が同じ候補に対応しており、疾患で観察・評価したい表現型の軸からも確認対象になります。"
        )
        _fix85_denominator_sentence = _fix85_conclusion_denominator_sentence(phenotype_keyword_denominator_summary)
        if _fix85_denominator_sentence:
            interpretation_parts.append(_fix85_denominator_sentence)
    elif selected_mp_summary or selected_overlap:
        _fix59_pheno_msg = _fix59_selected_phenotype_interpretation(single_record, selected_mp_summary, selected_overlap)
        if _fix59_pheno_msg:
            interpretation_parts.append(_fix59_pheno_msg)
    if applications:
        interpretation_parts.append(f"研究用途情報として {applications} が登録されており、実験設計上の用途確認にも使えます。")
    if integrated_priority:
        interpretation_parts.append(f"統合候補一覧上の確認優先度は {integrated_priority} です。")
    _svt_statement = selected_vs_top.get("comparison_statement_ja") if isinstance(selected_vs_top, dict) else None
    if _svt_statement:
        interpretation_parts.append(_svt_statement)
    integrated_interpretation_ja = "".join(interpretation_parts)

    payload = {
        "schema_version": "integrated_candidate_interpretation_v1_fix88",
        "file_role_ja": "選択候補1件について、第2段階LLM詳細、表現型キーワード由来探索の当該候補行（存在する場合）、統合候補一覧の当該候補行を束ね、人と機械の双方が読める解釈として保存する主出力。",
        "term_definitions": _fix58_domain_term_definitions(),
        "target": {
            "target_mondo_id": target_mondo_id or None,
            "target_mondo_iri": _obo_iri_from_local_id(str(target_mondo_id or "")) or None,
            "selected_candidate_id": strain_id or None,
        },
        "machine_reading_order": [
            "interpretation_summary_ja",
            "term_definitions",
            "relationship_to_selected_candidate_llm_detail",
            "stage1_gene_context",
            "integrated_quality_control",
            "selected_vs_integrated_top_comparison",
            "evidence_axes",
            "how_to_read_this_file_ja",
            "candidate_snapshot",
            "selected_candidate_llm_detail_extract",
            "stage1_pre_second_stage_phenotype_keyword_search_summary",
            "second_stage_phenotype_keyword_match_summary",
            "phenotype_keyword_search_extract_for_this_candidate",
            "unified_candidate_extract_for_this_candidate",
            "references_and_materials",
            "provenance",
        ],
        "interpretation_summary_ja": integrated_interpretation_ja,
        "relationship_to_selected_candidate_llm_detail": {
            "role_ja": "selected_candidate_llm_detail.md/json を中核入力とし、その解釈を第一段階LLMの遺伝子根拠、表現型キーワード探索結果（当該候補行が存在する場合）および統合候補一覧の当該候補行で補強・再評価した主解釈ファイル。",
            "can_override_source_assessment": True,
            "override_policy_ja": "統合前データに表現の矛盾や評価の揺れがある場合、統合後データでは第一段階遺伝子根拠、構造化値、候補MP照合、表現型キーワード探索、統合候補一覧を優先して評価を正規化します。必要な場合は統合前データの自由記述を否定・修正してよい。",
            "does_not_replace_source_file": True,
        },
        "stage1_gene_context": {
            "role_ja": "第一段階LLM成果から抽出した疾患関連遺伝子の説明・GeneID・Sources・対応マウス数。統合解釈では、表現型探索より前に読む中核的な遺伝子根拠として扱います。",
            "context": stage1_ctx if stage1_ctx.get("available") else None,
            "short_text_ja": _fix61_stage1_context_short_text(stage1_ctx) or None,
        },
        "integrated_quality_control": {
            "phenotype_support_level": single_record.get("phenotype_support_level") or None,
            "phenotype_consistency_statement_ja": _fix59_phenotype_support_statement(single_record),
            "contradictory_negative_phenotype_wording_removed": True if str(single_record.get("phenotype_support_level") or "").strip() == "high" else False,
            "policy_ja": "phenotype_support_level が high の場合、否定的な表現を使わず、『表現型整合性は高いが直接的な疾患モデル証明ではない』と分離して記述します。",
        },
        "selected_vs_integrated_top_comparison": selected_vs_top,
        "evidence_axes": {
            "stage1_gene_context_axis": {
                "meaning_ja": "第一段階LLMで得た疾患関連遺伝子の生物学的説明と、同一遺伝子に対応する候補群。候補の疾患研究上の意味を読むための主要根拠です。",
                "gene_symbol": stage1_ctx.get("gene_symbol") or gene or None,
                "human_gene_id": stage1_ctx.get("human_gene_id") or None,
                "gene_id_iri": stage1_ctx.get("gene_id_iri") or None,
                "sources": stage1_ctx.get("sources") or None,
                "matched_mouse_count": stage1_ctx.get("matched_mouse_count") or None,
                "selected_candidate_in_stage1_matched_mouse_list": stage1_ctx.get("selected_candidate_in_stage1_matched_mouse_list") if stage1_ctx.get("selected_candidate_in_stage1_matched_mouse_list") is not None else None,
                "stage1_biological_explanation_ja": stage1_ctx.get("stage1_biological_explanation_ja") or None,
            },
            "gene_disease_known_evidence_axis": {
                "meaning_ja": "疾患関連遺伝子・既知根拠に基づく候補性。主関連遺伝子は、本システムが疾患との対応を読むための主要な遺伝子手がかりであり、単独原因性の断定ではありません。",
                "primary_gene": gene or None,
                "primary_gene_definition_ja": _fix58_domain_term_definitions().get("主関連遺伝子"),
                "sources": sources or None,
                "selection_priority_hint": single_record.get("selection_priority_hint") or unified_record.get("selection_priority_hint") or None,
                "llm_recommendation_display_ja": single_record.get("llm_recommendation_display_ja") or unified_record.get("llm_recommendation_display_ja") or None,
            },
            "gene_importance_axis": {
                "meaning_ja": "主関連遺伝子が対象疾患の病態理解・候補評価にどの程度重要な確認軸になるかを示す参考評価。",
                "primary_gene": gene or None,
                "gene_importance_level": single_record.get("gene_importance_level") or None,
                "gene_importance_assessment_ja": single_record.get("gene_importance_assessment_ja") or None,
                "gene_importance_note_ja": single_record.get("gene_importance_note_ja") or None,
                "recommended_use_tag": single_record.get("recommended_use_tag") or unified_record.get("recommended_use_tag") or None,
                "recommended_use_tag_definition_ja": _recommended_use_tag_explanation_ja(single_record.get("recommended_use_tag") or unified_record.get("recommended_use_tag") or ""),
            },
            "selected_candidate_phenotype_annotation_axis": {
                "meaning_ja": "選択候補自身に付与・集約されているMP/表現型注釈。追加探索結果とは別に読む。",
                "phenotype_support_level": single_record.get("phenotype_support_level") or None,
                "phenotype_support_interpretation_ja": _fix59_phenotype_support_statement(single_record),
                "direct_model_validity_claim": False,
                "direct_model_validity_note_ja": "表現型整合性の強弱にかかわらず、文献・実験による疾患モデル妥当性の直接証明とは区別します。",
                "evidence_mp_summary_ja": _fix58_normalize_phenotype_support_text(selected_mp_summary, single_record.get("phenotype_support_level")) or None,
                "keyword_overlap_terms": selected_overlap or None,
                "llm_inferred_phenotype_confidence": single_record.get("llm_inferred_phenotype_confidence") or None,
            },
            "phenotype_keyword_search_axis_for_this_candidate": {
                "meaning_ja": "疾患から生成した表現型キーワードで探索した結果のうち、この候補に対応する行。対応行がない場合は、この候補は表現型キーワード探索では検出されていないと読む。",
                "phenotype_candidate_priority": phenotype_priority or None,
                "novelty_status": phenotype_record.get("novelty_status") or unified_record.get("novelty_status") or None,
                "matched_keywords": matched_keywords or None,
                "matched_mp_ids": matched_mp_ids or None,
                "matched_mp_labels": matched_mp_labels or None,
                "unique_high_relevance_mp_count": phenotype_record.get("unique_high_relevance_mp_count") or unified_record.get("unique_high_relevance_mp_count") or None,
                "generated_keyword_count_ja": phenotype_keyword_denominator_summary.get("generated_keyword_count_ja") or None,
                "generated_keyword_count_en": phenotype_keyword_denominator_summary.get("generated_keyword_count_en") or None,
                "matched_label_count": phenotype_keyword_denominator_summary.get("matched_label_count") or None,
                "unique_matched_mp_id_count": phenotype_keyword_denominator_summary.get("unique_matched_mp_id_count") or phenotype_record.get("unique_matched_mp_id_count") or unified_record.get("unique_matched_mp_id_count") or None,
                "phenotype_relevance_reason_ja": phenotype_record.get("phenotype_relevance_reason_ja") or unified_record.get("phenotype_relevance_reason_ja") or None,
            },
            "integrated_assessment_axis": {
                "meaning_ja": "疾患遺伝子・既知根拠と表現型キーワード一致を候補確認順として束ねた評価。",
                "integrated_candidate_priority": integrated_priority or None,
                "candidate_check_order_score": unified_record.get("candidate_check_order_score") or None,
                "evidence_basis_ja": evidence_basis or None,
                "check_next_action_ja": check_next_action or None,
            },
        },
        "how_to_read_this_file_ja": [
            "最初に interpretation_summary_ja を読み、この候補を実験候補として見る理由の全体像を確認します。",
            "次に stage1_gene_context と evidence_axes.stage1_gene_context_axis を読み、この候補がどの疾患関連遺伝子根拠から出ているかを確認します。",
            "次に evidence_axes を読み、疾患遺伝子・既知根拠、候補自身の表現型注釈、表現型キーワード探索、統合評価を分けて確認します。",
            "selected_candidate_phenotype_annotation_axis は、選択候補自身の注釈です。phenotype_keyword_search_axis_for_this_candidate は、表現型キーワード探索結果の当該候補行です。両者は混同しません。",
            "references_and_materials には入力データに存在したURL、IRI、PMID、DOI、資料ロールのみを記録します。存在しないURLは生成しません。",
        ],
        "candidate_snapshot": {
            "strain_id": strain_id or None,
            "strain_name": single_record.get("strain_name") or unified_record.get("strain_name") or None,
            "variation_class": single_record.get("variation_class") or unified_record.get("variation_class") or None,
            "resource_type_iri": single_record.get("resource_type_iri") or unified_record.get("resource_type_iri") or None,
            "resource_type_label_en": single_record.get("resource_type_label_en") or unified_record.get("resource_type_label_en") or None,
            "resource_type_label_ja": single_record.get("resource_type_label_ja") or unified_record.get("resource_type_label_ja") or None,
            "variation_class_raw": single_record.get("variation_class_raw") or unified_record.get("variation_class_raw") or None,
            "variation_class_normalized": single_record.get("variation_class_normalized") or unified_record.get("variation_class_normalized") or None,
            "variation_class_source": single_record.get("variation_class_source") or unified_record.get("variation_class_source") or None,
            "variation_class_status": single_record.get("variation_class_status") or unified_record.get("variation_class_status") or None,
            "primary_gene": gene or None,
            "stage1_human_gene_id": stage1_ctx.get("human_gene_id") or None,
            "stage1_gene_id_iri": stage1_ctx.get("gene_id_iri") or None,
            "sources": sources or None,
            "applications": applications or None,
            "resource_iri": resource_iri or None,
        },
        "selected_candidate_llm_detail_extract": single_record,
        "stage1_pre_second_stage_phenotype_keyword_search_summary": stage1_phenotype_keyword_export or None,
        "second_stage_phenotype_keyword_match_summary": phenotype_keyword_denominator_summary,
        "phenotype_keyword_search_extract_for_this_candidate": phenotype_record if phenotype_record else None,
        "unified_candidate_extract_for_this_candidate": unified_record,
        "references_and_materials": _fix58_build_references_and_materials(
            target_mondo_id=target_mondo_id,
            selected_strain_id=strain_id,
            single_record=single_record,
            phenotype_record=phenotype_record,
            unified_record=unified_record,
        ),
        "provenance": {
            "created_by": "fix88 deterministic integrated candidate interpretation renderer; fix81 matching preserved, denominator display and 5-0 stage1 phenotype keyword payload export added",
            "third_llm_execution": "not_executed",
            "third_llm_policy_ja": "fix61では入力根拠の混線を避けるため、まず第一段階遺伝子根拠を含めて決定論的に統合解釈を作成します。外部URL、PMID、DOI、IRIは生成しません。",
            "source_data_available": {
                "selected_candidate_llm_detail": bool(single_record),
                "phenotype_keyword_search_row_for_selected_candidate": bool(phenotype_record),
                "unified_candidate_row_for_selected_candidate": bool(unified_record),
            },
        },
    }
    return payload


def _fix58_render_integrated_candidate_interpretation_md(payload: Dict[str, Any]) -> str:
    target = payload.get("target", {}) or {}
    snapshot = payload.get("candidate_snapshot", {}) or {}
    axes = payload.get("evidence_axes", {}) or {}
    stage1 = payload.get("stage1_gene_context", {}) or {}
    refs = payload.get("references_and_materials", {}) or {}

    def _v(value: Any) -> str:
        text = _fix58_clean_scalar(value)
        return text if text else "(未記載)"

    lines: List[str] = []
    lines.extend([
        "# 統合候補解釈",
        "",
        f"- target_mondo_id: {_v(target.get('target_mondo_id'))}",
        f"- selected_candidate_id: {_v(target.get('selected_candidate_id'))}",
        "- file_role: 選択候補1件について、第2段階LLM詳細、表現型キーワード探索の当該候補行（存在する場合）、統合候補一覧の当該候補行を束ねた主出力。",
        "- paired_machine_file: `*_integrated_candidate_interpretation.json`",
        "",
        "## 1. 結論",
        "",
        _v(payload.get("interpretation_summary_ja")),
        "",
        "## 2. 候補の基本情報",
        "",
        f"- strain_id: {_v(snapshot.get('strain_id'))}",
        f"- strain_name: {_v(snapshot.get('strain_name'))}",
        f"- variation_class: {_v(snapshot.get('variation_class'))}",
        f"- resource_type_label_en: {_v(snapshot.get('resource_type_label_en'))}",
        f"- resource_type_label_ja: {_v(snapshot.get('resource_type_label_ja'))}",
        f"- variation_class_status: {_v(snapshot.get('variation_class_status'))}",
        f"- primary_gene: {_v(snapshot.get('primary_gene'))}",
        f"- stage1_human_gene_id: {_v(snapshot.get('stage1_human_gene_id'))}",
        f"- stage1_gene_id_iri: {_v(snapshot.get('stage1_gene_id_iri'))}",
        f"- sources: {_v(snapshot.get('sources'))}",
        f"- applications: {_v(snapshot.get('applications'))}",
        f"- resource_iri: {_v(snapshot.get('resource_iri'))}",
        "",
        "## 3. 第一段階LLMの疾患関連遺伝子根拠",
        "",
        _v(stage1.get("role_ja")),
        "",
        _v(stage1.get("short_text_ja")),
        "",
        "## 4. 選択候補と統合候補上位の関係",
        "",
        _v((payload.get("selected_vs_integrated_top_comparison") or {}).get("comparison_statement_ja")),
        "",
        "## 5. 用語定義",
        "",
    ])
    for _term, _desc in (payload.get("term_definitions") or {}).items():
        lines.append(f"- {_term}: {_desc}")

    lines.extend([
        "",
        "## 6. 統合前データとの関係",
        "",
        _v((payload.get("relationship_to_selected_candidate_llm_detail") or {}).get("role_ja")),
        "",
        _v((payload.get("relationship_to_selected_candidate_llm_detail") or {}).get("override_policy_ja")),
        "",
        "## 7. 根拠軸ごとの読み分け",
        "",
        "| 根拠軸 | 意味 | 主な値 |",
        "|---|---|---|",
    ])
    axis_rows = [
        ("第一段階LLM遺伝子根拠", axes.get("stage1_gene_context_axis", {}), ["gene_symbol", "human_gene_id", "gene_id_iri", "sources", "matched_mouse_count", "matched_mouse_record_count", "selected_candidate_in_stage1_matched_mouse_list", "stage1_biological_explanation_ja"]),
        ("疾患遺伝子・既知根拠", axes.get("gene_disease_known_evidence_axis", {}), ["primary_gene", "sources", "selection_priority_hint", "llm_recommendation_display_ja"]),
        ("遺伝子重要度", axes.get("gene_importance_axis", {}), ["primary_gene", "gene_importance_level", "recommended_use_tag", "gene_importance_assessment_ja"]),
        ("候補自身の表現型/MP注釈", axes.get("selected_candidate_phenotype_annotation_axis", {}), ["phenotype_support_level", "phenotype_support_interpretation_ja", "direct_model_validity_note_ja", "evidence_mp_summary_ja", "keyword_overlap_terms", "llm_inferred_phenotype_confidence"]),
        ("表現型キーワード探索での当該候補", axes.get("phenotype_keyword_search_axis_for_this_candidate", {}), ["phenotype_candidate_priority", "novelty_status", "matched_keywords", "matched_mp_ids", "matched_mp_labels", "unique_high_relevance_mp_count"]),
        ("統合評価", axes.get("integrated_assessment_axis", {}), ["integrated_candidate_priority", "evidence_basis_ja", "check_next_action_ja"]),
    ]
    for label, obj, keys in axis_rows:
        meaning = _v((obj or {}).get("meaning_ja"))
        vals = []
        for key in keys:
            val = _fix58_clean_scalar((obj or {}).get(key))
            if val:
                vals.append(f"{key}={val}")
        lines.append(f"| {label} | {meaning} | {' / '.join(vals) if vals else '(未記載)'} |")

    _fix88_stage1_kw = payload.get("stage1_pre_second_stage_phenotype_keyword_search_summary") or {}
    lines.extend([
        "",
        "## 8. 第1段階後・第2段階LLM前の表現型キーワード探索",
        "",
        _v(_fix88_stage1_kw.get("role_ja")),
        "",
        f"- LLM生成表現型キーワード（日本語）: {_v(_fix82_join_terms(_fix88_stage1_kw.get('llm_generated_disease_phenotype_keywords_ja')))}",
        f"- LLM生成表現型キーワード（英語）: {_v(_fix82_join_terms(_fix88_stage1_kw.get('llm_generated_disease_phenotype_keywords_en')))}",
        f"- 日本語キーワード数: {_v(_fix88_stage1_kw.get('generated_keyword_count_ja'))}",
        f"- 英語キーワード数: {_v(_fix88_stage1_kw.get('generated_keyword_count_en'))}",
        f"- 日英ラベル合算キーワード数: {_v(_fix88_stage1_kw.get('generated_keyword_count_total_label_level'))}",
        f"- 生成根拠: {_v(_fix88_stage1_kw.get('keyword_generation_basis_ja'))}",
        f"- 使用方針: {_v(_fix88_stage1_kw.get('use_policy_ja'))}",
        f"- 注意事項: {_v(_fix88_stage1_kw.get('caution_ja'))}",
        f"- 識別子ポリシー: {_v(_fix88_stage1_kw.get('identifier_policy_ja'))}",
        f"- 順位づけポリシー: {_v(_fix88_stage1_kw.get('ranking_policy_ja'))}",
    ])

    _fix82_kw = payload.get("second_stage_phenotype_keyword_match_summary") or {}
    lines.extend([
        "",
        "## 9. 第二段階LLM表現型キーワード照合の内訳",
        "",
        _v(_fix82_kw.get("role_ja")),
        "",
        f"- LLM生成表現型キーワード（日本語）: {_v(_fix82_join_terms(_fix82_kw.get('llm_generated_disease_phenotype_keywords_ja')))}",
        f"- LLM生成表現型キーワード（英語）: {_v(_fix82_join_terms(_fix82_kw.get('llm_generated_disease_phenotype_keywords_en')))}",
        f"- 日本語キーワード数: {_v(_fix82_kw.get('generated_keyword_count_ja'))}",
        f"- 英語キーワード数: {_v(_fix82_kw.get('generated_keyword_count_en'))}",
        f"- 日英ラベル合算キーワード数: {_v(_fix82_kw.get('generated_keyword_count_total_label_level'))}",
        f"- 照合対象の候補MPラベル: {_v(_fix82_join_terms(_fix82_kw.get('candidate_mp_labels_for_keyword_scoring')))}",
        f"- 一致ラベル: {_v(_fix82_join_terms(_fix82_kw.get('matched_label_terms')))}",
        f"- 一致ペア: {_v(_fix82_join_terms(_fix82_kw.get('matched_label_pairs')))}",
        f"- ラベル一致数: {_v(_fix82_kw.get('matched_label_count'))}",
        f"- 日本語ラベル一致数: {_v(_fix82_kw.get('matched_label_count_ja'))} / {_v(_fix82_kw.get('generated_keyword_count_ja'))}",
        f"- 英語ラベル一致数: {_v(_fix82_kw.get('matched_label_count_en'))} / {_v(_fix82_kw.get('generated_keyword_count_en'))}",
        f"- 一致MP ID: {_v(_fix82_join_terms(_fix82_kw.get('matched_mp_ids')))}",
        f"- 一致MPラベル: {_v(_fix82_join_terms(_fix82_kw.get('matched_mp_labels')))}",
        f"- 一意MP概念数: {_v(_fix82_kw.get('unique_matched_mp_id_count'))}",
        f"- 高関連MP概念数: {_v(_fix82_kw.get('unique_high_relevance_mp_count'))}",
        f"- 件数の読み方: {_v(_fix82_kw.get('counting_policy_ja'))}",
        f"- 要約: {_v(_fix82_kw.get('summary_ja'))}",
        "",
        "## 10. このファイルの読み方",
        "",
    ])
    for item in payload.get("how_to_read_this_file_ja", []) or []:
        lines.append(f"- {item}")

    lines.extend([
        "",
        "## 11. 次に確認すること",
        "",
        _v((axes.get("integrated_assessment_axis", {}) or {}).get("check_next_action_ja")),
        "",
        "## 12. 参考文献・資料",
        "",
        "### 候補リソース",
        "",
        "| 名称 | URL/IRI | 用途 |",
        "|---|---|---|",
    ])
    cand_res = refs.get("candidate_resource", {}) or {}
    lines.append(f"| {_v(cand_res.get('label'))} | {_v(cand_res.get('url'))} | {_v(cand_res.get('role_ja'))} |")
    lines.extend([
        "",
        "### 根拠ソース",
        "",
        "| ソース | URL | この候補での役割 |",
        "|---|---|---|",
    ])
    source_links = refs.get("evidence_source_links", []) or []
    if source_links:
        for item in source_links:
            lines.append(f"| {_v(item.get('label'))} | {_v(item.get('url'))} | {_v(item.get('role_ja'))} |")
    else:
        lines.append("| (未記載) | (未記載) | (未記載) |")
    lines.extend([
        "",
        "### 使用した入力ファイル・資料ロール",
        "",
        "| ファイルロール | 説明 |",
        "|---|---|",
    ])
    for item in refs.get("input_file_roles", []) or []:
        lines.append(f"| {_v(item.get('file_role'))} | {_v(item.get('description_ja'))} |")
    lines.extend([
        "",
        "### 文献",
        "",
    ])
    literature = refs.get("literature_references", []) or []
    if literature:
        for item in literature:
            lines.append(f"- {json.dumps(item, ensure_ascii=False)}")
    else:
        lines.append("入力データ内に文献URL、PMID、DOIは見つかりませんでした。")
    lines.extend([
        "",
        "### 参考資料ポリシー",
        "",
        _v(refs.get("source_policy")),
        "",
    ])
    return "\n".join(lines).strip() + "\n"



def _fix65_render_phenotype_search_summary_for_user(
    search_df: pd.DataFrame,
    *,
    selected_candidate_id: str = "",
    key_prefix: str = "fix65_phenotype_search_status",
) -> None:
    """Render phenotype keyword search status in researcher-facing Japanese."""
    if search_df is None or not isinstance(search_df, pd.DataFrame):
        return

    if search_df.empty:
        st.info(
            "表現型キーワード検索の結果: 登録表現型名の完全一致で表示対象の候補は見つかりませんでした。"
        )
        with st.expander("用語の説明: 登録表現型名の完全一致とは", expanded=False):
            st.write(
                "疾患から作成した表現型キーワードと、候補マウスに登録されている表現型名が、"
                "文字列として一致した場合を指します。オントロジーIDの近縁関係や意味的類似まで含めた"
                "広い検索ではありません。"
            )
        return

    if "diagnostic" in search_df.columns or "error" in search_df.columns:
        diag_col = search_df["diagnostic"] if "diagnostic" in search_df.columns else pd.Series(dtype=object)
        err_col = search_df["error"] if "error" in search_df.columns else pd.Series(dtype=object)
        diag_text = " / ".join(str(v) for v in diag_col.dropna().astype(str).tolist() if str(v).strip())
        err_text = " / ".join(str(v) for v in err_col.dropna().astype(str).tolist() if str(v).strip())
        if err_text:
            st.error(f"表現型キーワード検索でエラーが発生しました: {err_text}")
        elif diag_text:
            st.info(f"表現型キーワード検索の結果: {diag_text}")
        return

    def _norm_text(value: Any) -> str:
        if value is None:
            return ""
        try:
            if pd.isna(value):
                return ""
        except Exception:
            pass
        return str(value).strip()

    def _split_values(value: Any) -> list[str]:
        if value is None:
            return []
        if isinstance(value, (list, tuple, set)):
            parts = [str(v).strip() for v in value]
        else:
            text = _norm_text(value)
            for sep in [" | ", "；", ";", "、", ","]:
                text = text.replace(sep, "|")
            parts = [x.strip() for x in text.split("|")]
        out: list[str] = []
        seen: set[str] = set()
        for part in parts:
            if not part or part.lower() in {"nan", "none", "null"}:
                continue
            if part not in seen:
                seen.add(part)
                out.append(part)
        return out

    def _join_short(values: list[str], limit: int = 6) -> str:
        if not values:
            return ""
        shown = values[:limit]
        suffix = "" if len(values) <= limit else f" / ... 他{len(values) - limit}件"
        return " / ".join(shown) + suffix

    df = search_df.copy()
    if "strain_id" in df.columns:
        df["_fix65_strain_id_norm"] = df["strain_id"].astype(str).str.strip()
    else:
        df["_fix65_strain_id_norm"] = ""

    selected_id = str(selected_candidate_id or "").strip()
    selected_rows = df[df["_fix65_strain_id_norm"] == selected_id] if selected_id else pd.DataFrame()
    selected_detected = bool(selected_id and not selected_rows.empty)

    if "novelty_status" in df.columns:
        novelty = df["novelty_status"].astype(str).str.strip()
    else:
        novelty = pd.Series([""] * len(df))
    outside_count = int((novelty == "候補一覧外").sum())
    known_count = int((novelty == "既存候補").sum())
    total_count = int(len(df))

    st.markdown("#### 表現型キーワード検索の結果")
    if selected_id:
        if selected_detected:
            st.success(
                f"選択候補 {selected_id} は、表現型キーワード検索でも検出されています。"
            )
            row = selected_rows.iloc[0]
            matched_keywords = _split_values(row.get("matched_keywords_short", row.get("matched_keywords", "")))
            matched_labels = _split_values(row.get("matched_mp_labels_short", row.get("matched_mp_labels", "")))
            matched_ids = _split_values(row.get("matched_mp_ids", ""))
            with st.expander("選択候補の検出理由を表示", expanded=False):
                if matched_keywords:
                    st.write(f"一致キーワード: {_join_short(matched_keywords)}")
                if matched_labels:
                    st.write(f"一致した登録表現型名: {_join_short(matched_labels)}")
                if matched_ids:
                    st.write(f"対応する表現型ID: {_join_short(matched_ids)}")
                if not (matched_keywords or matched_labels or matched_ids):
                    st.write("一致内容の詳細列は、この検索結果には含まれていません。")
        else:
            st.warning(
                f"選択候補 {selected_id} は、今回の表現型キーワード検索結果には含まれていません。"
            )

    if outside_count > 0:
        st.info(
            f"第1段階候補一覧に含まれていない追加候補が {outside_count} 件見つかりました。"
            f"既存候補として検出された候補は {known_count} 件です。"
        )
    else:
        st.info(
            "第1段階候補一覧に含まれていない追加候補は、登録表現型名の完全一致では見つかりませんでした。"
            f"既存候補として検出された候補は {known_count} 件です。"
        )

    st.caption(f"表現型キーワード検索の総検出件数: {total_count} 件")
    with st.expander("用語の説明: 登録表現型名の完全一致とは", expanded=False):
        st.write(
            "疾患から作成した表現型キーワードと、候補マウスに登録されている表現型名が、"
            "文字列として一致した場合を指します。オントロジーIDの近縁関係や意味的類似まで含めた"
            "広い検索ではありません。"
        )
        st.write(
            "「第1段階候補一覧に含まれていない追加候補」とは、遺伝子・既知根拠に基づく"
            "第1段階の候補表には入っていなかったものの、表現型キーワード検索で追加検出された候補です。"
        )

def _render_single_strain_llm_runner(
    *,
    overview_df: pd.DataFrame,
    details_df: pd.DataFrame,
    log_text: str,
    target_mondo: str,
    root_mid_for_name: str,
    candidate_ids: List[str],
    section_title: str,
    selector_label: str,
    key_prefix: str,
    llm_model: str,
    default_selected_id: str = "",
) -> None:
    if overview_df is None or overview_df.empty:
        st.info("候補系統がありません。")
        return

    overview_df = _add_application_columns_to_overview_df(overview_df)
    overview_df = _fix77_add_resource_type_columns_to_overview_df(overview_df)
    overview_df = _add_recommended_use_columns_to_overview_df(overview_df)
    overview_df = _add_llm_recommendation_group_columns(overview_df)

    candidate_ids = [str(x).strip() for x in candidate_ids if str(x).strip()]
    if not candidate_ids:
        st.info("候補系統がありません。")
        return

    candidate_df = overview_df[overview_df["strain_id"].astype(str).isin(candidate_ids)].copy()
    if candidate_df.empty:
        st.info("候補系統がありません。")
        return

    display_cols = [
        c for c in [
            "strain_id", "strain_name", "primary_gene", "sources",
            "variation_class", "resource_type_label_en", "resource_type_label_ja", "variation_class_status", "recommended_use_tag", "recommended_use_tag_explanation_ja", "selection_priority_hint", "llm_recommendation_display_ja",
            "llm_recommendation_reason_category_ja", "llm_recommendation_diversity_axis_ja", "llm_recommendation_reason_ja", "llm_representative_strain_id",
            "llm_equivalent_group_size", "applications", "application_tags_ja", "recommended_marker", "recommended_reason_short", "recommended_reason_llm_ja", "selection_reason_short"
        ] if c in candidate_df.columns
    ]
    display_df = candidate_df[display_cols].copy()

    _ts_list = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    with st.expander(f"📋 {section_title} の候補一覧を表示", expanded=False):
        st.caption("LLM推奨（代表候補）は、候補の優劣を確定するラベルではなく、先に詳細確認する代表候補を示します。推奨理由カテゴリ・確認軸は、代表候補として見る理由を説明する補足情報です。同じ遺伝子・根拠・変異型などを持つ候補は、同等候補として表示します。application はRIKEN BRCに登録された研究用途情報であり、表現型支持レベルとは分けて表示します。")
        render_configurable_dataframe(
            display_df,
            label=f"{section_title} 候補一覧",
            key_prefix=f"{key_prefix}_candidates",
            default_columns=display_cols,
            selector_expanded=False,
        )
        st.download_button(
            f"CSVダウンロード（{section_title} 候補一覧）",
            data=display_df.to_csv(index=False).encode("utf-8"),
            file_name=f"{_ts_list}_{root_mid_for_name}_{key_prefix}_candidate_list.csv",
            mime="text/csv",
            key=f"{key_prefix}_candidate_list_dl_{_ts_list}",
        )

    def _option_label(row: pd.Series) -> str:
        bits = [str(row.get("strain_id", "")).strip()]
        if str(row.get("strain_name", "")).strip():
            bits.append(str(row.get("strain_name", "")).strip())
        meta = []
        if str(row.get("primary_gene", "")).strip():
            meta.append(f"primary_gene={str(row.get('primary_gene', '')).strip()}")
        if str(row.get("selection_priority_hint", "")).strip():
            meta.append(f"priority={str(row.get('selection_priority_hint', '')).strip()}")
        if str(row.get("application_tags_ja", "")).strip():
            meta.append(f"用途={str(row.get('application_tags_ja', '')).strip()}")
        if str(row.get("llm_recommendation_display_ja", "")).strip():
            marker = str(row.get("llm_recommendation_display_ja", "")).strip()
            reason = str(row.get("recommended_reason_short", "")).strip()
            meta.append(f"{marker} ({reason})" if reason and marker.startswith("LLM推奨") else marker)
        elif str(row.get("recommended_marker", "")).strip():
            marker = "LLM推奨（代表候補）"
            reason = str(row.get("recommended_reason_short", "")).strip()
            meta.append(f"{marker} ({reason})" if reason else marker)
        if meta:
            bits.append(" / ".join(meta))
        return " | ".join([b for b in bits if b])

    option_rows = []
    option_labels = []
    for _, _row in candidate_df.iterrows():
        option_rows.append(_row)
        option_labels.append(_option_label(_row))

    default_index = 0
    if default_selected_id:
        for i, _row in enumerate(option_rows):
            if str(_row.get("strain_id", "")).strip() == str(default_selected_id).strip():
                default_index = i
                break

    selected_label = st.selectbox(
        selector_label,
        options=option_labels,
        index=default_index,
        key=f"{key_prefix}_selected_strain_label",
    )
    selected_idx = option_labels.index(selected_label)
    row0 = option_rows[selected_idx]
    selected_strain_id = str(row0.get("strain_id", "")).strip()

    info_lines = []
    if str(row0.get("strain_name", "")).strip():
        info_lines.append(f"系統名={str(row0.get('strain_name', '')).strip()}")
    if str(row0.get("primary_gene", "")).strip():
        info_lines.append(f"primary_gene={str(row0.get('primary_gene', '')).strip()}")
    if str(row0.get("selection_priority_hint", "")).strip():
        info_lines.append(f"priority={str(row0.get('selection_priority_hint', '')).strip()}")
    if str(row0.get("application_tags_ja", "")).strip():
        info_lines.append(f"用途={str(row0.get('application_tags_ja', '')).strip()}")
    if str(row0.get("llm_recommendation_display_ja", "")).strip():
        info_lines.append(str(row0.get("llm_recommendation_display_ja", "")).strip())
    if str(row0.get("selection_reason_short", "")).strip():
        info_lines.append(f"reason={str(row0.get('selection_reason_short', '')).strip()}")
    if info_lines:
        st.caption(" / ".join(info_lines))
    st.caption(f"現在の単独候補 LLM モデル: {llm_model}")

    selected_row_df = candidate_df[candidate_df["strain_id"].astype(str).str.strip() == selected_strain_id].head(1)
    if not selected_row_df.empty:
        sel = selected_row_df.iloc[0]
        rr_short = str(sel.get("recommended_reason_short", "")).strip()
        rr_llm = str(sel.get("recommended_reason_llm_ja", "")).strip()
        rec_display = str(sel.get("llm_recommendation_display_ja", "")).strip()
        rec_note = str(sel.get("llm_recommendation_note_ja", "")).strip()
        group_size = str(sel.get("llm_equivalent_group_size", "")).strip()
        group_members = str(sel.get("llm_equivalent_group_members_short", "")).strip()
        apps = str(sel.get("applications", "")).strip()
        app_tags = str(sel.get("application_tags_ja", "")).strip()
        app_interp = str(sel.get("application_interpretation_ja", "")).strip()
        if rr_short or rr_llm or rec_display or rec_note or apps or app_tags or app_interp:
            with st.expander("LLM推奨・同等候補の説明", expanded=False):
                if rec_display:
                    st.markdown("**位置づけ**")
                    st.write(rec_display)
                if rec_note:
                    st.markdown("**説明**")
                    st.write(rec_note)
                if group_size:
                    st.markdown("**同等候補数**")
                    st.write(group_size)
                if group_members:
                    st.markdown("**同等候補**")
                    st.write(group_members)
                if apps or app_tags or app_interp:
                    st.markdown("**研究用途情報（application）**")
                    if apps:
                        st.write(apps)
                    if app_tags:
                        st.markdown("**用途タグ**")
                        st.write(app_tags)
                    if app_interp:
                        st.markdown("**用途情報の解釈**")
                        st.write(app_interp)
                if rr_short:
                    st.markdown("**短い根拠**")
                    st.write(rr_short)
                if rr_llm:
                    st.markdown("**第1段階LLMの理由**")
                    st.write(rr_llm)

    cache_key = f"{key_prefix}_single_llm_cache::{selected_strain_id}"
    if cache_key not in st.session_state:
        st.session_state[cache_key] = {}

    if st.button("LLM要約を実行して表示", key=f"{key_prefix}_run_single_llm"):
        try:
            with st.spinner("系統要約の LLM 実行中..."):
                record = _build_single_strain_record_for_llm(
                    overview_df,
                    details_df,
                    log_text,
                    selected_strain_id,
                    target_mondo,
                )
                generated = _generate_single_strain_summary_with_llm(record, model=llm_model)
            st.session_state[cache_key] = generated
            st.rerun()
        except Exception as e:
            st.session_state[cache_key] = {
                "strain_id": selected_strain_id,
                "llm_worked": "false",
                "llm_failure_reason": f"{type(e).__name__}: {e}",
            }
            st.rerun()

    if st.session_state[cache_key]:
        _single_summary_row = dict(st.session_state[cache_key])
        _render_single_summary_content(
            _single_summary_row,
            key_prefix=key_prefix,
            root_mid_for_name=root_mid_for_name,
            section_title=section_title,
        )

        st.markdown("#### 表現型キーワードから当該候補の補足確認")
        st.caption(
            "このブロックは、すでに実行した単独候補LLM詳細の表現型キーワードで、"
            "当該候補および同じMP一致を持つ候補を補足確認するためのものです。"
            "第1段階後・第2段階LLM前の探索は上の『5-0』で実行します。"
            "ここで得た表現型一致は、第1段階LLM候補順を置き換える順位としては使いません。"
        )
        _kw_ja = str(_single_summary_row.get("llm_generated_disease_phenotype_keywords_ja", "") or _single_summary_row.get("llm_inferred_hpo_phenotype_terms_ja", "")).strip()
        _kw_en = str(_single_summary_row.get("llm_generated_disease_phenotype_keywords_en", "") or _single_summary_row.get("llm_inferred_hpo_phenotype_terms_en", "")).strip()
        if _kw_ja or _kw_en:
            with st.expander("探索に使うLLM生成表現型キーワード", expanded=False):
                if _kw_ja:
                    st.markdown("**日本語キーワード**")
                    st.write(_kw_ja)
                if _kw_en:
                    st.markdown("**英語キーワード**")
                    st.write(_kw_en)
        else:
            st.info("単独候補LLM詳細の表現型キーワードがないため、この補足確認は実行できません。第2段階LLM前の表現型探索は上の『5-0』で実行してください。")

        _search_cache_key = f"{key_prefix}_phenotype_keyword_search::{selected_strain_id}"
        if _search_cache_key not in st.session_state:
            st.session_state[_search_cache_key] = None
        if (_kw_ja or _kw_en) and st.button("表現型キーワードから新規候補探索を実行", key=f"{key_prefix}_run_pheno_keyword_search", use_container_width=True):
            try:
                with st.spinner("表現型キーワードからMP該当マウスを探索中..."):
                    _existing_ids = overview_df["strain_id"].astype(str).str.strip().dropna().tolist() if "strain_id" in overview_df.columns else []
                    _search_df = _build_phenotype_keyword_new_candidate_df(_single_summary_row, _existing_ids)
                    _search_df = _attach_llm_mp_relevance_to_search_df(_search_df, _single_summary_row, model=llm_model)
                st.session_state[_search_cache_key] = _search_df
                st.rerun()
            except Exception as e:
                st.session_state[_search_cache_key] = pd.DataFrame([{
                    "diagnostic": "表現型キーワードから新規候補探索に失敗しました",
                    "error": f"{type(e).__name__}: {e}",
                }])
                st.rerun()

        _search_df = st.session_state.get(_search_cache_key)
        if isinstance(_search_df, pd.DataFrame):
            _fix65_render_phenotype_search_summary_for_user(
                _search_df,
                selected_candidate_id=selected_strain_id,
                key_prefix=f"{key_prefix}_post_second_stage_pheno_status",
            )
            if not _search_df.empty:
                with st.expander("📋 表現型キーワード由来の候補探索結果を表示", expanded=True):
                    _display_df = _search_df.copy()
                    if "novelty_status" in _display_df.columns:
                        _outside_only = st.checkbox(
                            "第1段階候補一覧外の追加候補のみ表示",
                            value=True,
                            key=f"{key_prefix}_phenotype_keyword_search_outside_only",
                        )
                        st.caption(
                            "候補一覧外とは、第1段階LLMの単独候補一覧には含まれていないが、"
                            "表現型キーワードと実在MPラベルの一致により追加で見つかった候補です。"
                            "チェックONではこの追加候補のみ、OFFでは既存候補も含めて表示します。"
                        )
                        if _outside_only:
                            _display_df = _display_df[_display_df["novelty_status"].astype(str) == "候補一覧外"].reset_index(drop=True)
                    _top20 = st.checkbox(
                        "上位20件のみ表示",
                        value=True,
                        key=f"{key_prefix}_phenotype_keyword_search_top20",
                    )
                    if _top20 and len(_display_df) > 20:
                        _display_df = _display_df.head(20).reset_index(drop=True)
                    st.caption(f"表示: {len(_display_df)} 件 / CSV保存対象: {len(_search_df)} 件")
                    _default_cols = [c for c in [
                        "strain_id", "novelty_status", "phenotype_candidate_priority", "phenotype_candidate_rank_score",
                        "unique_matched_mp_id_count", "unique_high_relevance_mp_count", "unique_medium_relevance_mp_count",
                        "high_relevance_mp_count", "medium_relevance_mp_count", "specific_mp_count", "moderately_specific_mp_count", "broad_or_very_broad_mp_count",
                        "matched_keywords", "matched_mp_ids", "matched_mp_labels",
                        "phenotype_relevance_levels", "phenotype_specificity_levels", "phenotype_relevance_reason_ja", "match_types", "resource_iri",
                        "diagnostic", "error", "keywords_used"
                    ] if c in _display_df.columns]
                    render_configurable_dataframe(
                        _display_df,
                        label="表現型キーワード由来の候補探索結果",
                        key_prefix=f"{key_prefix}_phenotype_keyword_search",
                        default_columns=_default_cols or list(_display_df.columns),
                        selector_expanded=False,
                    )
                    _summary_payload = {
                        "target_mondo_id": str(root_mid_for_name or ""),
                        "selected_item": str(selected_strain_id or ""),
                        "search_executed": True,
                        "result_rows": int(len(_search_df)),
                        "display_rows": int(len(_display_df)),
                        "new_candidate_count": int((_search_df["novelty_status"].astype(str) == "候補一覧外").sum()) if "novelty_status" in _search_df.columns else 0,
                        "known_candidate_count": int((_search_df["novelty_status"].astype(str) == "既存候補").sum()) if "novelty_status" in _search_df.columns else 0,
                        "priority_counts": _search_df["phenotype_candidate_priority"].astype(str).value_counts().to_dict() if "phenotype_candidate_priority" in _search_df.columns else {},
                        "top_strain_ids": _display_df["strain_id"].astype(str).head(20).tolist() if "strain_id" in _display_df.columns else [],
                        **_fix60_top_strain_ids_by_novelty(_search_df),
                        "file_role_ja": "表現型キーワードから追加候補を探索した結果のサマリーJSON",
                        "reading_guide_ja": "このファイルは選択候補そのものの根拠説明ではなく、同じ疾患表現型キーワードで見つかる追加候補を俯瞰するための探索ログです。top_all_strain_ids は既存候補と候補一覧外を含む上位、top_new_candidate_strain_ids は候補一覧外のみ、top_known_candidate_strain_ids は既存候補のみです。主候補の判断は selected_candidate_llm_detail を先に読み、候補集合の比較は unified_candidates_review.csv を確認してください。",
                        "column_definitions_ja": {
                            "strain_id": "候補系統ID。表現型キーワード検索で見つかった系統です。",
                            "novelty_status": "第1段階の単独候補一覧に既に含まれていたかを示します。既存候補=既に候補一覧内、候補一覧外=表現型キーワード検索で新たに見つかった追加確認候補。",
                            "phenotype_candidate_priority": "表現型一致だけに基づく確認優先度です。疾患遺伝子根拠の強さではありません。",
                            "matched_keywords": "LLMが疾患から生成した表現型キーワードのうち、候補MPラベルと一致した語です。",
                            "matched_mp_ids": "一致したMP IDです。",
                            "matched_mp_labels": "一致したMPラベルです。",
                            "unique_high_relevance_mp_count": "疾患文脈との関連が高いと評価された一意なMP数です。",
                            "resource_iri": "候補系統のリソースIRIです。"
                        },
                        "value_definitions_ja": {
                            "候補一覧外": "第1段階LLM選定の単独候補一覧には入っていないが、表現型キーワード一致により追加で見つかった系統。GUIの『第1段階候補一覧外の追加候補のみ表示』をONにすると、この追加候補だけを表示します。OFFにすると第1段階候補一覧内の既存候補も含めて表示します。",
                            "既存候補": "第1段階LLM選定の単独候補一覧にも含まれる系統。",
                            "最優先確認候補": "表現型キーワード一致が強く、追加確認の優先度が最も高い候補。",
                            "優先確認候補": "表現型キーワード一致により優先して確認する候補。",
                            "確認候補": "表現型一致はあるが、特異性や根拠の強さを追加確認すべき候補。"
                        },
                        "gui_filter_guide_ja": "GUIの『第1段階候補一覧外の追加候補のみ表示』は、第1段階LLMの単独候補一覧には入っていないが、登録表現型名との一致で追加発見された候補だけに絞る表示です。第1段階候補一覧内の既存候補も併せて確認する場合は外し、表現型から見つかった追加候補を重点確認する場合に入れます。",
                        "note_ja": "選択候補LLM詳細JSONとは別の探索サマリーです。",
                    }
                    _ts_search = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                    st.download_button(
                        "JSON保存（表現型キーワード由来候補探索サマリー）",
                        data=json.dumps(_summary_payload, ensure_ascii=False, indent=2).encode("utf-8"),
                        file_name=f"{_ts_search}_{root_mid_for_name}_phenotype_keyword_candidate_search_summary.json",
                        mime="application/json",
                        key=f"{key_prefix}_phenotype_keyword_search_summary_dl_{_ts_search}_{selected_strain_id}",
                        use_container_width=True,
                    )
                    st.download_button(
                        "CSVダウンロード（表現型キーワード由来の候補探索結果）",
                        data=_search_df.to_csv(index=False).encode("utf-8"),
                        file_name=f"{_ts_search}_{root_mid_for_name}_phenotype_keyword_candidate_search.csv",
                        mime="text/csv",
                        key=f"{key_prefix}_phenotype_keyword_search_dl_{_ts_search}_{selected_strain_id}",
                        use_container_width=True,
                    )

                    _stage1_presearch_cached = st.session_state.get(f"fix64_stage1_phenotype_presearch::{root_mid_for_name}") or {}
                    _stage1_presearch_df = _stage1_presearch_cached.get("search_df") if isinstance(_stage1_presearch_cached, dict) else pd.DataFrame()
                    _unified_pheno_df = _fix89_union_phenotype_search_results(_stage1_presearch_df, _search_df)
                    _unified_df = _build_unified_gene_phenotype_candidate_df(overview_df, _unified_pheno_df)
                    _fix89_coverage = _fix89_stage1_presearch_coverage_summary(_stage1_presearch_df, _unified_df)
                    if _fix89_coverage.get("missing_stage1_presearch_strain_ids"):
                        st.error(
                            "5-0 疾患レベル表現型キーワード探索候補が統合候補一覧から脱落しています: "
                            + ", ".join(_fix89_coverage.get("missing_stage1_presearch_strain_ids", [])[:20])
                        )
                    elif _fix89_coverage.get("unified_contains_all_stage1_presearch_strains") is True:
                        st.caption("fix89: 5-0 疾患レベル表現型キーワード探索候補は unified_candidates に全件反映されています。")
                    if not _unified_df.empty:
                        _unified_review_df = _prepare_unified_candidates_review_df(_unified_df)
                        _unified_debug_df = _prepare_unified_gene_phenotype_export_df(_unified_df)
                        with st.expander("📋 統合候補一覧出力（候補確認用CSV / 構造化JSON / 検証用CSV）", expanded=False):
                            st.caption(
                                "読む順序: 1) selected_candidate_llm_detail.md/json で選択候補の意味を確認、"
                                "2) unified_candidates_review.csv で候補集合を比較、"
                                "3) phenotype_keyword_candidate_search.csv は5-1補足探索、5-0疾患レベル探索は unified_candidates に反映済みとして確認、"
                                "4) full.json/debug.csv は監査・再現確認用として確認します。"
                            )
                            _fix60_svt = _fix60_selected_vs_integrated_top_comparison(_unified_df, selected_strain_id)
                            if _fix60_svt.get("comparison_statement_ja"):
                                if _fix60_svt.get("same_candidate") is False:
                                    st.warning(_fix60_svt.get("comparison_statement_ja"))
                                else:
                                    st.info(_fix60_svt.get("comparison_statement_ja"))
                            _review_display = _unified_review_df.head(50).copy()
                            _review_default_cols = [c for c in [
                                "strain_id", "integrated_candidate_priority", "candidate_origin_ja",
                                "candidate_check_order_score", "evidence_path_ja", "evidence_basis_ja",
                                "primary_gene", "sources", "phenotype_candidate_priority", "phenotype_search_stage_ja",
                                "unique_high_relevance_mp_count", "matched_mp_labels_short",
                                "matched_keywords_short", "limitation_ja", "check_next_action_ja",
                            ] if c in _review_display.columns]
                            render_configurable_dataframe(
                                _review_display,
                                label="統合候補一覧（候補確認用・上位50件表示）",
                                key_prefix=f"{key_prefix}_unified_candidates_review",
                                default_columns=_review_default_cols or list(_review_display.columns),
                                selector_expanded=False,
                            )
                            _unified_full_json_payload = _build_unified_candidates_full_json_payload(
                                unified_df=_unified_df,
                                review_df=_unified_review_df,
                                target_mondo_id=root_mid_for_name,
                                selected_item=selected_strain_id,
                                stage1_phenotype_keyword_payload=(st.session_state.get(f"fix64_stage1_phenotype_presearch::{root_mid_for_name}") or {}).get("keyword_payload", {}),
                                stage1_presearch_df=_stage1_presearch_df,
                            )
                            _fix58_interpretation_payload = _fix58_build_integrated_candidate_interpretation_payload(
                                single_summary_row=_single_summary_row,
                                phenotype_search_df=_search_df,
                                unified_df=_unified_df,
                                target_mondo_id=root_mid_for_name,
                                selected_strain_id=selected_strain_id,
                                stage1_phenotype_keyword_payload=(st.session_state.get(f"fix64_stage1_phenotype_presearch::{root_mid_for_name}") or {}).get("keyword_payload", {}),
                            )
                            _fix58_interpretation_md = _fix58_render_integrated_candidate_interpretation_md(_fix58_interpretation_payload)
                            st.markdown("##### 最重要出力：統合候補解釈")
                            st.caption(
                                "選択候補1件について、selected_candidate_llm_detail、表現型キーワード探索の当該候補行、"
                                "unified_candidates の当該候補行を統合した、人・機械両用の解釈ファイルです。"
                            )
                            st.download_button(
                                "Markdown保存（統合候補解釈・主出力）",
                                data=_fix58_interpretation_md.encode("utf-8"),
                                file_name=f"{_ts_search}_{root_mid_for_name}_{selected_strain_id}_integrated_candidate_interpretation.md",
                                mime="text/markdown",
                                key=f"{key_prefix}_fix58_integrated_candidate_interpretation_md_dl_{_ts_search}_{selected_strain_id}",
                                use_container_width=True,
                            )
                            st.download_button(
                                "JSON保存（統合候補解釈・機械可読）",
                                data=json.dumps(_fix58_interpretation_payload, ensure_ascii=False, indent=2).encode("utf-8"),
                                file_name=f"{_ts_search}_{root_mid_for_name}_{selected_strain_id}_integrated_candidate_interpretation.json",
                                mime="application/json",
                                key=f"{key_prefix}_fix58_integrated_candidate_interpretation_json_dl_{_ts_search}_{selected_strain_id}",
                                use_container_width=True,
                            )
                            st.download_button(
                                "CSV保存（主出力：統合候補一覧・候補確認用）",
                                data=_unified_review_df.to_csv(index=False).encode("utf-8"),
                                file_name=f"{_ts_search}_{root_mid_for_name}_unified_candidates_review.csv",
                                mime="text/csv",
                                key=f"{key_prefix}_unified_candidates_review_dl_{_ts_search}_{selected_strain_id}",
                                use_container_width=True,
                            )
                            st.download_button(
                                "JSON保存（構造化記録：統合候補一覧・根拠保存用）",
                                data=json.dumps(_unified_full_json_payload, ensure_ascii=False, indent=2).encode("utf-8"),
                                file_name=f"{_ts_search}_{root_mid_for_name}_unified_candidates_full.json",
                                mime="application/json",
                                key=f"{key_prefix}_unified_candidates_full_json_dl_{_ts_search}_{selected_strain_id}",
                                use_container_width=True,
                            )
                            st.download_button(
                                "CSV保存（検証用：統合候補一覧・全列）",
                                data=_unified_debug_df.to_csv(index=False).encode("utf-8"),
                                file_name=f"{_ts_search}_{root_mid_for_name}_unified_candidates_debug.csv",
                                mime="text/csv",
                                key=f"{key_prefix}_unified_candidates_debug_dl_{_ts_search}_{selected_strain_id}",
                                use_container_width=True,
                            )
    else:
        st.info("まだ LLM 要約は実行されていません。")



def _fix64_stage1_gene_context_rows_for_phenotype_presearch(
    overview_df: pd.DataFrame,
    log_text: str,
    *,
    max_genes: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """Collect first-stage gene context for pre-second-stage phenotype search.

    fix64 policy:
      * phenotype keyword search is placed after Step3 / first-stage selection prep,
        before single-candidate LLM detail execution;
      * it uses disease/gene context only, not the selected candidate's second-stage
        LLM detail output;
      * it is an auxiliary discovery/comparison path and must not reorder the
        first-stage selected candidate list.

    fix76 policy:
      * collect all unique primary_gene values from the Stage1 overview by default,
        rather than stopping at the former top-20 cap.  The pre-second-stage
        candidate-selection table needs gene-function context for every existing
        gene/known-evidence candidate where possible.
    """
    rows: List[Dict[str, Any]] = []
    if overview_df is None or overview_df.empty:
        return rows
    work = overview_df.copy()
    if "primary_gene" not in work.columns:
        return rows
    if "candidate_check_order_score" in work.columns:
        work["_fix64_order_score"] = pd.to_numeric(work["candidate_check_order_score"], errors="coerce").fillna(0)
        work = work.sort_values(["_fix64_order_score", "strain_id"], ascending=[False, True])
    seen = set()
    for _, row in work.iterrows():
        gene = str(row.get("primary_gene", "") or "").strip()
        if not gene or gene in seen:
            continue
        seen.add(gene)
        ctx = _fix61_parse_stage1_gene_context(log_text, gene, str(row.get("strain_id", "") or ""))
        rows.append({
            "gene_symbol": gene,
            "strain_id_example": str(row.get("strain_id", "") or ""),
            "selection_priority_hint": str(row.get("selection_priority_hint", "") or ""),
            "sources": str(row.get("sources", "") or ""),
            "applications": str(row.get("applications", "") or ""),
            "stage1_human_gene_id": ctx.get("human_gene_id") if isinstance(ctx, dict) else None,
            "stage1_gene_id_iri": ctx.get("gene_id_iri") if isinstance(ctx, dict) else None,
            "stage1_matched_mouse_count": ctx.get("matched_mouse_count") if isinstance(ctx, dict) else None,
            "stage1_matched_mouse_record_count": ctx.get("matched_mouse_record_count") if isinstance(ctx, dict) else None,
            "stage1_biological_explanation_ja": ctx.get("stage1_biological_explanation_ja") if isinstance(ctx, dict) else None,
        })
        if max_genes is not None and max_genes > 0 and len(rows) >= max_genes:
            break
    return rows


def _fix76_merge_completed_stage1_gene_context_rows(
    base_rows: List[Dict[str, Any]],
    llm_rows: Any,
) -> List[Dict[str, Any]]:
    """Merge LLM-completed biological explanations into Stage1 gene context rows.

    fix76 uses the same first-stage/pre-second-stage LLM call to ensure that
    every primary_gene appearing in the Stage1 overview has a concise biological
    function explanation when possible.  To avoid fabricating identifiers, this
    helper accepts GeneID, IRI, sources, and matched counts only from the
    deterministic base rows; from the LLM-completed rows it accepts only the
    textual biological explanation for an already-listed gene.
    """
    if not isinstance(base_rows, list):
        return []

    def _clean(v: Any) -> str:
        if v is None:
            return ""
        try:
            if pd.isna(v):
                return ""
        except Exception:
            pass
        s = str(v).strip()
        if s.lower() in {"nan", "none", "<na>"}:
            return ""
        return s

    merged: List[Dict[str, Any]] = []
    by_gene: Dict[str, Dict[str, Any]] = {}
    for row in base_rows:
        if not isinstance(row, dict):
            continue
        rec = dict(row)
        gene = _clean(rec.get("gene_symbol")).upper()
        if not gene:
            continue
        rec.setdefault("stage1_gene_context_source_ja", "第1段階LLMの利用者向けログから決定論的に抽出。ログにない遺伝子機能説明はfix76の第1段階後補完LLMで補う。")
        merged.append(rec)
        by_gene[gene] = rec

    if isinstance(llm_rows, str):
        try:
            llm_rows = json.loads(llm_rows)
        except Exception:
            llm_rows = []
    if not isinstance(llm_rows, list):
        llm_rows = []

    for row in llm_rows:
        if not isinstance(row, dict):
            continue
        gene = _clean(row.get("gene_symbol") or row.get("primary_gene")).upper()
        if not gene or gene not in by_gene:
            continue
        target = by_gene[gene]
        existing_expl = _clean(target.get("stage1_biological_explanation_ja"))
        llm_expl = _clean(row.get("stage1_biological_explanation_ja") or row.get("biological_explanation_ja") or row.get("gene_function_ja"))
        if llm_expl and not existing_expl:
            target["stage1_biological_explanation_ja"] = llm_expl
            target["stage1_gene_context_source_ja"] = "第1段階後・第2段階LLM前の全primary_gene補完LLMで生成。GeneID・IRI・Sources・対応マウス数は既存データからのみ取得。"
        elif existing_expl:
            target["stage1_gene_context_source_ja"] = "第1段階LLMの利用者向けログから決定論的に抽出。"

    return merged


def _fix64_generate_stage1_phenotype_keywords(
    *,
    target_mondo_id: str,
    overview_df: pd.DataFrame,
    log_text: str,
    model: str = "gpt-6-luna",
    timeout_sec: float = 60.0,
) -> Dict[str, Any]:
    """Generate disease phenotype labels for pre-second-stage phenotype search."""
    client = _llm_client(require_key=True)
    if client is None:
        raise RuntimeError("OPENAI_API_KEY 未設定または openai パッケージ未利用")
    gene_context_rows = _fix64_stage1_gene_context_rows_for_phenotype_presearch(overview_df, log_text, max_genes=None)
    payload = {
        "target_mondo_id": str(target_mondo_id or ""),
        "stage1_gene_context_rows": gene_context_rows,
        "task": "Generate disease-relevant phenotype keyword labels for exact registered phenotype-name search before single-candidate LLM detail, and complete concise biological explanations for every primary_gene row when missing.",
    }
    system = (
        "あなたは生命科学・バイオリソース検索支援の専門家です。"
        "Step3/第1段階LLM後、単独候補LLM詳細を実行する前に、"
        "疾患文脈に合う表現型キーワードを生成してください。"
        "入力に含まれる疾患関連遺伝子、GeneID、Sources、生物学的説明を必ず利用してください。"
        "HPO ID、MP ID、IRIは生成しないでください。ラベル文字列のみを返してください。"
        "第2段階LLM対象候補を選ぶ前の評価材料として使える表現型ラベルを返してください。第2段階LLM実行後の再順位づけを指示してはいけません。"
        "必ずJSONのみを返し、次のキーを含めてください: "
        "llm_generated_disease_phenotype_keywords_ja, llm_generated_disease_phenotype_keywords_en, "
        "keyword_generation_basis_ja, use_policy_ja, caution_ja, stage1_gene_context_rows_completed。"
        "stage1_gene_context_rows_completed は、入力された各 gene_symbol について、"
        "gene_symbol と stage1_biological_explanation_ja だけを含む配列にしてください。"
        "GeneID、IRI、MP ID、HPO ID、MONDO ID、架空IDは生成しないでください。"
    )
    resp = client.chat.completions.create(service_tier="default", 
        model=_luna_model_guard(model),
        timeout=timeout_sec,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
        ],
        response_format={"type": "json_object"},
    )
    content = (resp.choices[0].message.content or "").strip()
    obj = json.loads(content)
    gene_context_rows = _fix76_merge_completed_stage1_gene_context_rows(
        gene_context_rows,
        obj.get("stage1_gene_context_rows_completed", []),
    )

    out = {
        "llm_generated_disease_phenotype_keywords_ja": _sanitize_llm_phenotype_text_no_ids(obj.get("llm_generated_disease_phenotype_keywords_ja", "")),
        "llm_generated_disease_phenotype_keywords_en": _sanitize_llm_phenotype_text_no_ids(obj.get("llm_generated_disease_phenotype_keywords_en", "")),
        "keyword_generation_basis_ja": str(obj.get("keyword_generation_basis_ja", "") or "").strip(),
        "use_policy_ja": str(obj.get("use_policy_ja", "") or "").strip(),
        "caution_ja": str(obj.get("caution_ja", "") or "").strip(),
        "target_mondo_id": str(target_mondo_id or ""),
        "phenotype_keyword_stage": "after_stage1_before_single_candidate_llm_detail",
        "phenotype_keyword_use_policy_fixed": "pre_second_stage_selection_evidence_not_posthoc_reranking",
        "stage1_gene_context_rows": gene_context_rows,
        "llm_model": model,
    }
    if not out["llm_generated_disease_phenotype_keywords_ja"] and not out["llm_generated_disease_phenotype_keywords_en"]:
        raise RuntimeError("表現型キーワード生成結果が空です。")
    return out


def _fix64_build_pre_second_stage_selection_df(
    overview_df: pd.DataFrame,
    phenotype_search_df: pd.DataFrame,
    stage1_gene_context_rows: Optional[List[Dict[str, Any]]] = None,
) -> pd.DataFrame:
    """Build the candidate-selection table used before second-stage LLM execution.

    fix70 policy:
    - Keep the Stage1 gene/known-evidence order as the default LLM execution lane.
    - Attach phenotype keyword hits to existing Stage1 candidates before the second-stage LLM.
    - Surface strong phenotype-supported existing candidates as additional review candidates,
      without silently replacing the default representative candidate.
    - Keep phenotype-only candidates in a comparison lane; they are not automatic LLM targets.
    """
    if overview_df is None or not isinstance(overview_df, pd.DataFrame) or overview_df.empty:
        return pd.DataFrame()

    base = overview_df.copy()
    if "strain_id" not in base.columns:
        return pd.DataFrame()
    base["strain_id"] = base["strain_id"].astype(str).str.strip()
    base = base[base["strain_id"] != ""].reset_index(drop=True)
    if base.empty:
        return pd.DataFrame()

    pheno_by_id: Dict[str, Dict[str, Any]] = {}
    if phenotype_search_df is not None and isinstance(phenotype_search_df, pd.DataFrame) and not phenotype_search_df.empty and "strain_id" in phenotype_search_df.columns:
        ph = phenotype_search_df.copy()
        ph["strain_id"] = ph["strain_id"].astype(str).str.strip()
        ph = ph[ph["strain_id"] != ""].reset_index(drop=True)
        if not ph.empty:
            for sid, grp in ph.groupby("strain_id", sort=False):
                row = grp.iloc[0]
                pheno_by_id[str(sid)] = {
                    "phenotype_keyword_candidate_flag": True,
                    "novelty_status": _cell_text(row, "novelty_status"),
                    "phenotype_candidate_priority": _cell_text(row, "phenotype_candidate_priority"),
                    "phenotype_candidate_rank_score": pd.to_numeric(row.get("phenotype_candidate_rank_score", None), errors="coerce"),
                    "unique_high_relevance_mp_count": pd.to_numeric(row.get("unique_high_relevance_mp_count", 0), errors="coerce"),
                    "unique_matched_mp_id_count": pd.to_numeric(row.get("unique_matched_mp_id_count", 0), errors="coerce"),
                    "matched_keywords": _cell_text(row, "matched_keywords"),
                    "matched_mp_ids": _cell_text(row, "matched_mp_ids"),
                    "matched_mp_labels": _cell_text(row, "matched_mp_labels"),
                    "phenotype_relevance_levels": _cell_text(row, "phenotype_relevance_levels"),
                    "phenotype_specificity_levels": _cell_text(row, "phenotype_specificity_levels"),
                    "phenotype_relevance_reason_ja": _cell_text(row, "phenotype_relevance_reason_ja"),
                    "resource_iri": _cell_text(row, "resource_iri"),
                }

    # fix75: stage1 gene-context rows are generated in the same presearch
    # payload.  The overview_df rows do not always carry stage1_gene_context_json,
    # so merge the already-generated gene context back by gene symbol before
    # exporting pre_second_stage_candidate_selection.csv.  Values are copied only
    # from the generated stage1_gene_context_rows payload; no GeneID/IRI/text is
    # newly inferred here.
    stage1_ctx_by_gene: Dict[str, Dict[str, Any]] = {}
    stage1_ctx_by_example_strain: Dict[str, Dict[str, Any]] = {}
    if isinstance(stage1_gene_context_rows, list):
        for ctx_row in stage1_gene_context_rows:
            if not isinstance(ctx_row, dict):
                continue
            gene_key = str(ctx_row.get("gene_symbol", "") or "").strip().upper()
            sid_key = str(ctx_row.get("strain_id_example", "") or "").strip()
            if gene_key and gene_key not in stage1_ctx_by_gene:
                stage1_ctx_by_gene[gene_key] = ctx_row
            if sid_key and sid_key not in stage1_ctx_by_example_strain:
                stage1_ctx_by_example_strain[sid_key] = ctx_row

    def _fix75_context_enriched_record(row_obj: Any) -> Dict[str, Any]:
        try:
            rec = row_obj.to_dict() if hasattr(row_obj, "to_dict") else dict(row_obj or {})
        except Exception:
            rec = {}
        sid = str(rec.get("strain_id", "") or "").strip()
        gene = str(rec.get("primary_gene", "") or rec.get("stage1_gene_symbol", "") or "").strip().upper()
        ctx_row = stage1_ctx_by_example_strain.get(sid) or stage1_ctx_by_gene.get(gene)
        if isinstance(ctx_row, dict) and ctx_row:
            rec.setdefault("stage1_gene_context_available", "true")
            rec.setdefault("stage1_gene_symbol", ctx_row.get("gene_symbol", ""))
            rec.setdefault("stage1_human_gene_id", ctx_row.get("stage1_human_gene_id", ""))
            rec.setdefault("stage1_gene_id_iri", ctx_row.get("stage1_gene_id_iri", ""))
            rec.setdefault("stage1_gene_sources", ctx_row.get("sources", ""))
            rec.setdefault("stage1_matched_mouse_count", ctx_row.get("stage1_matched_mouse_count", ""))
            rec.setdefault("stage1_matched_mouse_record_count", ctx_row.get("stage1_matched_mouse_record_count", ""))
            rec.setdefault("stage1_biological_explanation_ja", ctx_row.get("stage1_biological_explanation_ja", ""))
            rec.setdefault("stage1_gene_context_source_ja", ctx_row.get("stage1_gene_context_source_ja", ""))
            # For rows already in the Stage1 overview table, this field means
            # this strain belongs to the Stage1 gene/known-evidence candidate set.
            rec.setdefault("stage1_selected_candidate_in_matched_mouse_list", "true")
        return rec

    def _fix70_is_strong_pheno(ph: Dict[str, Any]) -> bool:
        if not ph:
            return False
        priority = str(ph.get("phenotype_candidate_priority", "") or "")
        high_n = ph.get("unique_high_relevance_mp_count", 0)
        matched_n = ph.get("unique_matched_mp_id_count", 0)
        high_n = 0 if pd.isna(high_n) else float(high_n)
        matched_n = 0 if pd.isna(matched_n) else float(matched_n)
        specificity = str(ph.get("phenotype_specificity_levels", "") or "").lower()
        return (
            priority in {"最優先確認候補", "優先確認候補"}
            and high_n >= 1
            and matched_n >= 1
            and ("specific" in specificity or "moderately_specific" in specificity)
        )

    rows: List[Dict[str, Any]] = []
    seen: set = set()
    default_flag_used = False

    for idx, row in base.iterrows():
        sid = str(row.get("strain_id", "") or "").strip()
        if not sid:
            continue
        seen.add(sid)

        stage1_score = pd.to_numeric(row.get("candidate_check_order_score", None), errors="coerce")
        if pd.isna(stage1_score):
            stage1_score = max(0.0, 100.0 - float(idx))

        ph = pheno_by_id.get(sid, {})
        ph_rank = ph.get("phenotype_candidate_rank_score", float("nan"))
        if pd.isna(ph_rank):
            high_n = ph.get("unique_high_relevance_mp_count", 0)
            matched_n = ph.get("unique_matched_mp_id_count", 0)
            high_n = 0 if pd.isna(high_n) else float(high_n)
            matched_n = 0 if pd.isna(matched_n) else float(matched_n)
            ph_rank = high_n * 20.0 + matched_n * 5.0
        ph_component = min(float(ph_rank or 0), 50.0)
        has_pheno = bool(ph)
        strong_pheno = _fix70_is_strong_pheno(ph)

        default_flag = False
        if not default_flag_used:
            default_flag = True
            default_flag_used = True

        additional_flag = bool(has_pheno and strong_pheno and not default_flag)
        if default_flag and has_pheno:
            selection_lane = "既定LLM実行候補（第1段階代表＋表現型一致）"
            llm_recommendation = "既定の第2段階LLM対象。表現型一致も補助注釈として読む。"
        elif default_flag:
            selection_lane = "既定LLM実行候補（第1段階代表）"
            llm_recommendation = "既定の第2段階LLM対象。表現型一致がない場合も、第1段階の遺伝子・既知根拠に基づき詳細評価する。"
        elif additional_flag:
            selection_lane = "追加LLM検討候補（既存候補＋表現型強一致）"
            llm_recommendation = "第2段階LLMの追加実行候補。既定候補を置換するのではなく、必要に応じて比較対象として追加評価する。"
        elif has_pheno:
            selection_lane = "既存候補（表現型一致あり・比較確認）"
            llm_recommendation = "第1段階候補内で表現型一致あり。既定候補の補助比較として確認する。"
        else:
            selection_lane = "既存候補（遺伝子・既知根拠）"
            llm_recommendation = "表現型一致は未確認。第1段階根拠に基づき必要に応じて確認する。"

        # Candidate-check score remains a visible aid only. Sorting is lane-based
        # to avoid phenotype evidence silently replacing the Stage1 representative.
        stage1_context_cols = _fix72_stage1_context_columns_from_row(_fix75_context_enriched_record(row))
        mutation_mode_cols = _fix73_mutation_mode_columns_from_row(row)
        mutation_component = pd.to_numeric(mutation_mode_cols.get("mutation_mode_component", 0.0), errors="coerce")
        if pd.isna(mutation_component):
            mutation_component = 0.0
        candidate_check_score = float(stage1_score) + (ph_component if has_pheno else 0.0) + float(mutation_component)

        rows.append({
            "strain_id": sid,
            "pre_second_stage_selection_score": round(candidate_check_score, 3),
            "stage1_candidate_score": round(float(stage1_score), 3),
            "phenotype_selection_component": round(float(ph_component), 3),
            "mutation_mode_component": round(float(mutation_component), 3),
            "selection_lane_ja": selection_lane,
            "llm_execution_recommendation_ja": llm_recommendation,
            "default_llm_execution_candidate_flag": default_flag,
            "additional_llm_review_candidate_flag": additional_flag,
            "phenotype_only_comparison_candidate_flag": False,
            "candidate_selection_class_ja": selection_lane,
            "next_action_ja": llm_recommendation,
            "primary_gene": _cell_text(row, "primary_gene"),
            "sources": _cell_text(row, "sources"),
            "selection_priority_hint": _cell_text(row, "selection_priority_hint"),
            "llm_recommendation_display_ja": _cell_text(row, "llm_recommendation_display_ja"),
            "applications": _cell_text(row, "applications"),
            **stage1_context_cols,
            **mutation_mode_cols,
            "phenotype_keyword_candidate_flag": has_pheno,
            "novelty_status": ph.get("novelty_status", "既存候補"),
            "phenotype_candidate_priority": ph.get("phenotype_candidate_priority", ""),
            "unique_high_relevance_mp_count": ph.get("unique_high_relevance_mp_count", 0),
            "unique_matched_mp_id_count": ph.get("unique_matched_mp_id_count", 0),
            "matched_keywords": ph.get("matched_keywords", ""),
            "matched_mp_ids": ph.get("matched_mp_ids", ""),
            "matched_mp_labels": ph.get("matched_mp_labels", ""),
            "phenotype_relevance_levels": ph.get("phenotype_relevance_levels", ""),
            "phenotype_specificity_levels": ph.get("phenotype_specificity_levels", ""),
            "phenotype_relevance_reason_ja": ph.get("phenotype_relevance_reason_ja", ""),
            "resource_iri": ph.get("resource_iri", _cell_text(row, "resource_iri")),
            "_fix70_lane_order": 0 if default_flag else (1 if additional_flag else (2 if has_pheno else 3)),
            "_fix70_stage1_order": int(idx) + 1,
        })

    for sid, ph in pheno_by_id.items():
        if sid in seen:
            continue
        ph_rank = ph.get("phenotype_candidate_rank_score", float("nan"))
        if pd.isna(ph_rank):
            high_n = ph.get("unique_high_relevance_mp_count", 0)
            matched_n = ph.get("unique_matched_mp_id_count", 0)
            high_n = 0 if pd.isna(high_n) else float(high_n)
            matched_n = 0 if pd.isna(matched_n) else float(matched_n)
            ph_rank = high_n * 20.0 + matched_n * 5.0
        stage1_context_cols = _fix72_empty_stage1_context_columns()
        mutation_mode_cols = _fix73_mutation_mode_columns_from_row({}, phenotype_only=True)

        phenotype_only_component = min(float(ph_rank or 0), 70.0)

        rows.append({
            "strain_id": sid,
            "pre_second_stage_selection_score": round(phenotype_only_component, 3),
            "stage1_candidate_score": 0.0,
            "phenotype_selection_component": round(phenotype_only_component, 3),
            "mutation_mode_component": 0.0,
            "selection_lane_ja": "表現型由来の追加比較候補（候補一覧外）",
            "llm_execution_recommendation_ja": "第1段階候補一覧外のため、自動的な第2段階LLM対象にはしない。研究者が明示的に選んだ場合のみ追加評価する。",
            "default_llm_execution_candidate_flag": False,
            "additional_llm_review_candidate_flag": False,
            "phenotype_only_comparison_candidate_flag": True,
            "candidate_selection_class_ja": "表現型由来の追加比較候補（候補一覧外）",
            "next_action_ja": "遺伝子・既知根拠候補との比較材料として確認する。第2段階LLMの追加実行は、研究者が明示的に選んだ場合のみ行う。",
            "primary_gene": "",
            "sources": "",
            "selection_priority_hint": "",
            "llm_recommendation_display_ja": "",
            "applications": "",
            **stage1_context_cols,
            **mutation_mode_cols,
            "phenotype_keyword_candidate_flag": True,
            "novelty_status": ph.get("novelty_status", "候補一覧外"),
            "phenotype_candidate_priority": ph.get("phenotype_candidate_priority", ""),
            "unique_high_relevance_mp_count": ph.get("unique_high_relevance_mp_count", 0),
            "unique_matched_mp_id_count": ph.get("unique_matched_mp_id_count", 0),
            "matched_keywords": ph.get("matched_keywords", ""),
            "matched_mp_ids": ph.get("matched_mp_ids", ""),
            "matched_mp_labels": ph.get("matched_mp_labels", ""),
            "phenotype_relevance_levels": ph.get("phenotype_relevance_levels", ""),
            "phenotype_specificity_levels": ph.get("phenotype_specificity_levels", ""),
            "phenotype_relevance_reason_ja": ph.get("phenotype_relevance_reason_ja", ""),
            "resource_iri": ph.get("resource_iri", ""),
            "_fix70_lane_order": 4,
            "_fix70_stage1_order": 10**9,
        })

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    sort_cols = ["_fix70_lane_order", "pre_second_stage_selection_score", "stage1_candidate_score", "phenotype_selection_component", "mutation_mode_component", "strain_id"]
    out = out.sort_values(sort_cols, ascending=[True, False, False, False, False, True]).reset_index(drop=True)
    out.insert(0, "pre_second_stage_rank", range(1, len(out) + 1))
    return out.drop(columns=[c for c in ["_fix70_lane_order", "_fix70_stage1_order"] if c in out.columns])


def _fix64_render_stage1_phenotype_presearch_section(
    *,
    overview_df: pd.DataFrame,
    log_text: str,
    root_mid_for_name: str,
    llm_model: str,
    key_prefix: str = "fix64_stage1_phenotype_presearch",
) -> None:
    """Render phenotype keyword search before single-candidate LLM detail."""
    if overview_df is None or overview_df.empty:
        return
    st.markdown("### 5-0. 表現型キーワード探索（第1段階後・第2段階LLM前）")
    st.caption(
        "この探索は、単独候補LLM詳細を実行する前に、Step3/第1段階LLMで得た疾患関連遺伝子情報から"
        "疾患表現型キーワードを生成し、登録表現型名との完全一致で候補を確認する導線です。"
        "第2段階LLMの対象候補を選ぶ前に、既定の遺伝子・既知根拠代表候補、表現型強一致の既存候補、候補一覧外の追加比較候補を分けて確認します。"
    )
    st.info(
        "位置づけ: 表現型キーワード探索は、第2段階LLM対象候補を決める前の評価材料です。"
        "第2段階LLM実行後に順位を覆す後付け材料としては使いません。"
    )
    cache_key = f"{key_prefix}::{root_mid_for_name}"
    if cache_key not in st.session_state:
        st.session_state[cache_key] = None
    if st.button("第1段階後の表現型キーワード探索を実行", key=f"{key_prefix}_run", use_container_width=True):
        try:
            with st.spinner("第1段階LLM情報から表現型キーワードを生成し、MP該当マウスを探索中..."):
                kw_payload = _fix64_generate_stage1_phenotype_keywords(
                    target_mondo_id=root_mid_for_name,
                    overview_df=overview_df,
                    log_text=log_text,
                    model=llm_model,
                )
                existing_ids = overview_df["strain_id"].astype(str).str.strip().dropna().tolist() if "strain_id" in overview_df.columns else []
                search_df = _build_phenotype_keyword_new_candidate_df(kw_payload, existing_ids)
                search_df = _attach_llm_mp_relevance_to_search_df(search_df, kw_payload, model=llm_model)
                selection_df = _fix64_build_pre_second_stage_selection_df(
                    overview_df,
                    search_df,
                    stage1_gene_context_rows=kw_payload.get("stage1_gene_context_rows", []),
                )
                st.session_state[cache_key] = {
                    "keyword_payload": kw_payload,
                    "search_df": search_df,
                    "selection_df": selection_df,
                }
                if isinstance(selection_df, pd.DataFrame) and not selection_df.empty and "strain_id" in selection_df.columns:
                    st.session_state[f"{key_prefix}_recommended_second_stage_strain_id"] = str(selection_df.iloc[0].get("strain_id", "") or "").strip()
            st.rerun()
        except Exception as e:
            st.session_state[cache_key] = {
                "keyword_payload": {"target_mondo_id": root_mid_for_name, "error": f"{type(e).__name__}: {e}"},
                "search_df": pd.DataFrame([{"diagnostic": "第1段階後の表現型キーワード探索に失敗しました", "error": f"{type(e).__name__}: {e}"}]),
            }
            st.rerun()
    cached = st.session_state.get(cache_key)
    if not isinstance(cached, dict):
        return
    kw_payload = cached.get("keyword_payload") or {}
    search_df = cached.get("search_df")
    selection_df = cached.get("selection_df")
    if kw_payload.get("error"):
        st.error(kw_payload.get("error"))
    else:
        with st.expander("探索に使った表現型キーワードと生成根拠", expanded=False):
            st.markdown("**日本語キーワード**")
            st.write(kw_payload.get("llm_generated_disease_phenotype_keywords_ja", ""))
            st.markdown("**英語キーワード**")
            st.write(kw_payload.get("llm_generated_disease_phenotype_keywords_en", ""))
            if kw_payload.get("keyword_generation_basis_ja"):
                st.markdown("**生成根拠**")
                st.write(kw_payload.get("keyword_generation_basis_ja"))
            st.markdown("**使用方針**")
            st.write("第2段階LLMの実行前に、遺伝子・既知根拠と表現型一致を併用して候補を確認します。実行後の後付け再順位づけには使いません。")
    if isinstance(selection_df, pd.DataFrame) and not selection_df.empty:
        top_sid = str(selection_df.iloc[0].get("strain_id", "") or "").strip()
        top_class = str(selection_df.iloc[0].get("candidate_selection_class_ja", "") or "").strip()
        if top_sid:
            st.success(f"第2段階LLMの推奨実行候補: {top_sid}（{top_class or '分類未記載'}）")
            st.caption("この表では、既定の第2段階LLM対象を第1段階代表候補として維持しつつ、表現型強一致の既存候補を追加LLM検討候補として明示します。候補一覧外の表現型由来候補は比較候補であり、自動的な第2段階LLM対象にはしません。変異様式・系統タイプは用途・代表性・比較軸を説明する補助成分として明示し、単独では疾患モデル妥当性を決定しません。")
        selection_cols = [c for c in [
            "pre_second_stage_rank", "strain_id", "selection_lane_ja",
            "default_llm_execution_candidate_flag", "additional_llm_review_candidate_flag",
            "phenotype_only_comparison_candidate_flag", "llm_execution_recommendation_ja",
            "pre_second_stage_selection_score", "stage1_candidate_score", "phenotype_selection_component", "mutation_mode_component",
            "primary_gene", "sources", "selection_priority_hint", "llm_recommendation_display_ja",
            "variation_class", "mutation_type", "resource_type_label_en", "resource_type_label_ja",
            "variation_class_normalized", "variation_class_status", "mutation_mode_use_tag_ja", "mutation_mode_rank_role_ja",
            "stage1_gene_symbol", "stage1_human_gene_id", "stage1_gene_id_iri",
            "stage1_biological_explanation_ja", "stage1_matched_mouse_count",
            "stage1_matched_mouse_record_count", "stage1_gene_context_short_ja",
            "phenotype_candidate_priority", "unique_high_relevance_mp_count", "unique_matched_mp_id_count",
            "matched_keywords", "matched_mp_ids", "matched_mp_labels", "next_action_ja", "resource_iri",
        ] if c in selection_df.columns]
        render_configurable_dataframe(
            selection_df.head(50),
            label="第2段階LLM対象候補選定表（第1段階後・第2段階前）",
            key_prefix=f"{key_prefix}_pre_second_stage_selection_table",
            default_columns=selection_cols or list(selection_df.columns),
            selector_expanded=False,
        )
        ts_sel = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
        st.download_button(
            "CSV保存（第2段階LLM対象候補選定表）",
            data=selection_df.to_csv(index=False).encode("utf-8"),
            file_name=f"{ts_sel}_{root_mid_for_name}_pre_second_stage_candidate_selection.csv",
            mime="text/csv",
            key=f"{key_prefix}_pre_second_stage_selection_csv_dl_{ts_sel}",
            use_container_width=True,
        )
    if isinstance(search_df, pd.DataFrame):
        _recommended_sid = ""
        if isinstance(selection_df, pd.DataFrame) and not selection_df.empty and "strain_id" in selection_df.columns:
            _recommended_sid = str(selection_df.iloc[0].get("strain_id", "") or "").strip()
        _fix65_render_phenotype_search_summary_for_user(
            search_df,
            selected_candidate_id=_recommended_sid,
            key_prefix=f"{key_prefix}_pre_second_stage_pheno_status",
        )
        if not search_df.empty:
            display_df = search_df.copy()
            if "novelty_status" in display_df.columns:
                outside_only = st.checkbox(
                    "第1段階候補一覧外の追加候補のみ表示",
                    value=True,
                    key=f"{key_prefix}_outside_only",
                )
                st.caption(
                    "候補一覧外とは、第1段階LLMの単独候補一覧には含まれていないが、"
                    "表現型キーワードと実在MPラベルの一致で追加発見された候補です。"
                    "ONでは新規発見候補のみ、OFFでは既存候補も含めて第2段階LLM前の比較対象を確認します。"
                )
                if outside_only:
                    display_df = display_df[display_df["novelty_status"].astype(str) == "候補一覧外"].reset_index(drop=True)
            default_cols = [c for c in [
                "strain_id", "novelty_status", "phenotype_candidate_priority", "phenotype_candidate_rank_score",
                "unique_matched_mp_id_count", "unique_high_relevance_mp_count", "matched_keywords", "matched_mp_ids", "matched_mp_labels",
                "phenotype_relevance_levels", "phenotype_specificity_levels", "phenotype_relevance_reason_ja", "resource_iri",
                "diagnostic", "error"
            ] if c in display_df.columns]
            render_configurable_dataframe(
                display_df.head(50),
                label="第1段階後の表現型キーワード探索結果",
                key_prefix=f"{key_prefix}_table",
                default_columns=default_cols or list(display_df.columns),
                selector_expanded=False,
            )
            ts = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
            summary_payload = {
                "schema_version": "stage1_phenotype_keyword_presearch_v7_fix89",
                "target_mondo_id": str(root_mid_for_name or ""),
                "file_role_ja": "第1段階LLM後・第2段階LLM前に行う表現型キーワード探索のサマリー",
                "use_policy_ja": "第2段階LLM実行前の候補選定材料として使う。表現型由来のみの候補は追加比較候補として別枠にし、自動的な第2段階LLM実行対象にはしない。第2段階LLM実行後に選定済み候補を覆す後付け順位としても使わない。",
                "keyword_payload": kw_payload,
                "result_rows": int(len(search_df)),
                "new_candidate_count": int((search_df["novelty_status"].astype(str) == "候補一覧外").sum()) if "novelty_status" in search_df.columns else 0,
                "known_candidate_count": int((search_df["novelty_status"].astype(str) == "既存候補").sum()) if "novelty_status" in search_df.columns else 0,
                "top_strain_ids": search_df["strain_id"].astype(str).head(20).tolist() if "strain_id" in search_df.columns else [],
                "pre_second_stage_recommended_strain_id": str(selection_df.iloc[0].get("strain_id", "") or "").strip() if isinstance(selection_df, pd.DataFrame) and not selection_df.empty and "strain_id" in selection_df.columns else None,
                "pre_second_stage_selection_top20": selection_df.head(20).to_dict(orient="records") if isinstance(selection_df, pd.DataFrame) and not selection_df.empty else [],
            }
            st.download_button(
                "JSON保存（第1段階後 表現型キーワード探索サマリー）",
                data=json.dumps(summary_payload, ensure_ascii=False, indent=2).encode("utf-8"),
                file_name=f"{ts}_{root_mid_for_name}_stage1_phenotype_keyword_presearch_summary.json",
                mime="application/json",
                key=f"{key_prefix}_summary_dl_{ts}",
                use_container_width=True,
            )
            _fix88_stage1_keyword_md = _fix88_render_stage1_phenotype_keyword_payload_md(kw_payload)
            st.download_button(
                "Markdown保存（第1段階後 表現型キーワードと生成根拠）",
                data=_fix88_stage1_keyword_md.encode("utf-8"),
                file_name=f"{ts}_{root_mid_for_name}_stage1_phenotype_keyword_presearch_keywords.md",
                mime="text/markdown",
                key=f"{key_prefix}_keywords_md_dl_{ts}",
                use_container_width=True,
            )
            st.download_button(
                "CSV保存（第1段階後 表現型キーワード探索結果）",
                data=search_df.to_csv(index=False).encode("utf-8"),
                file_name=f"{ts}_{root_mid_for_name}_stage1_phenotype_keyword_presearch.csv",
                mime="text/csv",
                key=f"{key_prefix}_csv_dl_{ts}",
                use_container_width=True,
            )

def _render_unified_llm_on_demand_section(
    *,
    df_det_A: pd.DataFrame,
    step3_log_text: str,
    root_mid_for_name: str,
    df_llm_pairs: pd.DataFrame,
    llm_single_model: str,
    llm_pair_model: str,
) -> None:
    target_mondo = str(root_mid_for_name or "").strip()
    overview_df = build_app_overview_table(df_det_A, target_mondo=target_mondo)
    if overview_df.empty:
        return

    recommended_ids = []
    if df_llm_pairs is not None and not df_llm_pairs.empty:
        pair_selected = df_llm_pairs[df_llm_pairs.get("selected_pair", "").astype(str).str.lower() == "true"].copy() if "selected_pair" in df_llm_pairs.columns else pd.DataFrame()
        if not pair_selected.empty:
            for col in ["strain_id_a", "strain_id_b"]:
                if col in pair_selected.columns:
                    recommended_ids.extend(pair_selected[col].astype(str).tolist())
    recommended_ids = [x for x in dict.fromkeys([str(x).strip() for x in recommended_ids if str(x).strip()])]

    overview_df = overview_df.copy()
    overview_df["recommended_marker"] = overview_df["strain_id"].astype(str).map(
        lambda x: "LLM推奨" if str(x).strip() in set(recommended_ids) else ""
    )
    overview_df = _add_application_columns_to_overview_df(overview_df)
    overview_df = _fix77_add_resource_type_columns_to_overview_df(overview_df)
    overview_df = _add_recommended_use_columns_to_overview_df(overview_df)
    overview_df = _add_llm_recommendation_group_columns(overview_df)

    st.subheader("5. LLM要約（オンデマンド）")
    st.caption("fix64では、表現型キーワード探索を第2段階LLM詳細の後付けではなく、第1段階後・第2段階LLM前に置き、遺伝子・既知根拠と表現型一致を同じ表で確認してから第2段階LLM対象を選べる導線にしました。")

    _fix64_render_stage1_phenotype_presearch_section(
        overview_df=overview_df,
        log_text=step3_log_text,
        root_mid_for_name=root_mid_for_name,
        llm_model=llm_single_model,
        key_prefix="fix64_stage1_phenotype_presearch",
    )

    st.markdown("### 5-1. 単独候補")
    _render_single_strain_llm_runner(
        overview_df=overview_df,
        details_df=df_det_A,
        log_text=step3_log_text,
        target_mondo=target_mondo,
        root_mid_for_name=root_mid_for_name,
        candidate_ids=overview_df["strain_id"].astype(str).tolist(),
        section_title="単独候補",
        selector_label="単独候補から 1 件選択",
        key_prefix="single_candidate",
        llm_model=llm_single_model,
    )

    st.markdown("### 5-2. 比較ペア")
    if df_llm_pairs is not None and not df_llm_pairs.empty:
        _render_pair_detail_block(
            df_llm_pairs,
            overview_df,
            root_mid_for_name=root_mid_for_name,
            key_prefix="llm_pairs_display_unified",
            llm_model=llm_pair_model,
        )
    else:
        st.info("比較提案 CSV が未指定のため、比較ペア要約は表示できません。")


def _resolve_existing_file(path_str: str, base_dir_str: str) -> Optional[Path]:
    s = str(path_str or "").strip()
    if not s:
        return None
    p = Path(s)
    if not p.is_absolute():
        p = Path(base_dir_str) / p
    return p


def _detect_root_mondo_from_artifacts(details_path: Optional[Path], summary_path: Optional[Path], pair_path: Optional[Path], details_df: pd.DataFrame) -> str:
    for p in [details_path, summary_path, pair_path]:
        if p is not None:
            m = re.search(r"(MONDO_\d{7})", str(p))
            if m:
                return m.group(1)
    if details_df is not None and not details_df.empty and "MONDO_ID" in details_df.columns:
        mids = details_df["MONDO_ID"].astype(str).map(_normalize_mondo_id)
        mids = [m for m in mids.tolist() if m]
        if mids:
            return mids[0]
    return "MONDO_ID_MISSING"


def _render_existing_artifacts_section(
    *,
    base_dir: str,
    details_csv_input: str,
    summary_csv_input: str,
    step3_log_input: str,
    pair_csv_input: str,
) -> bool:
    details_path = _resolve_existing_file(details_csv_input, base_dir)
    summary_path = _resolve_existing_file(summary_csv_input, base_dir)
    log_path = _resolve_existing_file(step3_log_input, base_dir)
    pair_path = _resolve_existing_file(pair_csv_input, base_dir)

    if not any([details_path, summary_path, log_path, pair_path]):
        return False

    if details_path is None or not details_path.exists():
        st.error("既存 details_table CSV が必要です。")
        return True
    if summary_path is not None and not summary_path.exists():
        st.error("指定された summary_stats CSV が見つかりません。")
        return True
    if log_path is not None and not log_path.exists():
        st.error("指定された Step3 ログが見つかりません。")
        return True

    try:
        if summary_path is not None and summary_path.exists():
            _, df_det_A, _, _ = build_views(summary_path, details_path)
        else:
            df_det_A = _read_csv(details_path)
            if "MONDO_ID" not in df_det_A.columns:
                df_det_A["MONDO_ID"] = ""
            if "RBRC" not in df_det_A.columns:
                st.error("details_table CSV に RBRC 列がありません。")
                return True
            for col in ["Strain", "Sources", "Mutation_Type"]:
                if col not in df_det_A.columns:
                    df_det_A[col] = ""
    except Exception as e:
        st.error(f"既存 CSV の読み込みに失敗しました: {e}")
        return True

    step3_log_text = _load_log_text(log_path) if log_path is not None else ""
    df_llm_pairs = pd.DataFrame()
    if pair_path is not None and pair_path.exists():
        df_llm_pairs = _safe_read_optional_csv(pair_path)
    else:
        root_mid_tmp = _detect_root_mondo_from_artifacts(details_path, summary_path, pair_path, df_det_A)
        auto_pair = _find_latest_optional_csv(str(_llm_outputs_dir(base_dir) / "selection"), f"strain_pair_suggestions*{root_mid_tmp}*.csv")
        if auto_pair is not None and auto_pair.exists():
            df_llm_pairs = _safe_read_optional_csv(auto_pair)
            pair_path = auto_pair

    root_mid_for_name = _detect_root_mondo_from_artifacts(details_path, summary_path, pair_path, df_det_A)

    st.success("既存成果物を読み込みました。Step1 / Step3 の再実行なしで後段 LLM を実行できます。")
    with st.expander("現在読み込まれているファイル", expanded=True):
        st.markdown(f"- **details_table**: `{details_path}`")
        st.markdown(f"- **summary_stats**: `{summary_path}`" if summary_path is not None else "- **summary_stats**: 未指定")
        st.markdown(f"- **step3_log**: `{log_path}`" if log_path is not None else "- **step3_log**: 未指定")
        if pair_path is not None and pair_path.exists():
            st.markdown(f"- **pair_suggestions**: `{pair_path}`")
        else:
            st.markdown("- **pair_suggestions**: 未指定または未検出")

    st.markdown("#### 第1段階LLM選定準備")
    st.caption("現在読み込んでいる details_table / summary_stats / Step3 ログから、strain_overview と strain_pair_suggestions を作成します。")
    if st.button("第1段階LLM選定準備を実行", key="existing_run_llm_selection_prep"):
        if log_path is None or not log_path.exists():
            st.error("第1段階LLM選定準備には Step3 ログが必要です。既存 Step3 ログ パスを指定してください。")
        else:
            prep_script = Path(base_dir) / "run_llm_strain_selection_prep_v1_fix4_reason.py"
            if not prep_script.exists():
                st.error(f"選定準備スクリプトが見つかりません: {prep_script}")
            else:
                api_key = _get_openai_api_key_for_llm_or_stop()
                output_root = _llm_outputs_dir(base_dir)
                cmd = [
                    sys.executable,
                    str(prep_script),
                    "--details-csv", str(details_path),
                    "--step3-log", str(log_path),
                    "--output-root", str(output_root),
                    "--llm-model", str(st.session_state.get("llm_single_model", "gpt-6-luna")),
                    "--recommend-count", "5",
                    "--max-pair-suggestions", "10",
                ]
                if summary_path is not None and summary_path.exists():
                    cmd.extend(["--summary-csv", str(summary_path)])
                with st.spinner("第1段階LLM選定準備を実行中..."):
                    proc = subprocess.run(
                        cmd,
                        cwd=str(base_dir),
                        text=True,
                        capture_output=True,
                        env=_subprocess_env({"OPENAI_API_KEY": api_key}),
                    )
                proc_stdout = _redact_secret_text(proc.stdout or "", [api_key])
                proc_stderr = _redact_secret_text(proc.stderr or "", [api_key])
                if proc.returncode != 0:
                    st.error(f"第1段階LLM選定準備に失敗しました（rc={proc.returncode}）。")
                    if proc_stderr:
                        st.code(proc_stderr)
                    if proc_stdout:
                        st.code(proc_stdout)
                else:
                    overview_out = _extract_path_from_stdout(r"STRAIN_OVERVIEW_CSV_PATH:\s*(.+)", proc_stdout)
                    pair_out = _extract_path_from_stdout(r"STRAIN_PAIR_SUGGESTIONS_CSV_PATH:\s*(.+)", proc_stdout)
                    runlog_out = _extract_path_from_stdout(r"RUN_LOG_PATH:\s*(.+)", proc_stdout)
                    st.success("第1段階LLM選定準備が完了しました。")
                    if overview_out:
                        st.markdown(f"- **strain_overview**: `{overview_out}`")
                    if pair_out:
                        st.markdown(f"- **strain_pair_suggestions**: `{pair_out}`")
                        pair_path = Path(pair_out)
                        df_llm_pairs = _safe_read_optional_csv(pair_path)
                    if runlog_out:
                        st.markdown(f"- **run_log**: `{runlog_out}`")

    st.session_state["_existing_llm_render_payload"] = {
        "df_det_A": df_det_A,
        "step3_log_text": step3_log_text,
        "root_mid_for_name": root_mid_for_name,
        "df_llm_pairs": df_llm_pairs,
    }
    return True


def _render_pair_detail_block(
    df_llm_pairs: pd.DataFrame,
    df_llm_summary: pd.DataFrame,
    *,
    root_mid_for_name: str,
    key_prefix: str,
    llm_model: str = "gpt-6-luna",
    timeout_sec: float = 60.0,
) -> None:
    if df_llm_pairs is None or df_llm_pairs.empty:
        return

    st.markdown("#### 比較ペア一覧")
    df_llm_pairs_display = build_llm_pair_display_df(df_llm_pairs)
    with st.expander("📋 比較ペア一覧を表示", expanded=False):
        render_configurable_dataframe(
            df_llm_pairs_display,
            label="LLM比較提案（一覧）",
            key_prefix=f"{key_prefix}_pairs_display",
            default_columns=list(df_llm_pairs_display.columns),
            selector_expanded=False,
        )

        _ts_llm_pair = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
        st.download_button(
            "CSVダウンロード（LLM比較提案一覧）",
            df_llm_pairs.to_csv(index=False).encode("utf-8"),
            file_name=f"{_ts_llm_pair}_{root_mid_for_name}_strain_pair_suggestions.csv",
            mime="text/csv",
            key=f"{key_prefix}_dl_llm_pairs_{_ts_llm_pair}",
        )

    _pair_options = []
    for _, _r in df_llm_pairs.iterrows():
        _pair_options.append(_pair_option_label(_r))

    if not _pair_options:
        return

    selected_pair_item = st.selectbox(
        "比較ペアから 1 組選択",
        options=_pair_options,
        key=f"{key_prefix}_selected_pair_item",
    )
    _pair_map = {_pair_option_label(r): i for i, (_, r) in enumerate(df_llm_pairs.iterrows())}
    _pair_idx = _pair_map.get(selected_pair_item)
    if _pair_idx is None:
        return
    _pair_row = df_llm_pairs.iloc[_pair_idx]

    _pair_cache_key = f"{key_prefix}_pair_llm_cache::{str(_pair_row.get('pair_id', _pair_idx)).strip() or _pair_idx}"
    if _pair_cache_key not in st.session_state:
        st.session_state[_pair_cache_key] = {}

    _pair_summary = dict(st.session_state[_pair_cache_key]) if st.session_state[_pair_cache_key] else {}

    _client_ready = _has_usable_user_openai_key() or (_allow_server_openai_key() and bool(os.getenv("OPENAI_API_KEY", "").strip()))
    _button_label = "LLM要約を再実行" if _pair_summary else "LLM要約を実行して表示"
    st.caption(f"現在の比較ペア LLM モデル: {llm_model}")

    button_cols = st.columns([1, 3])
    with button_cols[0]:
        if st.button(_button_label, key=f"{key_prefix}_run_pair_llm", use_container_width=True):
            try:
                with st.spinner("比較提案の LLM 要約を実行中..."):
                    _generated = _generate_pair_summary_with_llm(
                        _pair_row,
                        df_llm_summary,
                        model=llm_model,
                        timeout_sec=timeout_sec,
                    )
                st.session_state[_pair_cache_key] = _generated
                st.rerun()
            except Exception as e:
                st.session_state[_pair_cache_key] = {
                    "pair_llm_worked": "false",
                    "pair_llm_failure_reason": f"{type(e).__name__}: {e}",
                }
                st.rerun()
    with button_cols[1]:
        if not _client_ready:
            st.caption("保存済みユーザーAPI keyがない場合、比較提案のLLM要約は実行できません。")

    if _pair_summary:
        st.markdown("#### 比較ペアのLLM要約")
        for label, field in [
            ("このペアを選ぶ理由", "why_this_pair_ja"),
            ("何を比較できるか", "what_can_be_compared_ja"),
            ("想定差分軸", "expected_difference_axis"),
            ("共通文脈", "shared_context"),
            ("相違文脈", "difference_context"),
            ("注意点", "pair_caution_ja"),
        ]:
            val = str(_pair_summary.get(field, "")).strip()
            if val:
                st.markdown(f"**{label}**")
                st.write(val)
        if str(_pair_summary.get("pair_llm_worked", "")).strip():
            st.markdown("**LLM 実行成否**")
            st.write(str(_pair_summary.get("pair_llm_worked", "")).strip())
        if str(_pair_summary.get("pair_llm_failure_reason", "")).strip():
            st.markdown("**LLM 失敗理由**")
            st.write(str(_pair_summary.get("pair_llm_failure_reason", "")).strip())

        _pair_id_base = str(_pair_row.get("pair_id", "")).strip() or f"pair_{_pair_idx}"
        _pair_ts = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
        _pair_json_payload = {
            "target_mondo_id": str(root_mid_for_name or "").strip(),
            "selected_item": _pair_id_base,
            "pair_detail": {str(k): str(v).strip() for k, v in _pair_row.to_dict().items()},
            "pair_summary": {str(k): str(v).strip() for k, v in _pair_summary.items()},
        }
        _pair_md_lines = [
            "# 比較ペアのLLM要約",
            "",
            f"- target_mondo_id: {str(root_mid_for_name or '').strip()}",
            f"- selected_item: {_pair_id_base}",
            f"- llm_model: {str(_pair_summary.get('pair_llm_model', llm_model)).strip()}",
            "",
        ]
        for label, field in [
            ("このペアを選ぶ理由", "why_this_pair_ja"),
            ("何を比較できるか", "what_can_be_compared_ja"),
            ("想定差分軸", "expected_difference_axis"),
            ("共通文脈", "shared_context"),
            ("相違文脈", "difference_context"),
            ("注意点", "pair_caution_ja"),
        ]:
            val = str(_pair_summary.get(field, "")).strip()
            if val:
                _pair_md_lines.extend([f"## {label}", "", val, ""])
        _pair_md = "\n".join(_pair_md_lines).strip() + "\n"

        st.markdown("📥 保存:")
        _pair_dl_cols = st.columns(2)
        with _pair_dl_cols[0]:
            st.download_button(
                "Markdown保存（比較ペアのLLM要約）",
                data=_pair_md.encode("utf-8"),
                file_name=f"{_pair_ts}_{root_mid_for_name}_{_pair_id_base}_{key_prefix}.md",
                mime="text/markdown",
                key=f"{key_prefix}_pair_dl_md_{_pair_ts}_{_pair_id_base}",
                use_container_width=True,
            )
        with _pair_dl_cols[1]:
            st.download_button(
                "JSON保存（比較ペアのLLM要約）",
                data=json.dumps(_pair_json_payload, ensure_ascii=False, indent=2).encode("utf-8"),
                file_name=f"{_pair_ts}_{root_mid_for_name}_{_pair_id_base}_{key_prefix}.json",
                mime="application/json",
                key=f"{key_prefix}_pair_dl_json_{_pair_ts}_{_pair_id_base}",
                use_container_width=True,
            )
    else:
        st.info("まだ比較ペアの LLM 要約は実行されていません。")

    _pair_detail_fields = [
        ("ペアID", "pair_id"),
        ("比較テーマ", "comparison_theme"),
        ("系統A ID", "strain_id_a"),
        ("系統A 名", "strain_name_a"),
        ("系統A 優先区分", "priority_a"),
        ("系統B ID", "strain_id_b"),
        ("系統B 名", "strain_name_b"),
        ("系統B 優先区分", "priority_b"),
        ("比較できる点", "what_can_be_compared_ja"),
        ("系統A の選定理由", "selection_reason_a"),
        ("系統B の選定理由", "selection_reason_b"),
        ("source 根拠レベル", "source_provenance_level"),
        ("選択ペア", "selected_pair"),
    ]
    with st.expander("比較ペアの詳細（補助情報）", expanded=False):
        for field_label, field_name in _pair_detail_fields:
            if field_name in _pair_row.index:
                val = str(_pair_row[field_name]).strip()
                if val:
                    st.markdown(f"**{field_label}**")
                    st.write(val)



_existing_mode_rendered = _render_existing_artifacts_section(
    base_dir=base_dir,
    details_csv_input=existing_details_csv_input,
    summary_csv_input=existing_summary_csv_input,
    step3_log_input=existing_step3_log_input,
    pair_csv_input=existing_pair_csv_input,
)

# Step 1
if not _existing_mode_rendered:
    st.subheader("Step1. 疾患名で検索")
    q = st.text_input("クエリ（例: ALS / 筋萎縮性側索硬化症）", value="ALS")

    c1, c2 = st.columns([1, 3])
    with c1:
        do_search = st.button("検索", use_container_width=True)

    if do_search:
        out_dir = Path(base_dir) / outputs_dir
        _safe_mkdir(out_dir)
        json_out = out_dir / f"results_{re.sub(r'[^A-Za-z0-9]+', '_', q)[:30]}_{_now_tag()}.json"

        # Run interactive search: provide query then blank line
        base_args = ["--output-json", str(json_out)]

        # Optional args: try a couple of common spellings, then fallback to no-optional-args
        optional_arg_sets = [
            ["--top-k", str(int(top_k)), "--lambda-hybrid", str(float(lambda_hybrid))],
            ["--top_k", str(int(top_k)), "--lambda_hybrid", str(float(lambda_hybrid))],
            [],
        ]

        rc, out, err = 1, "", ""
        used_optional = None
        for opt in optional_arg_sets:
            rc, out, err = _run_interactive_python(
                search_script,
                base_args + opt,
                stdin_text=f"{q}\n\n",
                cwd=base_dir,
            )
            if rc == 0:
                used_optional = opt
                break
            # If unknown-arg, try next pattern.
            msg = (out + "\n" + err).lower()
            if "unrecognized arguments" in msg or "unknown option" in msg or "error:" in msg:
                continue
            break

        # Persist Step1 logs for display (always available; UI applies filtering)
        st.session_state.step1_out = out or ""
        st.session_state.step1_err = err or ""
        st.session_state.step1_rc = rc
        st.session_state.step1_used_optional = used_optional

        if used_optional is None:
            st.info("Step1 検索は、検索スクリプトが追加オプションに未対応の可能性があるため、基本設定のまま実行しました。")
        elif used_optional == []:
            st.info("Step1 検索は、検索スクリプトの対応状況に合わせて基本設定のまま実行しました。")

        if debug_show_stdout:
            st.code(_filter_noise_from_stdout(out))
            if err.strip():
                st.code(_filter_noise_from_stdout(err))

        if rc != 0:
            st.error(f"検索スクリプトが失敗しました (rc={rc})。stderr を確認してください。")
        else:
            # Some versions print actual json path; prefer that.
            printed = _extract_path_from_stdout(r"✅\s*JSON出力が完了しました:\s*(.+)", out)
            final_json = Path(printed) if printed else json_out
            if not final_json.is_absolute():
                final_json = Path(base_dir) / final_json

            if not final_json.exists():
                st.error(f"検索結果JSONが見つかりません: {final_json}")
            else:
                try:
                    results = _load_search_results_json(final_json)
                except Exception as e:
                    st.error(f"JSONの読み込みに失敗しました: {e}")
                    results = None

                if results:
                    st.session_state.search_json_path = str(final_json)
                    st.session_state.search_results = results
                    st.success(f"検索結果を読み込みました: {final_json}")


    # Step 1b: show results / selection
    if st.session_state.search_results:
        results = st.session_state.search_results
        show_n = int(show_n)
        n_cands = min(show_n, len(results))
        cands = results[:n_cands]
        st.subheader(f"候補（上位{n_cands}件）")
        def _to_float(x):
            try:
                if x in ('', None):
                    return ''
                return float(x)
            except Exception:
                return ''

        def _score_pick(r: dict, keys: list[str]):
            """Pick a numeric score from either top-level keys or nested r['score'] dict."""
            # 1) top-level keys
            for k in keys:
                if k in r and r[k] not in ('', None):
                    v = _to_float(r[k])
                    if v != '':
                        return v
            # 2) nested score dict
            sc = r.get('score')
            if isinstance(sc, dict):
                for k in keys:
                    k2 = k
                    if k2.startswith('score_'):
                        k2 = k2[len('score_'):]
                    k2 = k2.replace('_norm', '')
                    if k2 in sc and sc[k2] not in ('', None):
                        v = _to_float(sc[k2])
                        if v != '':
                            return v
            return ''

        rows = []
        for i, r in enumerate(cands, start=1):
            rows.append({
                'rank': i,
                'iri': r.get('iri', ''),
                'MONDO Label': r.get('MONDO Label', '') or r.get('label', ''),
                'hit_term': r.get('hit_term', ''),
                'prop': r.get('prop', ''),
                'score_hybrid': r.get('score_hybrid', None),
                'score_bm25_norm': r.get('score_bm25_norm', None),
                'score_faiss_norm': r.get('score_faiss_norm', None),
                'score_bm25_raw': r.get('score_bm25_raw', None),
                'score_faiss_raw': r.get('score_faiss_raw', None),
                'iri_obo_format': _iri_to_obo_format(r.get('iri', '')),
            })

        df_r = pd.DataFrame(rows)

        # 空欄列は表示しない（score_* が全て空なら列ごと削除）
        _drop_cols = []
        for _c in ('score_hybrid','score_bm25_norm','score_faiss_norm','score_bm25_raw','score_faiss_raw'):
            if _c in df_r.columns:
                _s = df_r[_c].replace('', pd.NA)
                if _s.isna().all():
                    _drop_cols.append(_c)
        if _drop_cols:
            df_r = df_r.drop(columns=_drop_cols)

        # 期待するカラム順（存在するものだけ）
        _want_cols = ['rank','iri','MONDO Label','hit_term','prop','score_hybrid','score_bm25_norm','score_faiss_norm','score_bm25_raw','score_faiss_raw','iri_obo_format']
        _cols = [c for c in _want_cols if c in df_r.columns]
        df_r = df_r[_cols]

        # sidebar の「候補の表示件数 (show_n)」に合わせて表示を制限
        df_r = df_r.head(int(show_n))
        st.dataframe(df_r, use_container_width=True, hide_index=True)

        # --- Step1 logs (this is important information; always show) ---
        with st.expander("ログ（Step1: 疾患名検索）", expanded=False):
            rc = st.session_state.step1_rc
            used = st.session_state.step1_used_optional
            st.markdown(f"- return code: **{rc}**  ")
            if used is not None:
                st.markdown(f"- CLI options: `{used}`")
            out_f = _filter_log_text(st.session_state.step1_out)
            err_f = _filter_log_text(st.session_state.step1_err)
            if out_f.strip():
                st.code(out_f, language="text")
            if err_f.strip():
                st.markdown("**stderr**")
                st.code(err_f, language="text")
            # raw download
            raw = (st.session_state.step1_out or "") + ("\n\n---\n\n" if (st.session_state.step1_out and st.session_state.step1_err) else "") + (st.session_state.step1_err or "")
            st.download_button(
                "Step1 ログをダウンロード (.log)",
                data=raw.encode("utf-8", errors="replace"),
                file_name=f"step1_log_{_now_tag()}.log",
                mime="text/plain",
                key="step1_log_dl",
            )

        sel_rank = st.radio(
            "解析対象を選択",
            options=list(range(1, n_cands + 1)),
            horizontal=True,
        )
        st.session_state.selected_result = results[sel_rank - 1]

        if st.button("この候補で Step3 解析を実行", type="primary"):
            out_dir = Path(base_dir) / outputs_dir
            _safe_mkdir(out_dir)

            rank_csv = out_dir / f"results_rank1_{_now_tag()}.csv"
            _make_rank_csv_from_result(st.session_state.selected_result, rank_csv)
            st.session_state.rank_csv_path = str(rank_csv)

            st.caption(f"現在の Step3 LLM モデル: 記号補完={st.session_state.get('step3_symbol_model', 'gpt-6-luna')} / 遺伝子機能解説={st.session_state.get('step3_gene_explanation_model', 'gpt-6-luna')}")
            st.caption("注: Step3 モデル設定を使う場合は、モデル引数に対応した Step3 スクリプトを指定してください。未対応スクリプトはエラーで停止します。")
            with st.spinner("Step3 を実行中…（OpenAI API 呼び出し等で時間がかかる場合があります）"):
                try:
                    api_key = _get_openai_api_key_for_llm_or_stop()
                    step3_out = run_step3(
                        step3_script,
                        rank_csv,
                        cwd=base_dir,
                        llm_model_symbol_completion=str(st.session_state.get("step3_symbol_model", "gpt-6-luna")),
                        llm_model_gene_explanation=str(st.session_state.get("step3_gene_explanation_model", "gpt-6-luna")),
                        log_dir=_app_log_dir(base_dir) if os.getenv("APP_LOG_DIR") else None,
                        env_extra={"OPENAI_API_KEY": api_key},
                    )
                    st.session_state.step3_outputs = step3_out
                    # Persist target MONDO id for downstream (SUBSET) even if Step2 was skipped later.
                    if getattr(step3_out, 'target_mondo_id', None):
                        st.session_state.target_mondo_id = step3_out.target_mondo_id
                    st.success("Step3 が完了しました")
                except Exception as e:
                    st.error(f"Step3 でエラーが発生しました: {e}")
                    st.exception(e)
                except Exception as e:
                    st.session_state.step3_outputs = None
                    st.error(str(e))

# Step 3 outputs
if st.session_state.step3_outputs:
    step3_out: Step3Outputs = st.session_state.step3_outputs

    # logs (重要情報なので常に表示)
    with st.expander("ログ（Step3: 解析）", expanded=True):
        stdout_f = _filter_log_text(step3_out.stdout)
        stderr_f = _filter_log_text(step3_out.stderr)

        if stdout_f.strip():
            st.markdown("**stdout**")
            st.code(stdout_f, language="text")
        else:
            st.info("（stdout は空です）")

        if stderr_f.strip():
            st.markdown("**stderr**")
            st.code(stderr_f, language="text")

        # raw download
        raw = (step3_out.stdout or "") + ("\n\n---\n\n" if (step3_out.stdout and step3_out.stderr) else "") + (step3_out.stderr or "")
        st.download_button(
            "Step3 ログをダウンロード (.log)",
            data=raw.encode("utf-8", errors="replace"),
            file_name=f"step3_log_{_now_tag()}.log",
            mime="text/plain",
            key="step3_log_dl",
        )

        if step3_out.log_path and step3_out.log_path.exists():
            st.markdown(f"**生成ログファイル**: `{step3_out.log_path}`")
            st.download_button(
                "生成ログファイルをダウンロード",
                data=step3_out.log_path.read_bytes(),
                file_name=(step3_out.log_path.stem + ".log" if step3_out.log_path.suffix.lower() == ("." + "txt") else step3_out.log_path.name),
                mime="text/plain",
                key="step3_runlog_dl",
            )

    with st.expander("実行SPARQL（Step3候補抽出）", expanded=False):
        st.caption("Step3で実際に使用したSPARQLクエリを保存します。候補抽出ロジックやLLMプロンプトは変更していません。")
        sparql_items = [
            ("SPARQL_MOUSE（BRCマウス候補抽出）", getattr(step3_out, "sparql_mouse_rq", None), "application/sparql-query"),
            ("SPARQL_SEED（疾患関連ヒト遺伝子取得）", getattr(step3_out, "sparql_seed_rq", None), "application/sparql-query"),
            ("SPARQL manifest JSON", getattr(step3_out, "sparql_queries_json", None), "application/json"),
        ]
        for label, p, mime in sparql_items:
            if p is not None and not p.is_absolute():
                p = Path(base_dir) / p
            if p is not None and p.exists():
                st.markdown(f"**{label}**: `{p}`")
                if str(p).lower().endswith(".json"):
                    try:
                        st.json(json.loads(p.read_text(encoding="utf-8")))
                    except Exception:
                        st.code(p.read_text(encoding="utf-8", errors="replace"), language="json")
                else:
                    st.code(p.read_text(encoding="utf-8", errors="replace"), language="sparql")
                st.download_button(
                    f"{label} をダウンロード",
                    data=p.read_bytes(),
                    file_name=p.name,
                    mime=mime,
                    key=f"step3_sparql_dl_{p.name}",
                    use_container_width=True,
                )
            else:
                st.info(f"{label}: 出力ファイルは検出されていません。SPARQL出力対応版Step3を使用すると表示されます。")

    # Resolve paths
    summary_csv = step3_out.summary_csv
    details_csv = step3_out.details_csv

    if not summary_csv.is_absolute():
        summary_csv = Path(base_dir) / summary_csv
    if not details_csv.is_absolute():
        details_csv = Path(base_dir) / details_csv

    if not summary_csv.exists() or not details_csv.exists():
        st.error(f"Step3 出力CSVが見つかりません。summary={summary_csv} details={details_csv}")
    else:
        df_sum_A, df_det_A, df_det_B, id2label = build_views(summary_csv, details_csv)

        st.markdown("#### 第1段階LLM選定準備")
        st.caption("現在の Step3 出力 details_table / summary_stats / Step3 ログから、strain_overview と strain_pair_suggestions を作成します。")
        if st.button("第1段階LLM選定準備を実行", key="step3_run_llm_selection_prep"):
            log_path_for_prep = step3_out.log_path
            if log_path_for_prep is not None and not log_path_for_prep.is_absolute():
                log_path_for_prep = Path(base_dir) / log_path_for_prep
            if log_path_for_prep is None or not log_path_for_prep.exists():
                st.error("第1段階LLM選定準備には Step3 ログが必要です。Step3 ログファイルを確認してください。")
            else:
                prep_script = Path(base_dir) / "run_llm_strain_selection_prep_v1_fix4_reason.py"
                if not prep_script.exists():
                    st.error(f"選定準備スクリプトが見つかりません: {prep_script}")
                else:
                    api_key = _get_openai_api_key_for_llm_or_stop()
                    output_root = _llm_outputs_dir(base_dir)
                    cmd = [
                        sys.executable,
                        str(prep_script),
                        "--details-csv", str(details_csv),
                        "--summary-csv", str(summary_csv),
                        "--step3-log", str(log_path_for_prep),
                        "--output-root", str(output_root),
                        "--llm-model", str(st.session_state.get("llm_single_model", "gpt-6-luna")),
                        "--recommend-count", "5",
                        "--max-pair-suggestions", "10",
                    ]
                    with st.spinner("第1段階LLM選定準備を実行中..."):
                        proc = subprocess.run(
                            cmd,
                            cwd=str(base_dir),
                            text=True,
                            capture_output=True,
                            env=_subprocess_env({"OPENAI_API_KEY": api_key}),
                        )
                    proc_stdout = _redact_secret_text(proc.stdout or "", [api_key])
                    proc_stderr = _redact_secret_text(proc.stderr or "", [api_key])
                    if proc.returncode != 0:
                        st.error(f"第1段階LLM選定準備に失敗しました（rc={proc.returncode}）。")
                        if proc_stderr:
                            st.code(proc_stderr)
                        if proc_stdout:
                            st.code(proc_stdout)
                    else:
                        overview_out = _extract_path_from_stdout(r"STRAIN_OVERVIEW_CSV_PATH:\s*(.+)", proc_stdout)
                        pair_out = _extract_path_from_stdout(r"STRAIN_PAIR_SUGGESTIONS_CSV_PATH:\s*(.+)", proc_stdout)
                        runlog_out = _extract_path_from_stdout(r"RUN_LOG_PATH:\s*(.+)", proc_stdout)
                        st.success("第1段階LLM選定準備が完了しました。")
                        if overview_out:
                            st.markdown(f"- **strain_overview**: `{overview_out}`")
                        if pair_out:
                            st.markdown(f"- **strain_pair_suggestions**: `{pair_out}`")
                        if runlog_out:
                            st.markdown(f"- **run_log**: `{runlog_out}`")

        all_seed_mondo_ids, all_seed_mondo_label_map, all_seed_mondo_source_map = _extract_seed_mondo_entries_from_step3_stdout(step3_out.stdout)
        root_mid_for_name = str(st.session_state.get("target_mondo_id") or "").strip()
        if not root_mid_for_name and st.session_state.selected_result:
            _iri_tmp = str(st.session_state.selected_result.get("iri") or "").strip()
            _m = re.search(r"MONDO[_:][0-9]+", _iri_tmp, flags=re.I)
            if _m:
                root_mid_for_name = _m.group(0).replace(":", "_")
        if not root_mid_for_name:
            root_mid_for_name = "MONDO_ID_MISSING"
        if st.session_state.selected_result:
            iri_tmp = st.session_state.selected_result.get("iri", "")
            mtmp = re.search(r"MONDO[_:]\\d+", iri_tmp)
            if mtmp:
                root_mid_for_name = mtmp.group(0).replace(":", "_")

        # New unified flow: auto-load latest pair suggestions from llm_outputs/selection when available.
        df_llm_pairs = pd.DataFrame()
        llm_pair_path = None
        try:
            _llm_base = _llm_outputs_dir(base_dir) / "selection"
            llm_pair_path = _find_latest_optional_csv(str(_llm_base), f"strain_pair_suggestions*{root_mid_for_name}*.csv")
            if llm_pair_path is not None and llm_pair_path.exists():
                df_llm_pairs = _safe_read_optional_csv(llm_pair_path)
            else:
                st.info("比較提案 CSV は未検出です。必要なら run_llm_strain_reresummary_v5_minimal_outputs.py を実行してください。")
        except Exception as e:
            st.warning(f"比較提案 CSV の自動読み込みに失敗しました: {e}")
            df_llm_pairs = pd.DataFrame()
            llm_pair_path = None


        # -----------------------------
        # 1. 疾患サブタイプ別・網羅統計
        # -----------------------------
        st.subheader("1. 疾患別候補数")
        st.caption("まず推定候補を確認し、その後に既知モデルを含む参考表示と比較できるようにします。")

        # A (authoritative): summary_stats CSV
        st.markdown("#### 疾患別候補数")
        st.caption("疾患関連遺伝子に基づく推定候補に加え、既知の疾患モデルも表示しています。入力疾患そのものに加え、関連する下位疾患ごとの候補も含まれます。")
        st.caption("下の「候補内訳（推定候補のみ）」は、この表のうち推定候補のみを表示したものです。")
        with st.expander("📋 疾患別候補数［表のみ］を表示", expanded=False):
            render_configurable_dataframe(
                df_sum_A,
                label="疾患別候補数［表のみ］",
                key_prefix="df_sum_A",
                default_columns=list(df_sum_A.columns),
                selector_expanded=False,
            )
            export_ts = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
            export_name_A = f"{export_ts}_{root_mid_for_name}_ROOT_summary_stats.csv"
            st.download_button(
                "ダウンロード（疾患別候補数［表のみ］）",
                data=df_sum_A.to_csv(index=False).encode("utf-8"),
                file_name=f"{export_ts}_{root_mid_for_name}_disease_candidate_count.csv",
                mime="text/csv",
                key=f"dl_root_summary_stats_{export_ts}",
            )

        with st.expander("📋 疾患別の系統内訳（推定候補＋既知疾患モデル）［表のみ］を表示", expanded=False):
            df_a_detail = build_rbrc_detail_table(df_det_A)
            if df_a_detail.empty:
                st.info("表示できる系統内訳（推定候補＋既知疾患モデル）詳細がありません。")
            else:
                st.caption("疾患別の系統内訳（推定候補＋既知疾患モデル）まとめに対応するマウス一覧です。RBRC番号、系統名、遺伝子、変異型、ソース、対応疾患を確認できます。")
                render_configurable_dataframe(
                    df_a_detail,
                    label="疾患別の系統内訳（推定候補＋既知疾患モデル）［表のみ］",
                    key_prefix="df_a_detail",
                    default_columns=[c for c in ["RBRC", "Strain", "riken_related_gene_id", "riken_related_gene_symbol", "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol", "extdb_related_human_gene_id", "extdb_related_human_gene_symbol", "Mutation_Type", "Sources", "Mapped_Disease", "MONDO_ID"] if c in df_a_detail.columns],
                    selector_expanded=False,
                )
                _ts_a = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                root_mid_for_name = st.session_state.get('target_mondo_id', '')
                if not root_mid_for_name:
                    _sel = st.session_state.get('selected_result', {}) or {}
                    _iri = str(_sel.get('iri', '')).strip()
                    _m = re.search(r'(MONDO[_:]\d+)', _iri)
                    if _m:
                        root_mid_for_name = _m.group(1).replace(':', '_')
                st.download_button(
                    "CSVダウンロード（疾患別の系統内訳（推定候補＋既知疾患モデル）［表のみ］）",
                    df_a_detail.to_csv(index=False).encode("utf-8"),
                    file_name=f"{_ts_a}_{root_mid_for_name if root_mid_for_name else 'MONDO_UNKNOWN'}_ROOT_rbrc_detail.csv",
                    mime="text/csv",
                    key=f"dl_root_rbrc_detail_{_ts_a}",
                )


    # --- ROOT（広義・網羅）: root + 配下 (Genes不問) ---------------------------------
    st.markdown("---")
    st.markdown("#### 候補系統一覧")
    root_mid = st.session_state.get('target_mondo_id', '')  # e.g. MONDO_0004976
    if not root_mid:
        st.info("候補系統一覧は Step2 で MONDO を確定してから実行してください。")
    else:
        st.warning("おすすめ: Step3 実行後は、先に候補系統一覧を表示すると、推定候補と既知の疾患モデルをまとめて確認できます。")
        col_a1, col_a2 = st.columns([1.2, 3])
        with col_a1:
            run_aroot = st.button("⭐ おすすめ: 候補系統一覧を表示", key="run_aroot_btn", use_container_width=True)
        with col_a2:
            st.caption("入力疾患とその下位疾患をまとめた候補系統の一覧です。推定候補に加え、既知の疾患モデルも表示します。")
        st.caption("下の「候補一覧（推定候補のみ）」は、この候補一覧のうち推定候補のみを表示したものです。")
        if run_aroot:
            st.session_state["_aroot_run"] = True

        if st.session_state.get("_aroot_run", False):
            try:
                mondo_edges = _load_mondo_subclass_edges()
                root_set = set([root_mid]) | _get_descendants(root_mid, mondo_edges)
                df_det_A2 = df_det_A.copy()
                if "MONDO_ID" in df_det_A2.columns:
                    df_det_A2["_MONDO_ID_NORM"] = df_det_A2["MONDO_ID"].astype(str).map(_normalize_mondo_id)
                elif "Mapped_Disease" in df_det_A2.columns:
                    df_det_A2["_MONDO_ID_NORM"] = df_det_A2["Mapped_Disease"].astype(str).map(_normalize_mondo_id)
                else:
                    df_det_A2["_MONDO_ID_NORM"] = ""

                df_in = df_det_A2[df_det_A2["_MONDO_ID_NORM"].isin(root_set)].copy()

                # union（重複除去後の総数）
                if "RBRC" in df_in.columns:
                    rbrc_col = "RBRC"
                elif "RBRC_ID" in df_in.columns:
                    rbrc_col = "RBRC_ID"
                else:
                    rbrc_col = None

                if rbrc_col is None:
                    st.warning("details_table に RBRC 列が見つからないため、候補系統一覧を計算できません。")
                else:
                    rbrc_all = set(df_in[rbrc_col].dropna().astype(str).tolist())
                    union_count = len(rbrc_all)

                    root_label_union = ""
                    try:
                        root_label_union = str(id2label.get(root_mid, "") or "").strip()
                    except Exception:
                        root_label_union = ""
                    root_disp_union = f"{root_mid}: {root_label_union}".rstrip(": ")
                    df_root_union = pd.DataFrame([{
                        "Mapped_Disease": root_disp_union + "  [ROOT union: 下位概念を包含 / Genes不問]",
                        "系統数": union_count
                    }])

                    # A-ROOT 内訳（B-1相当を root配下でフィルタ：各MONDOごとのユニークRBRC）
                    df_aroot_dist = (
                        df_in.groupby("_MONDO_ID_NORM")[rbrc_col]
                        .nunique()
                        .reset_index()
                        .rename(columns={"_MONDO_ID_NORM": "MONDO_ID", rbrc_col: "系統数"})
                        .sort_values("系統数", ascending=False)
                    )

                    st.markdown("##### 検索した疾患の系統総数（推定候補＋既知疾患モデル）")
                    ts_aroot = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                    st.download_button(
                        "CSVダウンロード（検索した疾患の系統総数（推定候補＋既知疾患モデル）［表のみ］）",
                        df_root_union.to_csv(index=False).encode("utf-8"),
                        file_name=f"{ts_aroot}_{root_mid}_searched_disease_system_total_all.csv",
                        mime="text/csv",
                        key=f"root_total_{ts_aroot}",
                    )
                    render_configurable_dataframe(
                        df_root_union,
                        label="検索した疾患の系統総数（推定候補＋既知疾患モデル）［表のみ］",
                        key_prefix="df_root_union",
                        default_columns=[c for c in ["Mapped_Disease", "系統数"] if c in df_root_union.columns],
                        selector_expanded=False,
                    )

                    with st.expander("📋 系統内訳（推定候補のみ）詳細B［表のみ］を表示", expanded=False):
                        df_aroot_detail = build_rbrc_detail_table(df_in)
                        if df_aroot_detail.empty:
                            st.info("表示できる RBRC 詳細がありません。")
                        else:
                            st.caption("検索した疾患の系統総数（推定候補のみ）Bに対応するマウス一覧です。RBRC番号、系統名、遺伝子、変異型、ソース、対応疾患を確認できます。")
                            render_configurable_dataframe(
                                df_aroot_detail,
                                label="系統内訳（推定候補のみ）詳細B［表のみ］",
                                key_prefix="df_aroot_detail",
                                default_columns=[c for c in ["RBRC", "Strain", "extdb_related_human_gene_id", "extdb_related_human_gene_symbol", "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol", "riken_related_gene_id", "riken_related_gene_symbol", "Mutation_Type", "Sources", "Mapped_Disease", "MONDO_ID"] if c in df_aroot_detail.columns],
                            )
                            st.download_button(
                                "CSVダウンロード（系統内訳（推定候補のみ）詳細B［表のみ］）",
                                df_aroot_detail.to_csv(index=False).encode("utf-8"),
                                file_name=f"{ts_aroot}_{root_mid}_system_breakdown_predicted_detail_B.csv",
                                mime="text/csv",
                                key=f"dl_root_rbrc_detail_{root_mid}_{ts_aroot}",
                            )


                    # タグ付け（RBRC単位で「なぜroot集合に入ったか」）
                    # - in_root: root直下に出現
                    # - in_desc: 配下（root以外）に出現
                    # - gene_known_any: Genes が ID:UNKNOWN 以外の行を1つでも含む
                    def _is_gene_known(x):
                        if x is None:
                            return False
                        s = str(x).strip()
                        if not s or s.lower() == "nan":
                            return False
                        return True
                    _gk_h = df_in["extdb_related_human_gene_id"].map(_is_gene_known) if "extdb_related_human_gene_id" in df_in.columns else False
                    _gk_em = df_in["extdb_related_mouse_gene_id"].map(_is_gene_known) if "extdb_related_mouse_gene_id" in df_in.columns else False
                    _gk_rm = df_in["riken_related_gene_id"].map(_is_gene_known) if "riken_related_gene_id" in df_in.columns else False
                    masks = [m for m in (_gk_h, _gk_em, _gk_rm) if not isinstance(m, bool)]
                    if not masks:
                        df_in["_GENE_KNOWN"] = False
                    else:
                        m = masks[0]
                        for mm in masks[1:]:
                            m = m | mm
                        df_in["_GENE_KNOWN"] = m

                    df_in["_IN_ROOT"] = (df_in["_MONDO_ID_NORM"] == root_mid)
                    df_in["_IN_DESC"] = (df_in["_MONDO_ID_NORM"].isin(root_set) & (df_in["_MONDO_ID_NORM"] != root_mid))

                    if rbrc_col in df_in.columns:
                        _rbrc_norm = df_in[rbrc_col].astype(str).str.strip()
                        df_in = df_in[~_rbrc_norm.str.startswith("RBRC-AES", na=False)].copy()

                    def _join_unique_values(series, drop_values=None, limit=50, normalize_gene_id=False, split_commas=False):
                        drop_values = set(drop_values or [])
                        vals = []
                        for v in series.dropna().tolist():
                            items = str(v).split(",") if split_commas else [v]
                            for item in items:
                                s = str(item).strip()
                                if not s or s.lower() == "nan" or s in drop_values:
                                    continue
                                if normalize_gene_id and s.endswith(".0") and s[:-2].isdigit():
                                    s = s[:-2]
                                vals.append(s)
                        uniq = []
                        seen = set()
                        for s in vals:
                            if s not in seen:
                                seen.add(s)
                                uniq.append(s)
                        return ", ".join(uniq[:limit])

                    agg_spec = {
                        "in_root": ("_IN_ROOT", "max"),
                        "in_desc": ("_IN_DESC", "max"),
                        "gene_known_any": ("_GENE_KNOWN", "max"),
                        "diseases": ("_MONDO_ID_NORM", lambda s: ",".join(sorted(set(map(str, s.dropna().tolist())))[:50])),
                        "Sources": ("Sources", lambda s: _join_unique_values(s, split_commas=True)),
                    }

                    if "extdb_related_human_gene_id" in df_in.columns:
                        agg_spec["extdb_related_human_gene_id"] = ("extdb_related_human_gene_id", lambda s: _join_unique_values(s, drop_values={"UNKNOWN"}, split_commas=True))
                    else:
                        agg_spec["extdb_related_human_gene_id"] = ("Genes", lambda s: "")

                    if "extdb_related_human_gene_symbol" in df_in.columns:
                        agg_spec["extdb_related_human_gene_symbol"] = ("extdb_related_human_gene_symbol", lambda s: _join_unique_values(s, drop_values={"ID:UNKNOWN"}, split_commas=True))
                    elif "related_gene_symbol" in df_in.columns:
                        agg_spec["extdb_related_human_gene_symbol"] = ("related_gene_symbol", lambda s: _join_unique_values(s, drop_values={"ID:UNKNOWN"}, split_commas=True))
                    else:
                        agg_spec["extdb_related_human_gene_symbol"] = ("_MONDO_ID_NORM", lambda s: "")

                    if "extdb_related_mouse_gene_id" in df_in.columns:
                        agg_spec["extdb_related_mouse_gene_id"] = ("extdb_related_mouse_gene_id", lambda s: _join_unique_values(s, drop_values={"UNKNOWN"}, split_commas=True))
                    else:
                        agg_spec["extdb_related_mouse_gene_id"] = ("_MONDO_ID_NORM", lambda s: "")

                    if "extdb_related_mouse_gene_symbol" in df_in.columns:
                        agg_spec["extdb_related_mouse_gene_symbol"] = ("extdb_related_mouse_gene_symbol", lambda s: _join_unique_values(s, drop_values={"ID:UNKNOWN"}, split_commas=True))
                    else:
                        agg_spec["extdb_related_mouse_gene_symbol"] = ("_MONDO_ID_NORM", lambda s: "")

                    if "riken_related_gene_id" in df_in.columns:
                        agg_spec["riken_related_gene_id"] = ("riken_related_gene_id", lambda s: _join_unique_values(s, drop_values={"UNKNOWN"}, split_commas=True))
                    elif "riken_related_mouse_gene_id" in df_in.columns:
                        agg_spec["riken_related_gene_id"] = ("riken_related_mouse_gene_id", lambda s: _join_unique_values(s, drop_values={"UNKNOWN"}, split_commas=True))
                    else:
                        agg_spec["riken_related_gene_id"] = ("_MONDO_ID_NORM", lambda s: "")

                    if "riken_related_gene_symbol" in df_in.columns:
                        agg_spec["riken_related_gene_symbol"] = ("riken_related_gene_symbol", lambda s: _join_unique_values(s, drop_values={"ID:UNKNOWN"}, split_commas=True))
                    elif "riken_related_mouse_gene_symbol" in df_in.columns:
                        agg_spec["riken_related_gene_symbol"] = ("riken_related_mouse_gene_symbol", lambda s: _join_unique_values(s, drop_values={"ID:UNKNOWN"}, split_commas=True))
                    elif "Genes" in df_in.columns:
                        agg_spec["riken_related_gene_symbol"] = ("Genes", lambda s: _join_unique_values(s, drop_values={"ID:UNKNOWN"}, split_commas=True))
                    else:
                        agg_spec["riken_related_gene_symbol"] = ("_MONDO_ID_NORM", lambda s: "")

                    df_tags = (
                        df_in.groupby(rbrc_col)
                        .agg(**agg_spec)
                        .reset_index()
                        .rename(columns={rbrc_col: "RBRC"})
                    )

                    # 表示用：チェックボックスになるよう bool に正規化（念のため）
                    for _c in ["in_root", "in_desc", "gene_known_any"]:
                        if _c in df_tags.columns:
                            df_tags[_c] = df_tags[_c].astype(bool)


                    def _tag_row(r):
                        tags = []
                        tags.append("ROOT" if r["in_root"] else "no-ROOT")
                        tags.append("DESC" if r["in_desc"] else "no-DESC")
                        tags.append("GeneKnown" if r["gene_known_any"] else "GeneUnknown")
                        return "+".join(tags)

                    df_tags["tag_combo"] = df_tags.apply(_tag_row, axis=1)
                    _tag_order = ["RBRC", "in_root", "in_desc", "gene_known_any", "diseases", "Sources", "riken_related_gene_id", "riken_related_gene_symbol", "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol", "extdb_related_human_gene_id", "extdb_related_human_gene_symbol", "tag_combo"]
                    df_tags = df_tags[[c for c in _tag_order if c in df_tags.columns]]

                    df_tag_counts = (
                        df_tags["tag_combo"].value_counts()
                        .reset_index()
                        .rename(columns={"index": "由来パターン", "tag_combo": "系統数"})
                    )

                    st.markdown("##### 由来パターン別の系統数")
                    with st.expander("📋 由来パターン別の系統数［表のみ］を表示", expanded=False):
                        render_configurable_dataframe(
                            df_tag_counts,
                            label="由来パターン別の系統数［表のみ］",
                            key_prefix="df_tag_counts",
                            default_columns=list(df_tag_counts.columns),
                            selector_expanded=False,
                        )
                        st.download_button(
                            "CSVダウンロード（由来パターン別の系統数［表のみ］）",
                            df_tag_counts.to_csv(index=False).encode("utf-8"),
                            file_name=f"{ts_aroot}_{root_mid}_origin_pattern_system_count.csv",
                            mime="text/csv",
                            key=f"root_tag_counts_{ts_aroot}",
                        )
                    try:
                        df_tag_plot = df_tag_counts.copy()
                        if not df_tag_plot.empty and set(["由来パターン", "系統数"]).issubset(df_tag_plot.columns):
                            import plotly.express as px
                            fig_tag_counts = px.bar(
                                df_tag_plot,
                                x="由来パターン",
                                y="系統数",
                                title="由来パターン別の系統数",
                                text="系統数",
                            )
                            fig_tag_counts.update_traces(textposition="outside")
                            fig_tag_counts.update_layout(
                                xaxis_title="由来パターン",
                                yaxis_title="系統数",
                                height=520,
                                margin=dict(l=20, r=20, t=60, b=140),
                            )
                            st.plotly_chart(fig_tag_counts, use_container_width=True)
                    except Exception as e:
                        st.warning(f"由来パターン別グラフの描画に失敗しました: {e}")

                    with st.expander("📋 系統ごとの由来情報［表のみ］を表示", expanded=False):
                        st.caption("この表は RBRC 単位に再集約した由来・判定表です。疾患別候補数（候補一覧との対応）グラフの元データではありません。")
                        st.download_button(
                            "CSVダウンロード（系統ごとの由来情報［表のみ］）",
                            df_tags.to_csv(index=False).encode("utf-8"),
                            file_name=f"{ts_aroot}_{root_mid}_system_origin_info.csv",
                            mime="text/csv",
                            key=f"dl_root_rbrc_tag_detail_{root_mid}_{ts_aroot}",
                        )

                        # 画面表示はチェックボックス風（読み取り専用）
                        render_configurable_dataframe(
                            df_tags,
                            label="系統ごとの由来情報［表のみ］",
                            key_prefix="df_tags_detail",
                            default_columns=[c for c in ["RBRC", "in_root", "in_desc", "gene_known_any", "diseases", "Sources", "riken_related_gene_id", "riken_related_gene_symbol", "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol", "extdb_related_human_gene_id", "extdb_related_human_gene_symbol", "tag_combo"] if c in df_tags.columns],
                            selector_expanded=False,
                        )

                    # 棒グラフ：Step3 の details_table 全体を正として描画（図2と同じ疾患集合 + ROOT union 1本）
                    st.markdown("##### 疾患別候補数（候補一覧との対応）")
                    st.caption("このグラフの元データは Step3 の details_table 由来です。『系統ごとの由来情報（ROOT_rbrc_tags_detail）』は別の再集約表であり、このグラフの元データではありません。")
                    try:
                        import plotly.graph_objects as go

                        df_graph1 = df_det_A.copy()
                        if "MONDO_ID" in df_graph1.columns:
                            df_graph1["_MONDO_ID_GRAPH1"] = df_graph1["MONDO_ID"].astype(str).map(_normalize_mondo_id)
                        elif "Mapped_Disease" in df_graph1.columns:
                            df_graph1["_MONDO_ID_GRAPH1"] = df_graph1["Mapped_Disease"].astype(str).map(_normalize_mondo_id)
                        else:
                            df_graph1["_MONDO_ID_GRAPH1"] = ""
                        df_graph1 = df_graph1[df_graph1["_MONDO_ID_GRAPH1"].astype(str).str.strip() != ""].copy()

                        # グラフ1の検証用：元データをそのままダウンロードできるようにする
                        graph1_source_export = df_graph1.copy()
                        if "RBRC" in graph1_source_export.columns:
                            _rbrc_graph1 = graph1_source_export["RBRC"].astype(str).str.strip()
                            graph1_source_export = graph1_source_export[~_rbrc_graph1.str.startswith("RBRC-AES", na=False)].copy()
                        _keep_graph1 = [c for c in ["RBRC", "Strain", "Mapped_Disease", "MONDO_ID", "_MONDO_ID_GRAPH1", "Sources", "Mutation_Type"] if c in graph1_source_export.columns]
                        if _keep_graph1:
                            graph1_source_export = graph1_source_export[_keep_graph1].copy()
                        graph1_source_export = graph1_source_export.rename(columns={"_MONDO_ID_GRAPH1": "GRAPH_MONDO_ID"})
                        st.download_button(
                            "CSVダウンロード（疾患別候補数（候補一覧との対応）の元データ・行単位）",
                            graph1_source_export.to_csv(index=False).encode("utf-8"),
                            file_name=f"{ts_aroot}_{root_mid}_graph1_source_rows.csv",
                            mime="text/csv",
                            key=f"dl_graph1_source_{root_mid}_{ts_aroot}",
                        )
                        with st.expander("📋 疾患別候補数（候補一覧との対応）の元データ・行単位を表示", expanded=False):
                            render_configurable_dataframe(
                                graph1_source_export,
                                label="疾患別候補数（候補一覧との対応）の元データ・行単位",
                                key_prefix=f"graph1_source_{root_mid}",
                                default_columns=list(graph1_source_export.columns),
                                selector_expanded=False,
                            )

                        _rbrc_map = (
                            df_graph1.groupby("_MONDO_ID_GRAPH1")[rbrc_col]
                            .agg(lambda s: sorted(set(map(str, s.dropna().tolist()))))
                            .to_dict()
                        )

                        def _hover_rbrc_text(vals):
                            vals = [str(v) for v in vals if str(v).strip()]
                            if not vals:
                                return "(なし)"
                            return ", ".join(vals)

                        def _uniq_sorted_strain(values):
                            vals = sorted({str(v).strip() for v in values if pd.notna(v) and str(v).strip() and str(v).strip().lower() != "nan"})
                            return vals

                        def _join_strains(vals):
                            vals = [str(v) for v in vals if str(v).strip()]
                            if not vals:
                                return ""
                            return ", ".join(vals)

                        _strain_map = {}
                        if "Strain" in df_graph1.columns:
                            _strain_map = (
                                df_graph1.groupby("_MONDO_ID_GRAPH1")["Strain"]
                                .agg(lambda s: _uniq_sorted_strain(s))
                                .to_dict()
                            )

                        df_plot = (
                            df_graph1.groupby("_MONDO_ID_GRAPH1")[rbrc_col]
                            .nunique()
                            .reset_index()
                            .rename(columns={"_MONDO_ID_GRAPH1": "MONDO_ID", rbrc_col: "系統数"})
                            .sort_values("系統数", ascending=False)
                        )
                        if _strain_map:
                            df_plot["該当系統"] = df_plot["MONDO_ID"].map(lambda mid: _join_strains(_strain_map.get(mid, [])))
                        x = df_plot["MONDO_ID"].tolist()
                        y = df_plot["系統数"].tolist()
                        hover_rbrc = [_hover_rbrc_text(_rbrc_map.get(mid, [])) for mid in x]
                        union_count_graph1 = int(df_graph1[rbrc_col].dropna().astype(str).nunique())
                        union_hover = _hover_rbrc_text(sorted(set(map(str, df_graph1[rbrc_col].dropna().tolist()))))
                        category_order = x + [f"{root_mid} [ROOT union]"]

                        # グラフそのものと一致する集計済みデータ（棒の本数と同じ）
                        df_plot_graph1 = df_plot.copy()
                        _union_row = {"MONDO_ID": f"{root_mid} [ROOT union]", "系統数": union_count_graph1}
                        if "Strain" in df_graph1.columns:
                            _union_row["該当系統"] = _join_strains(_uniq_sorted_strain(df_graph1["Strain"]))
                        df_plot_graph1 = pd.concat([
                            df_plot_graph1,
                            pd.DataFrame([_union_row])
                        ], ignore_index=True)
                        st.download_button(
                            "CSVダウンロード（疾患別候補数（候補一覧との対応）の表示データ）",
                            df_plot_graph1.to_csv(index=False).encode("utf-8"),
                            file_name=f"{ts_aroot}_{root_mid}_graph1_plot_data.csv",
                            mime="text/csv",
                            key=f"dl_graph1_plotdata_{root_mid}_{ts_aroot}",
                        )
                        with st.expander("📋 疾患別候補数（候補一覧との対応）の表示データを表示", expanded=False):
                            render_configurable_dataframe(
                                df_plot_graph1,
                                label="疾患別候補数（候補一覧との対応）の表示データ",
                                key_prefix=f"graph1_plotdata_{root_mid}",
                                default_columns=list(df_plot_graph1.columns),
                                selector_expanded=False,
                            )

                        fig = go.Figure()
                        fig.add_trace(go.Bar(
                            x=y,
                            y=x,
                            orientation="h",
                            name="root配下（内訳）",
                            customdata=hover_rbrc,
                            hovertemplate="%{y}<br>系統数=%{x}<br>%{customdata}<extra></extra>",
                        ))
                        fig.add_trace(go.Bar(
                            x=[union_count_graph1],
                            y=[f"{root_mid} [ROOT union]"],
                            orientation="h",
                            name="ROOT union（重複除去後）",
                            marker_color=ROOT_BAR_COLORS["ROOT union（重複除去後）"],
                            customdata=[union_hover],
                            hovertemplate="%{y}<br>系統数=%{x}<br>%{customdata}<extra></extra>",
                        ))
                        plot_height = max(900, 32 * max(len(category_order), 1) + 180)
                        fig.update_layout(
                            width=1400,
                            height=plot_height,
                            margin=dict(l=260, r=40, t=80, b=60),
                            xaxis_title="系統数（ユニークRBRC）",
                            yaxis_title="MONDO",
                            showlegend=True,
                        )
                        fig.update_yaxes(
                            categoryorder="array",
                            categoryarray=category_order,
                            tickmode="array",
                            tickvals=category_order,
                            ticktext=category_order,
                            automargin=True,
                        )
                        st.plotly_chart(fig, use_container_width=False)
                        # key_prefix is required to avoid Streamlit widget key collisions
                        _plotly_download_buttons(fig, "disease_distribution_ROOT", key_prefix="ROOT_dist")
                    except Exception as _e:
                        st.warning(f"候補一覧対応グラフの作成に失敗しました: {_e}")
            except Exception as e:
                st.warning(f"候補系統一覧の計算でエラー: {e}")

        # B: recompute from details_table excluding unknown genes
        st.markdown("#### サブセット：1 のうち推定候補のみ表示")

        # --- lazy execution (Aのみ先に描画して、Bはボタンで実行) ---
        if "run_B" not in st.session_state:
            st.session_state.run_B = False
        if "run_B_root" not in st.session_state:
            st.session_state.run_B_root = False

        cols_bbtn = st.columns([1, 1, 6])
        with cols_bbtn[0]:
            if st.button("疾患別の系統内訳（推定候補のみ）まとめを表示", key="btn_run_B1"):
                st.session_state.run_B = True
        with cols_bbtn[1]:
            if st.button("系統内訳（推定候補のみ）詳細を表示", key="btn_run_BROOT"):
                st.session_state.run_B = True
                st.session_state.run_B_root = True

        if not st.session_state.run_B:
            st.info("推定候補のみの表示は重い処理（特に下位疾患を含む集計）を含むため、必要なときに上のボタンを押して表示してください。")
            df_b = None
            df_b1 = df_b.copy() if df_b is not None else None
            root_row = None
            df_root = None
            mondo_desc = set()
            root_mid_tmp = ""
        else:
            # B-1: per-MONDO counts as-is (no roll-up)
            df_b = None
            df_root = None
            if {"MONDO_ID", "RBRC"}.issubset(df_det_B.columns):
                df_b = df_det_B.groupby("MONDO_ID")["RBRC"].nunique().reset_index(name="系統数")
                df_b["Mapped_Disease"] = df_b["MONDO_ID"].astype(str).map(
                    lambda mid: f"{mid}: {id2label.get(mid,'')}".rstrip(": ")
                )
                df_b = df_b[["Mapped_Disease", "系統数"]].sort_values("系統数", ascending=False)

            # Prefer stored target MONDO (from Step3 stdout) when available; fallback to Step2 selection.
            root_mid_tmp = str(st.session_state.get("target_mondo_id") or "").strip()
            if not root_mid_tmp and st.session_state.selected_result:
                iri_tmp = st.session_state.selected_result.get("iri", "")
                mtmp = re.search(r"MONDO[_:]\d+", iri_tmp)
                if mtmp:
                    root_mid_tmp = mtmp.group(0).replace(":", "_")

            root_row = None
            mondo_desc = set()
            if st.session_state.run_B_root and root_mid_tmp:
                mondo_edges = _load_mondo_subclass_edges()
                if mondo_edges:
                    mondo_desc = _get_descendants(root_mid_tmp, mondo_edges)
                    mondo_desc.add(root_mid_tmp)
                    df_root = df_det_B[df_det_B["MONDO_ID"].isin(mondo_desc)]
                    root_count = int(df_root["RBRC"].nunique())
                    root_label = id2label.get(root_mid_tmp, "")
                    root_row = {
                        "Mapped_Disease": f"{root_mid_tmp}: {root_label}".rstrip(": ")
                        + "  [ROOT union: 下位概念を包含]",
                        "系統数": root_count,
                    }
                else:
                    msg = st.session_state.get(
                        "mondo_ontology_error",
                        "mondo.owl / mondo.json が見つからないため、候補一覧（推定候補のみ）の階層集計を計算できません。カレントディレクトリに mondo.owl（推奨）を配置してください。",
                    )
                    st.info(msg)
                    if st.button("MONDO再読込（キャッシュクリア）", key="reload_mondo_cache"):
                        try:
                            st.cache_resource.clear()
                        except Exception:
                            pass
                        st.rerun()

        # Render
        if st.session_state.run_B:
            if df_b is None:
                st.warning("details_table の列が想定と異なるため、推定候補のみの表示を作成できません。")
            else:
                if root_row is not None:
                    df_broot = pd.DataFrame([root_row])
                    st.caption("上の「候補系統一覧」のうち、推定候補のみを表示しています。")
                    _df_broot_summary = pd.DataFrame([root_row])
                    with st.expander("📋 検索した疾患の系統総数（推定候補のみ）B［表のみ］を表示", expanded=False):
                        render_configurable_dataframe(
                            _df_broot_summary,
                            label="検索した疾患の系統総数（推定候補のみ）B［表のみ］",
                            key_prefix="df_broot_summary",
                            default_columns=list(_df_broot_summary.columns),
                            selector_expanded=False,
                        )

                    with st.expander("📋 検索した疾患の系統総数（推定候補のみ）［表のみ］を表示", expanded=False):
                        render_configurable_dataframe(
                            df_broot,
                            label="検索した疾患の系統総数（推定候補のみ）［表のみ］",
                            key_prefix="df_broot_table",
                            default_columns=[c for c in ["Mapped_Disease", "系統数"] if c in df_broot.columns],
                            selector_expanded=False,
                        )

                    with st.expander("📋 候補一覧（推定候補のみ）の RBRC 詳細［表のみ］を表示", expanded=False):
                        df_broot_detail = build_rbrc_detail_table(df_root)
                        if df_broot_detail.empty:
                            st.info("表示できる RBRC 詳細がありません。")
                        else:
                            st.caption("候補一覧（推定候補のみ）［表のみ］に対応するマウス一覧です。RBRC番号、系統名、遺伝子、変異型、ソース、対応疾患を確認できます。")
                            render_configurable_dataframe(
                                df_broot_detail,
                                label="候補一覧（推定候補のみ）の RBRC 詳細［表のみ］",
                                key_prefix="df_broot_detail",
                                default_columns=[c for c in ["RBRC", "Strain", "riken_related_gene_id", "riken_related_gene_symbol", "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol", "extdb_related_human_gene_id", "extdb_related_human_gene_symbol", "Mutation_Type", "Sources", "Mapped_Disease", "MONDO_ID"] if c in df_broot_detail.columns],
                            )
                            _ts_broot = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                            _root_name = (root_mid_tmp or "MONDO_UNKNOWN")
                            st.download_button(
                                "CSVダウンロード（検索した疾患の系統総数（推定候補のみ）B［表のみ］）",
                                df_broot_detail.to_csv(index=False).encode("utf-8"),
                                file_name=f"{_ts_broot}_{_root_name}_SUBSET_rbrc_detail.csv",
                                mime="text/csv",
                                key=f"dl_broot_rbrc_detail_{_root_name}_{_ts_broot}",
                            )

                st.caption("上の「疾患別候補数」のうち、推定候補のみを表示しています。")
                with st.expander("📋 疾患別の系統内訳（推定候補のみ）［表のみ］を表示", expanded=False):
                    render_configurable_dataframe(
                        df_b,
                        label="疾患別の系統内訳（推定候補のみ）［表のみ］",
                        key_prefix="df_b",
                        default_columns=list(df_b.columns),
                        selector_expanded=False,
                    )

                with st.expander("📋 系統内訳（推定候補のみ）詳細［表のみ］を表示", expanded=False):
                    df_b_detail = build_rbrc_detail_table(df_det_B)
                    if df_b_detail.empty:
                        st.info("表示できる RBRC 詳細がありません。")
                    else:
                        st.caption("疾患別の系統内訳（推定候補のみ）まとめに対応するマウス一覧です。RBRC番号、系統名、遺伝子、変異型、ソース、対応疾患を確認できます。")
                        render_configurable_dataframe(
                            df_b_detail,
                            label="系統内訳（推定候補のみ）詳細［表のみ］",
                            key_prefix="df_b_detail",
                            default_columns=[c for c in ["RBRC", "Strain", "riken_related_gene_id", "riken_related_gene_symbol", "extdb_related_mouse_gene_id", "extdb_related_mouse_gene_symbol", "extdb_related_human_gene_id", "extdb_related_human_gene_symbol", "Mutation_Type", "Sources", "Mapped_Disease", "MONDO_ID"] if c in df_b_detail.columns],
                            selector_expanded=False,
                        )
                        _ts_b1 = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                        st.download_button(
                            "CSVダウンロード（系統内訳（推定候補のみ）詳細［表のみ］）",
                            df_b_detail.to_csv(index=False).encode("utf-8"),
                            file_name=f"{_ts_b1}_{root_mid_for_name}_B1_rbrc_detail.csv",
                            mime="text/csv",
                            key=f"dl_b1_rbrc_detail_{root_mid_for_name}_{_ts_b1}",
                        )

        st.markdown("---")
        st.caption("上の2つは、入力疾患とその下位疾患をまとめた候補一覧です。下の2つは、その候補がどの疾患単位で見つかったかを見るための内訳です。")

        plot_guard_metrics = _evaluate_plot_limits(df_det_A, root_mid_for_name)
        if plot_guard_metrics.get("warn") and not plot_guard_metrics.get("hard_stop"):
            st.info(
                f"件数が多めです（MONDO={plot_guard_metrics['mondo_count']}, 最大RBRC/MONDO={plot_guard_metrics['max_rbrc_per_mondo']}, ROOT union={plot_guard_metrics['root_union_count']}）。"
                "図は表示しますが、より下位の疾患語での再検索を推奨します。"
            )

        # Export (A/B) - avoid filename collision
        root_mid_for_name = str(st.session_state.get("target_mondo_id") or "").strip()
        if not root_mid_for_name and st.session_state.selected_result:
            iri_tmp = st.session_state.selected_result.get("iri", "")
            mtmp = re.search(r"MONDO[_:]\d+", iri_tmp)
            if mtmp:
                root_mid_for_name = mtmp.group(0).replace(":", "_")
        if not root_mid_for_name and 'root_mid' in locals():
            root_mid_for_name = str(root_mid or "").strip()
        if not root_mid_for_name:
            root_mid_for_name = "MONDO_ID_MISSING"

        # B は実行されたものだけを個別にエクスポート（衝突防止のためファイル名を分離）
        if "df_broot" in locals() and hasattr(df_broot, "to_csv") and len(df_broot) > 0:
            export_name_Broot = f"{export_ts}_{root_mid_for_name}_SUBSET_union.csv"
            st.download_button(
                "検索した疾患の系統総数（推定候補のみ）［表のみ］",
                data=df_broot.to_csv(index=False).encode("utf-8"),
                file_name=export_name_Broot,
                mime="text/csv",
            )
        if "df_b1" in locals() and hasattr(df_b1, "to_csv") and len(df_b1) > 0:
            export_name_B1 = f"{export_ts}_{root_mid_for_name}_SUBSET_1_per_mondo.csv"
            st.download_button(
                "疾患別の系統内訳（推定候補のみ）［表のみ］",
                data=df_b1.to_csv(index=False).encode("utf-8"),
                file_name=export_name_B1,
                mime="text/csv",
            )

        # -----------------------------
        # 2. 階層構造サンバースト図
        # -----------------------------
        if plot_guard_metrics.get("hard_stop"):
            _render_plot_limit_message(plot_guard_metrics)
        else:
            st.subheader("2. 階層構造サンバースト図")
            st.caption("外側へ向かって 疾患 → 遺伝子 → 変異型 → 系統 を表示します。遺伝子は extdb human → extdb mouse → riken mouse の順で採用し、空欄時は「遺伝子未設定」として扱います。")
            # Root disease ID
            root_mid = ""
            if st.session_state.selected_result:
                iri = st.session_state.selected_result.get("iri", "")
                m = re.search(r"MONDO[_:]\d+", iri)
                if m:
                    root_mid = m.group(0).replace(":", "_")
    
            if not root_mid and len(id2label) > 0:
                root_mid = list(id2label.keys())[0]
    
            fig_sb = None
            if root_mid:
                fig_sb = plot_sunburst_gene_hierarchy(df_det_B, id2label, root_mid)
    
            if fig_sb is None:
                st.warning("サンバースト図の生成に必要な列が不足しているため、作図できませんでした。")
            else:
                df_sb_source = build_sunburst_source_table(df_det_B)
                if not df_sb_source.empty:
                    _ts_sb = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                    st.download_button(
                        "CSVダウンロード（階層構造サンバースト図の元データ）",
                        df_sb_source.to_csv(index=False).encode("utf-8"),
                        file_name=f"{_ts_sb}_SUNBURST_source_{root_mid_for_name}.csv",
                        mime="text/csv",
                        key=f"dl_sunburst_source_{_ts_sb}",
                    )
                    with st.expander("📋 階層構造サンバースト図の元データを表示", expanded=False):
                        render_configurable_dataframe(
                            df_sb_source,
                            label="階層構造サンバースト図の元データ",
                            key_prefix="sunburst_source",
                            default_columns=list(df_sb_source.columns),
                            selector_expanded=False,
                        )
                st.plotly_chart(fig_sb, use_container_width=True)
                st.markdown("📥 保存:")
                _plotly_download_buttons(fig_sb, "hierarchy_sunburst", key_prefix="hierarchy")
            # -----------------------------
            # 3. エビデンスソース別（全体）ユニーク系統数
            # -----------------------------
            st.subheader("3. エビデンスソース別（全体）ユニーク系統数")
            st.caption("RBRC単位で Sources を統合した全体分布です。棒にマウスカーソルを合わせると、対応する RBRC 番号を確認できます。")
            global_source_df = _prepare_sources_aggregated_df(df_det_A, include_mondo=False)
            fig_src = plot_source_summary(df_det_A, title="エビデンスソース別ユニーク系統数")
            if fig_src is None:
                st.warning("details_table に Sources/RBRC 列がないため、作図できませんでした。")
            else:
                df_src_plot = build_source_summary_table(df_det_A)
                _ts_src = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                st.download_button(
                    "CSVダウンロード（エビデンスソース別（全体）ユニーク系統数の表示データ）",
                    df_src_plot.to_csv(index=False).encode("utf-8"),
                    file_name=f"{_ts_src}_EVIDENCE_plotdata_{root_mid_for_name}.csv",
                    mime="text/csv",
                    key=f"dl_evidence_plotdata_{_ts_src}",
                )
                with st.expander("📋 エビデンスソース別（全体）ユニーク系統数の表示データを表示", expanded=False):
                    render_configurable_dataframe(
                        df_src_plot,
                        label="エビデンスソース別（全体）ユニーク系統数の表示データ",
                        key_prefix="evidence_plotdata",
                        default_columns=list(df_src_plot.columns),
                        selector_expanded=False,
                    )
                st.plotly_chart(fig_src, use_container_width=True)
                st.markdown("📥 保存:")
                _plotly_download_buttons(fig_src, "evidence_sources", key_prefix="evidence")
            # -----------------------------
            # 4. 疾患別系統数分布
            # -----------------------------
            st.subheader("4. 疾患ごとの候補分布")
            st.caption("Graph3 と同じく、MONDO_ID + RBRC 単位で Sources を統合した疾患別内訳です。棒にマウスカーソルを合わせると、対応する RBRC 番号を確認できます。")
            st.markdown("#### 疾患別の系統内訳（推定候補＋既知疾患モデル）")
            fig_dist_A = plot_disease_distribution(df_det_A, id2label, title="疾患別の系統内訳（推定候補＋既知疾患モデル）", all_mondo_ids=all_seed_mondo_ids, all_mondo_label_map=all_seed_mondo_label_map, global_source_df=global_source_df)
            if fig_dist_A is not None:
                df_dist_A_plot = build_disease_distribution_table(df_det_A, id2label, all_mondo_ids=all_seed_mondo_ids, all_mondo_label_map=all_seed_mondo_label_map, global_source_df=global_source_df)
                _ts_distA = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                st.download_button(
                    "CSVダウンロード（疾患別の系統内訳（推定候補＋既知疾患モデル）の表示データ）",
                    df_dist_A_plot.to_csv(index=False).encode("utf-8"),
                    file_name=f"{_ts_distA}_DISTA_plotdata_{root_mid_for_name}.csv",
                    mime="text/csv",
                    key=f"dl_distA_plotdata_{_ts_distA}",
                )
                with st.expander("📋 疾患別の系統内訳（推定候補＋既知疾患モデル）の表示データを表示", expanded=False):
                    render_configurable_dataframe(
                        df_dist_A_plot,
                        label="疾患別の系統内訳（推定候補＋既知疾患モデル）の表示データ",
                        key_prefix="distA_plotdata",
                        default_columns=list(df_dist_A_plot.columns),
                        selector_expanded=False,
                    )
                st.plotly_chart(fig_dist_A, use_container_width=True)
                st.markdown("📥 保存:")
                _plotly_download_buttons(fig_dist_A, "disease_distribution_A", key_prefix="distA")
            else:
                st.warning("details_table に必要な列がないため、A) を作図できませんでした。")
    
            st.markdown("#### 疾患別の系統内訳（推定候補のみ）")
            if st.session_state.get("run_B", False):
                fig_dist_B = plot_disease_distribution(df_det_B, id2label, title="疾患別の系統内訳（推定候補のみ）", all_mondo_ids=all_seed_mondo_ids, all_mondo_label_map=all_seed_mondo_label_map, global_source_df=global_source_df)
                if fig_dist_B is not None:
                    df_dist_B_plot = build_disease_distribution_table(df_det_B, id2label, all_mondo_ids=all_seed_mondo_ids, all_mondo_label_map=all_seed_mondo_label_map, global_source_df=global_source_df)
                    _ts_distB = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                    st.download_button(
                        "CSVダウンロード（疾患別の系統内訳（推定候補のみ）の表示データ）",
                        df_dist_B_plot.to_csv(index=False).encode("utf-8"),
                        file_name=f"{_ts_distB}_DISTB_plotdata_{root_mid_for_name}.csv",
                        mime="text/csv",
                        key=f"dl_distB_plotdata_{_ts_distB}",
                    )
                    with st.expander("📋 疾患別の系統内訳（推定候補のみ）の表示データを表示", expanded=False):
                        render_configurable_dataframe(
                            df_dist_B_plot,
                            label="疾患別の系統内訳（推定候補のみ）の表示データ",
                            key_prefix="distB_plotdata",
                            default_columns=list(df_dist_B_plot.columns),
                            selector_expanded=False,
                        )
                    st.plotly_chart(fig_dist_B, use_container_width=True)
                    st.markdown("📥 保存:")
                    _plotly_download_buttons(fig_dist_B, "disease_distribution_B", key_prefix="distB")
                else:
                    st.warning("details_table に必要な列がないため、B-1 を作図できませんでした。")
    
                # Optional: SUBSET single-bar chart (root+desc union)
                if st.session_state.get("run_B_root", False) and ("df_b_root" in locals()):
                    try:
                        _c = int(root_row["系統数"]) if isinstance(root_row, dict) and "系統数" in root_row else int(df_root["RBRC"].nunique())
                        _mid = str(root_mid_for_name)
                        _lab = str(id2label.get(_mid, ""))
                        fig_root = plot_root_union_bar(_mid, _lab, _c, title="候補一覧（推定候補のみ）: 入力疾患と下位疾患を含むユニークRBRC")
                        if "df_root" in locals() and isinstance(df_root, pd.DataFrame):
                            df_root_plot = build_root_union_source_table(df_root, _mid, id2label)
                            _ts_root = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                            st.download_button(
                                "CSVダウンロード（候補一覧（推定候補のみ）の表示データ）",
                                df_root_plot.to_csv(index=False).encode("utf-8"),
                                file_name=f"{_ts_root}_BROOT_plotdata_{_mid}.csv",
                                mime="text/csv",
                                key=f"dl_broot_plotdata_{_ts_root}",
                            )
                            with st.expander("📋 候補一覧（推定候補のみ）の表示データを表示", expanded=False):
                                render_configurable_dataframe(
                                    df_root_plot,
                                    label="候補一覧（推定候補のみ）の表示データ",
                                    key_prefix="broot_plotdata",
                                    default_columns=list(df_root_plot.columns),
                                    selector_expanded=False,
                                )
                        st.plotly_chart(fig_root, use_container_width=True)
                        st.markdown("📥 保存:")
                        _plotly_download_buttons(fig_root, "SUBSET_union", key_prefix="broot")
                    except Exception:
                        pass
            else:
                st.info("推定候補のみの表示は重い処理になり得るため、上のボタンを押したときだけ計算・作図します。")


        _late_llm_payload = None
        if st.session_state.get("_existing_llm_render_payload"):
            _late_llm_payload = st.session_state.get("_existing_llm_render_payload")
        elif "df_det_A" in locals() and isinstance(df_det_A, pd.DataFrame) and not df_det_A.empty:
            _late_llm_payload = {
                "df_det_A": df_det_A,
                "step3_log_text": str(getattr(step3_out, "stdout", "") or ""),
                "root_mid_for_name": root_mid_for_name,
                "df_llm_pairs": df_llm_pairs if "df_llm_pairs" in locals() else pd.DataFrame(),
            }

        if _late_llm_payload is not None:
            _render_unified_llm_on_demand_section(
                df_det_A=_late_llm_payload["df_det_A"],
                step3_log_text=_late_llm_payload["step3_log_text"],
                root_mid_for_name=_late_llm_payload["root_mid_for_name"],
                df_llm_pairs=_late_llm_payload["df_llm_pairs"],
                llm_single_model=str(st.session_state.get("llm_single_model", "gpt-6-luna")),
                llm_pair_model=str(st.session_state.get("llm_pair_model", "gpt-6-luna")),
            )

        # -----------------------------
        # 5. LLM補助要約（候補系統の選択支援）
        # -----------------------------
        if False and ((df_llm_summary is not None and not df_llm_summary.empty) or (df_llm_pairs is not None and not df_llm_pairs.empty)):
            st.subheader("5. LLM補助要約（候補系統の選択支援）")
            st.caption("Step3 の details_table / summary_stats を基礎に、外部根拠を補助的に加えて整理した別成果物です。CSV がある場合のみ表示します。")

            if llm_summary_path is not None and llm_summary_path.exists():
                st.caption(f"系統要約CSV: {llm_summary_path.name}")
            if llm_pair_path is not None and llm_pair_path.exists():
                st.caption(f"比較提案CSV: {llm_pair_path.name}")

            if df_llm_summary is not None and not df_llm_summary.empty:
                st.markdown("#### 系統要約一覧")
                df_llm_summary_display = build_llm_summary_display_df(df_llm_summary)
                render_configurable_dataframe(
                    df_llm_summary_display,
                    label="LLM補助要約（一覧）",
                    key_prefix="llm_summary_display",
                    default_columns=list(df_llm_summary_display.columns),
                    selector_expanded=False,
                )
                _ts_llm = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
                st.download_button(
                    "CSVダウンロード（LLM補助要約一覧）",
                    df_llm_summary.to_csv(index=False).encode("utf-8"),
                    file_name=f"{_ts_llm}_{root_mid_for_name}_strain_summary.csv",
                    mime="text/csv",
                    key=f"dl_llm_summary_{_ts_llm}",
                )

                _choice_values = []
                if 'strain_id' in df_llm_summary.columns:
                    _choice_values = df_llm_summary['strain_id'].astype(str).tolist()
                elif 'strain_name' in df_llm_summary.columns:
                    _choice_values = df_llm_summary['strain_name'].astype(str).tolist()

                if _choice_values:
                    selected_llm_item = st.selectbox(
                        "詳細表示する系統を選択",
                        options=_choice_values,
                        key="llm_summary_selected_item",
                    )
                    if 'strain_id' in df_llm_summary.columns:
                        _sel_df = df_llm_summary[df_llm_summary['strain_id'].astype(str) == str(selected_llm_item)].head(1)
                    else:
                        _sel_df = df_llm_summary[df_llm_summary['strain_name'].astype(str) == str(selected_llm_item)].head(1)

                    if not _sel_df.empty:
                        _row = _sel_df.iloc[0]
                        st.markdown("#### 選択系統の詳細")
                        title_parts = []
                        if 'strain_id' in _row.index and str(_row['strain_id']).strip():
                            title_parts.append(str(_row['strain_id']).strip())
                        if 'strain_name' in _row.index and str(_row['strain_name']).strip():
                            title_parts.append(str(_row['strain_name']).strip())
                        if title_parts:
                            st.markdown(f"**{' / '.join(title_parts)}**")

                        for field_label, field_name in [
                            ("特徴の要約", "feature_summary_ja"),
                            ("疾患研究での活用可能性", "research_usefulness_ja"),
                            ("注意点", "caution_ja"),
                            ("要点", "key_points_ja"),
                            ("内部根拠", "evidence_internal"),
                            ("外部根拠（要約）", "evidence_external_summary"),
                            ("出典メモ", "citation_note_ja"),
                            ("外部リンク", "evidence_external_links"),
                        ]:
                            if field_name in _row.index and str(_row[field_name]).strip():
                                st.markdown(f"**{field_label}**")
                                st.write(str(_row[field_name]).strip())

            if df_llm_pairs is not None and not df_llm_pairs.empty:
                _render_pair_detail_block(
                    df_llm_pairs,
                    df_llm_summary,
                    root_mid_for_name=root_mid_for_name,
                    key_prefix="llm_pairs_display",
                )


st.markdown("---")
st.caption("このアプリは、疾患名の入力から検索、解析、可視化までを一体的に行う画面です。")
