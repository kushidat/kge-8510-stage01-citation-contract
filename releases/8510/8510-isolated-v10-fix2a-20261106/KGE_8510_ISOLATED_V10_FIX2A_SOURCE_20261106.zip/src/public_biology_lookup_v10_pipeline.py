"""V10 optional public evidence addenda on top of pinned V09 source-role gate."""
from __future__ import annotations
from public_biology_lookup_v09 import lookup_public_biology as lookup_stocks
from public_mgi_report_chain_v09 import append_mgi_public_reports
from public_mgi_marker_phenotype_v10 import append_marker_phenotype
from public_mondo_label_v10 import append_mondo_labels

def lookup_public_biology(pairs,fetch=None,allele_report_chunks=None,
                          genotype_report_chunks=None,allele_fetch=None,
                          genotype_fetch=None,stock_hint='',marker_page_fetch=None,mondo_fetch=None):
    context=lookup_stocks(pairs,fetch=fetch,stock_hint=stock_hint)
    context=append_mgi_public_reports(context,
         allele_report_chunks=allele_report_chunks,
         genotype_report_chunks=genotype_report_chunks,
         allele_fetch=allele_fetch,genotype_fetch=genotype_fetch)
    context=append_marker_phenotype(context,fetch=marker_page_fetch)
    context=append_mondo_labels(context,fetch=mondo_fetch)
    return context
