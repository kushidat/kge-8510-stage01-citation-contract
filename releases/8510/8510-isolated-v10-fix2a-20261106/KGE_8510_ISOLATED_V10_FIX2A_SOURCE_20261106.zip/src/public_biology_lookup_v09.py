"""On-demand, identifier-based PUBLIC annotation lookup for generic LLM biology.

No per-disease, per-gene, per-allele or per-stock embedded reference content.
Calls ONLY from the explicit LLM run action. All lookups are optional and fallible.
We never treat an unsuccessful network request as a negative scientific result.
"""
from __future__ import annotations
import html
from html.parser import HTMLParser
import json
import re
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from public_stock_identity_v09 import discover_stock_candidates, official_brc_no_from_card, MAX_CANDIDATES

MAX_RESPONSE_BYTES=1_500_000
JST=timezone(timedelta(hours=9))


def _ranked_ids(pairs,stock_hint=""):
    """Only structured role-scoped source edges can authorize candidate annotations.

    Unstructured uploads are still accepted and forwarded unchanged to the model,
    but their Gene/MP/GO mentions do not become candidate-specific search targets.
    """
    from source_role_v09 import extract_role_scoped_ids
    return extract_role_scoped_ids(pairs, stock_hint=stock_hint)


def _read_url(url,timeout=4):
    req=urllib.request.Request(url,headers={'User-Agent':'8510ResearchPrototype/0.4 (ontology lookup; no private data)','Accept':'application/json,text/html;q=0.5'})
    with urllib.request.urlopen(req,timeout=timeout) as reply:
        if urllib.parse.urlparse(reply.geturl()).hostname not in ('eutils.ncbi.nlm.nih.gov','www.ebi.ac.uk','knowledge.brc.riken.jp'):
            raise ValueError('Unexpected redirect origin')
        data=reply.read(MAX_RESPONSE_BYTES+1)
        if len(data)>MAX_RESPONSE_BYTES:raise ValueError('Public response exceeds limit')
        return data


class _PlainHTML(HTMLParser):
    def __init__(self):
        super().__init__();self.bits=[];self.skip=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style','noscript'):self.skip+=1
    def handle_endtag(self,tag):
        if tag in ('script','style','noscript') and self.skip:self.skip-=1
    def handle_data(self,data):
        if not self.skip and data.strip():self.bits.append(html.unescape(data.strip()))
    def text(self):return ' '.join(self.bits)


def lookup_public_biology(pairs:list[tuple[str,bytes]],fetch=None,stock_hint=""):
    """Return actual fetched public annotations only; never generate term labels locally.

    fetch argument is for offline test/mock; actual runs use HTTPS GET.
    """
    fetch=fetch or _read_url
    ids=_ranked_ids(pairs,stock_hint=stock_hint)
    context={'lookup_policy':'IDENTIFIER_ONLY_AFTER_USER_CLICK_NO_STATIC_PAIR_REGISTRY',
             'retrieved_at_jst':datetime.now(JST).isoformat(timespec='seconds'),
             'candidate_identifiers':ids,
             'source_role_boundary':'Only Mouse-anchored candidate_intrinsic genes/MP and explicitly candidate-mouse GO may be candidate facts. Disease gene and HP-MP mapping IDs remain disease context and are not candidate evidence.',
             'verified':[], 'unavailable':[],
             'interpretation_boundary':'Source facts are distinct from general biological hypotheses. Missing annotations are not negative findings. No ranking causal inference.'}
    if ids.get('structured_mouse_iri_count',0)>1:
        context['unavailable'].append({'request':'ROLE_SCOPED_PUBLIC_LOOKUP',
            'reason':'MULTI_MOUSE_BUNDLE_GENE_MP_GO_LOOKUP_HOLD',
            'note':'Single candidate-specific annotation list would risk attaching evidence to the wrong mouse.'})
    if ids.get('stock_candidates_unprocessed',0):
        context['unavailable'].append({'request':'BRC_CANDIDATE_LIMIT',
           'reason':'NOT_ALL_CANDIDATES_CHECKED',
           'unprocessed':ids['stock_candidates_unprocessed']})
    def record_error(src,ex):
        context['unavailable'].append({'request':src,'error_type':type(ex).__name__})
    if ids['genes']:
        url='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?'+urllib.parse.urlencode({'db':'gene','id':','.join(ids['genes']),'retmode':'json'})
        try:
            response=json.loads(fetch(url).decode('utf-8'))
            entries=(response.get('result') or {})
            for gene in ids['genes']:
                item=entries.get(gene)
                if not isinstance(item,dict):continue
                context['verified'].append({'id':'NCBIGene:'+gene,'type':'gene',
                    'symbol':str(item.get('name') or '')[:90],
                    'description':str(item.get('description') or '')[:240],
                    'functional_summary':str(item.get('summary') or '')[:1400],
                    'organism':str((item.get('organism') or {}).get('scientificname') or '')[:100],
                    'source_url':'https://www.ncbi.nlm.nih.gov/gene/'+gene,
                    'fetch_url':url,'verification':'HTTP_JSON_RESPONSE_MATCHED_ID',
                    'evidence_role':'CANDIDATE_MOUSE_GENE_SOURCE_EDGE_ONLY',
                    'evidence_origin':'evidence_bundle.source_edges.candidate_intrinsic',
                    'origin_source_edges':ids.get('source_edge_origins',{}).get('genes',{}).get(gene,[])})
        except (OSError,ValueError,TypeError,KeyError,UnicodeError,TimeoutError) as ex: record_error('NCBI_GENE',ex)
    if ids['go']:
        url='https://www.ebi.ac.uk/QuickGO/services/ontology/go/terms/'+','.join(ids['go'])
        try:
            response=json.loads(fetch(url).decode('utf-8'))
            allowed=set(ids['go'])
            for item in response.get('results',[]):
                if not isinstance(item,dict) or item.get('id') not in allowed:continue
                desc=item.get('definition')
                if isinstance(desc,dict):desc=desc.get('text')
                context['verified'].append({'id':item['id'],'type':'GO',
                    'name':str(item.get('name') or '')[:240],
                    'aspect':str(item.get('aspect') or '')[:100],
                    'definition':str(desc or '')[:900],
                    'source_url':'https://www.ebi.ac.uk/QuickGO/term/'+item['id'],
                    'fetch_url':url,'verification':'HTTP_JSON_RESPONSE_MATCHED_ID',
                    'evidence_role':'CANDIDATE_MOUSE_GO_CONTEXT_ONLY',
                    'evidence_origin':'evidence_bundle.go_context.candidate_mouse_go_or_shared',
                    'origin_source_edges':ids.get('source_edge_origins',{}).get('go',{}).get(item['id'],[])})
        except (OSError,ValueError,TypeError,KeyError,UnicodeError,TimeoutError) as ex:record_error('QUICKGO',ex)
    for mp in ids['mp']:
        url='https://www.ebi.ac.uk/ols4/api/search?'+urllib.parse.urlencode({'q':mp,'ontology':'mp','rows':10})
        try:
            response=json.loads(fetch(url).decode('utf-8'))
            for item in ((response.get('response') or {}).get('docs') or []):
                if item.get('obo_id')!=mp:continue
                d=item.get('description')
                context['verified'].append({'id':mp,'type':'MP',
                    'name':str(item.get('label') or '')[:250],
                    'definition':' '.join(d)[:900] if isinstance(d,list) else str(d or '')[:900],
                    'source_url':'https://www.ebi.ac.uk/ols4/ontologies/mp/classes?iri='+urllib.parse.quote(str(item.get('iri') or 'http://purl.obolibrary.org/obo/'+mp.replace(':','_')),safe=''),
                    'fetch_url':url,'verification':'HTTP_JSON_RESPONSE_MATCHED_ID',
                    'evidence_role':'CANDIDATE_MOUSE_MP_SOURCE_EDGE_ONLY',
                    'evidence_origin':'evidence_bundle.source_edges.candidate_intrinsic',
                    'mp_term_is_not_stock_measurement':True,
                    'origin_source_edges':ids.get('source_edge_origins',{}).get('mp',{}).get(mp,[])})
                break
        except (OSError,ValueError,TypeError,KeyError,UnicodeError,TimeoutError) as ex:record_error(mp,ex)
    # Optional public-stock lookup. Fetch is at user click, not on upload.
    for stock in ids['stocks']:
        url='https://knowledge.brc.riken.jp/resource/animal/card?'+urllib.parse.urlencode({'__lang__':'ja','brc_no':stock})
        try:
            raw=fetch(url)
            reader=_PlainHTML();reader.feed(raw.decode('utf-8',errors='replace'))
            plain=' '.join(reader.text().split())
            # Official card FIELD adjudication. Echoed text alone is not identity.
            official=official_brc_no_from_card(plain)
            if official == stock:
                pos=plain.find('BRC No.')
                context['verified'].append({'id':official,'official_brc_no':official,
                    'requested_id':stock,'type':'public_stock_card',
                    'page_excerpt':plain[max(0,pos-180):pos+5200],
                    'source_url':url,'fetch_url':url,
                    'verification':'OFFICIAL_BRC_NO_EXACT_MATCH_CARD_HTML; PHENOTYPE_ASSERTIONS_NOT_AUTOMATICALLY_CHECKED'})
            else:
                context['unavailable'].append({'request':stock,
                    'error_type':'BRC_OFFICIAL_RECORD_NOT_EXACTLY_CONFIRMED',
                    'official_brc_no':official or None})
        except (OSError,ValueError,TypeError,UnicodeError,TimeoutError) as ex:record_error(stock,ex)
    return context
