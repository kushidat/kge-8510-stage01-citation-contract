#!/usr/bin/env python3
"""No-network, no-LLM retroaudit of source citations, does not write outputs."""
import argparse,hashlib,json,pathlib
from citation_integrity_v10 import audit_citations
p=argparse.ArgumentParser()
p.add_argument('input_json');p.add_argument('previous_llm_output_json');p.add_argument('--input-sha256',required=True)
a=p.parse_args()
src=pathlib.Path(a.input_json).read_bytes()
actual=hashlib.sha256(src).hexdigest()
if actual!=a.input_sha256:raise SystemExit('STOP_INPUT_SHA_MISMATCH')
obj=json.loads(pathlib.Path(a.previous_llm_output_json).read_bytes())
refs=obj.get('input_files') or []
q=audit_citations(obj.get('interpretation_text',''),refs,obj.get('public_annotations') or {},[(pathlib.Path(a.input_json).name,src)])
print('INPUT_SHA256='+actual)
print('CITATION_INTEGRITY='+json.dumps(q,ensure_ascii=False,sort_keys=True))
print('EXTERNAL_HTTP_CALLS=0')
print('LLM_API_CALLS=0')
print('OUTPUT_WRITES=0')
print('ORIGINAL_TRAIN_BYTE_CHECK=NOT_ASSESSED')
print('SCIENTIFIC_VALIDATION=NOT_ASSESSED')
if not q['source_binding_ok']:raise SystemExit(1)
