"""Source-verified MONDO term label, never hardcoded to a disease/pair.
Safe public ontology lookup, only after explicitly initiating external lookup.
"""
from __future__ import annotations
import json,urllib.parse
from public_biology_lookup_v09 import _read_url
BASE='https://www.ebi.ac.uk/ols4/api/search?'
def append_mondo_labels(context,*,fetch=None):
    fetch=fetch or _read_url
    values=context.get('candidate_identifiers',{}).get('diseases',[])
    context['disease_label_policy']='PUBLIC_OLS4_ONTOLOGY_ID_EXACT_MATCH_ONLY'
    for disease in values[:4]:
        if not isinstance(disease,str) or not disease.startswith('MONDO:') or not disease[6:].isdigit():continue
        url=BASE+urllib.parse.urlencode({'q':disease,'ontology':'mondo','rows':10})
        try:
            result=json.loads(fetch(url).decode('utf-8'))
            docs=((result.get('response') or {}).get('docs') or [])
            items=[x for x in docs if isinstance(x,dict) and x.get('obo_id')==disease
                 and x.get('label') and (x.get('ontology_name','mondo')=='mondo')]
            if len(items)!=1:
                context.setdefault('unavailable',[]).append({'request':'MONDO_OFFICIAL_LABEL','reason':'NON_UNIQUE_OR_MISSING_EXACT_ID','id':disease});continue
            it=items[0]
            iri=it.get('iri') or ('http://purl.obolibrary.org/obo/'+disease.replace(':','_'))
            source_url='https://www.ebi.ac.uk/ols4/ontologies/mondo/classes?'+urllib.parse.urlencode({'iri':iri})
            context.setdefault('verified',[]).append({'type':'MONDO_disease_label','id':disease,
                'name':str(it['label'])[:200],'ontology':'MONDO','source_url':source_url,
                'fetch_url':url,'verification':'PUBLIC_OLS4_EXACT_OBO_ID_AND_ONTOLOGY_MATCH',
                'not_candidate_mouse_phenotype':True})
        except (OSError,RuntimeError,ValueError,TypeError,KeyError,UnicodeError,TimeoutError) as ex:
            context.setdefault('unavailable',[]).append({'request':'MONDO_OFFICIAL_LABEL','reason':'FETCH_OR_PARSE_UNVERIFIED','error_type':type(ex).__name__,'id':disease})
    return context
