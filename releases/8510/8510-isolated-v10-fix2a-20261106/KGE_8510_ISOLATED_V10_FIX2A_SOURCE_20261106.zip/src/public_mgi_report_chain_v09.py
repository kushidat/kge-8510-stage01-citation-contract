"""Generic MGI allele/genotype report chain. Called only after explicit LLM click.

This module composes source-identical FIX1.match_report and FIX2.parse_report/
detail_validation; it does not reuse FIX1's historically failed genotype-link
HTML path or hardcode a gene, allele, strain, phenotype or result.
All data come from allowed public records. Unverified records are never promoted
to verified annotations. No private input bytes are transmitted to MGI.
"""
from __future__ import annotations
import urllib.parse
import MGI_REPORT_FIX1_NO_LLM_20261106 as fix1
import MGI_GENOTYPE_REPORT_FIX2_NO_LLM_20261106 as fix2
from public_allele_evidence_v05 import _stock_alleles, _normal_symbol, _fetch_mgi, _parse_html, _excerpt

MAX_PAIRS=4
MAX_GENOTYPE_DETAILS_PER_ALLELE=2
PUBLIC_ALLELE='https://www.informatics.jax.org/allele/'
PUBLIC_GENOTYPE='https://www.informatics.jax.org/allele/genoview/'

def _unavailable(context,stage,reason,**extras):
    context['unavailable'].append({'request':stage,'reason':reason,**extras})

def append_mgi_public_reports(context,*,allele_report_chunks=None,
                              genotype_report_chunks=None,allele_fetch=None,
                              genotype_fetch=None):
    """Update existing V04 verified/unavailable lists; nonfatal independent stages.

    Injecting in-memory report chunks and fetch functions is test-only; the
    production path uses HTTPS with host/cap/redirect guards from FIX1/FIX2.
    """
    verified=context.setdefault('verified',[])
    context.setdefault('unavailable',[])
    stocks=[]
    for record in list(verified):
        stock=str(record.get('id','')) if isinstance(record,dict) else ''
        if (isinstance(record,dict) and record.get('type')=='public_stock_card'
            and stock and record.get('official_brc_no')==stock
            and str(record.get('verification','')).startswith('OFFICIAL_BRC_NO_EXACT_MATCH_CARD_HTML')
            and stock in record.get('page_excerpt','')):
            stocks.append(record)
    pairs=[]
    for stock in stocks:
        for q in _stock_alleles(stock['page_excerpt']):
            item={'stock_id':stock['id'],**q}
            if item not in pairs:pairs.append(item)
    context['mgi_report_policy']='EXACT_PUBLIC_CARD_ALLELE_SYMBOL_AND_GENE_MARKER__OFFICIAL_REPORT_ID_AND_HTML'
    context['mgi_genotype_boundary']='An MGI genotype/background observation is NOT a new measurement of the currently distributed RBRC stock; no proof of KGE rank causation.'
    if not pairs:
        context['mgi_report_status']='NO_VERIFIED_STOCK_ALLELE_MARKER_PAIR'
        return context
    if len(pairs)>MAX_PAIRS:
        _unavailable(context,'MGI_REPORT_PAIR_LIMIT','MORE_PAIRS_THAN_SAFETY_LIMIT',pairs=len(pairs))
        context['mgi_report_status']='STOP_TOO_MANY_PAIRS'
        return context
    context['mgi_report_status']='ATTEMPTED_NOT_VERIFIED'
    allele_fetch=allele_fetch or _fetch_mgi
    genotype_fetch=genotype_fetch or fix2.network_bytes
    # FIX1 parser is original verified code; report may not be bundled/cached.
    try:
        chunks=allele_report_chunks if allele_report_chunks is not None else fix1._stream_report(fix1.REPORT_URL)
        report=fix1.match_report(chunks,pairs,_normal_symbol)
        if report['bytes']<100_000:raise ValueError('PUBLIC_ALLELE_REPORT_UNEXPECTEDLY_SMALL')
        context['mgi_allele_report']={'url':fix1.REPORT_URL,'sha256':report['sha256'],
            'bytes':report['bytes'],'rows_scanned':report['lines']}
    except (OSError,RuntimeError,ValueError,TimeoutError,UnicodeError) as ex:
        _unavailable(context,'MGI_OFFICIAL_ALLELE_REPORT','FETCH_OR_PARSE_FAILED',error_type=type(ex).__name__)
        context['mgi_report_status']='UNVERIFIED_REPORT_FAILURE'
        return context
    selected=[]
    for q in pairs:
        key=(q['gene_marker_id'],_normal_symbol(q['allele_symbol']),_normal_symbol(q['gene_symbol']))
        hit=report['per_key'][key]
        if hit['status']!='EXACT_UNIQUE':
            _unavailable(context,'MGI_ALLELE_DISCOVERY',hit['status'],stock_id=q['stock_id'],allele_symbol=q['allele_symbol'])
            continue
        r=hit['record'];aid=r['mgi_allele_id']
        url=PUBLIC_ALLELE+urllib.parse.quote(aid,safe=':')
        try:
            page=_parse_html(allele_fetch(url))
            plain=page.plain()
            if aid not in plain or _normal_symbol(q['allele_symbol']) not in _normal_symbol(plain):
                _unavailable(context,'MGI_ALLELE_DETAIL','ID_OR_ALLELE_SYMBOL_MISMATCH',source_url=url)
                continue
            selected.append({'stock_id':q['stock_id'],'allele_id':aid,'marker_id':q['gene_marker_id'],
                'allele_symbol':q['allele_symbol']})
            verified.append({'id':aid,'type':'MGI_allele','stock_id':q['stock_id'],
                'allele_symbol':q['allele_symbol'],'gene_marker_id':q['gene_marker_id'],
                'source_url':url,'report_source_url':fix1.REPORT_URL,'report_sha256':report['sha256'],
                'verification':'OFFICIAL_REPORT_EXACT_ALLELE_MARKER_AND_HTML_ID_SYMBOL',
                'allele_name':r['allele_name'],'allele_type':r['allele_type'],
                'mutation_and_references_excerpt':_excerpt(page,'Mutation',1200),
                'not_distributed_stock_measurement':True})
        except (OSError,RuntimeError,ValueError,TimeoutError,UnicodeError,TypeError) as ex:
            _unavailable(context,'MGI_ALLELE_DETAIL','PAGE_UNVERIFIED',source_url=url,error_type=type(ex).__name__)
    if not selected:
        context['mgi_report_status']='NO_EXACT_ALLELE_VERIFIED'
        return context
    try:
        chunks=genotype_report_chunks if genotype_report_chunks is not None else genotype_fetch(fix2.REPORT_URL,fix2.MAX_REPORT_BYTES)
        genos=fix2.parse_report(chunks,selected)
        if genos['bytes']<100_000:raise ValueError('PUBLIC_GENOTYPE_REPORT_UNEXPECTEDLY_SMALL')
        context['mgi_genotype_report']={'url':fix2.REPORT_URL,'sha256':genos['sha256'],
            'bytes':genos['bytes'],'rows_scanned':genos['lines']}
    except (OSError,RuntimeError,ValueError,TimeoutError,UnicodeError) as ex:
        _unavailable(context,'MGI_OFFICIAL_GENOTYPE_REPORT','FETCH_OR_PARSE_FAILED',error_type=type(ex).__name__)
        context['mgi_report_status']='ALLELE_VERIFIED_GENOTYPE_UNVERIFIED'
        return context
    verified_genotypes=0
    for q in selected:
        found=genos['matches'][(q['allele_id'],q['marker_id'])]
        if not found:
            _unavailable(context,'MGI_GENOTYPE_DISCOVERY','NO_EXACT_ROW_IN_OFFICIAL_REPORT',allele_id=q['allele_id'])
            continue
        for gid,r in sorted(found.items())[:MAX_GENOTYPE_DETAILS_PER_ALLELE]:
            url=PUBLIC_GENOTYPE+urllib.parse.quote(gid,safe=':')
            try:
                raw=b''.join(genotype_fetch(url,fix2.MAX_PAGE_BYTES,accept='text/html, */*'))
                excerpt,reason=fix2.detail_validation(raw,gid,q['allele_symbol'])
                if reason:
                    _unavailable(context,'MGI_GENOTYPE_DETAIL',reason,source_url=url)
                    continue
                verified_genotypes+=1
                verified.append({'id':gid,'type':'MGI_genotype_phenotype','stock_id':q['stock_id'],
                    'mgi_allele_id':q['allele_id'],'allele_symbol':q['allele_symbol'],
                    'source_url':url,'report_source_url':fix2.REPORT_URL,'report_sha256':genos['sha256'],
                    'verification':'OFFICIAL_REPORT_EXACT_ALLELE_MARKER_SYMBOL_AND_GENOTYPE_HTML',
                    'allelic_composition':r['allelic_composition'],
                    'genetic_background':r['genetic_background'], 'mp_ids':r['mp_ids'],
                    'pubmed_ids':r['pubmed_ids'],
                    'genotype_background_phenotype_excerpt':excerpt[:2000],
                    'not_distributed_stock_measurement':True})
            except (OSError,RuntimeError,ValueError,TimeoutError,UnicodeError,TypeError) as ex:
                _unavailable(context,'MGI_GENOTYPE_DETAIL','PAGE_UNVERIFIED',source_url=url,error_type=type(ex).__name__)
        if len(found)>MAX_GENOTYPE_DETAILS_PER_ALLELE:
            _unavailable(context,'MGI_GENOTYPE_DETAIL','SAFETY_CAP_NOT_ALL_GENOTYPES_FETCHED',
                allele_id=q['allele_id'],total=len(found),verified_sample_cap=MAX_GENOTYPE_DETAILS_PER_ALLELE)
    context['mgi_report_status']='ALLELE_AND_GENOTYPE_EXACT_VERIFIED' if verified_genotypes else 'ALLELE_VERIFIED_GENOTYPE_UNVERIFIED'
    return context
