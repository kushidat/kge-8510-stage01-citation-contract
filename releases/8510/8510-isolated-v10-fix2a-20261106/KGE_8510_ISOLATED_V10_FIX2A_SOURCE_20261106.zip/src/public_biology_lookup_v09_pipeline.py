"""V07 official BRC No. gate + the V06 verified MGI reports pathway."""
from __future__ import annotations
import public_biology_lookup_v09 as _brc
from public_mgi_report_chain_v09 import append_mgi_public_reports

def lookup_public_biology(pairs,fetch=None,allele_report_chunks=None,
                          genotype_report_chunks=None,allele_fetch=None,
                          genotype_fetch=None,stock_hint=''):
    context=_brc.lookup_public_biology(pairs,fetch=fetch,stock_hint=stock_hint)
    return append_mgi_public_reports(context,
         allele_report_chunks=allele_report_chunks,
         genotype_report_chunks=genotype_report_chunks,
         allele_fetch=allele_fetch, genotype_fetch=genotype_fetch)
