"""2026-11-06 V09: evidence-role based, read-only annotation target selection.

A candidate is NOT an ALS model because a disease HP maps to an MP term.
This unit never rejects uploaded files, predicts BRC accession format, or calls a network.
For recognized 8504 bundles, only explicit mouse-anchored candidate_intrinsic
edges authorize candidate-gene/MP public lookup. GO requires candidate-mouse
support; disease-context GO, genes and HP->MP mappings are kept separate.
Opaque/unknown formats are carried through to LLM original prompt unchanged,
but unscoped free-text IDs cannot be automatically promoted to candidate evidence.
"""
from __future__ import annotations
import json
import re
from public_stock_identity_v09 import discover_stock_candidates, MAX_CANDIDATES

MAX_LOOKUP_INPUT=2_000_000


def _obo(text, prefix):
    if not isinstance(text,str):return None
    m=re.search(r'(?:^|[/:])'+re.escape(prefix)+r'[_:](\d{7})(?:$|[^0-9])',text,re.I)
    return prefix.upper()+':'+m.group(1) if m else None


def _gene(text):
    if not isinstance(text,str):return None
    m=re.search(r'(?:^|[/:])ncbigene[/_:](\d{1,10})(?:$|[^0-9])',text,re.I)
    return m.group(1) if m else None


def _add(out, seen, key, value, origin=None):
    if not value:return
    if value not in seen.setdefault(key,set()):
        out.setdefault(key,[]).append(value)
        seen[key].add(value)
    if origin and key in ('genes','mp','go'):
        origins=out.setdefault('source_edge_origins',{}).setdefault(key,{})
        detail=origins.setdefault(value,[])
        if origin not in detail:detail.append(origin)


def extract_role_scoped_ids(pairs,stock_hint=''):
    """Extract only role-supported identifiers; never infer mouse evidence from HP->MP."""
    result={k:[] for k in ('genes','go','mp','diseases','source_ids','disease_context_genes',
                            'disease_context_hp','disease_hp_mp_mapping','unattributed_text_mentions')}
    seen={}
    result['source_edge_origins']={}
    parsed_count=0
    distinct_mice=[]
    shared_go=[]
    for name,data in pairs:
        if not isinstance(data,(bytes,bytearray)) or len(data)>MAX_LOOKUP_INPUT:
            continue
        try:obj=json.loads(bytes(data).decode('utf-8-sig'))
        except (ValueError,UnicodeError,TypeError):continue
        if not isinstance(obj,dict):continue
        bundle=obj.get('evidence_bundle') if isinstance(obj.get('evidence_bundle'),dict) else obj
        src=bundle.get('source_edges')
        if not isinstance(src,dict):
            # A generic JSON payload has no authority to associate a gene or MP with mouse.
            continue
        identity=bundle.get('identity') or {}
        if not isinstance(identity,dict):identity={}
        mouse=identity.get('mouse_iri')
        disease=identity.get('disease_iri')
        if not isinstance(mouse,str) or not mouse.strip():
            # Source roles cannot be tied to a particular mouse without an identity.
            continue
        parsed_count+=1
        if mouse not in distinct_mice:distinct_mice.append(mouse)
        _add(result,seen,'diseases',_obo(disease,'MONDO'))
        intrinsic=src.get('candidate_intrinsic')
        for edge in intrinsic if isinstance(intrinsic,list) else []:
            if not isinstance(edge,dict):continue
            subj=edge.get('subject_iri');obj_iri=edge.get('object_iri')
            if subj==mouse and isinstance(obj_iri,str):other=obj_iri
            elif obj_iri==mouse and isinstance(subj,str):other=subj
            else:continue
            origin={'file_name':str(name)[:120],'source_id':str(edge.get('source_id') or ''),
                    'source_row_number':edge.get('source_row_number'),
                    'mouse_iri':mouse,'edge_role':'CANDIDATE_INTRINSIC_DIRECT'}
            _add(result,seen,'genes',_gene(other),origin)
            _add(result,seen,'mp',_obo(other,'MP'),origin)
            _add(result,seen,'source_ids',edge.get('source_id'))
        context=src.get('disease_context')
        for edge in context if isinstance(context,list) else []:
            if not isinstance(edge,dict):continue
            subj=edge.get('subject_iri');obj_iri=edge.get('object_iri')
            if (disease and obj_iri==disease):
                _add(result,seen,'disease_context_genes',_gene(subj))
            if (disease and subj==disease):
                _add(result,seen,'disease_context_hp',_obo(obj_iri,'HP'))
        links=src.get('candidate_linking')
        for edge in links if isinstance(links,list) else []:
            if not isinstance(edge,dict):continue
            hp=_obo(edge.get('subject_iri'),'HP');mp=_obo(edge.get('object_iri'),'MP')
            if hp and mp:
                mapping={'hp':hp,'mp':mp,'source_id':str(edge.get('source_id') or ''),
                         'source_row_number':edge.get('source_row_number'),
                         'role':'HP_TO_MP_MAPPING_NOT_MOUSE_PHENOTYPE'}
                if mapping not in result['disease_hp_mp_mapping']:
                    result['disease_hp_mp_mapping'].append(mapping)
        go_context=bundle.get('go_context')
        if isinstance(go_context,dict):
            cg=go_context.get('candidate_mouse_go')
            for item in cg if isinstance(cg,list) else []:
                if isinstance(item,str): term=_obo(item,'GO')
                elif isinstance(item,dict):term=_obo(item.get('go_iri') or item.get('go_id') or item.get('id'),'GO')
                else:term=None
                _add(result,seen,'go',term,{'file_name':str(name)[:120],
                    'mouse_iri':mouse,'edge_role':'EXPLICIT_CANDIDATE_MOUSE_GO'})
            shared=go_context.get('shared_candidate_disease_gene_go')
            for item in shared if isinstance(shared,list) else []:
                if not isinstance(item,dict):continue
                refs=item.get('candidate_mouse_references')
                ref_list=refs if isinstance(refs,list) else str(refs or '').replace('|',';').split(';')
                if not any(str(x).strip() for x in ref_list):continue
                term=_obo(item.get('go_iri') or item.get('go_id'),'GO')
                if term:
                    _add(result,seen,'go',term,{'file_name':str(name)[:120],
                        'mouse_iri':mouse,'edge_role':'SHARED_GO_WITH_CANDIDATE_SIDE_REFERENCE'})
                    shared_go.append(item)
    result['structured_mouse_iri_count']=len(distinct_mice)
    result['structured_mouse_iris']=distinct_mice[:10]
    if len(distinct_mice)>1:
        # Multiple subjects cannot share a single unqualified candidate gene/MP list.
        # Preserve role-aware original receipts but do not query ambiguous aggregate IDs.
        result['multi_mouse_unqueried_role_targets']={k:list(result[k]) for k in ('genes','mp','go')}
        for k in ('genes','mp','go'):result[k]=[]
    result['genes']=result['genes'][:6]
    result['go']=result['go'][:10]
    result['mp']=result['mp'][:5]
    result['diseases']=result['diseases'][:3]
    result['source_ids']=result['source_ids'][:12]
    result['source_role_policy']='MOUSE_ANCHORED_CANDIDATE_INTRINSIC_ONLY; DISEASE_CONTEXT_SEPARATE; UNKNOWN_ROLE_NOT_PROMOTED'
    result['structured_mouse_bundle_count']=parsed_count
    result['candidate_mp_is_not_stock_measurement']=True
    result['disease_context_evidence_not_candidate_evidence']=True
    result['candidate_mouse_mp_count_in_selected_input']=len(seen.get('mp',set()))
    result['disease_hp_mp_mapping_count']=len(result['disease_hp_mp_mapping'])
    result['go_evidence_independence']={
        'total_shared':len(shared_go),
        'same_reference_id_count':sum(1 for item in shared_go if
           (set(str(item.get('candidate_mouse_references') or '').replace('|',';').split(';')) &
            set(str(item.get('disease_context_references') or '').replace('|',';').split(';'))) - {''}),
        'meaning':'Shared GO only when candidate side has a recorded source reference; source overlap is not independent corroboration, nor rank causality.'
    } if shared_go else {'status':'NOT_COMPUTABLE_FROM_INPUT'}
    stocks=discover_stock_candidates(pairs,stock_hint=stock_hint)
    result['stocks']=[r['candidate'] for r in stocks[:MAX_CANDIDATES]]
    result['stock_candidate_details']=stocks[:MAX_CANDIDATES]
    result['stock_candidate_total']=len(stocks)
    result['stock_candidates_unprocessed']=max(0,len(stocks)-MAX_CANDIDATES)
    if len(distinct_mice)>1:
        result['source_role_status']='MULTI_MOUSE_BUNDLE_PUBLIC_GENE_MP_GO_LOOKUP_HOLD'
    elif not parsed_count:
        result['source_role_status']='NO_TRUSTED_STRUCTURED_MOUSE_ROLE; NO_CANDIDATE_GENE_MP_GO_PROMOTION'
    else:
        result['source_role_status']='STRUCTURED_MOUSE_ROLE_SEPARATED'
    return result
