#!/usr/bin/env python3
"""Read-only MGI allele provenance diagnostic, with no LLM/API-key usage.

Given an existing V05 diagnostic JSON (not the original 8504 record),
resolve stock allele symbols against the official weekly MGI phenotypic
alleles TSV using exact symbol AND parent marker ID. This avoids relying
on visible anchor texts in the MGI allele summary HTML table.

The large public TSV is streamed in memory only. The program never saves
or modifies it and does not contact OpenAI. The parent V05 program is
imported read-only after its SHA256 is pinned.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import urllib.parse
import urllib.request

PACKAGE = Path(__file__).resolve().parent
PARENT = Path.home() / 'projects/mondo_eval/release_records/8504_8510/isolated/8510_GENERIC_LLM_ALLELE_EVIDENCE_V05_20261106'
PARENT_SOURCE = PARENT / 'public_allele_evidence_v05.py'
PARENT_SHA256 = 'f5037bc1a7758e28777e9b8f9d8a97b19eb91e0b8b427b0913e5193b9dfe15db'
REPORT_URL = 'https://www.informatics.jax.org/downloads/reports/MGI_PhenotypicAllele.rpt'
REPORT_MAX_BYTES = 55_000_000
OUTPUT_PREFIX = 'MGI_REPORT_FIX1_'


def _parent_functions():
    if PARENT_SOURCE.is_symlink() or not PARENT_SOURCE.is_file():
        raise RuntimeError('STOP_PARENT_V05_SOURCE_MISSING_OR_SYMLINK')
    if hashlib.sha256(PARENT_SOURCE.read_bytes()).hexdigest() != PARENT_SHA256:
        raise RuntimeError('STOP_PARENT_V05_SOURCE_SHA_MISMATCH')
    sys.path.insert(0, str(PARENT))
    from public_allele_evidence_v05 import _stock_alleles, _normal_symbol, _fetch_mgi, _parse_html, _find_genotypes, _excerpt
    return (_stock_alleles, _normal_symbol, _fetch_mgi, _parse_html, _find_genotypes, _excerpt)


def _load_source(p):
    if p.is_symlink() or not p.is_file() or p.stat().st_size > 2_000_000:
        raise RuntimeError('STOP_MISSING_UNSAFE_OR_TOO_LARGE_INPUT')
    raw = p.read_bytes()
    doc = json.loads(raw)
    if doc.get('record_type') != '8510_public_mgi_allele_genotype_lookup_v05':
        raise RuntimeError('STOP_NOT_V05_DIAGNOSTIC_JSON')
    if doc.get('real_llm_api_calls') != 0 or doc.get('primary_test_access') is not False:
        raise RuntimeError('STOP_NOT_PUBLIC_DIAGNOSTIC_INPUT')
    stocks = [x for x in doc.get('public_annotations',{}).get('verified',[]) if isinstance(x,dict)
              and x.get('type') == 'public_stock_card'
              and str(x.get('verification','')).startswith('HTTP_HTML_PAGE_CONTAINS_STOCK_ID')
              and isinstance(x.get('id'),str) and re.fullmatch(r'RBRC-[A-Za-z0-9-]{4,30}', x['id'])
              and x['id'] in x.get('page_excerpt','')]
    if not stocks:
        raise RuntimeError('STOP_NO_VERIFIED_PUBLIC_BRC_STOCK_CARD')
    return raw, doc, stocks


def _pairs(stocks, stock_alleles):
    items = []
    for stock in stocks:
        for allele in stock_alleles(stock.get('page_excerpt','')):
            item = {'stock_id':stock['id'], **allele}
            if item not in items: items.append(item)
    if not items or len(items)>4:
        raise RuntimeError('STOP_NO_OR_TOO_MANY_STOCK_ALLELE_MARKER_PAIRS')
    return items


def _stream_report(url):
    p=urllib.parse.urlsplit(url)
    if p.scheme!='https' or p.hostname!='www.informatics.jax.org':
        raise RuntimeError('STOP_UNTRUSTED_REPORT_URL')
    req=urllib.request.Request(url,headers={
        'User-Agent':'8510MGIPublicReportDiagnostic/0.1 (no account; public TSV only)',
        'Accept':'text/plain, text/tab-separated-values, */*'
    })
    with urllib.request.urlopen(req,timeout=45) as response:
        final=urllib.parse.urlsplit(response.geturl())
        if final.scheme!='https' or final.hostname not in ('www.informatics.jax.org','informatics.jax.org'):
            raise RuntimeError('STOP_REPORT_REDIRECT_HOST')
        claimed=response.headers.get('Content-Length')
        if claimed and int(claimed)>REPORT_MAX_BYTES:
            raise RuntimeError('STOP_REPORT_TOO_LARGE')
        chunks=[]
        total=0
        while True:
            chunk=response.read(131072)
            if not chunk: break
            total+=len(chunk)
            if total>REPORT_MAX_BYTES:raise RuntimeError('STOP_REPORT_TOO_LARGE')
            yield chunk


def match_report(chunks, pairs, normal):
    """Parse exact official TSV columns 1/2/7/8; never fuzzy-match IDs."""
    wanted={(q['gene_marker_id'],normal(q['allele_symbol']),normal(q['gene_symbol'])) for q in pairs}
    hits={key:set() for key in wanted}
    first={}
    hasher=hashlib.sha256()
    buf=b''
    lines=0
    nbytes=0
    def take(line):
        nonlocal lines
        lines+=1
        vals=line.rstrip(b'\r').decode('utf-8',errors='replace').split('\t')
        if len(vals)<8:return
        allele_id,sym,marker_id,gene=vals[0].strip(),vals[1].strip(),vals[6].strip(),vals[7].strip()
        key=(marker_id,normal(sym),normal(gene))
        if key in hits and re.fullmatch(r'MGI:\d{4,10}',allele_id):
            hits[key].add(allele_id)
            first.setdefault(key,{'mgi_allele_id':allele_id,'allele_symbol':sym,'gene_marker_id':marker_id,
                                  'marker_symbol':gene,'allele_name':vals[2][:400],'allele_type':vals[3][:200]})
    for chunk in chunks:
        nbytes+=len(chunk)
        if nbytes>REPORT_MAX_BYTES:raise RuntimeError('STOP_REPORT_TOO_LARGE')
        hasher.update(chunk)
        buf+=chunk
        while b'\n' in buf:
            line,buf=buf.split(b'\n',1)
            if len(line)>500_000:raise RuntimeError('STOP_REPORT_LINE_TOO_LONG')
            take(line)
        if len(buf)>500_000:raise RuntimeError('STOP_REPORT_LINE_TOO_LONG')
    if buf:take(buf)
    out={}
    for key,found in hits.items():
        if len(found)==1:out[key]={'status':'EXACT_UNIQUE','record':first[key]}
        elif not found:out[key]={'status':'NOT_FOUND_IN_OFFICIAL_REPORT'}
        else:out[key]={'status':'AMBIGUOUS_MULTIPLE_IDS','candidate_allele_ids':sorted(found)}
    return {'bytes':nbytes,'sha256':hasher.hexdigest(),'lines':lines,'per_key':out}


def run_lookup(doc, pairs, functions, report_chunks=None, fetch_page=None):
    _, normal, actual_fetch, parse_html, find_genotypes, excerpt=functions
    report_chunks = report_chunks if report_chunks is not None else _stream_report(REPORT_URL)
    fetch_page=fetch_page or actual_fetch
    report=match_report(report_chunks,pairs,normal)
    result={'report_source_url':REPORT_URL,'report_sha256':report['sha256'],'report_bytes':report['bytes'],
            'report_lines_scanned':report['lines'], 'records':[], 'unavailable':[],
            'boundary':'MGI genotype records refer to reported genotype and genetic background, NOT measurement of current distributed RBRC stock.'}
    if report['bytes']<100_000:
        result['unavailable'].append({'stage':'MGI_OFFICIAL_TSV','reason':'REPORT_UNEXPECTEDLY_SMALL'})
        return result
    for q in pairs:
        key=(q['gene_marker_id'],normal(q['allele_symbol']),normal(q['gene_symbol']))
        found=report['per_key'][key]
        if found['status']!='EXACT_UNIQUE':
            result['unavailable'].append({'stage':'MGI_ALLELE_DISCOVERY','stock_id':q['stock_id'],
                 'allele_symbol':q['allele_symbol'],'gene_marker_id':q['gene_marker_id'],'reason':found['status']})
            continue
        data=found['record']
        allele_id=data['mgi_allele_id']
        url='https://www.informatics.jax.org/allele/'+urllib.parse.quote(allele_id,safe=':')
        try:
            page=parse_html(fetch_page(url))
            plain=page.plain()
            if allele_id not in plain or normal(q['allele_symbol']) not in normal(plain):
                result['unavailable'].append({'stage':'MGI_ALLELE_DETAIL','stock_id':q['stock_id'],
                  'mgi_allele_id':allele_id,'reason':'ALLELE_ID_OR_SYMBOL_MISMATCH','source_url':url})
                continue
            record={'stock_id':q['stock_id'],'stock_allele_symbol':q['allele_symbol'],
                'gene_marker_id':q['gene_marker_id'],'mgi_allele_id':allele_id,
                'allele_symbol_mgi':data['allele_symbol'],'allele_name':data['allele_name'],
                'allele_type':data['allele_type'], 'match':'REPORT_EXACT_SYMBOL_MARKER_AND_DETAIL_MATCH',
                'report_url':REPORT_URL,'source_url':url,
                'mutation_detail_excerpt':excerpt(page,'Mutation',1700),
                'genotypes':[]}
            result['records'].append(record)
        except (RuntimeError,ValueError,OSError,TimeoutError,UnicodeError) as e:
            result['unavailable'].append({'stage':'MGI_ALLELE_DETAIL','stock_id':q['stock_id'],
                'mgi_allele_id':allele_id,'error_type':type(e).__name__,'source_url':url})
            continue
        marker='https://www.informatics.jax.org/marker/phenotypes/'+q['gene_marker_id']
        try:
            mpage=parse_html(fetch_page(marker))
            geno_ids=find_genotypes(mpage,q['allele_symbol'])
            if not geno_ids:
                result['unavailable'].append({'stage':'MGI_GENOTYPE_DISCOVERY','stock_id':q['stock_id'],
                    'mgi_allele_id':allele_id,'reason':'NO_EXACT_GENOTYPE_LINK','source_url':marker})
                continue
            for gid in geno_ids[:2]:
                g_url='https://www.informatics.jax.org/allele/genoview/'+urllib.parse.quote(gid,safe=':')
                gp=parse_html(fetch_page(g_url))
                if gid not in gp.plain() or normal(q['allele_symbol']) not in normal(gp.plain()):
                    result['unavailable'].append({'stage':'MGI_GENOTYPE_DETAIL','mgi_genotype_id':gid,'reason':'GENOTYPE_ID_OR_SYMBOL_MISMATCH','source_url':g_url})
                    continue
                record['genotypes'].append({'mgi_genotype_id':gid,'source_url':g_url,
                    'verification':'EXACT_GENOTYPE_ID_AND_ALLELE_SYMBOL_MATCHED',
                    'genotype_phenotype_excerpt':excerpt(gp,'Genotype',2500),
                    'not_distributed_stock_measurement':True})
        except (RuntimeError,ValueError,OSError,TimeoutError,UnicodeError) as e:
            result['unavailable'].append({'stage':'MGI_GENOTYPE_LOOKUP','stock_id':q['stock_id'],
                'mgi_allele_id':allele_id,'error_type':type(e).__name__,'source_url':marker})
    return result


def main(argv=None):
    ap=argparse.ArgumentParser()
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--lookup',action='store_true')
    ap.add_argument('--input',required=True)
    args=ap.parse_args(argv)
    source=Path(args.input).expanduser()
    original,doc,stocks=_load_source(source)
    funcs=_parent_functions()
    pairs=_pairs(stocks,funcs[0])
    digest=hashlib.sha256(original).hexdigest()
    print('V05_DIAGNOSTIC_SHA256='+digest)
    print('V05_PARENT_SOURCE_SHA256='+PARENT_SHA256)
    print('EXACT_BRC_ALLELE_MARKER_PAIRS='+str(len(pairs)))
    for pair in pairs:
        print('STOCK='+pair['stock_id']+' ALLELE='+pair['allele_symbol']+' MARKER='+pair['gene_marker_id'])
    if args.check:
        print('CHECK=PASS READ_ONLY=YES NETWORK_REQUESTS=0 FILE_WRITES=0 LLM_API_CALLS=0')
        return
    output=run_lookup(doc,pairs,funcs)
    now=datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d_%H%M%S_%f')
    outdir=PACKAGE/'diagnostics'
    outdir.mkdir(parents=True,exist_ok=True)
    dst=outdir/(OUTPUT_PREFIX+now+'_'+digest[:12]+'.json')
    result={'record_type':'8510_mgi_official_phenotypic_allele_report_fix1_no_llm',
      'created_at_jst':datetime.now(timezone(timedelta(hours=9))).isoformat(timespec='seconds'),
      'input_file_name':source.name,'input_file_sha256':digest,
      'previous_v05_allele_status':doc.get('public_annotations',{}).get('allele_lookup_status'),
      'public_allele_report_lookup':output,'real_llm_api_calls':0,'primary_test_access':False,
      'scientific_validation':False,'formal_app_mutation':False}
    fd=os.open(dst,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:
        f.write((json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
    print('REPORT_BYTES='+str(output['report_bytes']))
    print('MGI_ALLELE_DETAIL_MATCHES='+str(len(output['records'])))
    print('MGI_GENOTYPE_DETAIL_MATCHES='+str(sum(len(x['genotypes']) for x in output['records'])))
    print('UNAVAILABLE='+str(len(output['unavailable'])))
    print('OUTPUT_JSON='+str(dst))
    print('LLM_API_CALLS=0 ORIGINAL_INPUT_UNMODIFIED=YES')

if __name__=='__main__':
    try: main()
    except Exception as e:
        print('MGI_FIX1_STOP='+type(e).__name__+':'+str(e)[:280],file=sys.stderr)
        raise SystemExit(2)
