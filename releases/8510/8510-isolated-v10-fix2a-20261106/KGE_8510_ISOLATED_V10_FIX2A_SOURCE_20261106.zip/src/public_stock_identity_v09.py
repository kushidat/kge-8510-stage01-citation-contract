"""Read-only candidate discovery and official BRC card identity adjudication.

No regular expression is used to decide an accession's allowed *format*.
All supplied identifier strings stay opaque; a candidate is NOT an identity until
an official BRC No. field from the BRC card equals the candidate exactly.
A candidate from text is a search hint, not an accepted accession.

Only the already-approved PUBLIC BRC card host is queried, and only after the
user explicitly clicks the existing LLM action with external lookup consent.
"""
from __future__ import annotations
from html import unescape
import json
from urllib.parse import parse_qs, unquote, urlsplit

MAX_CANDIDATES=6
MAX_CANDIDATE_CHARS=160
MAX_TEXT_CHARS=1_300_000
SOURCE_KEY_NAMES={
    'rbrcid','brcno','brcnumber','mouseid','mouseidentifier','stockid',
    'strainid','strainidentifier','mouseaccession','stockaccession',
    'resourceid','resourceidentifier','mouseiri','stockiri','strainiri',
    'resourceiri','mouseurl','stockurl','strainurl',
}
URI_KEY_NAMES={'resourceiri','mouseiri','stockiri','strainiri','mouseurl','stockurl','strainurl'}


def _safe_candidate(value):
    # Transport safety bounds are not BRC accession syntax restrictions.
    if not isinstance(value,(str,int)):
        return None
    s=str(value).strip()
    if not s or len(s)>MAX_CANDIDATE_CHARS:
        return None
    if any(ord(c)<32 or ord(c)==127 for c in s):
        return None
    return s


def _value_from_official_uri(value):
    """Get exact resource identity, never convert or guess its format."""
    if not isinstance(value,str):return None
    text=unescape(value).strip()
    try:
        p=urlsplit(text)
    except ValueError:
        return None
    host=(p.hostname or '').lower()
    if p.scheme in ('https','http') and host=='knowledge.brc.riken.jp' and p.path.rstrip('/')=='/resource/animal/card':
        vals=parse_qs(p.query,keep_blank_values=False).get('brc_no') or []
        return _safe_candidate(vals[0]) if len(vals)==1 else None
    if p.scheme in ('https','http') and host=='metadb.riken.jp' and '/db/rikenbrc_mouse/' in p.path:
        return _safe_candidate(unquote(p.path.split('/db/rikenbrc_mouse/',1)[1]).strip('/'))
    return None


def _add(result,value,origin):
    if value is None:return
    canonical=_value_from_official_uri(value) or _safe_candidate(value)
    if canonical and canonical not in [r['candidate'] for r in result]:
        result.append({'candidate':canonical,'origin':origin})


def _walk_json(obj,output,source,depth=0):
    if depth>12:return
    if isinstance(obj,dict):
        for k,v in list(obj.items())[:1500]:
            key=''.join(c.lower() for c in str(k) if c.isalnum())
            if key in SOURCE_KEY_NAMES:
                if isinstance(v,(str,int)):_add(output,v,source+':FIELD:'+str(k)[:50])
            elif key in ('id','identifier','url','iri') and isinstance(v,str):
                # Generic id fields are hints only when they contain a BRC-specific URI.
                official=_value_from_official_uri(v)
                if official:_add(output,official,source+':OFFICIAL_URI')
            if isinstance(v,(dict,list)):_walk_json(v,output,source,depth+1)
    elif isinstance(obj,list):
        for v in obj[:1500]:
            if isinstance(v,(dict,list)):_walk_json(v,output,source,depth+1)


def _scan_text(txt,output,source):
    """Only context-labeled values and official URL query parameters.

    Unlabelled free text is ambiguous; the optional user hint handles it.
    No accession syntax is inferred and no input files are rejected.
    """
    txt=txt[:MAX_TEXT_CHARS]
    # A labeled value can have any syntax. Labels only locate the value;
    # acceptance always depends on a matching BRC official card field.
    for label in ('BRC No.', 'BRC番号:', 'マウス番号:', 'Mouse ID:', 'Strain ID:'):
        start=0
        while True:
            at=txt.find(label,start)
            if at<0:break
            value_start=at+len(label)
            rest=txt[value_start:value_start+MAX_CANDIDATE_CHARS+30]
            stop_at=len(rest)
            for delim in ('\n','\r',' Type ',' Strain name '):
                k=rest.find(delim)
                if k>=0:stop_at=min(stop_at,k)
            value=rest[:stop_at].strip().lstrip(':').strip()
            _add(output,value,source+':LABELED_VALUE')
            start=value_start+max(1,stop_at)
    marker='brc_no='
    pos=0
    while len(output)<300:
        pos=txt.find(marker,pos)
        if pos<0:break
        start=pos+len(marker)
        end=start
        while end<len(txt) and txt[end] not in '&\r\n\t \"\'<>':end+=1
        _add(output,unquote(txt[start:end]),source+':URL_QUERY')
        pos=end+1


def discover_stock_candidates(pairs,stock_hint=''):
    """Return all unverified search hints with provenance, never validate by regex."""
    found=[]
    if stock_hint:
        _add(found,stock_hint,'USER_OPTIONAL_HINT')
    for file_name,data in pairs:
        # A filename is transport metadata, not a verified mouse identifier.
        # For structured sources, use values in named entity fields and
        # official resource URLs; never tokenize arbitrary JSON narrative.
        name=str(file_name or '')[:300]
        if not isinstance(data,(bytes,bytearray)) or len(data)>2_000_000:continue
        try:txt=bytes(data).decode('utf-8-sig')
        except UnicodeError:continue
        try:obj=json.loads(txt)
        except (ValueError,TypeError):obj=None
        if obj is not None:
            _walk_json(obj,found,'JSON:'+name[:100])
        else:
            # Plain text requires a contextual label or official URL query.
            # Unlabelled free text may be supplied as an optional hint.
            _scan_text(txt,found,'TEXT:'+name[:100])
    return found


def official_brc_no_from_card(plain):
    """Read *field value*, not the mere occurrence of requested text on a page.

    For unrecognized markup/field delimiters, return None rather than guess.
    Multiple differing `BRC No.` values fail closed. The card may contain
    arbitrary accession punctuation inside this field.
    """
    if not isinstance(plain,str) or 'BRC No.' not in plain:return None
    if 'Strain Data Sheet' not in plain or 'Strain Information' not in plain:
        return None
    values=[]
    pivot=0
    while True:
        at=plain.find('BRC No.',pivot)
        if at<0:break
        start=at+len('BRC No.')
        end=plain.find(' Type ',start)
        if end>=0 and end-start<=MAX_CANDIDATE_CHARS+10:
            value=_safe_candidate(plain[start:end].strip())
            if value and value not in values:values.append(value)
        pivot=start
    return values[0] if len(values)==1 else None
