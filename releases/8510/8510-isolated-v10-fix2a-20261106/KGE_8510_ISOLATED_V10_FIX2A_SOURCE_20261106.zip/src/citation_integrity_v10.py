"""Read-only citation validation against uploaded input AND FROZEN_TRAIN provenance.

Input JSON source-edge row existence can be verified. Original frozen TRAIN bytes
have not been independently verified by this module; model biology and KGE
ranking causality remain NOT_ASSESSED. No internet, APIs, filesystem writes.
"""
from __future__ import annotations
import json,re
from urllib.parse import urlsplit
OPENING=re.compile(r'\[(?:8504|PUBLIC):',re.I)
CITATION=re.compile(r'\[(8504|PUBLIC):([^\]\n]*)\]',re.I)
SHA_LOCATOR=re.compile(r'([0-9a-f]{64})\s*/\s*(\S(?:[^\n]*\S)?)\Z',re.I)
TRAIN_LOCREf=re.compile(r'FROZEN_TRAIN行\s*(.+)\Z')
HEX=re.compile(r'[0-9a-f]{64}',re.I)
VALID_RANGE=re.compile(r'(\d{4,8})\s*[–—-]\s*(\d{4,8})|(?<!\d)(\d{4,8})(?!\d)')

def _sources(pairs):
    indexed=[]
    for name,data in pairs if isinstance(pairs,(list,tuple)) else []:
        try:
            if not isinstance(data,bytes):continue
            obj=json.loads(data.decode('utf-8-sig'))
            eb=obj.get('evidence_bundle',{})
            if not isinstance(eb,dict):continue
            prov=eb.get('provenance',{}).get('frozen_train',{})
            sha=str(prov.get('sha256','')).lower()
            if not HEX.fullmatch(sha):continue
            source_edges=eb.get('source_edges',{})
            rows={}
            if isinstance(source_edges,dict):
                for role,edges in source_edges.items():
                    if not isinstance(edges,list):continue
                    for edge in edges:
                        if not isinstance(edge,dict) or edge.get('source_id')!='FROZEN_TRAIN':continue
                        n=edge.get('source_row_number')
                        if isinstance(n,int) and n>0:rows.setdefault(n,set()).add(role)
            indexed.append({'name':str(name),'train_sha':sha,'rows':rows})
        except (ValueError,UnicodeError,AttributeError,TypeError):pass
    return indexed

def _train_rows(selector):
    if not selector.startswith('FROZEN_TRAIN行'):return None
    m=TRAIN_LOCREf.fullmatch(selector.strip())
    if not m:return None
    span=m.group(1).strip()
    if not span or '?' in span or '…' in span or '...' in span:return None
    # Reject unrecognized words and punctuation instead of accepting incidental digits.
    scrub=VALID_RANGE.sub('',span)
    if re.sub(r'[\s・,，、;；]+','',scrub):return None
    nums=[]
    for r in VALID_RANGE.finditer(span):
        left,right,single=r.groups()
        if single:nums.append(int(single))
        else:
            a,b=int(left),int(right)
            if b<a or b-a>500: return None
            nums.extend(range(a,b+1))
        if len(nums)>600:return None
    return nums if nums else None

def audit_citations(answer,input_records,public_context,input_pairs=None):
    text=answer if isinstance(answer,str) else ''
    records=input_records if isinstance(input_records,list) else []
    context=public_context if isinstance(public_context,dict) else {}
    digests={str(r.get('sha256','')).lower() for r in records if isinstance(r,dict)}
    refs=set()
    for obj in context.get('verified') or []:
        if isinstance(obj,dict) and isinstance(obj.get('source_url'),str):refs.add(obj['source_url'])
    known=_sources(input_pairs or [])
    hits=list(CITATION.finditer(text))
    opening=list(OPENING.finditer(text))
    errors=[]
    for op in opening:
        if not any(x.start()==op.start() for x in hits):errors.append({'kind':'UNTERMINATED_SOURCE_TAG','excerpt':text[op.start():op.start()+110]})
    matched_input=matched_train=matched_public=0
    train_details=[]
    for hit in hits:
        kind,token=hit.group(1).upper(),hit.group(2).strip()
        if kind=='8504':
            m=SHA_LOCATOR.fullmatch(token)
            if not m:
                errors.append({'kind':'MALFORMED_8504_SOURCE_TAG','excerpt':hit.group(0)[:170]});continue
            sha,loc=m.group(1).lower(),m.group(2).strip()
            if any(p in loc for p in ('?', '\ufffd', '…','...')):
                errors.append({'kind':'UNRESOLVED_8504_LOCATOR','excerpt':hit.group(0)[:170]});continue
            if loc.startswith('FROZEN_TRAIN'):
                nums=_train_rows(loc)
                if not nums:
                    errors.append({'kind':'INVALID_FROZEN_TRAIN_ROW_LOCATOR','excerpt':hit.group(0)[:170]});continue
                candidates=[x for x in known if x['train_sha']==sha]
                if not candidates:
                    errors.append({'kind':'FROZEN_TRAIN_DIGEST_NOT_BOUND_TO_INPUT','excerpt':hit.group(0)[:170]});continue
                valid=[x for x in candidates if all(n in x['rows'] for n in nums)]
                if not valid:
                    errors.append({'kind':'FROZEN_TRAIN_ROW_NOT_IN_INPUT_SOURCE_EDGES','excerpt':hit.group(0)[:170]});continue
                matched_train+=1
                train_details.append({'digest':sha,'row_count':len(nums),'all_rows_in_input_source_edges':True,'frozen_train_original_byte_check':'NOT_ASSESSED'})
            elif sha in digests:
                matched_input+=1
            else:
                errors.append({'kind':'SOURCE_DIGEST_NOT_IN_UPLOADED_INPUT','excerpt':hit.group(0)[:170]})
        elif kind=='PUBLIC':
            try:p=urlsplit(token)
            except ValueError:p=None
            if not p or p.scheme!='https' or not p.hostname or p.username or p.password:
                errors.append({'kind':'PUBLIC_URL_SYNTAX_UNVERIFIED','excerpt':hit.group(0)[:170]})
            elif token not in refs:
                errors.append({'kind':'PUBLIC_URL_NOT_IN_CURRENT_VERIFIED_RECORDS','excerpt':hit.group(0)[:170]})
            else: matched_public+=1
    if not hits and not opening:errors.append({'kind':'NO_CITED_SOURCE_TAGS'})
    bound=bool(hits and not errors)
    return {
        'status':'SOURCE_BINDINGS_INPUT_EVIDENCE_CONFIRMED_ORIGINALS_NOT_ASSESSED' if bound else 'REVIEW_REQUIRED_INVALID_SOURCE_REFERENCE',
        'source_binding_ok':bound,'source_locator_validation':'TRAIN_ROWS_IN_UPLOADED_EVIDENCE_ONLY' if matched_train else 'NOT_ASSESSED',
        'original_train_row_byte_validation':'NOT_ASSESSED',
        'scientific_claim_validation':False,'cited_tag_count':len(hits),
        'matched_uploaded_input_tag_count':matched_input,
        'matched_frozen_train_source_edge_tag_count':matched_train,
        'matched_public_fetched_url_tag_count':matched_public,
        'frozen_train_binding_details':train_details,
        'error_count':len(errors),'errors':errors[:24],
        'note':'Only frozen TRAIN digest and row numbers in uploaded 8504 evidence were compared, not the original TRAIN file; biology and KGE rank formation unverified.'}
