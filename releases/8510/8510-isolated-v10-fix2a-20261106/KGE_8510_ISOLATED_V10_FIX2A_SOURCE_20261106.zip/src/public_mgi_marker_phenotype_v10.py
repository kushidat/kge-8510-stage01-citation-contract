"""Supplemental MGI marker phenotype table, *not* an MGI genotype-ID report.

Never promote a marker-level phenotype to a distributed-stock measurement.
Fetch only after user initiated the on-demand pipeline. Fail closed when row,
allele composition, reference, marker or background cannot be established.
"""
from __future__ import annotations
import html,re,urllib.parse,urllib.request
from html.parser import HTMLParser
from public_allele_evidence_v05 import _normal_symbol
BASE='https://www.informatics.jax.org/marker/phenotypes/'
MAX=1_000_000
class TableRows(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack=[];self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='tr':self.row=[]
        if tag in ('td','th') and self.row is not None:self.cell=[]
    def handle_data(self,data):
        if self.cell is not None:self.cell.append(data)
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.cell is not None and self.row is not None:
            self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
        if tag=='tr' and self.row is not None:
            self.rows.append(self.row);self.row=None;self.cell=None

def _fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':'8510ResearchPrototype/0.4 (public MGI source)', 'Accept':'text/html'})
    with urllib.request.urlopen(req,timeout=5) as res:
        if urllib.parse.urlparse(res.geturl()).hostname != 'www.informatics.jax.org':raise ValueError('MGI_UNEXPECTED_REDIRECT')
        payload=res.read(MAX+1)
        if len(payload)>MAX:raise ValueError('MGI_PAGE_TOO_LARGE')
        return payload

def _exact_composition(cell,allele):
    # HTML <sup> is reduced to plain text; compare both alleles without assuming
    # an accession-number syntax. A mixed or unknown second allele is rejected.
    parts=cell.split('/',1)
    if len(parts)!=2:return False
    target=_normal_symbol(allele)
    # Remove only explicit 'involves' genetic-background suffix.
    a,b=(x.split('involves:')[0].strip() for x in parts)
    return bool(target and _normal_symbol(a)==target and _normal_symbol(b)==target)

def append_marker_phenotype(context,*,fetch=None):
    verified=context.setdefault('verified',[]);context.setdefault('unavailable',[])
    alleles=[r for r in verified if isinstance(r,dict) and r.get('type')=='MGI_allele'
             and r.get('verification')=='OFFICIAL_REPORT_EXACT_ALLELE_MARKER_AND_HTML_ID_SYMBOL']
    context['mgi_marker_phenotype_policy']='SECONDARY_OFFICIAL_MARKER_PAGE_ALLELE_COMPOSITION_BACKGROUND_REFERENCE_ROW; NO_GENOTYPE_ID_CLAIM'
    if not alleles:
        context['mgi_marker_phenotype_status']='NOT_ATTEMPTED_NO_VERIFIED_ALLELE';return context
    if len(alleles)>4:
        context['mgi_marker_phenotype_status']='STOP_ALLELE_SAFETY_LIMIT';return context
    fetch=fetch or _fetch
    for allele in alleles:
        marker=allele.get('gene_marker_id','');symbol=allele.get('allele_symbol','')
        if not re.fullmatch(r'MGI:\d+',marker) or not symbol:continue
        url=BASE+urllib.parse.quote(marker,safe=':')
        try:
            raw=fetch(url)
            if not isinstance(raw,bytes):raise ValueError('NOT_BYTES')
            if len(raw)>MAX:raise ValueError('TOO_LARGE')
            page=raw.decode('utf-8',errors='replace')
            p=TableRows();p.feed(page)
            # The official header must assert exactly the requested marker ID.
            if marker not in html.unescape(re.sub('<[^>]+>',' ',page)):
                raise ValueError('MARKER_ID_NOT_IN_PAGE')
            for row in p.rows:
                if len(row)<3:continue
                composition=row[0]
                if not _exact_composition(composition,symbol):continue
                if len(row)>=4:
                    background,phenotype_term,reference=row[1],row[2],row[3]
                else:
                    # MGI may combine genotype and background in the first cell.
                    match=re.search(r'involves:\s*(.+)',composition,re.I)
                    if not match:continue
                    background,phenotype_term,reference=match.group(1),row[1],row[2]
                ref=re.search(r'\bJ:\d+\b',reference)
                # Only accept a phenotype and background from the very same
                # table row. Never infer these from separate marker-level text.
                if not ref or not background.strip() or not phenotype_term.strip():continue
                if not re.search(r'phenotype',phenotype_term,re.I):continue
                verified.append({'type':'MGI_marker_phenotype_secondary',
                  'id':allele['allele_symbol'],'stock_id':allele['stock_id'],
                  'mgi_allele_id':allele['id'],'gene_marker_id':marker,
                  'source_url':url,'verification':'OFFICIAL_MARKER_PAGE_ROW_ALLELIC_COMPOSITION_BACKGROUND_TERM_REFERENCE',
                  'allelic_composition':composition,'genetic_background':background,
                  'phenotype_term':phenotype_term[:400], 'phenotype_term_and_reference':(phenotype_term+' / '+reference)[:500],'reference_id':ref.group(0),
                  'genotype_mgi_id':'NOT_VERIFIED','not_distributed_stock_measurement':True,
                  'not_als_phenotype_evidence_by_itself':True})
                break
            else:
                context['unavailable'].append({'request':'MGI_MARKER_PHENOTYPE','reason':'NO_MATCHING_ALLELE_COMPOSITION_ROW','source_url':url})
        except (OSError,RuntimeError,ValueError,TimeoutError,UnicodeError,TypeError) as ex:
            context['unavailable'].append({'request':'MGI_MARKER_PHENOTYPE','reason':'PUBLIC_MARKER_PAGE_UNVERIFIED','error_type':type(ex).__name__,'source_url':url})
    context['mgi_marker_phenotype_status']='MATCHED_OFFICIAL_MARKER_ROW_NO_GENOTYPE_ID' if any(r.get('type')=='MGI_marker_phenotype_secondary' for r in verified if isinstance(r,dict)) else 'NOT_VERIFIED'
    return context
