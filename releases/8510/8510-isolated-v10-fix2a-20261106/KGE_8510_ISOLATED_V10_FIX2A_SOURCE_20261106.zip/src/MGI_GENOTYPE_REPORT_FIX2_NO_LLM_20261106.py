#!/usr/bin/env python3
"""One-shot read-only public MGI genotype provenance diagnostic. No LLM calls.

Input: the existing FIX1 public allele-report output, with its exact source
SHA256 pinned. Do not read 8504 TRAIN/test, Docker, or private research data.
Consult the official MGI_GenePheno.rpt once, in memory. Verify genotype detail
pages against returned genotype ID and exact source allele symbol.
"""
from __future__ import annotations
import argparse
import hashlib
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import sys
from datetime import datetime, timezone, timedelta
from urllib.parse import urlsplit, quote
from urllib.request import Request, urlopen

REPORT_URL = 'https://www.informatics.jax.org/downloads/reports/MGI_GenePheno.rpt'
ALLOWED_HOSTS = {'www.informatics.jax.org', 'informatics.jax.org'}
INPUT_EXPECTED_SHA256 = 'dde04c96d0d43b4954cebdceadcb10b8bc8899bea2bdf52b2d353fb808bd275d'
MAX_REPORT_BYTES = 80000000
MAX_PAGE_BYTES = 3000000
MAX_INPUT_BYTES = 250000
MAX_GENOTYPES_PER_ALLELE = 8


def sha256(b):return hashlib.sha256(b).hexdigest()
def valid_id(s):return isinstance(s,str) and re.fullmatch(r'MGI:\d{4,10}',s) is not None
def symbol_norm(s):return re.sub('[^a-z0-9]','',str(s).casefold())


def read_fixture(path):
    p=Path(path)
    if p.is_symlink() or not p.is_file() or p.stat().st_size>MAX_INPUT_BYTES:
        raise RuntimeError('STOP_INPUT_NOT_REGULAR_OR_TOO_LARGE')
    b=p.read_bytes()
    if sha256(b)!=INPUT_EXPECTED_SHA256:
        raise RuntimeError('STOP_FIX1_JSON_SHA_MISMATCH')
    j=json.loads(b)
    if j.get('record_type')!='8510_mgi_official_phenotypic_allele_report_fix1_no_llm':
        raise RuntimeError('STOP_INPUT_NOT_FIX1_RESULT')
    if j.get('real_llm_api_calls')!=0 or j.get('primary_test_access') is not False or j.get('formal_app_mutation') is not False:
        raise RuntimeError('STOP_NONPUBLIC_OR_NONDIAGNOSTIC_INPUT')
    report=j.get('public_allele_report_lookup') or {}
    records=report.get('records') or []
    if not isinstance(records,list) or not 1<=len(records)<=4:
        raise RuntimeError('STOP_FIX1_ALLELE_RECORD_COUNT')
    out=[]
    for x in records:
        aid=x.get('mgi_allele_id');mid=x.get('gene_marker_id');sym=x.get('allele_symbol_mgi');stock=x.get('stock_id')
        if x.get('match')!='REPORT_EXACT_SYMBOL_MARKER_AND_DETAIL_MATCH' or not valid_id(aid) or not valid_id(mid):
            raise RuntimeError('STOP_ALLELE_NOT_EXACTLY_VERIFIED')
        if symbol_norm(sym)!=symbol_norm(x.get('stock_allele_symbol')):
            raise RuntimeError('STOP_ALLELE_SYMBOL_DIFFERS_FROM_STOCK')
        if not re.fullmatch(r'RBRC-[A-Za-z0-9-]{4,30}',str(stock)):
            raise RuntimeError('STOP_STOCK_ID_UNSAFE')
        out.append({'stock_id':stock,'allele_id':aid,'marker_id':mid,'allele_symbol':sym})
    return b,out


def network_bytes(url,cap,timeout=55,accept='text/plain, text/tab-separated-values, */*'):
    s=urlsplit(url)
    if s.scheme!='https' or s.hostname not in ALLOWED_HOSTS or s.username or s.password:
        raise RuntimeError('STOP_UNTRUSTED_MGI_HOST')
    req=Request(url,headers={'User-Agent':'8510-MGI-Public-Diagnostic-FIX2/1.0 (no personal data)', 'Accept':accept})
    with urlopen(req,timeout=timeout) as resp:
        final=urlsplit(resp.geturl())
        if final.scheme!='https' or final.hostname not in ALLOWED_HOSTS:
            raise RuntimeError('STOP_UNTRUSTED_REDIRECT')
        declared=resp.headers.get('Content-Length')
        if declared and int(declared)>cap:raise RuntimeError('STOP_OVERSIZE_PUBLIC_REPORT')
        chunks=[];size=0
        while True:
            b=resp.read(131072)
            if not b:break
            size+=len(b)
            if size>cap:raise RuntimeError('STOP_OVERSIZE_PUBLIC_REPORT')
            chunks.append(b)
    return chunks


def token_field(s):
    """Pipe-separated IDs; do not substring-match one genotype/allele to another."""
    return {t.strip() for t in re.split(r'[|;,]',str(s)) if t.strip()}


def parse_report(chunks,selected):
    """Official MGI_GenePheno.rpt eight columns per MGI reports index.
    Composition | Allele symbols | Allele IDs | Background | MP ID |
    PubMed IDs | Marker IDs | MGI Genotype ID.
    """
    target={(x['allele_id'],x['marker_id']):x for x in selected}
    matched={k:{} for k in target};scanned=0;nbytes=0;h=hashlib.sha256();buffer=b'';well_formed=0
    def process(raw):
        nonlocal scanned,well_formed
        scanned+=1
        cols=raw.rstrip(b'\r').decode('utf-8','replace').split('\t')
        if len(cols)<8:return
        well_formed+=1
        allele_ids=token_field(cols[2]);marker_ids=token_field(cols[6]);geno_id=cols[7].strip()
        if not valid_id(geno_id):return
        for (aid,mid),q in target.items():
            if aid not in allele_ids or mid not in marker_ids:continue
            # Allele symbols may be pipe-separated; independent ID match still mandatory.
            if symbol_norm(q['allele_symbol']) not in {symbol_norm(t) for t in token_field(cols[1])}:
                continue
            slot=matched[(aid,mid)]
            rec=slot.setdefault(geno_id, {'mgi_genotype_id':geno_id,
                'allelic_composition':cols[0][:1000],
                'allele_symbols':cols[1][:1000], 'allele_ids':sorted(allele_ids),
                'genetic_background':cols[3][:1000], 'mp_ids':[], 'pubmed_ids':[],
                'marker_ids':sorted(marker_ids), 'genotype_match':'EXACT_ALLELE_ID_MARKER_AND_SYMBOL_IN_OFFICIAL_REPORT'})
            rec['mp_ids']=sorted(set(rec['mp_ids']) | {m for m in token_field(cols[4]) if re.fullmatch(r'MP:\d{7}',m)})[:150]
            rec['pubmed_ids']=sorted(set(rec['pubmed_ids']) | {p for p in token_field(cols[5]) if re.fullmatch(r'\d+',p)})[:150]
    for chunk in chunks:
        nbytes+=len(chunk)
        if nbytes>MAX_REPORT_BYTES:raise RuntimeError('STOP_PUBLIC_REPORT_TOO_LARGE')
        h.update(chunk);buffer+=chunk
        while b'\n' in buffer:
            line,buffer=buffer.split(b'\n',1)
            if len(line)>400000:raise RuntimeError('STOP_REPORT_LINE_TOO_LONG')
            process(line)
        if len(buffer)>400000:raise RuntimeError('STOP_REPORT_LINE_TOO_LONG')
    if buffer:process(buffer)
    return {'bytes':nbytes,'sha256':h.hexdigest(),'lines':scanned,'tabular_lines':well_formed,'matches':matched}


class Page(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.text=[];self.hidden=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style','noscript'):self.hidden+=1
        if tag in ('tr','td','p','li','div','br','sup','h1','h2') and not self.hidden:self.text.append(' ')
    def handle_data(self,data):
        if not self.hidden:self.text.append(html.unescape(data))
    def handle_endtag(self,tag):
        if tag in ('script','style','noscript') and self.hidden:self.hidden-=1
        if tag in ('tr','td','p','li','div','br','sup','h1','h2') and not self.hidden:self.text.append(' ')
    def plain(self):return ' '.join(''.join(self.text).split())


def detail_validation(raw,geno_id,symbol):
    p=Page();p.feed(raw.decode('utf-8','replace'));text=p.plain()
    if geno_id not in text:return None,'GENOTYPE_ID_NOT_IN_PUBLIC_PAGE'
    # MGI displays Gck^{Rgsc960}; no requirement to hardcode the gene/allele names.
    m=re.fullmatch(r'([A-Za-z][A-Za-z0-9_.-]{0,30})<([A-Za-z0-9_.()/-]{1,70})>',symbol)
    if not m:return None,'UNRECOGNIZED_ALLELE_FORMAT'
    gene,tag=m.groups()
    match=re.search(r'\b'+re.escape(gene)+r'\s*(?:\^|<|\{|\s)*\s*'+re.escape(tag)+r'(?![A-Za-z0-9_.-])',text,re.I)
    if not match:return None,'EXACT_ALLELE_NOT_IN_GENOTYPE_PAGE'
    pos=text.lower().find('phenotypes associated with this genotype')
    if pos<0:pos=text.lower().find('genotype')
    if pos<0:pos=0
    return text[pos:pos+5000],None


def lookup(input_bytes,selected,fetch=network_bytes,report_chunks=None):
    chunks=report_chunks if report_chunks is not None else fetch(REPORT_URL,MAX_REPORT_BYTES)
    stats=parse_report(chunks,selected)
    result={'source':'MGI_GenePheno.rpt','report_source_url':REPORT_URL,
      'report_sha256':stats['sha256'],'report_bytes':stats['bytes'],
      'lines_scanned':stats['lines'],'tabular_lines':stats['tabular_lines'],
      'records':[],'unavailable':[],
      'boundary':'These are historical annotations to a specified genotype/background; not a new measurement of the current RBRC stock.'}
    if stats['bytes']<100000:
        result['unavailable'].append({'stage':'MGI_GENOTYPE_REPORT','reason':'REPORT_UNEXPECTEDLY_SMALL'})
        return result
    for q in selected:
        key=(q['allele_id'],q['marker_id']);geno_by_id=stats['matches'][key]
        if not geno_by_id:
            result['unavailable'].append({'stage':'MGI_GENOTYPE_DISCOVERY','stock_id':q['stock_id'],
               'mgi_allele_id':q['allele_id'],'reason':'NO_EXACT_GENOTYPE_ROW_IN_OFFICIAL_REPORT'})
            continue
        for gid,rec in sorted(geno_by_id.items())[:MAX_GENOTYPES_PER_ALLELE]:
            item={**q,**rec,'source_url':'https://www.informatics.jax.org/allele/genoview/'+quote(gid,safe=':'),
                  'report_url':REPORT_URL,'html_genotype_detail_verification':'NOT_VERIFIED'}
            try:
                b=b''.join(fetch(item['source_url'],MAX_PAGE_BYTES,accept='text/html, */*'))
                excerpt,reason=detail_validation(b,gid,q['allele_symbol'])
                if reason:
                    item['html_genotype_detail_verification']='UNVERIFIED_'+reason
                    result['unavailable'].append({'stage':'MGI_GENOTYPE_DETAIL','mgi_genotype_id':gid,
                         'reason':reason,'source_url':item['source_url']})
                else:
                    item['html_genotype_detail_verification']='MATCHED_ID_AND_EXACT_ALLELE'
                    item['genotype_phenotype_source_excerpt']=excerpt
            except (RuntimeError,TimeoutError,ValueError,OSError,UnicodeError) as e:
                item['html_genotype_detail_verification']='FETCH_FAILED_'+type(e).__name__
                result['unavailable'].append({'stage':'MGI_GENOTYPE_DETAIL','mgi_genotype_id':gid,'reason':type(e).__name__,
                      'source_url':item['source_url']})
            result['records'].append(item)
        if len(geno_by_id)>MAX_GENOTYPES_PER_ALLELE:
            result['unavailable'].append({'stage':'MGI_GENOTYPE_DISCOVERY',
                'reason':'MATCHED_MORE_GENOTYPES_THAN_SAFETY_CAP','count':len(geno_by_id)})
    return result


def main():
    p=argparse.ArgumentParser();m=p.add_mutually_exclusive_group(required=True);m.add_argument('--check',action='store_true');m.add_argument('--lookup',action='store_true')
    p.add_argument('--input',required=True);a=p.parse_args()
    raw,selected=read_fixture(a.input)
    print('INPUT_SHA256='+sha256(raw))
    for x in selected:print('EXACT_ALLELE='+x['stock_id']+'|'+x['allele_symbol']+'|'+x['allele_id']+'|'+x['marker_id'])
    if a.check:
        print('CHECK=PASS; HTTP_REQUESTS=0; LLM_CALLS=0; WRITES=0');return
    doc={'record_type':'8510_mgi_official_genotype_report_fix2_no_llm',
         'created_at_jst':datetime.now(timezone(timedelta(hours=9))).isoformat(timespec='seconds'),
         'fix1_input_sha256':sha256(raw),'genotype_lookup_status':'UNVERIFIED',
         'public_genotype_report_lookup':{},'real_llm_api_calls':0,'primary_test_access':False,
         'scientific_validation':False,'formal_app_mutation':False}
    try:
        doc['public_genotype_report_lookup']=lookup(raw,selected)
        rec=doc['public_genotype_report_lookup']['records']
        doc['genotype_lookup_status']='MATCHED_PUBLIC_GENOTYPE' if any(x['html_genotype_detail_verification']=='MATCHED_ID_AND_EXACT_ALLELE' for x in rec) else ('REPORT_ALLELE_MATCH_BUT_HTML_UNVERIFIED' if rec else 'NO_EXACT_GENOTYPE_FOUND')
    except (OSError,ValueError,TimeoutError,RuntimeError,UnicodeError) as e:
        doc['genotype_lookup_status']='ERROR_'+type(e).__name__
        doc['public_genotype_report_lookup']={'unavailable':[{'reason':str(e)[:300],'type':type(e).__name__}]}
    stamp=datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d_%H%M%S_%f')
    target=Path(a.input).resolve().parent/('MGI_GENOTYPE_REPORT_FIX2_'+stamp+'_'+sha256(raw)[:12]+'.json')
    payload=(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode()
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(payload)
    print('OUTPUT='+str(target))
    print('OUTPUT_SHA256='+sha256(payload))
    print('GENOTYPE_STATUS='+doc['genotype_lookup_status'])
    print('LLM_CALLS=0; FORMAL_APP_MUTATION=NO')

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('STOP_'+type(e).__name__+':'+str(e),file=sys.stderr);sys.exit(1)
