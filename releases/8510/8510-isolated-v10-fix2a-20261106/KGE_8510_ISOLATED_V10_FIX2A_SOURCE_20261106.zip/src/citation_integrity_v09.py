"""Read-only citation-source binding check for provisional LLM outputs.

Checks only that citations are syntactically coherent and are tied to an
uploaded input digest or URL of a public record fetched in this request.
It does NOT validate the biological claim, TSV row, nested JSON locator,
or causal interpretation. No network, LLM, or persisted mutable state.
"""
from __future__ import annotations
import re
from urllib.parse import urlsplit

OPENING=re.compile(r'\[(?:8504|PUBLIC):',re.IGNORECASE)
CITATION=re.compile(r'\[(8504|PUBLIC):([^\]\n]*)\]',re.IGNORECASE)
SHA_LOCATOR=re.compile(r'([0-9a-f]{64})/(\S(?:[^\n]*\S)?)\Z',re.IGNORECASE)


def audit_citations(answer, input_records, public_context):
    text=answer if isinstance(answer,str) else ''
    records=input_records if isinstance(input_records,list) else []
    context=public_context if isinstance(public_context,dict) else {}
    digests={str(r.get('sha256','')).lower() for r in records if isinstance(r,dict)}
    urls=set()
    for ref in context.get('verified') or []:
        if not isinstance(ref,dict):continue
        for k in ('source_url',):
            u=ref.get(k)
            if isinstance(u,str):urls.add(u)
    hits=list(CITATION.finditer(text))
    opens=list(OPENING.finditer(text))
    errors=[]
    for op in opens:
        if not any(x.start()==op.start() for x in hits):
            errors.append({'kind':'UNTERMINATED_SOURCE_TAG','excerpt':text[op.start():op.start()+110]})
    validated_8504=0
    validated_public=0
    for match in hits:
        kind,token=match.group(1).upper(),match.group(2).strip()
        if kind=='8504':
            parsed=SHA_LOCATOR.fullmatch(token)
            if not parsed:
                errors.append({'kind':'MALFORMED_8504_SOURCE_TAG','excerpt':match.group(0)[:150]})
                continue
            sha,locator=parsed.group(1).lower(),parsed.group(2)
            if '?' in locator or '\ufffd' in locator or '\u2026' in locator:
                errors.append({'kind':'UNRESOLVED_8504_LOCATOR','excerpt':match.group(0)[:150]})
            elif sha not in digests:
                errors.append({'kind':'SOURCE_DIGEST_NOT_IN_UPLOADED_INPUT','excerpt':match.group(0)[:150]})
            else:
                validated_8504+=1
        elif kind=='PUBLIC':
            try:p=urlsplit(token)
            except ValueError:p=None
            if not p or p.scheme!='https' or not p.hostname or p.username or p.password:
                errors.append({'kind':'PUBLIC_URL_SYNTAX_UNVERIFIED','excerpt':match.group(0)[:150]})
            elif token not in urls:
                errors.append({'kind':'PUBLIC_URL_NOT_IN_CURRENT_VERIFIED_RECORDS','excerpt':match.group(0)[:150]})
            else:
                validated_public+=1
    if not hits and not opens:
        errors.append({'kind':'NO_CITED_SOURCE_TAGS'})
    binding_ok=bool(hits and not errors)
    return {
        'status':'SOURCE_BINDINGS_LEXICALLY_CONFIRMED_LOCATORS_UNVERIFIED' if binding_ok else 'REVIEW_REQUIRED_INVALID_SOURCE_REFERENCE',
        'source_binding_ok':binding_ok,
        'source_locator_validation':'NOT_ASSESSED',
        'scientific_claim_validation':False,
        'cited_tag_count':len(hits),
        'matched_uploaded_input_tag_count':validated_8504,
        'matched_public_fetched_url_tag_count':validated_public,
        'error_count':len(errors),
        'errors':errors[:24],
        'note':'No biological claim or exact row/pointer has been independently validated.'
    }
