#!/usr/bin/env python3
"""Generic no-network/no-write source-role audit for received 8504 input JSON.

This is source-role QA, NOT a scientific assessment or formal rank review.
"""
import argparse,hashlib,json,pathlib,sys
from public_biology_lookup_v09 import _ranked_ids

def main():
    p=argparse.ArgumentParser()
    p.add_argument('input_path')
    p.add_argument('--expected-sha256',default=None)
    a=p.parse_args()
    src=pathlib.Path(a.input_path)
    if not src.is_file() or src.is_symlink():raise ValueError('STOP_INPUT_MISSING_OR_SYMLINK')
    b=src.read_bytes()
    digest=hashlib.sha256(b).hexdigest()
    if a.expected_sha256 and digest.lower()!=a.expected_sha256.lower():raise ValueError('STOP_INPUT_SHA_MISMATCH')
    ids=_ranked_ids([(src.name,b)])
    show=['source_role_status','structured_mouse_iri_count','stocks','genes','mp','go',
          'disease_context_genes','disease_context_hp',
          'disease_hp_mp_mapping_count','candidate_mouse_mp_count_in_selected_input','source_edge_origins']
    print('INPUT_SHA256='+digest)
    print('INPUT_SIZE_BYTES='+str(len(b)))
    print('SOURCE_ROLES='+json.dumps({k:ids.get(k) for k in show},ensure_ascii=False,sort_keys=True))
    print('EXTERNAL_HTTP_CALLS=0')
    print('LLM_API_CALLS=0')
    print('OUTPUT_WRITES=0')
    print('SCIENTIFIC_VALIDATION=NOT_ASSESSED')
if __name__=='__main__':
    try:main()
    except Exception as ex:
        print('VERIFY_STOP: '+str(ex)[:180],file=sys.stderr)
        sys.exit(2)
