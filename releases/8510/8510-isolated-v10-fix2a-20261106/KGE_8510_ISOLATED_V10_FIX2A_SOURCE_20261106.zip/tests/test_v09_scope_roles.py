"""V09 incremental new science-protection regression tests (offline; no provider/HTTP)."""
import sys, pathlib, json,unittest,urllib.parse
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from public_biology_lookup_v09 import _ranked_ids,lookup_public_biology
from source_role_v09 import extract_role_scoped_ids
from public_stock_identity_v09 import discover_stock_candidates

MOUSE='http://metadb.riken.jp/db/rikenbrc_mouse/RBRC10811'
DISEASE='http://purl.obolibrary.org/obo/MONDO_0004976'

def bundle(intrinsic=None,links=None,disease_ctx=None,go=None,mouse=MOUSE):
    return {'evidence_bundle': {'identity':{'mouse_iri':mouse,'disease_iri':DISEASE},
        'source_edges':{'candidate_intrinsic':intrinsic or [],'candidate_linking':links or [],'disease_context':disease_ctx or []},
        'go_context':go or {}}}

def pairs(data,filename='EVIDENCE_LLM_INPUT__MONDO_0004976__node2vec__rank2__RBRC10811.json'):
    return [(filename,json.dumps(data).encode())]

def edge(a,b,row=10):
    return {'subject_iri':a,'object_iri':b,'source_id':'FROZEN_TRAIN','source_row_number':row}

class ScopeProtection(unittest.TestCase):
    def test_candidate_gene_only(self):
        d=bundle([edge(MOUSE,'http://identifiers.org/ncbigene/66745',176799)],
            [edge('http://purl.obolibrary.org/obo/HP_0000708','http://purl.obolibrary.org/obo/MP_0004924',201029)],
            [edge('http://identifiers.org/ncbigene/20257',DISEASE,8524)])
        x=_ranked_ids(pairs(d));self.assertEqual(x['genes'],['66745']);self.assertEqual(x['mp'],[])
        self.assertEqual(x['disease_context_genes'],['20257']);self.assertEqual(x['disease_hp_mp_mapping_count'],1)
        self.assertEqual(x['source_role_status'],'STRUCTURED_MOUSE_ROLE_SEPARATED')

    def test_no_mp_query_for_disease_side_map(self):
        d=bundle([edge(MOUSE,'http://identifiers.org/ncbigene/66745')],
            [edge('http://purl.obolibrary.org/obo/HP_0000708','http://purl.obolibrary.org/obo/MP_0004924')])
        calls=[]
        def fake(url):
            calls.append(url)
            if 'esummary.fcgi' in url:return json.dumps({'result':{'66745':{'name':'Trpd52l3','organism':{}}}}).encode()
            if 'knowledge.brc.riken.jp' in url:
                return b'<html><body>Strain Data Sheet Strain Information BRC No. RBRC10811 Type Knockout</body></html>'
            raise AssertionError('Unexpected role-contaminated public lookup: '+url)
        ctx=lookup_public_biology(pairs(d),fetch=fake)
        self.assertEqual([r.get('id') for r in ctx['verified']],['NCBIGene:66745','RBRC10811'])
        self.assertEqual(ctx['candidate_identifiers']['mp'],[])
        self.assertEqual(len(calls),2)

    def test_disease_genes_and_mp_never_candidate_search(self):
        d=bundle([], [edge('http://purl.obolibrary.org/obo/HP_0001257','http://purl.obolibrary.org/obo/MP_0004143')],
            [edge('http://identifiers.org/ncbigene/20257',DISEASE),edge('http://identifiers.org/ncbigene/20402',DISEASE),edge('http://identifiers.org/ncbigene/23996',DISEASE)])
        x=_ranked_ids(pairs(d));self.assertEqual(x['genes'],[]);self.assertEqual(x['mp'],[])
        self.assertEqual(x['disease_context_genes'],['20257','20402','23996'])

    def test_candidate_direct_mp_is_lookup_eligible(self):
        d=bundle([edge(MOUSE,'http://purl.obolibrary.org/obo/MP_0004924')])
        self.assertEqual(_ranked_ids(pairs(d))['mp'],['MP:0004924'])

    def test_reversed_mouse_role_is_valid(self):
        d=bundle([edge('http://identifiers.org/ncbigene/66745',MOUSE)])
        self.assertEqual(_ranked_ids(pairs(d))['genes'],['66745'])

    def test_other_mouse_edge_must_not_promote(self):
        d=bundle([edge('http://metadb.riken.jp/db/rikenbrc_mouse/DIFFERENT','http://identifiers.org/ncbigene/999')])
        self.assertEqual(_ranked_ids(pairs(d))['genes'],[])

    def test_source_id_without_mouse_edge_not_proof(self):
        d=bundle([edge('http://identifiers.org/ncbigene/999','http://purl.obolibrary.org/obo/MP_0004924')])
        x=_ranked_ids(pairs(d));self.assertEqual(x['genes'],[]);self.assertEqual(x['mp'],[])

    def test_unstructured_file_remains_accepted_but_cannot_assign_role(self):
        raw=b'A hypothesis about ncbigene/20402 and MP_0004924 in disease context.'
        x=_ranked_ids([('anything.bin',raw)])
        self.assertEqual(x['genes'],[]);self.assertEqual(x['mp'],[])
        self.assertEqual(x['source_role_status'],'NO_TRUSTED_STRUCTURED_MOUSE_ROLE; NO_CANDIDATE_GENE_MP_GO_PROMOTION')

    def test_generic_json_keys_are_not_candidate_evidence(self):
        x=_ranked_ids(pairs({'gene':'ncbigene/20257','phenotype':'MP_0004924','id':'RBRC10811'}))
        self.assertEqual(x['genes'],[]);self.assertEqual(x['mp'],[])

    def test_candidate_go_explicit_and_disease_go_no(self):
        go={'candidate_mouse_go':[{'go_iri':'http://purl.obolibrary.org/obo/GO_0001234'}],
            'disease_gene_linked_go':[{'go_iri':'http://purl.obolibrary.org/obo/GO_0004321'}]}
        x=_ranked_ids(pairs(bundle(go=go)))
        self.assertEqual(x['go'],['GO:0001234'])

    def test_shared_go_requires_candidate_ref(self):
        good={'go_iri':'http://purl.obolibrary.org/obo/GO_0001234','candidate_mouse_references':'PMID:123','disease_context_references':'PMID:123'}
        bad={'go_iri':'http://purl.obolibrary.org/obo/GO_0004321','candidate_mouse_references':'','disease_context_references':'PMID:12'}
        x=_ranked_ids(pairs(bundle(go={'shared_candidate_disease_gene_go':[good,bad]})))
        self.assertEqual(x['go'],['GO:0001234']);self.assertEqual(x['go_evidence_independence']['same_reference_id_count'],1)

    def test_external_opaque_stock_number_retained(self):
        unusual='EXT#mouse.???/with punctuation'
        d=bundle();d['evidence_bundle']['identity']['mouse_iri']='https://metadb.riken.jp/db/rikenbrc_mouse/'+urllib.parse.quote(unusual,safe='')
        z=discover_stock_candidates(pairs(d),stock_hint=unusual)
        self.assertEqual(z[0]['candidate'],unusual)

    def test_per_source_receipt_includes_mouse_and_train_row(self):
        x=_ranked_ids(pairs(bundle([edge(MOUSE,'http://identifiers.org/ncbigene/66745',176799)])))
        self.assertEqual(x['source_edge_origins']['genes']['66745'][0]['source_row_number'],176799)
        self.assertEqual(x['source_edge_origins']['genes']['66745'][0]['mouse_iri'],MOUSE)

    def test_source_ranking_not_changed_by_lookup(self):
        d=bundle([edge(MOUSE,'http://identifiers.org/ncbigene/66745')]);d['evidence_bundle']['ranking']={'family':'node2vec','final_rank':2}
        before=json.dumps(d,sort_keys=True)
        _ranked_ids(pairs(d));self.assertEqual(before,json.dumps(d,sort_keys=True))

    def test_multiple_mouse_bundle_blocks_flattened_gene_mp_query(self):
        d1=bundle([edge(MOUSE,'http://identifiers.org/ncbigene/66745')])
        d2=bundle([edge('http://metadb.riken.jp/db/rikenbrc_mouse/RBRC00222',
                          'http://identifiers.org/ncbigene/20402')],
                  mouse='http://metadb.riken.jp/db/rikenbrc_mouse/RBRC00222')
        x=_ranked_ids(pairs(d1,'a.json')+pairs(d2,'b.json'))
        self.assertEqual(x['genes'],[])
        self.assertEqual(x['multi_mouse_unqueried_role_targets']['genes'],['66745','20402'])
        self.assertEqual(x['source_role_status'],'MULTI_MOUSE_BUNDLE_PUBLIC_GENE_MP_GO_LOOKUP_HOLD')
        self.assertEqual(x['structured_mouse_iri_count'],2)

    def test_mgi_and_ncbi_annotation_keeps_source_mouse_row(self):
        d=bundle([edge(MOUSE,'http://identifiers.org/ncbigene/66745',176799)])
        def mock(url):
            if 'esummary.fcgi' in url:
                return json.dumps({'result':{'66745':{'name':'Trpd52l3','organism':{}}}}).encode()
            return b'<html><body>Strain Data Sheet Strain Information BRC No. RBRC10811 Type Gene-trap</body></html>'
        ctx=lookup_public_biology(pairs(d),fetch=mock)
        gene=[r for r in ctx['verified'] if r.get('type')=='gene'][0]
        self.assertEqual(gene['origin_source_edges'][0]['mouse_iri'],MOUSE)
        self.assertEqual(gene['origin_source_edges'][0]['source_row_number'],176799)

    def test_original_8504_raw_bytes_replayed_to_llm_without_mutation(self):
        from manual_8504_intake_v09 import receive_files
        d=bundle([edge(MOUSE,'http://identifiers.org/ncbigene/66745')]);b=json.dumps(d).encode()
        rows,text,images,blocked,coverage=receive_files([('x.anyext',b)])
        self.assertEqual(rows[0]['bytes'],len(b));self.assertIn(b.decode(),text)
        self.assertEqual(coverage,'FULL_TEXT_FOR_TEXT_FILES');self.assertEqual(blocked,[])

if __name__=='__main__':unittest.main()
