import copy,hashlib,json,pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from citation_integrity_v10 import audit_citations
from public_mgi_marker_phenotype_v10 import append_marker_phenotype
from public_mondo_label_v10 import append_mondo_labels
V09_OUTPUT=pathlib.Path('/mnt/data/8510_8504_interpretation_20261106_122744_000b7d79.json')
ALS=pathlib.Path('/mnt/data/EVIDENCE_LLM_INPUT__MONDO_0004976__node2vec__rank2__RBRC10811.json')

class V10Test(unittest.TestCase):
 def setUp(self):
  self.out=json.loads(V09_OUTPUT.read_bytes());self.src=ALS.read_bytes();self.records=self.out['input_files'];self.ctx=self.out['public_annotations'];self.pairs=[(ALS.name,self.src)]
 def audit(self,txt):return audit_citations(txt,self.records,self.ctx,self.pairs)
 def test_previous_1227_no_false_citation_failures(self):
  q=self.audit(self.out['interpretation_text']);self.assertTrue(q['source_binding_ok'],q);self.assertEqual(q['error_count'],0);self.assertEqual(q['matched_frozen_train_source_edge_tag_count'],3);self.assertEqual(q['matched_public_fetched_url_tag_count'],5);self.assertEqual(q['cited_tag_count'],8);self.assertEqual(q['original_train_row_byte_validation'],'NOT_ASSESSED');self.assertFalse(q['scientific_claim_validation'])
 def test_wrong_train_sha_rejected(self):
  sha='9b9e5fab42f1754b2462a5a6dd77c44ee31ff3b21b2c8eda4d7b45f36242e806';bad=self.audit('[8504:'+('0'*64)+'/FROZEN_TRAIN行176799]');self.assertFalse(bad['source_binding_ok'])
 def test_nonexistent_row_rejected(self):
  sha=json.loads(self.src)['evidence_bundle']['provenance']['frozen_train']['sha256'];bad=self.audit('[8504:'+sha+'/FROZEN_TRAIN行999999]');self.assertEqual(bad['errors'][0]['kind'],'FROZEN_TRAIN_ROW_NOT_IN_INPUT_SOURCE_EDGES')
 def test_wrong_range_rejected(self):
  sha=json.loads(self.src)['evidence_bundle']['provenance']['frozen_train']['sha256'];bad=self.audit('[8504:'+sha+'/FROZEN_TRAIN行204894–204999]');self.assertFalse(bad['source_binding_ok'])
 def test_reversed_range_rejected(self):
  sha=json.loads(self.src)['evidence_bundle']['provenance']['frozen_train']['sha256'];bad=self.audit('[8504:'+sha+'/FROZEN_TRAIN行204999–204894]');self.assertFalse(bad['source_binding_ok'])
 def test_malformed_ellipsis_rejected(self):
  sha=json.loads(self.src)['evidence_bundle']['provenance']['frozen_train']['sha256'];bad=self.audit('[8504:'+sha+'/FROZEN_TRAIN行17…]');self.assertFalse(bad['source_binding_ok'])
 def test_unterminated_tag_rejected(self):
  self.assertFalse(self.audit('[8504:'+('0'*64))['source_binding_ok'])
 def test_unknown_public_url_rejected(self):
  self.assertFalse(self.audit('[PUBLIC:https://evil.invalid/example]')['source_binding_ok'])
 def test_known_public_url_passes(self):
  u=self.ctx['verified'][0]['source_url'];self.assertTrue(self.audit('[PUBLIC:'+u+']')['source_binding_ok'])
 def test_input_digest_path_labeled_but_locator_not_assessed(self):
  s=self.records[0]['sha256'];q=self.audit('[8504:'+s+'/evidence_bundle.go_context]');self.assertTrue(q['source_binding_ok']);self.assertEqual(q['source_locator_validation'],'NOT_ASSESSED')
 def test_no_source_tag_fails(self):
  self.assertFalse(self.audit('source unknown')['source_binding_ok'])
 def test_no_pairs_fails_train_even_matching_digest(self):
  t=self.out['interpretation_text'];q=audit_citations(t,self.records,self.ctx,[]);self.assertFalse(q['source_binding_ok'])
 def test_official_marker_phenotype_row_matched_with_four_columns(self):
  row=b'''<html><body>Trpd52l3 MGI:1913995<table><tr><th>Allelic Composition</th><th>Genetic Background</th><th>Annotated Term</th><th>Reference</th></tr><tr><td>Trpd52l3<sup>em1Osb</sup>/Trpd52l3<sup>em1Osb</sup></td><td>C57BL/6NJcl * DBA/2NJcl</td><td>normal reproductive system phenotype</td><td>J:279039</td></tr></table></body></html>'''
  ctx={'verified':[{'type':'MGI_allele','verification':'OFFICIAL_REPORT_EXACT_ALLELE_MARKER_AND_HTML_ID_SYMBOL','gene_marker_id':'MGI:1913995','allele_symbol':'Trpd52l3<em1Osb>','stock_id':'RBRC10811','id':'MGI:6361179'}]}
  out=append_marker_phenotype(ctx,fetch=lambda u:row)
  self.assertEqual(out['mgi_marker_phenotype_status'],'MATCHED_OFFICIAL_MARKER_ROW_NO_GENOTYPE_ID')
  self.assertEqual(out['verified'][-1]['reference_id'],'J:279039')
  self.assertEqual(out['verified'][-1]['genotype_mgi_id'],'NOT_VERIFIED')
  self.assertTrue(out['verified'][-1]['not_distributed_stock_measurement'])
 def test_official_three_cell_row_with_involves_background(self):
  row=b'''<html>MGI:1913995<table><tr><td>Trpd52l3<sup>em1Osb</sup>/Trpd52l3<sup>em1Osb</sup> involves: C57BL/6NJcl * DBA/2NJcl</td><td>normal reproductive system phenotype</td><td>J:279039</td></tr></table></html>'''
  ctx={'verified':[{'type':'MGI_allele','verification':'OFFICIAL_REPORT_EXACT_ALLELE_MARKER_AND_HTML_ID_SYMBOL','gene_marker_id':'MGI:1913995','allele_symbol':'Trpd52l3<em1Osb>','stock_id':'RBRC10811','id':'MGI:6361179'}]}
  out=append_marker_phenotype(ctx,fetch=lambda u:row)
  self.assertEqual(out['mgi_marker_phenotype_status'],'MATCHED_OFFICIAL_MARKER_ROW_NO_GENOTYPE_ID')
 def test_other_allele_in_second_genotype_rejected(self):
  row=b'''<html>MGI:1913995<table><tr><td>Trpd52l3<sup>em1Osb</sup>/Trpd52l3<sup>em2Osb</sup></td><td>C57</td><td>normal reproductive system phenotype</td><td>J:279039</td></tr></table></html>'''
  ctx={'verified':[{'type':'MGI_allele','verification':'OFFICIAL_REPORT_EXACT_ALLELE_MARKER_AND_HTML_ID_SYMBOL','gene_marker_id':'MGI:1913995','allele_symbol':'Trpd52l3<em1Osb>','stock_id':'RBRC10811','id':'MGI:6361179'}]}
  out=append_marker_phenotype(ctx,fetch=lambda u:row)
  self.assertEqual(out['mgi_marker_phenotype_status'],'NOT_VERIFIED')
 def test_marker_id_mismatch_rejected(self):
  row=b'''<html>MGI:9999999<table><tr><td>Trpd52l3em1Osb/Trpd52l3em1Osb</td><td>C57</td><td>normal reproductive system phenotype</td><td>J:279039</td></tr></table></html>'''
  ctx={'verified':[{'type':'MGI_allele','verification':'OFFICIAL_REPORT_EXACT_ALLELE_MARKER_AND_HTML_ID_SYMBOL','gene_marker_id':'MGI:1913995','allele_symbol':'Trpd52l3<em1Osb>','stock_id':'RBRC10811','id':'MGI:6361179'}]}
  out=append_marker_phenotype(ctx,fetch=lambda u:row)
  self.assertEqual(out['mgi_marker_phenotype_status'],'NOT_VERIFIED')
 def test_marker_no_reference_rejected(self):
  row=b'''<html>MGI:1913995<table><tr><td>Trpd52l3em1Osb/Trpd52l3em1Osb</td><td>C57</td><td>normal reproductive system phenotype</td><td>no reference</td></tr></table></html>'''
  ctx={'verified':[{'type':'MGI_allele','verification':'OFFICIAL_REPORT_EXACT_ALLELE_MARKER_AND_HTML_ID_SYMBOL','gene_marker_id':'MGI:1913995','allele_symbol':'Trpd52l3<em1Osb>','stock_id':'RBRC10811','id':'MGI:6361179'}]}
  self.assertEqual(append_marker_phenotype(ctx,fetch=lambda u:row)['mgi_marker_phenotype_status'],'NOT_VERIFIED')
 def test_mondo_source_exact_match_only(self):
  ctx={'candidate_identifiers':{'diseases':['MONDO:0004976']},'verified':[]}
  response={'response':{'docs':[{'obo_id':'MONDO:0004976','ontology_name':'mondo','label':'amyotrophic lateral sclerosis','iri':'http://purl.obolibrary.org/obo/MONDO_0004976'}]}}
  got=append_mondo_labels(ctx,fetch=lambda u:json.dumps(response).encode())
  self.assertEqual(got['verified'][0]['name'],'amyotrophic lateral sclerosis')
 def test_mondo_wrong_id_not_promoted(self):
  ctx={'candidate_identifiers':{'diseases':['MONDO:0004976']},'verified':[]}
  response={'response':{'docs':[{'obo_id':'MONDO:0005148','ontology_name':'mondo','label':'type 2 diabetes mellitus'}]}}
  self.assertFalse(append_mondo_labels(ctx,fetch=lambda u:json.dumps(response).encode())['verified'])
 def test_no_live_calls_in_audit(self):
  self.assertEqual(self.audit(self.out['interpretation_text'])['error_count'],0)

if __name__=='__main__':unittest.main(verbosity=1)
